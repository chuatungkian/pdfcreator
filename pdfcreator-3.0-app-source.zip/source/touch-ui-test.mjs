import assert from 'node:assert/strict';
import {directFormatting} from './direct-formatting-inline.js';
import {boot} from './experience-test-env.mjs';
import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
let options={};if(process.env.PDFCREATOR_TEST_HTML){const html=fs.readFileSync(process.env.PDFCREATOR_TEST_HTML,'utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64')));fs.writeFileSync('/tmp/pdfcreator-touch-compiled.mjs',assets.app);options={moduleURL:pathToFileURL('/tmp/pdfcreator-touch-compiled.mjs').href,assets}}
const context=await boot(options);const {app,window}=context;let count=0;
const check=(ok,label)=>{assert.ok(ok,label);count++},tick=()=>new Promise(r=>setTimeout(r,30));
try{
const pdf=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)pdf.addPage([600,800]).drawRectangle({x:50,y:400,width:180,height:60,color:app.PDFLib.rgb(.7,.2,.4)});const bytes=new Uint8Array(await pdf.save());await app.openFiles([{name:'touch.pdf',type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer}]);app.state.fit=false;app.state.zoom=1;await app.render();
function geometry(){document.querySelector('.pdf-page-view').getBoundingClientRect=()=>({left:100,top:200,right:700,bottom:1000,width:600,height:800})}geometry();
const overlay=()=>document.getElementById('overlay');
function event(type,pointerType,x,y){const e=new window.MouseEvent(type,{bubbles:true,cancelable:true,button:0,clientX:x+100,clientY:y+200,detail:1});Object.defineProperties(e,{pointerType:{value:pointerType},pointerId:{value:1},isPrimary:{value:true}});overlay().dispatchEvent(e);return e}
async function tap(pointerType){event('pointerdown',pointerType,80,370);event('pointermove',pointerType,88,370);event('pointerup',pointerType,88,370);await tick();event('click',pointerType,88,370);await tick()}
await tap('touch');check(app.state.tool==='objects','finger jitter selects shape');check(!!document.querySelector('.object-selection'),'finger selection opens');check(overlay().style.touchAction==='manipulation','objects permit navigation');
await app.activate('select');geometry();await tap('mouse');check(app.state.tool==='select','mouse movement tolerance unchanged');
await app.activate('objects');geometry();const d=event('pointerdown','touch',350,300);event('pointermove','touch',350,250);check(!d.defaultPrevented,'finger press available to browser');check(!document.querySelector('.object-marquee'),'finger swipe does not create marquee');event('pointercancel','touch',350,250);
await app.activate('ink');check(overlay().style.touchAction==='none','drawing mode owns gestures');const before=app.state.bytes;event('pointerdown','touch',300,250);event('pointermove','touch',320,260);event('pointercancel','touch',320,260);check(!document.getElementById('inkPreview'),'cancel removes ink preview');check(app.state.bytes===before,'cancel leaves PDF unchanged');
for(const mode of ['images','editfields']){await app.activate(mode);check(overlay().style.touchAction==='manipulation',mode+' permits navigation')}
const input=document.createElement('textarea');input.value='Alpha Beta';input.renderRuns=()=>{};document.body.append(input);const formatting=directFormatting({document,input,target:{text:input.value,size:12,font:'original',fontName:'Arial',color:'#000000'}});document.body.append(formatting.root);input.setSelectionRange(6,10);const bold=formatting.root.querySelector('[data-direct-format=bold]'),press=new window.MouseEvent('pointerdown',{bubbles:true,cancelable:true,button:0});Object.defineProperty(press,'pointerType',{value:'touch'});bold.dispatchEvent(press);check(press.defaultPrevented,'format button preserves focus on touch');bold.click();const ranges=formatting.options().formatting;check(ranges.length===1&&ranges[0].start===6&&ranges[0].end===10&&ranges[0].style.bold,'touch formats selected word only');formatting.destroy();formatting.root.remove();input.remove();
console.log('Touch UI: '+count+' assertions passed.');
}finally{await context.close()}
