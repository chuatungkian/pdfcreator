/* Move original controls between their primary row and More; never clone editor controls. */
import {PHONE_LAYOUT} from './phone-workspace.js';

export class AdaptiveToolbar{
 constructor({root,fields,rail,overflow,toggle}){Object.assign(this,{root,fields,rail,overflow,toggle});this.items=[];const document=root.ownerDocument;for(const node of fields.querySelectorAll('.context-control-group'))if(/^(Style|Paragraph|Image tools|Appearance|Navigate)$/.test(node.getAttribute('aria-label'))){const anchor=document.createComment('toolbar home');node.before(anchor);this.items.push({node,anchor})}this.extra=document.createElement('div');this.extra.className='adaptive-extra-actions';overflow.append(this.extra);for(const node of rail.querySelectorAll('button')){const name=node.dataset.contextAction||node.dataset.action||'';if(['duplicate','delete'].includes(name)||node.hasAttribute('data-field-delete')){const anchor=document.createComment('action home');node.before(anchor);this.items.push({node,anchor,action:true})}}this.registerPresets=()=>{let added=false;for(const node of fields.querySelectorAll('.style-presets:not([data-adaptive-preset])')){node.dataset.adaptivePreset='';const anchor=document.createComment('preset home');node.before(anchor);this.items.push({node,anchor});added=true}if(added)this.update()};this.presetsObserver=new root.ownerDocument.defaultView.MutationObserver(records=>{if(records.some(r=>[...r.addedNodes].some(n=>n.nodeType===1&&(n.matches('.style-presets')||n.querySelector('.style-presets')))))this.registerPresets()});this.presetsObserver.observe(root,{subtree:true,childList:true});this.registerPresets();this.refresh=()=>this.update();this.observer=root.ownerDocument.defaultView.ResizeObserver?new root.ownerDocument.defaultView.ResizeObserver(this.refresh):null;this.observer?.observe(root);root.ownerDocument.defaultView.addEventListener('resize',this.refresh);this.update()}
 update(){
  const window=this.root.ownerDocument.defaultView;
  const phone=window.matchMedia(PHONE_LAYOUT).matches;
  const width=this.root.getBoundingClientRect().width||this.root.parentElement?.getBoundingClientRect().width||window.innerWidth;
  const compact=width<820,tiny=width<600;
  this.root.dataset.adaptive=compact?'compact':'full';
  if(!this.phoneField&&this.root.matches('.form-field-editor')){
   const format=this.fields.querySelector('[aria-label="Text"]');
   if(format){
    const anchor=this.root.ownerDocument.createComment('field format home');
    format.before(anchor);
    this.phoneField={node:format,anchor,phoneOnly:true};
    this.items.push(this.phoneField);
   }
  }
  if(this.toggle?.matches('.toolbar-options-toggle')){
   if(!this.toggleHome){
    this.toggleHome=this.root.ownerDocument.createComment('more button home');
    this.toggle.before(this.toggleHome);
   }
   if(phone&&this.toggle.parentNode!==this.rail)this.rail.prepend(this.toggle);
   if(!phone&&this.toggle.parentNode===this.rail)this.toggleHome.after(this.toggle);
  }
  for(const item of this.items){
   if(!item.node.parentNode)continue;
   const move=item.phoneOnly?phone:item.action?tiny:compact;
   const parent=move?(item.action?this.extra:this.overflow):item.anchor.parentNode;
   if(item.node.parentNode===parent)continue;
   if(move)parent.append(item.node);else item.anchor.after(item.node);
  }
  this.extra.hidden=!tiny;
  this.toggle?.setAttribute('title',compact?'More formatting and layout options':'More layout options');
 }
 destroy(){this.presetsObserver.disconnect();this.observer?.disconnect();this.root.ownerDocument.defaultView.removeEventListener('resize',this.refresh);for(const {node,anchor}of this.items){if(anchor.parentNode&&node.parentNode)anchor.after(node);anchor.remove()}if(this.toggleHome){this.toggleHome.after(this.toggle);this.toggleHome.remove()}this.extra.remove()}
}
