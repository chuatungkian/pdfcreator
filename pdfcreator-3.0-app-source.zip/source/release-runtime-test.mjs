/* Boot the actual compiled release in a controlled DOM with real bundled engines. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import {boot} from './experience-test-env.mjs';
const out=path.resolve(process.env.PDFCREATOR_RELEASE_DIR||'../../outputs'),html=fs.readFileSync(path.join(out,'index.html'),'utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64'))),target=path.resolve('../../tmp/compiled-release.mjs');fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,assets.app);
let context,checks=0;const check=(v,label)=>{checks++;assert.ok(v,label)},equal=(a,b,label)=>{checks++;assert.deepEqual(a,b,label)};
const until=async test=>{const end=Date.now()+10000;while(!test()){if(Date.now()>end)throw Error('Compiled release operation timed out');await new Promise(r=>setTimeout(r,10))}};
try{
 context=await boot({moduleURL:pathToFileURL(target).href+'?runtime='+Date.now(),assets});const {app,$,window}=context;check(app.name==='PDFCreator'&&!$('boot'),'actual release boots');await app.createDemo();check(app.state.doc.countPages()>0,'bundled PDF engine creates/renders sample document');const bytes=app.state.bytes;
 await app.activate('text');check($('activeToolGuide').textContent.includes('Add text'),'compiled tool guide works');$('activeToolGuide').querySelector('[data-guide-favourite]').click();check(app.toolPreferences.favourites.includes('text'),'compiled favourite action works');await $('activeToolGuide').querySelector('[data-guide-done]').onclick();equal(app.state.bytes,bytes,'tool discovery leaves document bytes intact');
 const p=app.state.doc.loadPage(0),annotations=p.getAnnotations();annotations.forEach(a=>a.destroy());p.destroy();
 const native=await app.PDFLib.PDFDocument.create();native.addPage([595,842]).drawText('PACKAGED TEXT',{x:40,y:760,size:14});const input=new Uint8Array(await native.save({useObjectStreams:false}));await app.openFiles([{name:'Packaged.pdf',type:'application/pdf',arrayBuffer:async()=>input.buffer}]);app.state.fit=false;app.state.zoom=1;await app.render();
 window.Range.prototype.getClientRects=()=>[{left:40,top:68,right:170,bottom:84,width:130,height:16}];window.Range.prototype.getBoundingClientRect=function(){return this.getClientRects()[0]};const range=document.createRange();range.selectNodeContents($('overlay').querySelector('.textline'));const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);app.workspaceUX.showSelection();check(!!$('selectionActions'),'compiled text-selection toolbar appears');await $('selectionActions').querySelector('[data-selection-action="highlight"]').onclick();const page=app.state.doc.loadPage(0),notes=page.getAnnotations();equal(notes.filter(a=>a.getType()==='Highlight').length,1,'compiled action creates native highlight');notes.forEach(a=>a.destroy());page.destroy();await $('undo').onclick();equal(app.state.bytes,input,'compiled action undoes to exact bytes');
 const task=app.importWordDocument();await until(()=>$('wordEngine'));equal($('wordEngine').options[0].textContent,'In-browser docx and doc converter','requested converter label retained in actual release');check($('workspace').inert,'compiled modal blocks background interaction');$('modalcancel').click();await task;check(!$('workspace').inert,'compiled modal restores background');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator compiled release: '+checks+' assertions passed with actual bundled startup, PDF mutation/undo and Word import UI.');
}finally{if(context)await context.close()}
