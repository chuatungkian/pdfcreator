/* Offline phone layout and keyboard regression in Chromium with real PDFs. */
import assert from 'node:assert/strict';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {PDFDocument} from 'pdf-lib';

const require=createRequire(import.meta.url);
let playwright;
try{playwright=require('playwright')}catch{
 playwright=require(path.join(process.env.PDFPRO_NODE_MODULES||path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'),'playwright'));
}
const browser=await playwright.chromium.launch({
 executablePath:process.env.PDFPRO_BROWSER||'C:/Program Files/Google/Chrome/Application/chrome.exe',
 headless:true,
 args:['--no-first-run','--disable-background-networking']
});
const release=pathToFileURL(path.resolve(process.env.PDFCREATOR_RELEASE_DIR||'../../outputs','pdfpro.html')).href;
const source=await PDFDocument.create();
for(let i=1;i<=3;i++)source.addPage([595,842]).drawText('Source page '+i,{x:45,y:685,size:20});
source.getForm().createTextField('Comment').addToPage(source.getPage(0),{x:45,y:605,width:155,height:32});
source.getForm().getTextField('Comment').enableMultiline();
const dest=await PDFDocument.create();
dest.addPage([595,842]).drawText('Destination',{x:45,y:685,size:20});
const files=await Promise.all([['Source.pdf',source],['Destination.pdf',dest]].map(async ([name,doc])=>({
 name,mimeType:'application/pdf',buffer:Buffer.from(await doc.save())
})));
const open=async options=>{
 const context=await browser.newContext(options);
 await context.route(/^https?:\/\//,route=>route.abort());
 const page=await context.newPage();
 const errors=[];
 page.on('pageerror',error=>errors.push(error.stack||error.message));
 return {context,page,errors};
};
const tap=(page,selector)=>page.locator(selector).tap();
const layout=page=>page.evaluate(()=>{
 const box=id=>document.getElementById(id).getBoundingClientRect().toJSON();
 return {viewport:innerWidth,main:box('main'),stage:box('documentStage'),bar:box('phoneBottomBar'),pane:box('toolpane')};
});
try{
 const {context,page,errors}=await open({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2});
 await page.addInitScript(()=>{
  const natural=window.visualViewport;
  const simulated=new EventTarget();
  let keyboardHeight=null;
  Object.defineProperties(simulated,{
   height:{get:()=>keyboardHeight??natural.height},
   offsetTop:{get:()=>keyboardHeight===null?natural.offsetTop:22},
   scale:{get:()=>natural.scale}
  });
  Object.defineProperty(window,'visualViewport',{value:simulated});
  window.simulateKeyboard=height=>{keyboardHeight=height;simulated.dispatchEvent(new Event('resize'))};
 });
 await page.goto(release);
 await page.locator('#boot').waitFor({state:'detached'});
 assert(await page.locator('#phoneBottomBar').isVisible());
 assert(await page.locator('#phonePages').isDisabled());
 assert(await page.locator('#saveBtn').isVisible());
 await tap(page,'#phoneTools');
 await page.locator('#createBtn').waitFor();
 await tap(page,'#createBtn');
 await page.locator('#toolpane [data-tool=createPDF]').waitFor();
 const chooser=page.waitForEvent('filechooser');
 await tap(page,'#toolpane [data-tool=createPDF]');
 await (await chooser).setFiles(files);
 await page.waitForFunction(()=>window.PDFCreator.tabs.length===2&&!window.PDFCreator.state.abort);
 await page.getByRole('tab',{name:/Source.pdf/}).tap();
 await page.waitForFunction(()=>window.PDFCreator.state.name==='Source.pdf'&&!window.PDFCreator.state.abort);
 const initial=await layout(page);
 assert(initial.main.width>=385&&initial.stage.width===initial.viewport,'PDF uses phone width');

 await tap(page,'#phoneTools');
 await tap(page,'#nav [data-group=Edit]');
 await page.locator('#toolpane [data-tool=directedit]').waitFor();
 const sheet=await layout(page);
 assert(sheet.pane.width>=385&&sheet.pane.bottom<=sheet.bar.top,'tool sheet sits above phone navigation');
 assert.equal(sheet.main.width,initial.main.width,'tool sheet overlays the page');
 await tap(page,'#homeBtn');
 await page.locator('#toolpane').waitFor({state:'hidden'});
 await page.getByRole('tab',{name:/Source.pdf/}).tap();
 await page.locator('.pdf-field-target').first().waitFor();

 await tap(page,'#phonePages');
 await tap(page,'#phoneSelectPages');
 assert.equal(await page.locator('#pageSelectionStatus').textContent(),'0 selected');
 await tap(page,'#thumbs [data-page="0"]');
 await tap(page,'#thumbs [data-page="2"]');
 assert.equal(await page.getByRole('checkbox',{checked:true}).count(),2);
 assert.equal(await page.locator('#pageSelectionStatus').textContent(),'2 selected');
 await tap(page,'[data-strip-action=rotate]');
 await page.waitForFunction(()=>window.PDFCreator.state.undo.length===1&&!window.PDFCreator.state.abort);
 assert.equal(await page.evaluate(()=>window.PDFCreator.state.doc.loadPage(2).getBounds()[2]),842);
 await page.evaluate(()=>document.getElementById('undo').click());
 await page.waitForFunction(()=>window.PDFCreator.state.undo.length===0&&!window.PDFCreator.state.abort);
 if(await page.locator('#phoneSelectPages').getAttribute('aria-pressed')==='false')await tap(page,'#phoneSelectPages');
 for(const i of [1,2]){
  const tile=page.locator('#thumbs [data-page="'+i+'"]');
  if(await tile.getAttribute('aria-checked')==='false')await tile.tap();
 }
 if(await page.locator('#thumbs [data-page="0"]').getAttribute('aria-checked')==='true')await tap(page,'#thumbs [data-page="0"]');
 await tap(page,'[data-strip-action=transfer]');
 assert.match(await page.locator('#transferTarget').textContent(),/Destination.pdf/);
 await page.locator('#modalform button[type=submit]').tap();
 await page.waitForFunction(()=>window.PDFCreator.tabs.some(tab=>tab.snapshot.name==='Destination.pdf'&&tab.pageCount===3)&&!window.PDFCreator.state.abort);
 assert.equal(await page.evaluate(()=>window.PDFCreator.state.doc.countPages()),3);
 await tap(page,'[data-strip-action=delete]');
 await page.getByRole('heading',{name:'Delete 2 selected pages?'}).waitFor();
 await tap(page,'#modalcancel');
 assert.equal(await page.evaluate(()=>window.PDFCreator.state.doc.countPages()),3);
 await tap(page,'[data-strip-action=transfer]');
 await page.locator('#transferMode').selectOption('move');
 await page.locator('#modalform button[type=submit]').tap();
 await page.waitForFunction(()=>window.PDFCreator.state.doc.countPages()===1&&!window.PDFCreator.state.abort);
 assert.equal(await page.evaluate(()=>window.PDFCreator.tabs.find(tab=>tab.snapshot.name==='Destination.pdf').pageCount),5);

 await tap(page,'#phoneSearch');
 await page.locator('#functionSearchQuery').fill('direct edit');
 await page.evaluate(()=>window.simulateKeyboard(390));
 await page.locator('body.phone-keyboard').waitFor();
 assert((await page.locator('#functionSearchPopup').boundingBox()).y>=22,'search fits above keyboard');
 await page.evaluate(()=>window.simulateKeyboard(null));
 await tap(page,'#closeFunctionSearch');
 await page.locator('#functionSearchPopup').waitFor({state:'detached'});

 await page.evaluate(()=>window.PDFCreator.activate('directedit'));
 await page.getByRole('button',{name:'Direct edit: Source page 1',exact:true}).tap();
 const input=page.locator('.on-page-text-surface .direct-editor-input');
 await input.fill('Phone edit');
 await page.evaluate(()=>{window.simulateKeyboard(320);window.dispatchEvent(new Event('resize'))});
 await page.locator('body.phone-editor-keyboard').waitFor();
 assert.equal(await input.textContent(),'Phone edit');
 const more=page.locator('.page-text-toolbar .toolbar-actions .toolbar-options-toggle');
 assert(await more.isVisible());
 const apply=page.locator('.page-text-toolbar').getByRole('button',{name:'Apply',exact:true});
 assert((await apply.boundingBox()).y<342,'Apply sits above keyboard');
 await apply.tap();
 await page.waitForFunction(()=>window.PDFCreator.Engine.extractTextPDF(window.PDFCreator.state.bytes)[0].text.includes('Phone edit'),null,{timeout:5000}).catch(async error=>{
  const details=await page.evaluate(()=>({
   feedback:document.querySelector('.direct-editor-error')?.textContent,
   modal:document.querySelector('#modaltitle')?.textContent,
   status:document.querySelector('#statusText')?.textContent,
   text:window.PDFCreator.Engine.extractTextPDF(window.PDFCreator.state.bytes)[0].text
  }));
  throw Error('Phone text did not apply: '+JSON.stringify(details),{cause:error});
 });
 await page.evaluate(()=>window.simulateKeyboard(null));

 await tap(page,'.pdf-field-target[data-field-name=Comment]');
 await page.locator('#nativeFieldValue').fill('Field edited on the phone');
 await page.evaluate(()=>window.simulateKeyboard(300));
 await page.locator('body.phone-editor-keyboard').waitFor();
 assert(await page.locator('#contextMorePanel #nativeFieldFont').count()===1,'form formatting lives under More');
 const fieldApply=page.locator('.form-field-editor button[type=submit]');
 assert((await fieldApply.boundingBox()).y<322,'field Apply sits above keyboard');
 await fieldApply.tap();
 await page.locator('.form-field-editor').waitFor({state:'detached'});
 assert.equal(await page.evaluate(async()=>{
  const {PDFLib,state}=window.PDFCreator;
  const pdf=await PDFLib.PDFDocument.load(state.bytes);
  return pdf.getForm().getTextField('Comment').getText();
 }),'Field edited on the phone');
 await page.evaluate(()=>window.simulateKeyboard(null));
 await page.setViewportSize({width:844,height:390});
 assert(await page.locator('#phoneBottomBar').isVisible(),'phone landscape retains phone controls');
 assert.deepEqual(errors,[]);
 await context.close();

 const desktop=await open({viewport:{width:1440,height:900}});
 await desktop.page.goto(release);
 await desktop.page.locator('#boot').waitFor({state:'detached'});
 assert(await desktop.page.locator('#nav').isVisible());
 assert(!(await desktop.page.locator('#phoneBottomBar').isVisible()));
 await desktop.page.locator('#fileinput').setInputFiles(files);
 await desktop.page.waitForFunction(()=>window.PDFCreator.tabs.length===2&&!window.PDFCreator.state.abort);
 await desktop.page.getByRole('tab',{name:/Source.pdf/}).click();
 await desktop.page.waitForFunction(()=>window.PDFCreator.state.name==='Source.pdf'&&!window.PDFCreator.state.abort);
 assert.equal(await desktop.page.locator('#thumbs [data-page="0"]').getAttribute('draggable'),'true');
 await desktop.page.locator('#thumbs [data-page="1"]').click({modifiers:['Control']});
 assert.equal(await desktop.page.locator('#thumbs [aria-pressed=true]').count(),2);
 await desktop.page.keyboard.press('Control+k');
 await desktop.page.locator('#functionSearchQuery').waitFor();
 assert.equal(await desktop.page.evaluate(()=>document.activeElement.id),'functionSearchQuery');
 await desktop.page.keyboard.press('Escape');
 await desktop.page.locator('#functionSearchPopup').waitFor({state:'detached'});
 await desktop.page.locator('#moreActions').click();
 await desktop.page.locator('#pinToolRail').check();
 await desktop.page.locator('#workspace.pane-docked').waitFor();
 assert.deepEqual(desktop.errors,[]);
 await desktop.context.close();
 console.log('PDFCreator phone workspace passed in offline Chromium with mobile and desktop viewports.');
}finally{await browser.close()}
