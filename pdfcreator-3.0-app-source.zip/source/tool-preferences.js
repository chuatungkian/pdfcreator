/* Browser-local tool discovery preferences. No document content is stored here. */
export const TOOL_SHORTCUTS={search:'Ctrl/Cmd+F',findreplace:'Ctrl/Cmd+H',save:'Ctrl/Cmd+S',appHome:'',appAbout:''};
export class ToolPreferences{
 constructor(entries,onChange=()=>{}){this.valid=new Set(entries.map(e=>e.id));this.onChange=onChange;this.favourites=[];this.recent=[];this.helperHidden=false}
 restore(value={}){this.helperHidden=value?.helperHidden===true;const clean=list=>Array.isArray(list)?[...new Set(list.filter(id=>this.valid.has(id)))]:[];this.favourites=clean(value?.favourites).slice(0,this.valid.size);this.recent=clean(value?.recent).slice(0,8);this.onChange(false)}
 toggleHelper(){this.helperHidden=!this.helperHidden;this.onChange(true)}
 snapshot(){return{helperHidden:this.helperHidden,favourites:[...this.favourites],recent:[...this.recent]}}
 toggle(id){if(!this.valid.has(id))return;const index=this.favourites.indexOf(id);if(index>=0)this.favourites.splice(index,1);else if(this.favourites.length<this.valid.size)this.favourites.push(id);this.onChange(true)}
 record(id){if(!this.valid.has(id))return;this.recent=[id,...this.recent.filter(item=>item!==id)].slice(0,8);this.onChange(true)}
 order(entries){const ids=[...new Set([...this.favourites,...this.recent])];return [...entries].sort((a,b)=>{const rank=id=>ids.includes(id)?ids.indexOf(id):ids.length;return rank(a.id)-rank(b.id)})}
}
