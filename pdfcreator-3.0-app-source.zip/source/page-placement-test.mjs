/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

import {watermarkGeometry} from './watermarks.js';
import {applyPageDecorations,POINTS_PER_CM,putPageBand} from './page-decorations.js';
let assertions=0;const check=(v,label)=>{assertions++;assert.ok(v,label)},equal=(a,b,label)=>{assertions++;assert.deepEqual(a,b,label)},near=(a,b,label)=>check(Math.abs(a-b)<.03,label),pause=()=>new Promise(r=>setTimeout(r,0));async function until(fn,label){const end=Date.now()+7000;while(!fn()){if(Date.now()>end)throw Error('Timeout '+label);await pause()}}
let context;try{context=await boot();const {app,$,window}=context,PDF=app.PDFLib,m=app.Engine.mupdf;
 for(const rotation of [0,90,180,270]){let d=await PDF.PDFDocument.create();const p=d.addPage([600,800]);p.setCropBox(20,30,550,730);p.setRotation(PDF.degrees(rotation));p.drawText('BODY RETAINED',{x:250,y:380,size:12});const source=new Uint8Array(await d.save({useObjectStreams:false})),native=app.Engine.openPDF(source),g=watermarkGeometry(native,0);native.destroy();d=await PDF.PDFDocument.load(source);const reports=await applyPageDecorations(d,[0],'header',{header:'HEADER',headerAlign:'left',headerEdge:'top',headerOffsetCm:2,headerLeftCm:1.2,headerRightCm:3,headerLine:true,headerThickness:2,footer:'FOOTER',footerAlign:'right',footerEdge:'bottom',footerOffsetCm:3,footerLeftCm:2,footerRightCm:2.3,withNumbers:true,prefix:'P',start:7,numberAlign:'centre',numberEdge:'top',numberOffsetCm:4.5,numberLeftCm:1,numberRightCm:3},()=>g),[header,footer,num]=reports,w=g.bounds[2]-g.bounds[0],h=g.bounds[3]-g.bounds[1];near(header.rect[0],1.2*POINTS_PER_CM,'header left margin '+rotation);near(header.rect[1],2*POINTS_PER_CM,'header top edge '+rotation);near(w-footer.rect[2],2.3*POINTS_PER_CM,'footer right margin '+rotation);near(h-footer.rect[3],3*POINTS_PER_CM,'footer bottom edge '+rotation);near(num.rect[1],4.5*POINTS_PER_CM,'page number top edge '+rotation);near((num.rect[0]+num.rect[2])/2,(w-2*POINTS_PER_CM)/2,'centre uses asymmetric margins '+rotation);
 const bytes=new Uint8Array(await d.save({useObjectStreams:false})),checkDoc=app.Engine.openPDF(bytes),page=checkDoc.loadPage(0),pix=page.toPixmap(m.Matrix.identity,m.ColorSpace.DeviceRGB,true,true),data=pix.getPixels(),n=pix.getNumberOfComponents(),pw=pix.getWidth();for(const report of reports){const y0=Math.max(0,Math.floor(report.rect[1])-2),y1=Math.min(pix.getHeight(),Math.ceil(report.rect[3])+2);let minX=pw,minY=10000,maxX=-1,maxY=-1;for(let y=y0;y<y1;y++)for(let x=0;x<pw;x++){if(data[(y*pw+x)*n+n-1]>35){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y)}}check(maxX>=minX,'band remains visible '+report.slot+'/'+rotation);check(Math.abs(minX-report.rect[0])<2&&Math.abs(minY-report.rect[1])<2,'native band pixels match centimetre offsets '+report.slot+'/'+rotation)}
 let linePixels=0;const ly=Math.round(header.lineY);for(let x=0;x<pw;x++)if(data[(ly*pw+x)*n+n-1]>50)linePixels++;check(linePixels>=pw-1,'full-width rule moves with header '+rotation);const text=page.toStructuredText('');check(text.asText().includes('BODY RETAINED'),'body survives '+rotation);text.destroy();pix.destroy();page.destroy();checkDoc.destroy();if(rotation===0){fs.writeFileSync('../../tmp/pdfs/page-placement-proof.pdf',bytes);fs.writeFileSync('../../tmp/pdfs/page-placement-proof.png',app.Engine.renderPagePNG(bytes,0,{scale:1}).bytes)}
 const prior=d.getPageCount();await assert.rejects(()=>putPageBand(d,0,'header',{text:'Invalid',leftCm:100,rightCm:100},g),/margins/);assertions++;await assert.rejects(()=>putPageBand(d,0,'footer',{text:'Invalid',offsetCm:100},g),/outside/);assertions++;equal(d.getPageCount(),prior,'invalid placement adds no temporary page '+rotation);
 }
 const source=await PDF.PDFDocument.create();source.addPage([595,842]);await app.openFiles([{name:'Placement.pdf',type:'application/pdf',arrayBuffer:async()=>(await source.save({useObjectStreams:false})).buffer}]);let task=app.activate('header');await until(()=>document.querySelector('[name=headerOffsetCm]'),'header positions');for(const prefix of ['header','footer','number'])for(const suffix of ['Edge','OffsetCm','LeftCm','RightCm'])check(!!document.querySelector(`[name=${prefix+suffix}]`),'UI offers '+prefix+suffix);const set=(name,val)=>{document.querySelector('[name='+name+']').value=val};set('header','Positioned header');set('headerOffsetCm','2.25');set('headerLeftCm','1.8');set('footer','Positioned footer');set('footerOffsetCm','1.2');document.querySelector('[name=withNumbers]').checked=true;set('numberEdge','top');set('numberOffsetCm','4');await $('modalform').onsubmit(new window.Event('submit',{cancelable:true}));await task;const final=app.state.bytes;check(app.Engine.extractTextPDF(final)[0].text.includes('Positioned header'),'UI position changes applied');equal(app.state.undo.length,1,'header/footer/number placements form one undo step');await $('undo').onclick();await $('redo').onclick();equal(app.state.bytes,final,'placement redo exact');task=app.activate('bates');await until(()=>document.querySelector('[name=numberLeftCm]'),'Bates positions');check(!!document.querySelector('[name=footerOffsetCm]'),'Bates footer has independent positions');$('modalcancel').click();await task;await context.close();context=null;console.log('PDFCreator centimetre placement: '+assertions+' assertions passed with native rotated/cropped PDF pixels and controlled UI.');}finally{if(context)await context.close()}
