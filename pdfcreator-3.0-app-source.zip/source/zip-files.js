/* Compressed downloads with a stored-ZIP fallback. AGPL-3.0-or-later. */
import {sourceCRC,compressZipBytes} from './source-package.js';
export async function zipFiles(entries,{signal,progress=()=>{}}={}){
  if(entries.length>65535)throw Error('Too many files for a ZIP archive.');
  const chunks=[],directory=[],names=new Set(),encoder=new TextEncoder();let offset=0;
  for(let index=0;index<entries.length;index++){
    if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
    const entry=entries[index];if(!entry.name||/[\\/\x00]/.test(entry.name)||names.has(entry.name))throw Error('Invalid or duplicate ZIP filename.');names.add(entry.name);
    const bytes=entry.bytes instanceof Uint8Array?entry.bytes:encoder.encode(String(entry.bytes)),name=encoder.encode(entry.name),crc=sourceCRC(bytes),{method,data}=await compressZipBytes(bytes);
    if(name.length>65535||offset+30+name.length+data.length>0xffffffff||bytes.length>0xffffffff)throw Error('ZIP size limit exceeded.');
    const h=new DataView(new ArrayBuffer(30)),c=new DataView(new ArrayBuffer(46));
    h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(8,method,true);h.setUint32(14,crc,true);h.setUint32(18,data.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,name.length,true);
    c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(10,method,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,bytes.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);
    chunks.push(h.buffer,name,data);directory.push(c.buffer,name);offset+=30+name.length+data.length;progress((index+1)/entries.length,'Compressing file '+(index+1)+' of '+entries.length);
  }
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  const size=directory.reduce((sum,part)=>sum+part.byteLength,0),end=new DataView(new ArrayBuffer(22));if(offset+size>0xffffffff)throw Error('ZIP size limit exceeded.');
  end.setUint32(0,0x06054b50,true);end.setUint16(8,entries.length,true);end.setUint16(10,entries.length,true);end.setUint32(12,size,true);end.setUint32(16,offset,true);
  return new Blob([...chunks,...directory,end.buffer],{type:'application/zip'});
}
