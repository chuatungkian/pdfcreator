/* Real-browser regression using just the HTML via file://, with normal CORS. */
import assert from 'node:assert/strict';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {wordFixture} from './offline-word-fixtures.mjs';
import {buildDoc} from './legacy-word-fixture.mjs';
const require=createRequire(import.meta.url);
const {chromium}=require(path.join(process.env.PDFPRO_NODE_MODULES||process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright'));
const browser=await chromium.launch({executablePath:process.env.PDFPRO_BROWSER,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
let assertions=0;const check=(value,label)=>{assertions++;assert.ok(value,label)};
const requests=[],errors=[];
try{
 const context=await browser.newContext({acceptDownloads:true,serviceWorkers:'block'}),page=await context.newPage();
 await context.route(/^https?:\/\//,route=>{requests.push(route.request().url());return route.abort()});
 page.on('pageerror',error=>errors.push(error.message));
 await page.goto(pathToFileURL(path.resolve('../../outputs/pdfcreator.html')).href);
 await page.waitForFunction(()=>window.PdfPro?.importWordDocument,{timeout:60000});
 check(new URL(page.url()).protocol==='file:','standalone HTML starts directly from disk');
 await page.evaluate(()=>window.PdfPro.createDemo());
 const owner=await page.evaluate(()=>window.PdfPro.activeTabId);
 async function convert(name,bytes){
  await page.evaluate(()=>{window.wordImportTask=window.PdfPro.importWordDocument()});
  await page.locator('#wordSource').setInputFiles({name,mimeType:name.endsWith('.docx')?'application/vnd.openxmlformats-officedocument.wordprocessingml.document':'application/msword',buffer:Buffer.from(bytes)});
  check(await page.locator('#wordEngine').inputValue()==='offline','built-in converter is selected');
  await page.locator('#modalform button[type=submit]').click();
  await page.waitForFunction(()=>document.getElementById('modaltitle')?.textContent==='Review Word conversion',{timeout:60000});
  check(await page.locator('.word-conversion-preview img').evaluate(image=>image.complete&&image.naturalWidth>0),'converted first-page preview displays');
 }
 await convert('Standalone.docx',wordFixture());
 check(await page.evaluate(()=>window.PdfPro.activeTabId)===owner,'review preserves existing PDF');
 await page.locator('#modalcancel').click();await page.evaluate(()=>window.wordImportTask);
 check(await page.evaluate(()=>window.PdfPro.activeTabId)===owner,'cancel keeps original tab');
 await convert('Standalone.docx',wordFixture());
 await page.locator('#modalform button[type=submit]').click();await page.evaluate(()=>window.wordImportTask);
 check(await page.evaluate(()=>window.PdfPro.state.doc.countPages())===2,'DOCX opens as a two-page PDF');
 check(await page.evaluate(()=>window.PdfPro.Engine.extractTextPDF(window.PdfPro.state.bytes).map(p=>p.text).join('\n').includes('TABLE LEFT')),'DOCX content remains searchable');
 await page.locator('#saveBtn').click();await page.locator('#modalform button[type=submit]').click();
 await page.waitForFunction(()=>document.getElementById('modaltitle')?.textContent==='Export review');
 const downloadEvent=page.waitForEvent('download');await page.locator('#modalform button[type=submit]').click();
 const download=await downloadEvent,downloaded=await download.createReadStream(),chunks=[];for await(const chunk of downloaded)chunks.push(chunk);
 check(Buffer.concat(chunks).subarray(0,5).toString()==='%PDF-','converted PDF downloads correctly');
 await convert('Standalone.doc',buildDoc([{text:'LEGACY WORD IMPORT\rSecond paragraph\r',compressed:false}]));
 await page.locator('#modalform button[type=submit]').click();await page.evaluate(()=>window.wordImportTask);
 check(await page.evaluate(()=>window.PdfPro.Engine.extractTextPDF(window.PdfPro.state.bytes).map(p=>p.text).join('\n').includes('LEGACY WORD IMPORT')),'binary DOC converts and opens');
 check(requests.length===0,'zero HTTP/HTTPS requests');check(errors.length===0,'no browser runtime errors');
 console.log(JSON.stringify({assertions,browser:await browser.version(),origin:'file://',requests,errors},null,2));
}finally{await browser.close()}
