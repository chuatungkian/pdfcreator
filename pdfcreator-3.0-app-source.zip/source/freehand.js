/* Pointer samples in displayed MuPDF page coordinates. AGPL-3.0-or-later. */
export function inkPoint(event,geometry){
  const {origin,zoom,bounds}=geometry;
  const x=(event.clientX-origin.left)/zoom+bounds[0],y=(event.clientY-origin.top)/zoom+bounds[1];
  if(!Number.isFinite(x)||!Number.isFinite(y))return null;
  return[Math.max(bounds[0],Math.min(bounds[2],x)),Math.max(bounds[1],Math.min(bounds[3],y))];
}
export function appendInkSamples(stroke,event){
  let events=[];
  try{events=event.getCoalescedEvents?.()||[]}catch{/* Older pointer implementations use the main event. */}
  for(const sample of [...events,event]){
    if(sample.pointerId!==undefined&&sample.pointerId!==stroke.pointer)continue;
    const point=inkPoint(sample,stroke),last=stroke.points.at(-1);
    if(point&&(!last||point[0]!==last[0]||point[1]!==last[1]))stroke.points.push(point);
  }
}
export function savedInkPoints(stroke){
  // MuPDF's round-capped Ink appearance needs a short segment for a pen tap.
  // Keep it subpixel-sized instead of applying the area tool's 160-point box.
  if(stroke.points.length!==1)return stroke.points;
  const[x,y]=stroke.points[0],epsilon=.01,dx=x+epsilon<=stroke.bounds[2]?epsilon:-epsilon;
  return[[x,y],[x+dx,y]];
}
