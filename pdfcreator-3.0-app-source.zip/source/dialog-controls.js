/* Shared page-range affordances and accessible modal boundaries. */
import {pageScope} from './page-scope.js';
export function dialogControls(root,{count=0,page=0,parsePages,selectedPages=[]}={}){
 const backgrounds=[...document.body.children].filter(node=>node!==root&&!node.contains(root)&&!['SCRIPT','STYLE'].includes(node.tagName));const previous=backgrounds.map(node=>[node,node.inert]);backgrounds.forEach(node=>node.inert=true);
 const cleanups=[];
 for(const input of root.querySelectorAll('input[name="pages"]')){
  if(!count||input.closest('[hidden]')||input.nextElementSibling?.hasAttribute('data-page-scope'))continue;
  cleanups.push(pageScope(input,{count,page,parsePages,selectedPages}));
 }
 return()=>{cleanups.forEach(cleanup=>cleanup());previous.forEach(([node,inert])=>node.inert=inert)};
}
export function modalFocusables(root){return [...root.querySelectorAll('button,input,select,textarea,a[href],summary,[tabindex]')].filter(node=>!node.matches(':disabled')&&node.type!=='hidden'&&node.tabIndex>=0&&!node.closest('[hidden],[inert]')&&![...node.closest('details:not([open])')?.children||[]].some(child=>child.tagName!=='SUMMARY'&&(child===node||child.contains(node))))}
