/* Shared page-range affordances and accessible modal boundaries. */
export function dialogControls(root,{count=0,page=0,parsePages}={}){
 const backgrounds=[...document.body.children].filter(node=>node!==root&&!node.contains(root)&&!['SCRIPT','STYLE'].includes(node.tagName));const previous=backgrounds.map(node=>[node,node.inert]);backgrounds.forEach(node=>node.inert=true);
 for(const input of root.querySelectorAll('input[name="pages"]')){
  if(!count||input.closest('[hidden]'))continue;const group=document.createElement('div');group.className='page-range-shortcuts';const info=document.createElement('span');info.className='help';info.setAttribute('aria-live','polite');
  const update=()=>{try{const indices=parsePages(input.value);input.removeAttribute('aria-invalid');info.textContent=indices.length+' of '+count+' pages selected'}catch(error){input.setAttribute('aria-invalid','true');info.textContent=error.message}};
  for(const [label,value]of [['All pages','1-'+count],['Current page',String(page+1)]]){const b=document.createElement('button');b.type='button';b.className='small';b.textContent=label;b.onclick=()=>{input.value=value;const Event=input.ownerDocument.defaultView.Event;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}))};group.append(b)}group.append(info);input.after(group);input.addEventListener('input',update);update();
 }
 return()=>previous.forEach(([node,inert])=>node.inert=inert);
}
export function modalFocusables(root){return [...root.querySelectorAll('button,input,select,textarea,a[href],summary,[tabindex]')].filter(node=>!node.matches(':disabled')&&node.type!=='hidden'&&node.tabIndex>=0&&!node.closest('[hidden],[inert]')&&![...node.closest('details:not([open])')?.children||[]].some(child=>child.tagName!=='SUMMARY'&&(child===node||child.contains(node))))}
