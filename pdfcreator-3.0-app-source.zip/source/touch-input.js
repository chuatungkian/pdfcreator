/* Gesture policy shared by page overlays and tap routing. */
export function tapTolerance(event,mouse=5){return event?.pointerType==='touch'?12:event?.pointerType==='pen'?6:mouse}
export function pageTouchAction(tool,directMode){return ['select','search','objects','images','editfields'].includes(tool)||tool==='directedit'&&directMode!=='chunk'?'manipulation':'none'}
