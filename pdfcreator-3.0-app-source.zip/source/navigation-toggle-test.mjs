/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
let context;
try{
 context=await boot();const {app,$,window}=context;
 await $('createBtn').onclick();check(app.state.paneOpen&&!$('modalform'),'Create opens tool popup on empty Home');equal($('createBtn').getAttribute('aria-expanded'),'true','Create reports expanded');await $('createBtn').onclick();check(!app.state.paneOpen,'second Create click closes popup');equal($('createBtn').getAttribute('aria-expanded'),'false','Create reports collapsed');await $('createBtn').onclick();check(app.state.paneOpen,'Create opens again');await app.createDocument();check(app.state.paneOpen,'non-navigation Create entry keeps pane open');await $('closeTools').onclick();
 await app.openFiles([file('Navigation.pdf',await fixture(app,'NAVIGATION'))]);await $('next').onclick();const bytes=app.state.bytes,owner=app.activeTabId,page=app.state.page;
 const group=name=>document.querySelector(`[data-group="${name}"]`);
 for(const name of ['View','Organize','Edit','Annotate','Forms','OCR & compare','Protect & sign','Export & batch']){
  if(app.state.group===name&&app.state.paneOpen)await $('closeTools').onclick();
  await group(name).onclick();check(app.state.paneOpen&&app.state.group===name,name+' opens');equal(group(name).getAttribute('aria-expanded'),'true',name+' expanded state');
  await group(name).onclick();check(!app.state.paneOpen,name+' closes on second click');equal(group(name).getAttribute('aria-expanded'),'false',name+' collapsed state');
  await group(name).onclick();check(app.state.paneOpen,name+' reopens');
 }
 await group('Edit').onclick();equal($('panel').querySelector('h2').textContent,'Edit','different group replaces popup content');check(app.state.paneOpen,'switching group keeps popup open');await $('createBtn').onclick();check(app.state.group==='Create'&&app.state.paneOpen,'Create replaces another function popup');await $('createBtn').onclick();check(!app.state.paneOpen,'Create closes while working on PDF');await $('addDocument').onclick();check(app.state.paneOpen&&app.state.group==='Create','tab-bar Create entry opens popup');
 await $('toggleNav').onclick();check(app.state.navCollapsed,'icon-only navigation active');await $('createBtn').onclick();check(!app.state.paneOpen,'icon-only Create toggles closed');await group('Edit').onclick();check(app.state.paneOpen,'icon-only group opens popup');await group('Edit').onclick();check(!app.state.paneOpen,'icon-only group closes popup');
 await group('Edit').onclick();await $('dockTools').onclick();await app.activate('text');check(app.state.paneDocked&&app.state.settingsOpen,'pinned tools have open text settings');await group('Edit').onclick();check(!app.state.settingsOpen,'active navigation closes pinned settings popup');check(app.state.paneDocked,'closing popup preserves pinned icon bar');equal(document.querySelectorAll('#panel [data-tool]').length,14,'pinned group actions remain available');
 equal(app.state.bytes,bytes,'navigation toggles preserve PDF bytes');equal(app.activeTabId,owner,'navigation toggles preserve document tab');equal(app.state.page,page,'navigation toggles preserve viewed page');equal(app.state.undo.length,0,'navigation creates no edit history');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator navigation toggles: '+assertions+' assertions passed in controlled UI with real PDFs.');
}finally{if(context)await context.close()}
