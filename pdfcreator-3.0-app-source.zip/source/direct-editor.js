/* Compact on-page text editor. The saved PDF uses its original font. */
export function openDirectEditor({overlay,target,bounds,zoom,apply,onClose,fontData,onMode,mode=target.scope||'paragraph'}){
  const document=overlay.ownerDocument,form=document.createElement('form');form.className='direct-editor';form.setAttribute('aria-label','Direct edit');
  const multiline=target.kind==='added'||mode!=='line',input=document.createElement(multiline?'textarea':'input');input.className='direct-editor-input';input.setAttribute('aria-label','Edit PDF text');input.value=target.text;input.spellcheck=false;
  if(input.tagName==='INPUT')input.type='text';
  const face=target.fontName.replace(/^[A-Z]{6}\+/,'');
  const family=/courier|mono/i.test(face)?'Courier New':/times|roman|serif/i.test(face)&&!/sans/i.test(face)?'Times New Roman':/helvetica|sans|arial/i.test(face)?'Arial':face;
  Object.assign(input.style,{fontFamily:'"'+family.replace(/["\\]/g,'')+'", sans-serif',fontSize:Math.max(4,target.size*zoom)+'px',fontWeight:target.bold?'700':'400',fontStyle:target.italic?'italic':'normal',color:target.color});
  const root=document.getElementById('main'),rootBox=root?.getBoundingClientRect(),pageBox=overlay.getBoundingClientRect();
  const left=Math.max(0,(target.rect[0]-bounds[0])*zoom,rootBox?.width?rootBox.left-pageBox.left+8:0),top=Math.max(0,(target.rect[1]-bounds[1])*zoom,rootBox?.height?rootBox.top-pageBox.top+8:0),available=Math.max(80,(bounds[2]-bounds[0])*zoom-left-8);
  Object.assign(form.style,{left:left+'px',top:top+'px',width:Math.min(available,Math.max(180,(target.rect[2]-target.rect[0])*zoom+24))+'px'});
  input.style.minHeight=Math.min(multiline?190:64,Math.max(multiline?80:26,(target.rect[3]-target.rect[1])*zoom+6))+'px';
  if(target.layout)input.style.lineHeight=target.layout.leading*zoom+'px';
  const scopeRow=document.createElement('div');scopeRow.className='direct-editor-scope-row';
  const scopeLabel=document.createElement('label');scopeLabel.textContent='Edit as';const scope=document.createElement('select');scope.className='direct-editor-scope';scope.setAttribute('aria-label','Editing scope');
  for(const [value,label]of [['paragraph','Paragraph'],['line','Line'],['chunk','Text chunk']]){const option=document.createElement('option');option.value=value;option.textContent=label;scope.append(option)}scope.value=mode;scopeLabel.append(scope);scopeRow.append(scopeLabel);if(target.kind==='added')scopeRow.hidden=true;
  let widthInput=null;
  if(target.layout&&mode!=='line'){
    const widthLabel=document.createElement('label');widthLabel.textContent='Width (pt)';widthInput=document.createElement('input');widthInput.type='number';widthInput.className='direct-editor-width';widthInput.min='20';widthInput.max='20000';widthInput.step='0.1';widthInput.value=String(Math.round(target.layout.width*10)/10);widthInput.setAttribute('aria-label','Reflow width in points');widthLabel.append(widthInput);scopeRow.append(widthLabel);
    const resize=()=>{const width=+widthInput.value;if(Number.isFinite(width)&&width>=20)form.style.width=Math.min(available,Math.max(180,width*zoom+8))+'px'};widthInput.oninput=resize;resize();
  }
  const bar=document.createElement('div');bar.className='direct-editor-bar';
  const label=document.createElement('span');label.className='direct-editor-style';label.textContent=face+' · '+Math.round(target.size*100)/100+' pt · '+target.color;label.title='The saved PDF retains its original font, colour and size. The typing preview uses a matching local font when available.';
  const save=document.createElement('button');save.type='submit';save.className='primary small';save.textContent='Apply';
  const cancel=document.createElement('button');cancel.type='button';cancel.className='small';cancel.textContent='Cancel';
  const error=document.createElement('div');error.className='direct-editor-error';error.setAttribute('role','alert');
  if(target.mixed)label.textContent+=' · Mixed styles retained';
  const help=document.createElement('p');help.className='direct-editor-help';help.textContent=mode==='line'?'Enter to apply · Escape to cancel':'Text rewraps at the original size. Enter starts a new line; Ctrl+Enter applies.';if(target.kind==='added')help.textContent='Edit this complete text box; the font size and box dimensions are retained.';
  bar.append(label,save,cancel);form.append(scopeRow,input,bar,help,error);overlay.append(form);
  let busy=false,closed=false,faceObject=null;
  const close=()=>{if(closed)return;closed=true;form.remove();if(faceObject)document.fonts?.delete(faceObject);onClose?.()};
  const FontFace=document.defaultView.FontFace;
  if(fontData&&FontFace&&document.fonts){
    try{
    const name='PdfProDirect'+Math.random().toString(36).slice(2),face=new FontFace(name,fontData,{weight:target.bold?'700':'400',style:target.italic?'italic':'normal'});
    void face.load().then(loaded=>{if(closed)return;faceObject=loaded;document.fonts.add(loaded);input.style.fontFamily=name}).catch(()=>{});
    }catch{}
  }
  cancel.onclick=()=>{if(!busy)close()};
  for(const event of ['pointerdown','pointerup','click'])form.addEventListener(event,e=>e.stopPropagation());
  form.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();if(!busy)close()}else if(event.key==='Enter'&&(input.tagName==='INPUT'||event.ctrlKey||event.metaKey)){event.preventDefault();void submit()}});
  const hasChanges=()=>input.value!==target.text||!!widthInput&&Math.abs(+widthInput.value-Math.round(target.layout.width*10)/10)>.01;
  scope.onchange=()=>{if(busy||hasChanges()){scope.value=mode;error.textContent='Apply or cancel your changes before choosing another editing scope.';return}const next=scope.value;close();onMode?.(next)};
  const submit=async()=>{if(busy||closed)return;busy=true;scope.disabled=save.disabled=cancel.disabled=input.disabled=true;if(widthInput)widthInput.disabled=true;error.textContent='';try{const applied=await apply(input.value,widthInput?{width:+widthInput.value}:{});if(applied!==false)close()}catch(e){error.textContent=e.message}finally{busy=false;scope.disabled=save.disabled=cancel.disabled=input.disabled=false;if(widthInput)widthInput.disabled=false;if(!closed)input.focus({preventScroll:true})}};
  form.onsubmit=event=>{event.preventDefault();return submit()};input.focus({preventScroll:true});input.select();return{close,form,input,hasChanges};
}
