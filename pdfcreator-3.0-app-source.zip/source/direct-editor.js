import {captureControls,restoreControls} from './editor-drafts.js';
import {onPageText,focusPageTextAt} from './on-page-text.js';
/* Compact native PDF text editor with selection formatting. */
import {directFormatting} from './direct-formatting.js';
import {inlineTextInput} from './inline-text-input.js';
import {directPagePreview} from './direct-page-preview.js';
import {ocrCorrection} from './ocr-correction.js';
export function openDirectEditor({overlay,target,bounds,zoom,apply,preview,onClose,fontData,onMode,mode=target.scope||'paragraph',caretPoint=null,styles=null}){
  const document=overlay.ownerDocument,form=document.createElement('form');form.className='direct-editor';form.setAttribute('aria-label','Direct edit');
  const multiline=target.kind==='added'||mode!=='line',input=inlineTextInput(document,{text:target.text,multiline});input.setAttribute('aria-label','Edit PDF text');
  if(input.tagName==='INPUT')input.type='text';
  const face=target.fontName.replace(/^[A-Z]{6}\+/,'');
  const family=/courier|mono/i.test(face)?'Courier New':/times|roman|serif/i.test(face)&&!/sans/i.test(face)?'Times New Roman':/helvetica|sans|arial/i.test(face)?'Arial':face;
  Object.assign(input.style,{fontFamily:'"'+family.replace(/["\\]/g,'')+'", sans-serif',fontSize:Math.max(4,target.size*zoom)+'px',fontWeight:target.bold?'700':'400',fontStyle:target.italic?'italic':'normal',color:target.color,textAlign:target.layout?.align||'left'});
  const root=document.getElementById('main'),rootBox=root?.getBoundingClientRect(),pageBox=overlay.getBoundingClientRect();
  const left=Math.max(0,(target.rect[0]-bounds[0])*zoom,rootBox?.width?rootBox.left-pageBox.left+8:0),top=Math.max(0,(target.rect[1]-bounds[1])*zoom,rootBox?.height?rootBox.top-pageBox.top+8:0),available=Math.max(80,(bounds[2]-bounds[0])*zoom-left-8);
  Object.assign(form.style,{left:left+'px',top:top+'px',width:Math.min(available,Math.max(180,(target.rect[2]-target.rect[0])*zoom+24))+'px'});
  input.style.minHeight=Math.min(multiline?190:64,Math.max(multiline?80:26,(target.rect[3]-target.rect[1])*zoom+6))+'px';
  input.style.lineHeight='1.4';
  const scopeRow=document.createElement('div');scopeRow.className='direct-editor-scope-row';
  const scopeLabel=document.createElement('label');scopeLabel.textContent='Edit as';const scope=document.createElement('select');scope.className='direct-editor-scope';scope.setAttribute('aria-label','Editing scope');
  for(const [value,label]of [['paragraph','Paragraph'],['line','Line'],['chunk','Text chunk']]){const option=document.createElement('option');option.value=value;option.textContent=label;scope.append(option)}scope.value=mode;scopeLabel.append(scope);scopeRow.append(scopeLabel);if(target.kind==='added')scopeRow.hidden=true;if(target.kind==='ocr')scopeLabel.hidden=true;
  let widthInput=null;
  if(target.layout&&mode!=='line'){
    const widthLabel=document.createElement('label');widthLabel.textContent='Width (pt)';widthInput=document.createElement('input');widthInput.type='number';widthInput.className='direct-editor-width';widthInput.min='20';widthInput.max='20000';widthInput.step='0.1';widthInput.value=String(Math.round(target.layout.width*10)/10);widthInput.setAttribute('aria-label','Reflow width in points');widthLabel.append(widthInput);scopeRow.append(widthLabel);
    const resize=()=>{const width=+widthInput.value;if(Number.isFinite(width)&&width>=20)form.style.width=Math.min(available,Math.max(180,width*zoom+8))+'px'};widthInput.oninput=resize;resize();
  }
  const bar=document.createElement('div');bar.className='direct-editor-bar';
  const label=document.createElement('span');label.className='direct-editor-style';label.textContent=face+' · '+Math.round(target.size*100)/100+' pt · '+target.color;label.title='The saved PDF retains its original font, colour and size. The typing preview uses a matching local font when available.';
  const save=document.createElement('button');save.type='submit';save.className='primary small';save.textContent='Apply';
  const cancel=document.createElement('button');cancel.type='button';cancel.className='small';cancel.textContent='Cancel';cancel.setAttribute('data-direct-cancel','');
  const error=document.createElement('div');error.className='direct-editor-error';error.setAttribute('role','alert');
  if(target.mixed)label.textContent+=' · Mixed styles retained';
  const help=document.createElement('p');help.className='direct-editor-help';help.textContent=mode==='line'?'Enter to apply · Escape to cancel':'Text rewraps to the chosen width. Enter starts a new line; Ctrl+Enter applies.';if(target.kind==='added')help.textContent='Edit this complete text box; the font size and box dimensions are retained.';
  let schedulePreview=()=>{};const formatting=directFormatting({document,input,target,onChange:()=>schedulePreview()});if(target.kind==='ocr'){formatting.root.querySelector('option[value=original]').textContent='Estimated font';label.textContent='OCR estimate · '+Math.round(target.confidence)+'% confidence';}
  label.title='Source appearance. Formatting controls change selected words or the whole block.';
  help.textContent+=' Edit directly on the PDF; formatting controls stay above the page.';if(target.kind==='ocr')help.textContent='Recognised English text: check the words before applying. Font and spacing are estimated. Applying replaces the selected visible lettering and adds editable PDF text.';
  const layoutLabel=document.createElement('label');layoutLabel.className='direct-layout-label';layoutLabel.textContent='Text layout';const layout=document.createElement('select');layout.dataset.directLayout='';layout.setAttribute('aria-label','Text layout');for(const [value,text]of [['keep','Keep layout'],['fit','Fit text into box'],['column','Move following text in this column']]){const option=document.createElement('option');option.value=value;option.textContent=text;layout.append(option)}layoutLabel.append(layout);const previewStatus=document.createElement('p');previewStatus.className='direct-preview-status';previewStatus.setAttribute('role','status');previewStatus.dataset.previewState='initial';previewStatus.textContent='Changes preview on the PDF page before Apply.';
  bar.append(label,save,cancel);form.append(formatting.root,scopeRow,layoutLabel,input,bar,help,previewStatus,error);overlay.append(form);
  let pageEditing=null;let busy=false,closed=false,faceObject=null,timer=null,generation=0,pendingPreview=Promise.resolve(),correction=null;const pagePreview=preview?directPagePreview({overlay,bounds,zoom}):null;
  const getOptions=()=>({...widthInput?{width:+widthInput.value}:{},...formatting.options(),layoutMode:layout.value,...correction?{sourceRects:correction.rects()}:{} });
  schedulePreview=()=>{clearTimeout(timer);const token=++generation;if(closed||busy)return;previewStatus.dataset.previewState='busy';previewStatus.textContent='Updating page preview…';timer=setTimeout(()=>{timer=null;pendingPreview=renderPreview(token)},250)};
  async function renderPreview(token){if(closed||busy||!preview)return;try{const result=await preview(input.value,getOptions());if(closed||token!==generation)return;pagePreview.show(result);previewStatus.dataset.previewState=result.fontScale<.999||result.affected?.length||result.moved?.length?'attention':'ready';previewStatus.textContent=(result.fontScale<.999?'Fitted at '+Math.round(result.fontScale*100)+'% · ':'')+(result.affected?.length?result.affected.length+' nearby text region(s) affected.':result.moved?.length?'Following text will move in this column.':'Page preview ready.')}catch(e){if(!closed&&token===generation){pagePreview?.clear();previewStatus.dataset.previewState='error';previewStatus.textContent='Preview: '+e.message}}}
  form.addEventListener('input',schedulePreview);form.addEventListener('change',schedulePreview);layout.onchange=schedulePreview;
  if(target.kind==='ocr'){correction=ocrCorrection({document,overlay,bounds,zoom,target,input,onChange:schedulePreview,onMatch:profile=>{input.setSelectionRange(0,input.value.length);input.dispatchEvent(new document.defaultView.Event('select'));for(const [key,value]of [['font',profile.font],['size',String(Math.round(profile.size*10)/10)]]){const field=form.querySelector('[data-direct-format='+key+']');field.value=value;field.onchange()}for(const key of ['bold','italic']){const button=formatting.root.querySelector('[data-direct-format='+key+']');if((button.getAttribute('aria-pressed')==='true')!==profile[key])button.click()}schedulePreview()}});layoutLabel.after(correction.root);}
  const flushPreview=async()=>{clearTimeout(timer);timer=null;const token=++generation;pendingPreview=renderPreview(token);await pendingPreview};
  const close=()=>{if(closed)return;closed=true;generation++;clearTimeout(timer);pagePreview?.destroy();correction?.destroy();pageEditing?.destroy();form.remove();formatting.destroy?.();if(faceObject)document.fonts?.delete(faceObject);onClose?.()};
  const FontFace=document.defaultView.FontFace;
  if(fontData&&FontFace&&document.fonts){
    try{
    const name='PdfProDirect'+Math.random().toString(36).slice(2),face=new FontFace(name,fontData,{weight:target.bold?'700':'400',style:target.italic?'italic':'normal'});
    void face.load().then(loaded=>{if(closed)return;faceObject=loaded;document.fonts.add(loaded);input.style.setProperty('--direct-original-font',name);pageEditing?.sync()}).catch(()=>{});
    }catch{}
  }
  cancel.onclick=()=>{if(!busy)close()};
  for(const event of ['pointerdown','pointerup','click'])form.addEventListener(event,e=>e.stopPropagation());
  form.addEventListener('keydown',event=>{event.stopPropagation();if(event.isComposing||event.keyCode===229)return;if(event.key==='Escape'){event.preventDefault();if(!busy)close()}else if(event.key==='Enter'&&(event.ctrlKey||event.metaKey||!multiline&&(event.onPageTextInput||event.target===input||input.contains(event.target)))){event.preventDefault();void submit()}});
  const hasChanges=()=>input.value!==target.text||formatting.hasChanges()||layout.value!=='keep'||!!correction?.changed()||!!widthInput&&Math.abs(+widthInput.value-Math.round(target.layout.width*10)/10)>.01;
  scope.onchange=()=>{if(busy||hasChanges()){scope.value=mode;error.textContent='Apply or cancel your changes before choosing another editing scope.';return}const next=scope.value;close();onMode?.(next)};
  const submit=async()=>{if(busy||closed||!form.reportValidity())return;busy=true;scope.disabled=layout.disabled=save.disabled=cancel.disabled=input.disabled=true;correction?.setDisabled(true);formatting.setDisabled(true);if(widthInput)widthInput.disabled=true;error.textContent='';try{generation++;clearTimeout(timer);const applied=await apply(input.value,getOptions());if(applied!==false)close()}catch(e){error.textContent=e.message}finally{busy=false;scope.disabled=layout.disabled=save.disabled=cancel.disabled=input.disabled=false;correction?.setDisabled(false);formatting.setDisabled(false);if(widthInput)widthInput.disabled=false;if(!closed)input.focus({preventScroll:true})}};
  form.onsubmit=event=>{event.preventDefault();return submit()};input.style.fontSize=target.size+'px';pageEditing=onPageText({root:form,input,overlay,rect:target.rect,bounds,zoom,width:()=>widthInput?+widthInput.value:target.rect[2]-target.rect[0],leading:target.layout?.leading?target.layout.leading+'px':1.2});input.style.fontSize=target.size+'px';input.focus({preventScroll:true});if(!focusPageTextAt(input,caretPoint))input.select();const releaseStyle=styles?.mount(form.querySelector('.toolbar-fields')||form,{kind:'text',read:formatting.readStyle,apply:style=>{formatting.applyStyle(style);schedulePreview()}});return{close:()=>{releaseStyle?.();close()},form,input,hasChanges,flushPreview,snapshot:()=>({format:formatting.snapshot(),controls:captureControls(form),boxes:correction?.rects()}),restore:s=>{restoreControls(form,s.controls);formatting.restore(s.format);if(s.boxes)correction?.restore(s.boxes);schedulePreview()}};
}
