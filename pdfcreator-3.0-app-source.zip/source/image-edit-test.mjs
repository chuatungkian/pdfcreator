/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {imageTargets,editImage,imageSettings,readImageRGBA,adjustImagePixels,croppedImageFrame} from './image-edit.js';
let context;
try{
 context=await boot();const {app}=context,PDF=app.PDFLib,m=app.Engine.mupdf;
 const canvasImage=canvas.createCanvas(80,60),ctx=canvasImage.getContext('2d');for(const [colour,x,y]of [['#ff0000',0,0],['#00ff00',40,0],['#0000ff',0,30],['#ffff00',40,30]]){ctx.fillStyle=colour;ctx.fillRect(x,y,40,30)}
 const pdf=await PDF.PDFDocument.create(),im=await pdf.embedPng(canvasImage.toBuffer('image/png'));for(let n=0;n<2;n++){const p=pdf.addPage([500,600]);p.drawText('BODY MUST SURVIVE',{x:40,y:520,size:15});p.drawImage(im,{x:100,y:200,width:200,height:120});p.drawImage(im,{x:320,y:200,width:100,height:60})}
 const bytes=new Uint8Array(await pdf.save({useObjectStreams:false}));
 async function change(input,fn){const d=app.Engine.openPDF(input);try{await fn(d);return saveDirectEdit(d)}finally{d.destroy()}}
 function colour(input,x,y,index=0){const d=app.Engine.openPDF(input),p=d.loadPage(index),pix=p.toPixmap(m.Matrix.identity,m.ColorSpace.DeviceRGB,false,true);try{const data=pix.getPixels(),at=(Math.floor(y)*pix.getWidth()+Math.floor(x))*3;return[...data.slice(at,at+3)]}finally{pix.destroy();p.destroy();d.destroy()}}
 let native=app.Engine.openPDF(bytes),targets=imageTargets(native,0);equal(targets.length,2,'both image occurrences found');equal(targets[0].rect,[100,280,300,400],'native displayed image bounds');const rgba=readImageRGBA(native,targets[0]);equal([...rgba.rgba.slice(0,4)],[255,0,0,255],'source RGB decoded');native.destroy();
 const crop={left:.5,top:0,right:0,bottom:0},cropped=await change(bytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{crop}));equal(colour(cropped,150,300),[255,255,255],'cropped-away half no longer painted');equal(colour(cropped,220,300),[0,255,0],'right crop retains green quadrant');equal(colour(cropped,220,370),[255,255,0],'crop retains vertical orientation');equal(colour(cropped,330,350),colour(bytes,330,350),'shared image occurrence unaffected');equal(app.Engine.renderPagePNG(cropped,1,{scale:1}).bytes,app.Engine.renderPagePNG(bytes,1,{scale:1}).bytes,'other page pixels unchanged');
 native=app.Engine.openPDF(cropped);targets=imageTargets(native,0);equal(targets.length,2,'edited wrapper remains selectable');equal(targets[0].settings.crop,crop,'crop recipe survives reopening');equal(targets[0].rect,[200,280,300,400],'crop trims frame rather than stretches');native.destroy();
 const restored=await change(cropped,doc=>editImage(doc,0,imageTargets(doc,0)[0],{}));equal(app.Engine.renderPagePNG(restored,0,{scale:1}).bytes,app.Engine.renderPagePNG(bytes,0,{scale:1}).bytes,'uncropping restores original image pixels and frame');
 const opacity=await change(bytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{opacity:.5}));check(colour(opacity,120,300)[0]===255&&Math.abs(colour(opacity,120,300)[1]-128)<2,'opacity blends image independently');
 const adjusted=await change(bytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{saturation:-100,brightness:-10}));const grey=colour(adjusted,120,300);check(grey[0]===grey[1]&&grey[1]===grey[2]&&grey[0]<60,'saturation and brightness alter image pixels');equal(colour(adjusted,330,350),colour(bytes,330,350),'colour changes isolate shared instance');
 const moved=await change(bytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{}, {geometry:{x:40,y:60,width:100,height:60}}));native=app.Engine.openPDF(moved);check(imageTargets(native,0)[0].rect.every((v,i)=>Math.abs(v-[40,60,140,120][i])<.001),'move and resize persist');native.destroy();
 const deleted=await change(bytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{}, {remove:true}));native=app.Engine.openPDF(deleted);equal(imageTargets(native,0).length,1,'deletion removes only selected occurrence');check(app.Engine.extractTextPDF(deleted)[0].text.includes('BODY MUST SURVIVE'),'image deletion preserves native text');native.destroy();
 // Imported nested Form occurrences share their resources until a leaf is edited.
 const formDoc=await PDF.PDFDocument.create(),formPage=formDoc.addPage([500,600]);formPage.drawImage(await formDoc.embedPng(canvasImage.toBuffer('image/png')),{x:100,y:200,width:200,height:120});formPage.drawText('NESTED CAPTION',{x:70,y:500,size:14});const container=await PDF.PDFDocument.create(),form=await container.embedPage((await PDF.PDFDocument.load(await formDoc.save({useObjectStreams:false}))).getPage(0));const cp=container.addPage([1000,600]);cp.drawPage(form,{x:0,y:0});cp.drawPage(form,{x:500,y:0});const nestedBytes=new Uint8Array(await container.save({useObjectStreams:false}));native=app.Engine.openPDF(nestedBytes);equal(imageTargets(native,0).length,2,'nested Form images found');native.destroy();const nestedEdited=await change(nestedBytes,doc=>editImage(doc,0,imageTargets(doc,0)[0],{brightness:-100}));equal(colour(nestedEdited,120,300),[0,0,0],'nested image adjusted');equal(colour(nestedEdited,620,300),colour(nestedBytes,620,300),'shared enclosing Form occurrence is isolated');check(app.Engine.extractTextPDF(nestedEdited)[0].text.includes('NESTED CAPTION'),'nested caption survives');
 for(const rotation of [0,90,180,270]){const r=await PDF.PDFDocument.load(bytes);r.getPage(0).setRotation(PDF.degrees(rotation));r.getPage(0).setCropBox(10,20,470,550);const rb=new Uint8Array(await r.save({useObjectStreams:false}));let old;native=app.Engine.openPDF(rb);old=imageTargets(native,0)[0];const expected=croppedImageFrame(old,crop).rect;native.destroy();const result=await change(rb,doc=>editImage(doc,0,imageTargets(doc,0)[0],{crop,opacity:.7}));native=app.Engine.openPDF(result);check(imageTargets(native,0)[0].rect.every((v,i)=>Math.abs(v-expected[i])<.01),'crop respects page rotation and origin '+rotation);native.destroy()}
 // Source alpha survives colour adjustment, including the soft-mask image.
 const alphaCanvas=canvas.createCanvas(80,60),ac=alphaCanvas.getContext('2d');ac.fillStyle='#ff000080';ac.fillRect(20,10,40,40);const ad=await PDF.PDFDocument.create();ad.addPage([200,200]).drawImage(await ad.embedPng(alphaCanvas.toBuffer('image/png')),{x:20,y:20,width:80,height:60});const ab=new Uint8Array(await ad.save({useObjectStreams:false}));native=app.Engine.openPDF(ab);const ar=readImageRGBA(native,imageTargets(native,0)[0]);equal(ar.rgba[3],0,'transparent source border decoded');check(ar.rgba[(20*80+30)*4+3]>120&&ar.rgba[(20*80+30)*4+3]<135,'partial source alpha decoded');native.destroy();const aa=await change(ab,doc=>editImage(doc,0,imageTargets(doc,0)[0],{brightness:-10}));equal(colour(aa,22,125),[255,255,255],'adjusted transparent border remains clear');check(colour(aa,50,150)[0]>200&&colour(aa,50,150)[1]>120,'adjusted image retains partial transparency');
 equal([...adjustImagePixels(new Uint8ClampedArray([10,100,240,123]),{})],[10,100,240,123],'neutral adjustment is pixel-identical');const tone=adjustImagePixels(new Uint8ClampedArray([100,100,100,255]),{warmth:100});check(tone[0]>tone[2],'warm colour tone');assert.throws(()=>imageSettings({crop:{left:.8,right:.8}}),/Keep at least/);assertions++;
 // Repeated adjustment must not retain superseded full-sized pixel copies.
 let repeated=adjusted,firstCount;for(let n=0;n<8;n++){repeated=await change(repeated,doc=>editImage(doc,0,imageTargets(doc,0)[0],{brightness:n+1}));native=app.Engine.openPDF(repeated);const count=native.countObjects();if(!n)firstCount=count;if(n===7)check(count<=firstCount+3,'repeated Apply prunes superseded adjusted image resources');native.destroy()}
 equal(colour(repeated,330,350),colour(bytes,330,350),'repeated Apply preserves other occurrences');
 native=app.Engine.openPDF(repeated);let generic=pageObjects(native,0).find(t=>t.type==='Image');check(!!generic,'adjusted image remains an Image in Select objects');transformObject(native,0,generic,{action:'duplicate',matrix:objectMatrix(generic.rect,{x:30,y:30,width:100,height:60,rotation:20})});const duplicated=saveDirectEdit(native);native.destroy();native=app.Engine.openPDF(duplicated);equal(imageTargets(native,0).length,3,'adjusted image can be duplicated and rotated');native.destroy();const copyChanged=await change(duplicated,doc=>editImage(doc,0,imageTargets(doc,0)[1],{brightness:-50}));equal(colour(copyChanged,120,300),colour(duplicated,120,300),'adjusting rotated duplicate leaves original image intact');
 const controller=new AbortController();controller.abort();native=app.Engine.openPDF(bytes);await assert.rejects(()=>editImage(native,0,imageTargets(native,0)[0],{brightness:30},{signal:controller.signal}),e=>e.name==='AbortError');assertions++;equal(imageTargets(native,0)[0].settings.brightness,0,'cancelled adjustment leaves source image unchanged');native.destroy();
 fs.writeFileSync('image-edit-proof.png',app.Engine.renderPagePNG(nestedEdited,0,{scale:.8}).bytes);
 await context.close();context=null;console.log('PDFCreator image editing: '+assertions+' assertions passed with native PDF pixels and shared/nested image instances.');
}finally{if(context)await context.close()}
