/* Visual-signature composition regression with real PNG/PDF pixels and a controlled DOM. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 const doc=await app.PDFLib.PDFDocument.create();doc.addPage([595,842]);doc.addPage([595,842]);await app.openFiles([file('Signature test.pdf',await doc.save())]);app.state.fit=false;app.state.zoom=1;await app.render();
 const path=[[80,160],[140,90],[130,200],[240,120],[310,170],[400,90],[460,160],[700,145]];
 function pointer(node,type,x,y,{id=1,button=0,primary=true}={}){const event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button});Object.defineProperties(event,{pointerId:{value:id},isPrimary:{value:primary}});node.dispatchEvent(event)}
 async function begin(){if(app.state.tool==='signatureImage')await app.activate('signature');const task=app.activate('signature');await until(()=>$('sigtext'),'signature dialogue');const c=$('drawcanvas');c.getBoundingClientRect=()=>({left:0,top:0,width:450,height:150});return{task,c}}
 function draw(c){pointer(c,'pointerdown',path[0][0]/2,path[0][1]/2);for(const point of path.slice(1,-1))pointer(c,'pointermove',point[0]/2,point[1]/2);pointer(c,'pointerup',path.at(-1)[0]/2,path.at(-1)[1]/2)}
 const submit=()=> $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
 async function decoded(bytes){const image=await canvas.loadImage(Buffer.from(bytes)),c=canvas.createCanvas(image.width,image.height);c.getContext('2d').drawImage(image,0,0);return{width:image.width,height:image.height,pixels:c.getContext('2d').getImageData(0,0,image.width,image.height).data}}
 function alpha(image,top,bottom){let count=0;for(let y=top;y<bottom;y++)for(let x=0;x<image.width;x++)if(image.pixels[(y*image.width+x)*4+3]>60)count++;return count}
 function pdfInk(top,bottom,bytes=app.state.bytes){const r=app.Engine.renderPagePixels(bytes,0,{scale:1});let count=0;for(let y=top;y<bottom;y++)for(let x=50;x<500;x++){const i=y*r.stride+x*r.components;if(r.pixels[i]<180&&r.pixels[i+1]<180&&r.pixels[i+2]<180)count++}return count}
 let editor=await begin();$('sigtext').value='Alex Morgan';draw(editor.c);const source=editor.c.getContext('2d').getImageData(0,0,900,300).data.slice();check(editor.c.dataset.drawn==='1','drawing is present before submission');submit();await editor.task;
 const combinedBytes=app.state.selectedImage.bytes,combined=await decoded(combinedBytes);equal(combined.width,900,'combined signature keeps drawing resolution');check(combined.height>300,'name has its own space below the drawing');check(alpha(combined,0,300)>500,'combined PNG retains drawn strokes');check(alpha(combined,300,combined.height)>1000,'combined PNG retains the typed name');equal(editor.c.getContext('2d').getImageData(0,0,900,300).data,source,'confirmation does not erase or overwrite the source drawing');check(alpha(combined,0,combined.height)<combined.width*combined.height/3,'combined signature keeps transparent background');equal(app.state.tool,'signatureImage','combined signature enters placement mode');
 const before=app.state.bytes;pointer($('overlay'),'pointerdown',50,80);pointer($('overlay'),'pointermove',500,310);pointer($('overlay'),'pointerup',500,310);await until(()=>app.state.bytes!==before&&!app.state.abort,'combined signature placed');await app.local.flush();await pause();
 check(pdfInk(80,230)>100,'saved PDF contains the drawn signature');check(pdfInk(230,310)>100,'saved PDF contains the typed name below it');equal(app.state.tool,'signatureImage','signature stays selected after placement');
 await $('undo').onclick();equal(pdfInk(80,310),0,'undo removes the whole combined image');await $('redo').onclick();check(pdfInk(80,230)>100&&pdfInk(230,310)>100,'redo restores both drawing and name');equal(app.state.selectedImage.bytes,combinedBytes,'placement and undo/redo do not alter signature image');
 fs.writeFileSync('visual-signature-proof.png',app.Engine.renderPagePNG(app.state.bytes,0,{scale:1}).bytes);
 editor=await begin();draw(editor.c);submit();await editor.task;const drawn=await decoded(app.state.selectedImage.bytes);equal(drawn.height,300,'drawn-only output retains original drawing area');check(alpha(drawn,0,300)>500,'drawn-only signature remains visible');
 editor=await begin();$('sigtext').value='Typed only';$('dialogFont').value='Georgia';submit();await editor.task;const typed=await decoded(app.state.selectedImage.bytes);equal(typed.height,300,'typed-only output retains its normal dimensions');check(alpha(typed,0,300)>1000,'typed-only signature remains visible');equal(app.state.font,'Georgia','typed signature retains selected font');
 editor=await begin();$('sigtext').value='Name after clear';draw(editor.c);$('clearsig').click();check(!editor.c.dataset.drawn,'Clear drawing resets drawn state');equal($('sigtext').value,'Name after clear','Clear drawing preserves typed name');const cleared=editor.c.getContext('2d').getImageData(0,0,900,300).data;check(!cleared.some((value,i)=>i%4===3&&value),'Clear drawing removes only drawn pixels');submit();await editor.task;equal((await decoded(app.state.selectedImage.bytes)).height,300,'cleared drawing is not included in final image');
 editor=await begin();const unmodified=app.state.bytes;submit();await pause();check(!!$('modalform')&&$('modalerror').textContent.includes('Type, draw, or import'),'empty signature stays in dialogue with useful message');equal(app.state.bytes,unmodified,'invalid signature does not edit PDF');
 pointer(editor.c,'pointerdown',45,45,{primary:false});pointer(editor.c,'pointerdown',45,45,{button:2});check(!editor.c.dataset.drawn,'secondary/right-button gestures do not draw');$('sigtext').value='Tap and name';pointer(editor.c,'pointerdown',45,45);pointer(editor.c,'pointerup',45,45);submit();await editor.task;const tapped=await decoded(app.state.selectedImage.bytes);check(alpha(tapped,0,300)>0&&alpha(tapped,300,tapped.height)>1000,'pen tap and typed name both appear');
 const retained=app.state.selectedImage,font=app.state.font;editor=await begin();$('sigtext').value='Cancelled';$('dialogFont').value='Consolas';draw(editor.c);$('modalcancel').click();await editor.task;equal(app.state.selectedImage,retained,'cancel preserves previously selected image');equal(app.state.font,font,'cancel preserves document font');
 editor=await begin();const importedCanvas=canvas.createCanvas(80,30);importedCanvas.getContext('2d').fillRect(10,10,60,10);const imported=new Uint8Array(importedCanvas.toBuffer('image/png'));$('sigtext').value='Unused with import';draw(editor.c);Object.defineProperty($('sigfile'),'files',{configurable:true,value:[{name:'signature.PNG',type:'',arrayBuffer:async()=>imported.slice().buffer}]});submit();await editor.task;equal(app.state.selectedImage.bytes,imported,'image import remains a standalone signature');equal(app.state.selectedImage.type,'image/png','PNG filename handles an empty browser MIME type');
 editor=await begin();$('sigtext').value='Recovered name';draw(editor.c);submit();await editor.task;const recoveredBytes=app.state.selectedImage.bytes,owner=app.activeTabId;await app.local.flush();await context.close();context=await boot();({app,$,window}=context);equal(app.activeTabId,owner,'signature document recovers');equal(app.state.tool,'signatureImage','signature placement mode recovers');equal(app.state.selectedImage.bytes,recoveredBytes,'combined signature bytes recover intact');const recovered=await decoded(app.state.selectedImage.bytes);check(alpha(recovered,0,300)>500&&alpha(recovered,300,recovered.height)>1000,'recovered signature retains both components');
 await context.close();context=null;console.log('pdfpro visual signatures: '+assertions+' assertions passed with PNG/native PDF pixels and simulated recovery.');
}finally{if(context)await context.close()}
