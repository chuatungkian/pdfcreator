/* Actual embedded PDF/OCR engines in a Node VM worker adapter. No browser or user files are opened. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {gunzipSync} from 'node:zlib';
import {installTestWorkers} from './test-worker-runtime.mjs';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
const runtime=installTestWorkers();
try{
 context=await boot();const {app,$,window}=context;const html=fs.readFileSync('../../outputs/pdfcreator.html','utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64')));window.PDFPRO_ASSETS=assets;
 const original=await fixture(app,'NATIVE WORKER');const extracted=await app.backgroundEngine('extractTextPDF',[original]);check(extracted[0].text.includes('NATIVE WORKER'),'real embedded background engine extracts text');
 const encrypted=await app.backgroundEngine('protectPDF',[original,{password:'worker-password',ownerPassword:'worker-owner'}]);assertions++;assert.throws(()=>app.Engine.openPDF(encrypted),/password/);const doc=app.Engine.openPDF(encrypted,'worker-password');equal(doc.countPages(),2,'worker encryption creates openable PDF');doc.destroy();
 const optimised=await app.backgroundEngine('optimizePDF',[original]);check(app.Engine.extractTextPDF(optimised)[0].text.includes('NATIVE WORKER'),'worker optimisation preserves text');
 const replaced=await app.backgroundEngine('replaceTextPDF',[original,[{page:0,rect:[30,60,300,110],text:'WORKER REPLACED',size:14}]]);check(app.Engine.extractTextPDF(replaced)[0].text.includes('WORKER REPLACED'),'worker bounded replacement writes new text');check(app.Engine.extractTextPDF(replaced)[1].text.includes('NATIVE WORKER'),'worker replacement preserves other pages');
 const image=await app.backgroundEngine('renderPagePNG',[original,0,{scale:.5}]);equal([...image.bytes.slice(0,8)],[137,80,78,71,13,10,26,10],'worker raster output');
 const redacted=await app.backgroundEngine('redactPDF',[original,[{page:0,rect:[20,20,150,100]}],{rasterize:true,dpi:72,sanitize:true}]);check(app.Engine.extractTextPDF(redacted.bytes||redacted).every(page=>!page.text.trim()),'worker secure redaction removes all search text');
 const sanitised=await app.backgroundEngine('sanitizePDF',[original,{rasterize:true,dpi:72}]);equal(app.Engine.inspectPDF(sanitised.bytes||sanitised).forms,0,'worker sanitisation removes interactive data');
 const aborted=new AbortController();aborted.abort();assertions++;await assert.rejects(()=>app.backgroundEngine('extractTextPDF',[original],aborted.signal),{name:'AbortError'});
 app.OCR.configureOCR(assets.ocr);const c=canvas.createCanvas(1200,220),ctx=c.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,1200,220);ctx.fillStyle='black';ctx.font='72px Arial';ctx.fillText('PDFPRO OFFLINE TEST 123',30,130);const result=await app.OCR.recognizeImage(new Uint8Array(c.toBuffer('image/png')),{pageSegmentation:6});check(result.text.includes('OFFLINE TEST 123'),'embedded OCR core and English model recognise real pixels');check(result.words.length>=4&&result.confidence>70,'OCR words and confidence produced');
 equal(runtime.networkAttempts,0,'engines use no network');app.OCR.cancelOCR();await context.close();context=null;console.log('pdfpro embedded engine/OCR workers: '+assertions+' assertions passed in Node VM worker transport (not a browser).');
}finally{if(context)await context.close();runtime.close()}
