// Self-contained, currentColour icons for the compact tool dock.
// Buttons provide their own accessible names; these SVGs are decorative.
const page = '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/>';
const form = '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h3M8 15h3M8 18h3"/>';
const landscape = '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="1.5"/><path d="m3 17 5-5 4 4 3-3 6 6"/>';
const bubble = '<path d="M20 14a3 3 0 0 1-3 3H9l-5 4v-5a3 3 0 0 1-2-3V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3z"/>';
const t = '<path d="M7 6h10M12 6v12M9 18h6"/>';
const lock = '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>';
const shield = '<path d="m12 2 8 3v6c0 5-3 8-8 11-5-3-8-6-8-11V5z"/>';
const imageFile = letter => page + '<path d="m8 16 3-3 3 3M8 18h8"/>' + `<text x="15.4" y="12" fill="currentColor" stroke="none" font-family="sans-serif" font-size="5.4" font-weight="700" text-anchor="middle">${letter}</text>`;

const icons = {
  objects:'<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M2 2h4v4H2zM18 2h4v4h-4zM2 18h4v4H2zM18 18h4v4h-4z"/>',
  eraser:'<path d="m4 13 9-10 8 8-10 10H7l-5-5zM7 10l8 8M11 21h11"/>',
  findreplace:'<circle cx="9" cy="8" r="5"/><path d="m13 12 4 4M3 19h15m-3-3 3 3-3 3"/>',
  directedit: '<path d="M3 4h10M8 4v14M4 18h7m3-5 6-6 3 3-6 6-4 1z"/>',
  view: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  edit: '<path d="m15 4 5 5M4 20l5-1L21 7a2.1 2.1 0 0 0-5-4L4 15zM4 15l5 4"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  bookmarks: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  metadata: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7v.2"/>',
  attachments: '<path d="m8 12 7-7a4 4 0 0 1 6 6l-9 9a6 6 0 0 1-8-8l9-9M7 15l9-9a1.4 1.4 0 0 1 2 2l-9 9a2 2 0 0 1-3-3"/>',

  rotate: '<path d="M4 9a8 8 0 1 1 0 7M4 3v6h6"/><rect x="10" y="10" width="7" height="9" rx="1"/>',
  duplicate: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3M11 14h6M14 11v6"/>',
  moveup: '<path d="m12 3-5 5m5-5 5 5M12 3v13M5 17v4h14v-4"/>',
  movedown: '<path d="m12 17-5-5m5 5 5-5M12 17V4M5 17v4h14v-4"/>',
  delete: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
  blank: page + '<path d="M9 14h6M12 11v6"/>',
  merge: '<path d="M3 3h6v7H3zM15 3h6v7h-6zM6 10v3h12v-3M12 13v8m-3-3 3 3 3-3"/>',
  extract: '<path d="M13 3H4v18h9M9 12h12m-4-4 4 4-4 4"/>',
  split: '<path d="M12 3v7M5 21v-7h14v7M12 10v4m-10 4 3 3 3-3m8 0 3 3 3-3"/>',
  reorder: '<path d="M4 5h10M4 12h7M4 19h10M18 3v18m-3-15 3-3 3 3m-6 12 3 3 3-3"/>',
  crop: '<path d="M6 3v15h15M3 6h15v15M3 21 21 3"/>',
  resize: '<path d="M9 3H3v6M3 3l7 7M15 21h6v-6m0 6-7-7M15 3h6v6M9 21H3v-6"/>',

  text: t,
  image: landscape,
  replace: '<path d="M3 8h6M6 8v8M15 8h6M18 8v8M3 4h15m-2-2 2 2-2 2M21 20H6m2-2-2 2 2 2"/>',
  link: '<path d="m10 13 4-4M8 15l-2 2a3.5 3.5 0 0 1-5-5l5-5a3.5 3.5 0 0 1 5 0m2 10a3.5 3.5 0 0 0 5 0l5-5a3.5 3.5 0 0 0-5-5l-2 2" transform="translate(1 0) scale(.92)"/>',
  watermarks: page + '<path d="m8 16 8-8 3 3-8 8-4 1z"/>',
  watermark: page + '<path d="M12 10c-1.5 2-3 3.5-3 5a3 3 0 0 0 6 0c0-1.5-1.5-3-3-5z"/>',
  number: page + '<path d="m10 11-1 7m5-7-1 7M8 13h8M8 16h8"/>',
  bates: '<path d="M5 16h14l2 5H3zM8 16v-4h8v4M10 12V8a2 2 0 0 1 4 0v4M3 3h6m-4 0v5m-2 0h4M17 3h4m-4 4h4m-3-6-1 8m4-8-1 8"/>',
  header: page + '<path d="M8 11h8M8 17h8M8 13v2M16 13v2"/>',

  highlight: '<path d="m5 16 9-12 6 5-10 11H5zM13 6l5 4M5 16l5 4M2 22h20"/>',
  underline: '<path d="M6 3v8a6 6 0 0 0 12 0V3M4 21h16"/>',
  strikeout: '<path d="M17 6c-1-2-3-3-6-3-3 0-5 1.5-5 4 0 3 3 3.5 6 4m-9 1h18M7 17c1 3 3 4 6 4s5-1.5 5-4c0-1.7-1.3-2.7-3-3.5"/>',
  note: '<path d="M20 14V4H4v16h10zM14 20v-6h6M8 8h8M8 11h5"/>',
  freetext: bubble + '<path d="M7 7h8M11 7v6"/>',
  ink: '<path d="m4 16 12-12a2 2 0 0 1 3 0l1 1a2 2 0 0 1 0 3L8 20l-5 1zM14 6l4 4M4 16l4 4M12 21h9"/>',
  rectangle: '<rect x="3" y="5" width="18" height="14" rx="1"/>',
  ellipse: '<ellipse cx="12" cy="12" rx="9" ry="7"/>',
  line: '<path d="m4 20 16-16"/><circle cx="4" cy="20" r="1"/><circle cx="20" cy="4" r="1"/>',
  arrow: '<path d="M4 20 20 4M10 4h10v10"/>',
  stamp: '<path d="M8 15v-4h2V6a2 2 0 0 1 4 0v5h2v4M5 15h14l2 5H3zM6 23h12"/>',
  comments: '<path d="M16 12H8l-5 4V4h13zM8 16v2h8l5 3V9h-2"/>',

  fill: form + '<path d="m13 17 6-6 2 2-6 6-3 1z"/>',
  fieldText: '<rect x="3" y="5" width="18" height="14" rx="2"/>' + '<path d="M8 9h8M12 9v6M10 15h4"/>',
  fieldCheck: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="m8 12 3 3 6-6"/>',
  fieldRadio: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="6" cy="6" r=".7" fill="currentColor"/><path d="M13 6h8M13 18h8"/>',
  fieldDropdown: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M15 5v14m-9-7 3 3 3-3"/>',
  flatten: '<path d="m3 7 9 5 9-5-9-5zM3 12l9 5 9-5M3 17l9 5 9-5M12 4v6"/>',
  formexport: '<path d="M12 3H4v18h8M7 7h4M7 11h4M7 15h4M13 12h9m-4-4 4 4-4 4"/>',
  formimport: '<path d="M12 3h8v18h-8M13 7h4M13 17h4M2 12h13m-4-4 4 4-4 4"/>',

  ocr: '<path d="M3 8V3h5M16 3h5v5M21 16v5h-5M8 21H3v-5M7 8h10M12 8v9M9 17h6"/>',
  compare: '<path d="M3 3h7v18H3zM14 3h7v18h-7zM5 7h3M5 11h3M16 7h3M16 11h3M5 16h3M16 16h3"/>',
  textExport: '<path d="M13 3H4v18h9M7 8h6M10 8v8M14 13h8m-3-3 3 3-3 3"/>',
  optimize: '<path d="M3 3l6 6M3 9h6V3M21 3l-6 6m0-6v6h6M3 21l6-6m-6 0h6v6m12 0-6-6m0 6v-6h6"/>',

  redact: page + '<rect x="8" y="11" width="8" height="3" fill="currentColor" stroke="none"/><rect x="8" y="16" width="6" height="2" fill="currentColor" stroke="none"/>',
  applyredact: '<rect x="3" y="4" width="16" height="7" rx="1" fill="currentColor" stroke="none"/><path d="M3 16h6m3 2 3 3 7-8"/>',
  clearmarks: '<path d="m4 13 9-10 8 7L11 21H7zM9 8l8 7M11 21h10"/>',
  sanitize: shield + '<path d="m12 7 1.3 3.7L17 12l-3.7 1.3L12 17l-1.3-3.7L7 12l3.7-1.3z"/>',
  encrypt: lock,
  signature: '<path d="M3 17c5-2 11-10 9-13-2-3-7 10-5 14 2 4 7-5 9-4 2 0-1 4 1 4l4-2M3 22h18"/>',
  certsign: '<path d="M14 3H4v18h7M14 3v5h5v4M14 3l5 5"/><circle cx="16" cy="16" r="3"/><path d="m14 19-1 4 3-2 3 2-1-4M7 8h3M7 12h3"/>',
  verify: shield + '<path d="m8 11 3 3 5-5"/>',

  save: '<path d="M3 3h15l3 3v15H3zM7 3v6h10V3M7 21v-8h10v8M14 5v2"/>',
  png: imageFile('P'),
  jpeg: imageFile('J'),
  allimages: '<path d="M3 16V3h14M6 19V6h14"/><rect x="9" y="9" width="13" height="13" rx="1"/><path d="m9 19 4-5 4 4 2-2 3 4"/><circle cx="18" cy="13" r="1"/>',
  project: '<path d="M21 9V6a1 1 0 0 0-1-1h-8l-2-2H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-3M12 9v9m-3-3 3 3 3-3"/>',
  restore: '<path d="M3 11V5h7l2 2h8v4M3 11h19l-3 10H2zM12 17V7m-3 3 3-3 3 3"/>',
  batch: '<path d="M4 16H2V2h14v2M7 19H5V5h14v2"/><rect x="8" y="8" width="14" height="14" rx="1"/><path d="m11 15 3 3 5-6"/>',
  print: '<path d="M6 8V3h12v5M6 17H3V8h18v9h-3M6 14h12v7H6zM17 11h1"/>'
};

export function toolIcon(key) {
  const drawing = Object.hasOwn(icons, key) ? icons[key] : page;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${drawing}</svg>`;
}
