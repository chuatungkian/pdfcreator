/* Offline source reconstruction tests using native ZIP/DEFLATE verification. */
import assert from 'node:assert/strict';
import {deflateRawSync} from 'node:zlib';
import {sourceCRC,rebuildSourceZip} from './source-package.js';
import {readTestZip} from './source-zip-test-utils.mjs';
let count=0;
const check=(value,label)=>{count++;assert.ok(value,label)};
const equal=(a,b,label)=>{count++;assert.deepEqual(a,b,label)};
const fails=async(value,label)=>{count++;await assert.rejects(()=>rebuildSourceZip(value,{fontBase64:font}),undefined,label)};
const b64=bytes=>Buffer.from(bytes).toString('base64');
const common=Buffer.from('Local source text · 日本語\n'.repeat(30));
const compressed=deflateRawSync(common),font=b64(Buffer.from([0,255,1,254,0,253]));
const shared={mupdf:Buffer.from([0,97,115,109,1,0,0,0]),'ocr-wasm':Buffer.from('ocr-core'.repeat(100)),'ocr-model':Buffer.from('recognition-model'.repeat(100)),'ocr-worker':Buffer.from('/* worker */'.repeat(100)),'ocr-core':Buffer.from('/* core · */'.repeat(100)),notices:Buffer.from('Licences · 日本語'),inter:Buffer.from(font,'base64')};
const assets={mupdfBase64:b64(shared.mupdf),ocr:{coreWasmBase64:b64(shared['ocr-wasm']),languageDataBase64:b64(shared['ocr-model']),workerSource:shared['ocr-worker'].toString(),coreSource:shared['ocr-core'].toString()},notices:shared.notices.toString(),sourceArchive:{version:1,poolBase64:b64(compressed),entries:[
 {name:'source/main.mjs',size:common.length,crc:sourceCRC(common),offset:0,length:compressed.length},
 {name:'source/alias/main.mjs',size:common.length,crc:sourceCRC(common),offset:0,length:compressed.length},
 ...Object.entries(shared).map(([asset,bytes])=>({name:'source/shared/'+asset,size:bytes.length,crc:sourceCRC(bytes),asset}))
]}};
equal(sourceCRC(Buffer.from('123456789')),0xcbf43926,'CRC agrees with the standard reference');
const blob=await rebuildSourceZip(assets,{fontBase64:font}),bytes=Buffer.from(await blob.arrayBuffer()),entries=readTestZip(bytes);
equal(blob.type,'application/zip','source download has ZIP MIME type');equal(entries.size,9,'all source paths retained');
equal(entries.get('source/main.mjs').bytes,common,'original compressed source is unchanged');equal(entries.get('source/alias/main.mjs').bytes,common,'duplicate source path is recreated');
for(const[key,value]of Object.entries(shared))equal(entries.get('source/shared/'+key).bytes,value,'shared '+key+' is byte-identical');
check(entries.get('source/shared/ocr-model').method===8,'native compression creates a valid compressed ZIP entry');
for(const Compression of [null,class{constructor(){throw Error('No compression')}}]){
 const fallback=readTestZip(Buffer.from(await(await rebuildSourceZip(assets,{fontBase64:font,Compression})).arrayBuffer()));
 check([...Object.keys(shared)].every(key=>fallback.get('source/shared/'+key).method===0),'fallback stores shared assets without requiring a new browser API');
 check([...entries].every(([name,entry])=>entry.bytes.equals(fallback.get(name).bytes)),'fallback preserves all source bytes');
}
equal(Buffer.from(await(await rebuildSourceZip({sourceZip:b64(bytes)})).arrayBuffer()),bytes,'legacy full source archives remain supported');
const change=(index,patch)=>({...assets,sourceArchive:{...assets.sourceArchive,entries:assets.sourceArchive.entries.map((entry,i)=>i===index?{...entry,...patch}:entry)}});
for(const name of ['source/../outside','/source/file','source/./file','source/file\\other','source//file','source/file\0other','outside/file'])await fails(change(0,{name}),'unsafe source path refused');
await fails(change(1,{name:'source/main.mjs'}),'duplicate paths refused');
await fails(change(0,{offset:-1}),'negative pool offset refused');await fails(change(0,{length:compressed.length+1}),'pool overrun refused');
await fails(change(0,{size:-1}),'negative size refused');await fails(change(2,{size:100}),'damaged shared asset length refused');await fails(change(2,{crc:1}),'damaged shared asset checksum refused');
await fails(change(2,{asset:'unknown'}),'unknown asset reference refused');
await fails({...assets,sourceArchive:{...assets.sourceArchive,version:2}},'future archive versions fail clearly');
await fails({},'missing source data fails clearly');
console.log('pdfpro source packaging: '+count+' assertions passed with native ZIP/DEFLATE verification.');
