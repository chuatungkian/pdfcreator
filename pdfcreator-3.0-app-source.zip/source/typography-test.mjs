/* Interface cascade regression; native PDF text sizes remain independent. */
import assert from 'node:assert/strict';
import {boot} from './experience-test-env.mjs';
let context,count=0;const equal=(a,b,label)=>{count++;assert.equal(a,b,label)};
try{
 context=await boot();const {app,window,$}=context;
 const size=node=>{let value=window.getComputedStyle(node).fontSize;for(let n=0;n<4&&value.startsWith('var(');n++){const key=value.match(/var\((--[^,)]+)/)?.[1];value=window.getComputedStyle(document.documentElement).getPropertyValue(key).trim()}return value};
 equal(size(document.querySelector('#quickTools>p.help')),'11px','highlighted Home help uses help size');
 await app.createDemo();await $('homeBtn').onclick();
 const end=Date.now()+5000;while(!document.querySelector('.recent-meta')){if(Date.now()>end)throw Error('Recent project not rendered');await new Promise(r=>setTimeout(r,10))}
 equal(size(document.querySelector('.recent-meta')),'10px','project metadata does not inherit Home paragraph size');
 equal(size(document.querySelector('.recent-body h3')),'12px','project tile title uses label size');
 equal(size(document.querySelector('.home-subtitle')),'11px','Home description uses help size');
 await app.switchTab(app.activeTabId);
 for(const group of ['View','Organize','Edit','Annotate','Forms','OCR & compare','Protect & sign','Export & batch']){
  await document.querySelector('[data-group="'+group+'"]').onclick();
  for(const button of document.querySelectorAll('#panel .toolgrid button'))equal(size(button),'12px',group+' tile '+button.dataset.tool);
  equal(size(document.querySelector('#panel>h2')),'18px',group+' panel heading');
 }
 const fixture=document.createElement('section');fixture.className='modal';fixture.innerHTML='<h2>Settings</h2><p>Body</p><p class="help">Help</p><label>Name</label><input><select><option>Value</option></select><button>Apply</button><small class="help">Hint</small>';document.body.append(fixture);
 for(const selector of ['input','select','button','p:not(.help)'])equal(size(fixture.querySelector(selector)),'12px','dialogue '+selector);
 for(const selector of ['label','p.help','small.help'])equal(size(fixture.querySelector(selector)),'11px','dialogue '+selector);
 equal(size(fixture.querySelector('h2')),'20px','dialogue heading');fixture.remove();
 const panel=document.createElement('div');panel.className='inspector-body';panel.innerHTML='<div class="object-inspector"><div class="object-actions"><button>Apply</button></div><label>X<input></label></div><div class="image-property-grid"><label>Width<input></label></div><input class="direct-editor-input" style="font-size:27px"><textarea id="nativeFieldValue" style="font-size:19px"></textarea><div class="inline-text-input"><span style="font-size:31px">PDF text</span></div>';document.body.append(panel);
 for(const node of panel.querySelectorAll('.object-inspector button,.object-inspector input,.image-property-grid input'))equal(size(node),'12px','inspector control');
 equal(size(panel.querySelector('.direct-editor-input')),'27px','PDF text editor size retained');equal(size(panel.querySelector('#nativeFieldValue')),'19px','native field preview size retained');equal(size(panel.querySelector('.inline-text-input span')),'31px','inline PDF run size retained');
 document.body.classList.add('dark');equal(size(document.querySelector('#quickTools>p.help')),'11px','dark mode retains help role');equal(size(panel.querySelector('.object-inspector button')),'12px','dark mode retains controls');panel.remove();
 await context.close();context=null;console.log('PDFCreator typography: '+count+' cascade assertions passed across Home, all tool groups, dialogues and inspectors.');
}finally{if(context)await context.close()}
