/* Native Merge & Split workspace. AGPL-3.0-or-later.
 * Source workflow: https://github.com/chuatungkian/pdfsplitter
 */
import * as Engine from './engine.js';
import {sourceCRC} from './source-package.js';
import {SplitPlan,normaliseSplitPlan,splitPrefix,splitOutputName} from './split-planner.js';
import {buildSplitPdfs} from './split-engine.js';
import {zipFiles} from './zip-files.js';
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
export class MergeSplitWorkspace{
  constructor({root,api}){this.root=root;this.api=api;this.isOpen=false;this.busy=false;this.generation=0;this.docs=new Map();this.previews=new Map();this.downloadUrl=null;this.pageStart=0;this.rangeDirty=false;this.pointsDirty=false;this.queue=Promise.resolve()}
  async readSource(id){
    const source=await this.api.getSource(id);if(!source?.bytes||!source.pageCount)throw Error('Stored PDF is unavailable.');
    return{...source,fingerprint:source.bytes.byteLength.toString(16)+':'+sourceCRC(source.bytes).toString(16)+':'+source.pageCount};
  }
  async open({ownerId,plan}){
    this.close();this.ownerId=ownerId;this.isOpen=true;this.busy=false;this.pageStart=0;this.rangeDirty=false;this.pointsDirty=false;
    this.root.hidden=false;this.api.visibility(true);this.root.innerHTML=this.shell();this.bind();
    const generation=this.generation;this.setBusy(true);
    try{
      this.available=await this.api.listSources();const saved=normaliseSplitPlan(plan)||{version:1,sourceIds:[ownerId],breaks:[],fingerprints:{},baseName:splitPrefix(this.available.find(row=>row.id===ownerId)?.name)};
      const sources=new Map();
      for(const id of saved.sourceIds){
        try{const source=await this.readSource(id);sources.set(id,source);if(!saved.fingerprints[id])saved.fingerprints[id]=source.fingerprint}
        catch(error){sources.set(id,{id,name:this.available.find(row=>row.id===id)?.name||'Unavailable source',error:error.message})}
        if(!this.isOpen||generation!==this.generation)return;
      }
      this.model=new SplitPlan(saved,sources);this.render();this.save();
      this.find('msSettings').open=!globalThis.matchMedia('(max-width:1100px)').matches;
      this.root.focus();
    }catch(error){if(this.isOpen)this.message(error.message,true)}finally{if(this.isOpen&&generation===this.generation)this.setBusy(false)}
  }
  shell(){return `<div class="ms-header"><div><span class="tag">Organise</span><h1>Merge &amp; Split</h1><p id="msSummary">Loading source PDFs…</p></div><button id="msBack" type="button" class="small">← Back to PDF</button></div>
  <div class="ms-actions"><button id="msUpload" type="button">＋ Add PDFs</button><button id="msSources" type="button" class="quiet">Sources &amp; settings</button><span class="spacer"></span><button id="msMerged" type="button">Create merged tab</button><button id="msZip" type="button" class="primary">Download ZIP</button><a id="msSaveZip" class="ms-save-link" hidden download>Save generated ZIP</a></div>
  <div id="msMessage" class="ms-message" role="status" hidden></div><div class="ms-layout"><details class="ms-settings" id="msSettings" open><summary>Sources &amp; split settings <span id="msSourceCount"></span></summary><div class="ms-settings-body">
  <h2>Source order</h2><p class="help">Drag files or use the arrows. Split markers follow their source pages.</p><div id="msSourceList" class="ms-source-list"></div>
  <label for="msSourcePicker">Add an open or locally saved PDF</label><div class="ms-add-source"><select id="msSourcePicker"></select><button id="msAddSource" type="button" class="small">Add</button></div>
  <button id="msRefresh" type="button" class="quiet small full">Refresh sources &amp; reset splits</button>
  <label for="msRanges">Output page ranges</label><input id="msRanges" placeholder="1-3,4-7,8-10" spellcheck="false"><p class="help">Each group becomes one PDF. Cover every page once, in order.</p><button id="msApply" type="button" class="small full">Apply ranges</button>
  <div class="ms-range-actions"><button id="msEvery" type="button" class="small">Split every page</button><button id="msReset" type="button" class="quiet small">Reset splits</button></div>
  <label for="msPrefix">Output filename prefix</label><input id="msPrefix" maxlength="80"><h2 class="ms-results-title">Generated files <span id="msOutputCount"></span></h2><div id="msResults" class="ms-results"></div><p class="help">The plan is saved with this PDF. Imported PDFs also appear as document tabs.</p></div></details>
  <section class="ms-pages" aria-label="Merged page preview"><div class="ms-points-controls"><h2>Split points</h2><label for="msPoints">Split after pages</label><div class="ms-points-input"><input id="msPoints" placeholder="e.g. 3, 7" aria-describedby="msPointsHelp" spellcheck="false"><button id="msApplyPoints" type="button" class="small">Apply split points</button></div><p id="msPointsHelp" class="help">Enter 3, 7 to create pages 1–3, 4–7 and 8 onwards. Or use the Split after page button below each preview.</p><p id="msPointsSummary" class="help" role="status"></p></div><div class="ms-grid-heading"><div><h2>Page previews</h2><span id="msPageWindow" class="help"></span></div><div><button id="msEarlier" type="button" class="small" aria-label="Earlier page previews">←</button><button id="msLater" type="button" class="small" aria-label="Later page previews">→</button></div></div><div id="msGrid" class="ms-grid"></div></section></div>`}
  find(id){return this.root.querySelector('#'+id)}
  bind(){
    this.find('msBack').onclick=()=>this.api.close();this.find('msSources').onclick=()=>{const details=this.find('msSettings');details.open=!details.open};
    this.find('msUpload').onclick=()=>this.run(async()=>{
      const files=await this.api.chooseFiles();if(!files?.length)return;
      await this.addFiles(files);
    });
    this.find('msAddSource').onclick=()=>this.run(async()=>{const id=this.find('msSourcePicker').value;if(id){this.model.add(await this.readSource(id));this.changed(true)}});
    this.find('msRefresh').onclick=()=>this.run(async()=>{
      for(const id of this.model.value.sourceIds){try{this.model.sources.set(id,await this.readSource(id))}catch(error){this.model.sources.set(id,{id,name:this.model.sources.get(id)?.name||'Unavailable source',error:error.message})}}
      this.model.acceptCurrent();this.changed(true);if(this.model.ready)this.message('Sources refreshed. Review and choose new split points.');
    });
    this.find('msRanges').oninput=()=>{this.rangeDirty=true;this.invalidateDownload();this.buttons();this.message('Apply ranges to update the split preview.')};
    this.find('msRanges').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();this.applyRanges()}};
    this.find('msApply').onclick=()=>this.applyRanges();
    this.find('msPoints').oninput=()=>{this.pointsDirty=true;this.invalidateDownload();this.buttons();this.message('Apply split points to update the output files.')};
    this.find('msPoints').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();this.applyPoints()}};
    this.find('msApplyPoints').onclick=()=>this.applyPoints();
    this.find('msEvery').onclick=()=>{this.model.everyPage();this.changed(false)};this.find('msReset').onclick=()=>{this.model.reset();this.changed(false)};
    this.find('msPrefix').oninput=event=>{this.model.value.baseName=splitPrefix(event.target.value);this.invalidateDownload();this.renderResults();this.save()};
    this.find('msEarlier').onclick=()=>{this.pageStart=Math.max(0,this.pageStart-60);this.renderGrid()};
    this.find('msLater').onclick=()=>{this.pageStart+=60;this.renderGrid()};
    this.find('msZip').onclick=()=>this.exportZip();this.find('msMerged').onclick=()=>this.createMerged();
    this.root.onkeydown=event=>{
      if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))event.stopPropagation();
      if(event.key==='Escape'&&!this.busy){event.preventDefault();event.stopPropagation();this.api.close()}
    };
    this.root.ondragover=event=>{if([...event.dataTransfer?.types||[]].includes('Files'))event.preventDefault()};
    this.root.ondrop=event=>{const files=[...event.dataTransfer?.files||[]];if(files.length){event.preventDefault();event.stopPropagation();void this.run(()=>this.addFiles(files))}};
  }
  async addFiles(files){
    const result=await this.api.importFiles(files);this.available=await this.api.listSources();
    for(const id of result.ids)this.model.add(await this.readSource(id));
    if(this.model.value.sourceIds.length>1&&this.model.value.baseName===splitPrefix(this.model.sources.get(this.model.value.sourceIds[0])?.name))this.model.value.baseName='merged-document';
    this.changed(true);this.find('msSettings').open=true;this.message(result.errors.length?result.errors.join('\n'):'Added '+result.ids.length+' source PDF(s).',!!result.errors.length);
  }
  async run(action){
    if(this.busy||!this.isOpen)return;const generation=this.generation;
    return this.api.run(async()=>{this.setBusy(true);try{await action()}catch(error){if(this.isOpen&&generation===this.generation)this.message(error.name==='AbortError'?'Operation cancelled.':error.message,true)}finally{if(this.isOpen&&generation===this.generation)this.setBusy(false)}});
  }
  setBusy(value){this.busy=value;this.root.setAttribute('aria-busy',String(value));this.buttons()}
  buttons(){
    this.root.querySelectorAll('button,input,select').forEach(node=>node.disabled=this.busy);
    if(!this.model){this.root.querySelectorAll('button,input,select').forEach(node=>node.disabled=this.busy||node.id!=='msBack');return}
    const disabled=this.busy||!this.model.ready||this.rangeDirty||this.pointsDirty;this.find('msZip').disabled=disabled;this.find('msMerged').disabled=disabled;
    this.find('msAddSource').disabled=this.busy||!this.find('msSourcePicker').value;
    this.find('msSourcePicker').onchange=()=>this.buttons();
    this.find('msEarlier').disabled=this.busy||this.pageStart===0;this.find('msLater').disabled=this.busy||this.pageStart+60>=this.model.pages.length;
    this.root.querySelectorAll('[data-ms-remove]').forEach(button=>button.disabled=this.busy||this.model.value.sourceIds.length===1);
    this.root.querySelectorAll('[data-ms-up]').forEach(button=>button.disabled=this.busy||this.model.value.sourceIds.indexOf(button.dataset.msUp)===0);
    this.root.querySelectorAll('[data-ms-down]').forEach(button=>button.disabled=this.busy||this.model.value.sourceIds.indexOf(button.dataset.msDown)===this.model.value.sourceIds.length-1);
    const last=this.model.pages.length-1;this.root.querySelectorAll('[data-ms-page],[data-ms-cut]').forEach(button=>button.disabled=this.busy||!this.model.ready||+(button.dataset.msPage??button.dataset.msCut)===last);
  }
  message(text,error=false){const node=this.find('msMessage');if(!node)return;node.textContent=text;node.hidden=!text;node.classList.toggle('error',error)}
  save(){if(this.model)this.api.savePlan(this.ownerId,this.model.serialise())}
  changed(grid){this.rangeDirty=false;this.pointsDirty=false;this.invalidateDownload();if(grid){this.pageStart=0;this.render()}else{this.renderResults();this.updateMarkers();this.buttons()}this.save()}
  applyRanges(){try{this.model.applyRanges(this.find('msRanges').value);this.changed(false);this.message('Split ranges applied.')}catch(error){this.message(error.message,true);this.find('msRanges').focus()}}
  applyPoints(){try{this.model.applyPoints(this.find('msPoints').value);this.changed(false);this.message('Split points applied. Review the output ranges, then choose Download ZIP.')}catch(error){this.message(error.message,true);this.find('msPoints').focus()}}
  render(){
    this.find('msSummary').textContent=this.model.value.sourceIds.length+' source PDF(s) · '+this.model.pages.length+' pages · '+this.model.ranges().length+' output file(s)';
    this.renderSources();this.renderResults();this.renderGrid();
    if(this.model.missing.length)this.message('Some source PDFs are unavailable. Remove or replace them before export.',true);
    else if(this.model.changed.length)this.message('A source PDF has changed since this plan was saved. Refresh sources and reset split points before export.',true);
    else this.message('');this.buttons();
  }
  renderSources(){
    const ids=this.model.value.sourceIds;let next=1;
    this.find('msSourceCount').textContent=String(ids.length);
    this.find('msSourceList').innerHTML=ids.map((id,index)=>{
      const source=this.model.sources.get(id)||{name:'Unavailable source'},count=source.pageCount||0,start=next;next+=count;
      return `<div class="ms-source ${source.error?'has-error':''}" draggable="${!this.busy}" data-ms-source="${escape(id)}"><div class="ms-source-copy"><strong>${index+1}. ${escape(source.name)}</strong><span>${source.error?escape(source.error):'Merged pages '+start+'–'+(next-1)+' · '+count+' page(s)'}</span></div><div class="ms-source-actions"><button type="button" data-ms-up="${escape(id)}" aria-label="Move ${escape(source.name)} earlier">↑</button><button type="button" data-ms-down="${escape(id)}" aria-label="Move ${escape(source.name)} later">↓</button><button type="button" data-ms-remove="${escape(id)}" aria-label="Remove ${escape(source.name)} from split sources">×</button></div></div>`;
    }).join('');
    this.find('msSourcePicker').innerHTML='<option value="">Choose another PDF</option>'+this.available.filter(source=>!ids.includes(source.id)).map(source=>`<option value="${escape(source.id)}">${escape(source.name)}${source.open?' · Open tab':' · Local library'}</option>`).join('');
    this.root.querySelectorAll('[data-ms-up],[data-ms-down],[data-ms-remove]').forEach(button=>button.onclick=()=>{
      try{if(button.dataset.msRemove)this.model.remove(button.dataset.msRemove);else{const id=button.dataset.msUp||button.dataset.msDown;this.model.move(id,ids.indexOf(id)+(button.dataset.msUp?-1:1))}this.changed(true)}catch(error){this.message(error.message,true)}
    });
    this.root.querySelectorAll('[data-ms-source]').forEach(row=>{
      row.ondragstart=event=>{if(this.busy){event.preventDefault();return}this.dragSource=row.dataset.msSource;event.dataTransfer?.setData('text/plain',this.dragSource)};
      row.ondragover=event=>{if(!this.busy&&this.dragSource){event.preventDefault();row.classList.add('drag-over')}};
      row.ondragleave=()=>row.classList.remove('drag-over');row.ondragend=()=>{this.dragSource=null;this.root.querySelectorAll('.drag-over').forEach(node=>node.classList.remove('drag-over'))};
      row.ondrop=event=>{event.preventDefault();if(!this.busy&&this.dragSource){this.model.move(this.dragSource,ids.indexOf(row.dataset.msSource));this.dragSource=null;this.changed(true)}};
    });
  }
  renderResults(){
    const ranges=this.model.ranges(),prefix=this.model.value.baseName;if(!this.rangeDirty)this.find('msRanges').value=this.model.rangeText();if(!this.pointsDirty)this.find('msPoints').value=this.model.pointText();this.find('msPointsSummary').textContent=this.model.pointText()?'Split after pages '+this.model.pointText()+' · '+ranges.length+' output PDFs':'No split points · one output PDF';if(this.root.ownerDocument.activeElement!==this.find('msPrefix'))this.find('msPrefix').value=prefix;
    this.find('msOutputCount').textContent=String(ranges.length);this.find('msResults').innerHTML=ranges.map((range,index)=>`<div><strong>${escape(splitOutputName(prefix,index,range,ranges.length))}</strong><span>Pages ${range.start}–${range.end} · ${range.end-range.start+1} page(s)</span></div>`).join('');
    this.find('msSummary').textContent=this.model.value.sourceIds.length+' source PDF(s) · '+this.model.pages.length+' pages · '+ranges.length+' output file(s)';
  }
  renderGrid(){
    this.observer?.disconnect();this.previewGeneration=(this.previewGeneration||0)+1;this.queue=Promise.resolve();
    const generation=this.previewGeneration,pages=this.model.pages,total=pages.length;this.pageStart=Math.max(0,Math.min(this.pageStart,Math.max(0,Math.floor((total-1)/60)*60)));
    this.find('msPageWindow').textContent=total?'Showing '+(this.pageStart+1)+'–'+Math.min(total,this.pageStart+60)+' of '+total:'';
    this.find('msGrid').innerHTML=pages.slice(this.pageStart,this.pageStart+60).map((page,offset)=>{const index=this.pageStart+offset;return `<div class="ms-page"><button class="ms-page-card" type="button" data-ms-page="${index}" aria-label="Split after merged page ${index+1}, ${escape(page.name)}, source page ${page.page+1}" aria-pressed="false"><span class="ms-page-preview" data-ms-preview="${index}"><span>Loading preview…</span></span><span class="ms-page-number">Page ${index+1}<span class="ms-cut-label"></span></span><span class="ms-page-source" title="${escape(page.name)}">${escape(page.name)} · ${page.page+1}</span></button><button class="ms-cut-button" type="button" data-ms-cut="${index}" aria-pressed="false">Split after page ${index+1}</button><span class="ms-cut-line" aria-hidden="true">Split</span></div>`}).join('')||'<div class="notice">Add a readable source PDF to preview its pages.</div>';
    this.root.querySelectorAll('[data-ms-page],[data-ms-cut]').forEach(button=>button.onclick=()=>{if(!this.busy&&this.model.ready&&this.model.toggle(+(button.dataset.msPage??button.dataset.msCut)))this.changed(false)});
    const enqueue=target=>{this.queue=this.queue.then(async()=>{await tick();if(!this.isOpen||generation!==this.previewGeneration||!target.isConnected)return;this.renderPreview(target,this.model.pages[+target.dataset.msPreview])}).catch(()=>{})};
    this.observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){this.observer.unobserve(entry.target);enqueue(entry.target)}},{root:this.api.scrollRoot,rootMargin:'160px'});
    this.root.querySelectorAll('[data-ms-preview]').forEach(node=>this.observer.observe(node));this.updateMarkers();this.buttons();
  }
  updateMarkers(){
    const cuts=new Set(this.model.value.breaks);this.root.querySelectorAll('[data-ms-page]').forEach(button=>{const index=+button.dataset.msPage,last=index===this.model.pages.length-1,active=!last&&cuts.has(this.model.pages[index].key),control=button.closest('.ms-page').querySelector('[data-ms-cut]');button.setAttribute('aria-pressed',String(active));button.closest('.ms-page').classList.toggle('has-cut',active);button.querySelector('.ms-cut-label').textContent=active?'Split after':last?'Final page':'';control.textContent=last?'Final page · automatic':active?'Remove split after page '+(index+1):'Split after page '+(index+1);control.setAttribute('aria-pressed',String(active))});
  }
  renderPreview(target,page){
    if(!page)return;const source=this.model.sources.get(page.id),key=page.key+':'+source.fingerprint;let url=this.previews.get(key);
    try{
      if(!url){
        let cached=this.docs.get(page.id);if(cached?.bytes!==source.bytes){cached?.doc.destroy();this.docs.delete(page.id);cached=null}
        if(!cached){cached={bytes:source.bytes,doc:Engine.openPDF(source.bytes)};this.docs.set(page.id,cached);while(this.docs.size>2){const id=this.docs.keys().next().value;this.docs.get(id).doc.destroy();this.docs.delete(id)}}
        const native=cached.doc.loadPage(page.page);let pix;
        try{const b=native.getBounds(),scale=Math.min(170/(b[2]-b[0]),210/(b[3]-b[1]));pix=native.toPixmap([scale,0,0,scale,-b[0]*scale,-b[1]*scale],Engine.mupdf.ColorSpace.DeviceRGB,false,true);url=URL.createObjectURL(new Blob([pix.asPNG()],{type:'image/png'}));this.previews.set(key,url)}finally{pix?.destroy();native.destroy()}
        while(this.previews.size>96){const oldest=this.previews.keys().next().value;URL.revokeObjectURL(this.previews.get(oldest));this.previews.delete(oldest)}
      }
      const image=document.createElement('img');image.src=url;image.alt='Preview of '+page.name+', page '+(page.page+1);target.replaceChildren(image);
    }catch{target.textContent='Preview unavailable'}
  }
  async checkSources(){
    if(!this.model.ready||this.rangeDirty||this.pointsDirty)throw Error('Apply valid split points or ranges and resolve source changes before export.');
    for(const id of this.model.value.sourceIds){const source=await this.readSource(id);if(source.fingerprint!==this.model.value.fingerprints[id]){this.model.sources.set(id,source);this.model.rebuild();this.render();throw Error('A source changed. Refresh sources and reset splits before export.')}this.model.sources.set(id,source)}
    await this.api.ensureSafe([...this.model.sources.values()].filter(source=>this.model.value.sourceIds.includes(source.id)));
  }
  async createMerged(){return this.run(async()=>{
    await this.checkSources();const entries=await this.api.job('Creating merged PDF',async(progress,signal)=>buildSplitPdfs({sources:this.model.sources,pages:this.model.pages,ranges:[{start:1,end:this.model.pages.length}],prefix:this.model.value.baseName,progress,signal}));
    await this.api.openMerged(entries[0].bytes,this.model.value.baseName+'-merged.pdf');
  })}
  exportZip(){
    if(this.busy||!this.model?.ready||this.rangeDirty||this.pointsDirty)return;
    const filename=this.model.value.baseName+'-split.zip';let picker;
    if(this.root.ownerDocument.defaultView.showSaveFilePicker&&this.root.ownerDocument.defaultView.isSecureContext){try{picker=this.root.ownerDocument.defaultView.showSaveFilePicker({suggestedName:filename,types:[{description:'ZIP archive',accept:{'application/zip':['.zip']}}]})}catch{}}
    // The save picker above runs in the original user gesture, before PDF generation.
    return this.run(async()=>{
      let handle;try{handle=await picker}catch(error){if(error.name==='AbortError')return}
      await this.checkSources();
      const ranges=this.model.ranges(),blob=await this.api.job('Preparing split ZIP',async(progress,signal)=>{
        const entries=await buildSplitPdfs({sources:this.model.sources,pages:this.model.pages,ranges,prefix:this.model.value.baseName,signal,progress:(p,text)=>progress(p*.8,text)});
        const sources=this.model.value.sourceIds.map((id,index)=>{const source=this.model.sources.get(id);return(index+1)+'. '+source.name.replace(/[\r\n]/g,' ')+' ('+source.pageCount+' pages)'}).join('\n');
        entries.push({name:'README.txt',bytes:'Created locally with PDFCreator\n\nSource order:\n'+sources+'\n\nOutput ranges: '+this.model.rangeText()+'\n'+entries.map((entry,index)=>entry.name+' · pages '+ranges[index].start+'-'+ranges[index].end).join('\n')+'\n'});
        return zipFiles(entries,{signal,progress:(p,text)=>progress(.8+p*.2,text)});
      });
      this.invalidateDownload();this.downloadUrl=URL.createObjectURL(blob);const link=this.find('msSaveZip');link.href=this.downloadUrl;link.download=filename;link.hidden=false;
      if(handle){let writable;try{writable=await handle.createWritable();await writable.write(blob);await writable.close();this.message('ZIP saved. The generated ZIP link is also available.')}catch{try{await writable?.abort()}catch{}this.message('The ZIP is ready. Use Save generated ZIP to download it.',true)}}
      else{link.click();this.message('ZIP ready. If the download did not start, use Save generated ZIP.')}
    });
  }
  invalidateDownload(){if(this.downloadUrl)URL.revokeObjectURL(this.downloadUrl);this.downloadUrl=null;const link=this.find('msSaveZip');if(link){link.hidden=true;link.removeAttribute('href')}}
  close(){
    this.isOpen=false;this.generation++;this.previewGeneration=(this.previewGeneration||0)+1;this.observer?.disconnect();this.invalidateDownload();
    for(const value of this.docs.values())value.doc.destroy();this.docs.clear();for(const url of this.previews.values())URL.revokeObjectURL(url);this.previews.clear();
    this.root.hidden=true;this.api.visibility(false);this.model=null;
  }
}
