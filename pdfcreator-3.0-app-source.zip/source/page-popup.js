/* Keep an on-page editor inside both its PDF page and the visible working area. */
export function containPagePopup(form,{overlay,bounds,zoom,anchor,width=420,height=540}){
 const doc=overlay.ownerDocument,win=doc.defaultView,work=doc.getElementById('main');let closed=false;
 const fit=()=>{if(closed||!form.isConnected)return;const page=overlay.getBoundingClientRect(),pw=page.width||(bounds[2]-bounds[0])*zoom,ph=page.height||(bounds[3]-bounds[1])*zoom,view=work?.getBoundingClientRect(),screen=win.visualViewport;
  let left=page.left,top=page.top,right=left+pw,bottom=top+ph;
  if(view?.width>0&&view?.height>0){left=Math.max(left,view.left);top=Math.max(top,view.top);right=Math.min(right,view.right);bottom=Math.min(bottom,view.bottom)}
  if(screen){left=Math.max(left,screen.offsetLeft);top=Math.max(top,screen.offsetTop);right=Math.min(right,screen.offsetLeft+screen.width);bottom=Math.min(bottom,screen.offsetTop+screen.height)}else{right=Math.min(right,win.innerWidth||right);bottom=Math.min(bottom,win.innerHeight||bottom);left=Math.max(left,0);top=Math.max(top,0)}
  const visible=right>left&&bottom>top;form.hidden=!visible;if(!visible)return;const gap=Math.min(8,(right-left)/8,(bottom-top)/8),availableWidth=right-left-2*gap,availableHeight=bottom-top-2*gap,w=Math.min(width,availableWidth),cap=Math.min(height,availableHeight);
  Object.assign(form.style,{boxSizing:'border-box',width:w+'px',maxWidth:w+'px',maxHeight:cap+'px',minWidth:'0',minHeight:'0',padding:Math.min(9,Math.max(0,(Math.min(w,cap)-4)/4))+'px'});form.classList.toggle('field-editor-compact',w<330);
  const measured=form.getBoundingClientRect().height||form.offsetHeight||form.scrollHeight||300,h=Math.min(cap,measured),x=(anchor[0]-bounds[0])*zoom,y=(anchor[1]-bounds[1])*zoom,minX=left-page.left+gap,minY=top-page.top+gap,maxX=right-page.left-gap-w,maxY=bottom-page.top-gap-h;
  form.style.left=Math.max(minX,Math.min(x,maxX))+'px';form.style.top=Math.max(minY,Math.min(y,maxY))+'px';
 };
 const observer=win.ResizeObserver?new win.ResizeObserver(fit):null;observer?.observe(form);observer?.observe(overlay);if(work)observer?.observe(work);win.addEventListener('resize',fit);win.addEventListener('scroll',fit,true);win.visualViewport?.addEventListener('resize',fit);win.visualViewport?.addEventListener('scroll',fit);fit();
 return{fit,destroy(){closed=true;observer?.disconnect();win.removeEventListener('resize',fit);win.removeEventListener('scroll',fit,true);win.visualViewport?.removeEventListener('resize',fit);win.visualViewport?.removeEventListener('scroll',fit)}};
}
