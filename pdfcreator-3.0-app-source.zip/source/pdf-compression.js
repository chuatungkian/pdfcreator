/* Non-flattening PDF compression. AGPL-3.0-or-later. */
import {mupdf,openPDF,optimizePDF} from './engine.js';
export const COMPRESSION_PROFILES={high:{dpi:220,quality:90},balanced:{dpi:150,quality:78},small:{dpi:96,quality:58}};
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
function check(signal){if(signal?.aborted)throw new DOMException('Cancelled','AbortError')}
function property(obj,key,type){const value=obj.get(key);try{return type==='ref'?(value.isIndirect()?value.asIndirect():null):type==='null'?value.isNull():type==='name'?(value.isName()?value.asName():''):type==='boolean'?value.asBoolean():value.asNumber()}finally{value.destroy()}}
function output(doc){const buffer=doc.saveToBuffer('garbage=4,compress=yes,compress-fonts=yes,compress-images=yes,objstms=yes');try{return buffer.asUint8Array().slice()}finally{buffer.destroy()}}
async function imagePass(bytes,{dpi,quality},progress,signal){
 const doc=openPDF(bytes),images=[],byPointer=new Map(),masks=new Set();let skipped=0,changed=0,device;
 try{
  const count=doc.countObjects();
  for(let i=1;i<count;i++){check(signal);const obj=doc.newIndirect(i);try{if(obj.isStream()&&property(obj,'Subtype','name')==='Image')for(const key of ['SMask','Mask']){const ref=property(obj,key,'ref');if(ref)masks.add(ref)}}catch{/* Broken/non-image objects are left to the native saver. */}finally{obj.destroy()}if(i%256===0)await tick()}
  for(let i=1;i<count;i++){
   check(signal);const ref=doc.newIndirect(i);let image;
   try{
    if(!ref.isStream()||property(ref,'Subtype','name')!=='Image')continue;
    const w=property(ref,'Width'),h=property(ref,'Height'),bpc=property(ref,'BitsPerComponent'),cs=property(ref,'ColorSpace','name');
    if(masks.has(i)||!property(ref,'SMask','null')||!property(ref,'Mask','null')||property(ref,'ImageMask','boolean')||bpc!==8||!['DeviceRGB','DeviceGray'].includes(cs)||w<128||h<128||w*h>20000000){skipped++;continue}
    image=doc.loadImage(ref);const record={number:i,image,width:w,height:h,displayWidth:0,displayHeight:0,unsafe:false};images.push(record);image=null;byPointer.set(record.image.pointer,record);
   }catch{skipped++}finally{image?.destroy();ref.destroy()}
   if(i%256===0)await tick();
  }
  // The same image may appear repeatedly, inside Forms or at different sizes.
  // Use its largest displayed axes; skip unknown uses rather than guessing DPI.
  device=new mupdf.Device({fillImage(image,matrix){try{const item=byPointer.get(image.pointer);if(item){item.displayWidth=Math.max(item.displayWidth,Math.hypot(matrix[0],matrix[1]));item.displayHeight=Math.max(item.displayHeight,Math.hypot(matrix[2],matrix[3]))}}finally{image.destroy()}}});
  for(let i=0;i<doc.countPages();i++){check(signal);const page=doc.loadPage(i);try{page.runPageContents(device,mupdf.Matrix.identity)}catch{for(const item of images)item.unsafe=true}finally{page.destroy()}await tick()}
  device.close();device.destroy();device=null;
  for(const [index,item]of images.entries()){
   check(signal);progress(index/Math.max(1,images.length),'Compressing image '+(index+1)+' of '+images.length);await tick();
   const ref=doc.newIndirect(item.number);let pix,scaled,raw;
   try{
    if(item.unsafe||!item.displayWidth||!item.displayHeight){skipped++;continue}
    pix=item.image.toPixmap();if(pix.getAlpha()){skipped++;continue}
    const ratio=Math.min(1,Math.max(item.displayWidth*dpi/72/item.width,item.displayHeight*dpi/72/item.height)),w=Math.max(1,Math.round(item.width*ratio)),h=Math.max(1,Math.round(item.height*ratio));
    if(w<item.width||h<item.height)scaled=pix.warp([[0,0],[item.width,0],[0,item.height],[item.width,item.height]],w,h);
    const source=scaled||pix,jpeg=source.asJPEG(quality);raw=ref.readRawStream();
    if(jpeg.length+256>=raw.getLength()){skipped++;continue}
    // Keep the original object identity, optional-content and structure metadata.
    // Only replace its encoded pixels and the corresponding image decoding keys.
    ref.writeRawStream(jpeg);ref.put('Width',w);ref.put('Height',h);ref.put('BitsPerComponent',8);ref.put('ColorSpace',property(ref,'ColorSpace','name'));ref.put('Filter','DCTDecode');
    for(const key of ['Decode','DecodeParms','F','FFilter','FDecodeParms','DL'])ref.delete(key);changed++;
   }catch(error){throw Error('Could not safely compress image '+item.number+': '+error.message)}finally{raw?.destroy();scaled?.destroy();pix?.destroy();ref.destroy()}
  }
  check(signal);return{bytes:output(doc),imagesRecompressed:changed,imagesSkipped:skipped,dpi,quality};
 }finally{device?.destroy();for(const item of images)item.image.destroy();doc.destroy()}
}
export async function compressPDF(bytes,{mode='lossless',targetBytes=null,minDpi=72,minQuality=45}={},progress=()=>{},signal){
 bytes=new Uint8Array(bytes);check(signal);if(!['lossless','high','balanced','small','target'].includes(mode))throw Error('Choose a valid compression mode.');
 if(mode==='target'&&(!Number.isSafeInteger(targetBytes)||targetBytes<1000||targetBytes>2147483648))throw Error('Choose a target from 1 kB to 2 GB.');
 if(![72,96,120,150,220,300].includes(+minDpi)||!Number.isFinite(+minQuality)||minQuality<35||minQuality>90)throw Error('Choose a valid image quality limit.');
 const finish=(result,passes)=>({...result,mode,before:bytes.length,after:result.bytes.length,targetBytes:mode==='target'?targetBytes:null,targetMet:mode==='target'?result.bytes.length<=targetBytes:null,passes,keptOriginal:result.bytes.length===bytes.length,percentSaved:Math.max(0,(1-result.bytes.length/bytes.length)*100)});
 if(mode==='target'&&bytes.length<=targetBytes)return finish({bytes,imagesRecompressed:0,imagesSkipped:0,dpi:null,quality:null},0);
 progress(0,'Lossless PDF cleanup');await tick();check(signal);
 const lossless=optimizePDF(bytes,{subsetFonts:false}),packedDoc=openPDF(lossless);let packed;try{packed=output(packedDoc)}finally{packedDoc.destroy()}
 let best={bytes:packed.length<lossless.length?packed:lossless,imagesRecompressed:0,imagesSkipped:0,dpi:null,quality:null};if(best.bytes.length>=bytes.length)best.bytes=bytes;
 if(mode==='lossless'||mode==='target'&&best.bytes.length<=targetBytes){progress(1,'Ready');return finish(best,1)}
 const levels=mode==='target'?[300,220,150,120,96,72].map((dpi,i,list)=>({dpi:Math.max(+minDpi,dpi),quality:Math.round(92-(92-minQuality)*i/(list.length-1))})).filter((p,i,list)=>!list.slice(0,i).some(q=>q.dpi===p.dpi&&q.quality===p.quality)):[COMPRESSION_PROFILES[mode]];
 let passes=1;
 for(const [i,profile]of levels.entries()){
  check(signal);const result=await imagePass(bytes,profile,(fraction,message)=>progress(.05+.9*(i+fraction)/levels.length,message+' · '+profile.dpi+' dpi'),signal);passes++;
  if(result.bytes.length<best.bytes.length)best=result;
  if(mode==='target'&&best.bytes.length<=targetBytes)break;
 }
 check(signal);progress(1,'Ready');return finish(best,passes);
}
