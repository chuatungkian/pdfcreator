/* PDFCreator annotation appearances. AGPL-3.0-or-later.
 * The /C entry of a FreeText annotation is its background color, not its text
 * color. Text color belongs in /DA and in its explicit /AP appearance stream.
 */
import * as mupdf from 'mupdf';

const IDENTITY = mupdf.Matrix.identity;
const MIN_SIZE = 4;
const MAX_TEXT = 10000;
function close(value) { value?.destroy(); }
function fail(message, code) { const error = new Error(message); error.code = code; throw error; }

function validate(page, options) {
  const kind = options.kind || 'freetext';
  if (!['freetext', 'stamp'].includes(kind)) throw new Error('Unknown text annotation kind.');
  const source = String(options.text ?? '');
  if (!source.trim()) throw new Error('Enter some text for the annotation.');
  if ([...source].length > MAX_TEXT) throw new Error(`Annotation text is limited to ${MAX_TEXT.toLocaleString()} characters.`);
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(source)) throw new Error('Annotation text contains unsupported control characters.');
  const rect = options.rect;
  if (!Array.isArray(rect) || rect.length !== 4 || !rect.every(Number.isFinite)) throw new Error('Select a rectangular area for the annotation.');
  const bounds = page.getBounds();
  const clipped = [Math.max(bounds[0], Math.min(rect[0], rect[2])), Math.max(bounds[1], Math.min(rect[1], rect[3])), Math.min(bounds[2], Math.max(rect[0], rect[2])), Math.min(bounds[3], Math.max(rect[1], rect[3]))];
  if (clipped[2] - clipped[0] < 8 || clipped[3] - clipped[1] < 8) throw new Error('Select a larger annotation area (at least 8 × 8 points).');
  const color = options.color || [.502, 0, .125];
  if (!Array.isArray(color) || color.length !== 3 || !color.every(n => Number.isFinite(n) && n >= 0 && n <= 1)) throw new Error('Text colour needs three RGB values between 0 and 1.');
  const size = Number(options.size ?? 14);
  if (!Number.isFinite(size) || size < MIN_SIZE || size > 144) throw new Error('Annotation text size must be between 4 and 144 points.');
  return { kind, source, rect: clipped, color, size, author: String(options.author || 'PDFCreator') };
}

function prepareCharacters(source, fonts) {
  // Canonical composition lets decomposed Latin accents use the same supported
  // glyph as their precomposed equivalent. Original Contents remains unchanged.
  const text = source.replace(/\r\n?/g, '\n').replace(/\t/g, '    ').normalize('NFC');
  const cache = new Map();
  return text.split('\n').map(paragraph => [...paragraph].map(character => {
    if (cache.has(character)) return cache.get(character);
    const code = character.codePointAt(0);
    // The bundled fonts do not supply the shaping/font coverage needed for
    // complex scripts and emoji. Refuse missing glyphs instead of silent boxes.
    let font = fonts.latin, glyph = font.encodeCharacter(code);
    if (!glyph) { font = fonts.cjk; glyph = font.encodeCharacter(code); }
    if (!glyph || /\p{Mark}/u.test(character)) fail(`The offline annotation fonts cannot display “${character}” (U+${code.toString(16).toUpperCase()}). Use supported Latin, Greek, Cyrillic, or CJK text.`, 'UNSUPPORTED_ANNOTATION_GLYPH');
    const sample = new mupdf.Text();
    let box;
    try {
      sample.showGlyph(font, [1, 0, 0, -1, 0, 0], glyph, code);
      box = sample.getBounds(null, IDENTITY);
      // fz_bound_text includes a one-point antialiasing margin on all sides.
      box = [box[0] + 1, box[1] + 1, box[2] - 1, box[3] - 1];
    } finally { sample.destroy(); }
    const item = { character, code, font, glyph, advance: font.advanceGlyph(glyph), box };
    cache.set(character, item);
    return item;
  }));
}

function wrap(paragraphs, width, size) {
  const lines = [];
  const finish = glyphs => {
    while (glyphs.length && /\s/u.test(glyphs.at(-1).character)) glyphs.pop();
    lines.push(glyphs);
  };
  for (const paragraph of paragraphs) {
    let line = [], used = 0;
    const tokens = [];
    for (const glyph of paragraph) {
      const whitespace = /\s/u.test(glyph.character);
      if (!tokens.length || tokens.at(-1).whitespace !== whitespace) tokens.push({ whitespace, glyphs: [] });
      tokens.at(-1).glyphs.push(glyph);
    }
    for (const token of tokens) {
      const tokenWidth = token.glyphs.reduce((n, glyph) => n + glyph.advance * size, 0);
      if (!token.whitespace && used && used + tokenWidth > width) { finish(line); line = []; used = 0; }
      for (const glyph of token.glyphs) {
        const advance = glyph.advance * size;
        if (used + advance > width && line.length) { finish(line); line = []; used = 0; }
        if (!line.length && token.whitespace) continue;
        line.push(glyph); used += advance;
      }
    }
    finish(line);
  }
  return lines;
}

function layoutAt(paragraphs, width, height, size, kind) {
  const padding = kind === 'stamp' ? 5 : 2;
  const availableWidth = width - padding * 2, availableHeight = height - padding * 2;
  if (availableWidth <= 2 || availableHeight <= 2) return { fits: false };
  const lines = wrap(paragraphs, availableWidth - 2, size);
  let ascent = 0, descent = 0;
  const measured = lines.map(glyphs => {
    let advance = 0, x0 = 0, x1 = 0;
    for (const glyph of glyphs) {
      if (!/\s/u.test(glyph.character)) {
        x0 = Math.min(x0, advance + glyph.box[0] * size);
        x1 = Math.max(x1, advance + glyph.box[2] * size);
        ascent = Math.max(ascent, -glyph.box[1] * size);
        descent = Math.max(descent, glyph.box[3] * size);
      }
      advance += glyph.advance * size;
    }
    return { glyphs, x0, x1: Math.max(x1, advance), advance };
  });
  const leading = Math.max(size * 1.3, ascent + descent + size * .15);
  const textHeight = ascent + descent + 2 + Math.max(0, lines.length - 1) * leading;
  const fits = textHeight <= availableHeight && measured.every(line => line.x1 - line.x0 + 2 <= availableWidth);
  const baseline = padding + 1 + ascent + (kind === 'stamp' ? Math.max(0, (availableHeight - textHeight) / 2) : 0);
  return { fits, lines: measured, size, leading, baseline, padding, availableWidth, textHeight };
}

function fitLayout(paragraphs, width, height, requested, kind) {
  let result = layoutAt(paragraphs, width, height, requested, kind);
  if (result.fits) return result;
  result = layoutAt(paragraphs, width, height, MIN_SIZE, kind);
  if (!result.fits) fail('The complete annotation text does not fit this area. Select a larger area or shorten the text.', 'ANNOTATION_TEXT_OVERFLOW');
  let low = MIN_SIZE, high = requested;
  for (let i = 0; i < 12; i++) {
    const middle = (low + high) / 2, candidate = layoutAt(paragraphs, width, height, middle, kind);
    if (candidate.fits) { low = middle; result = candidate; } else high = middle;
  }
  return result;
}

function makeAppearance(layout, width, height, color, kind) {
  const list = new mupdf.DisplayList([0, 0, width, height]);
  const device = new mupdf.DisplayListDevice(list), text = new mupdf.Text();
  let border, stroke;
  try {
    if (kind === 'stamp') {
      border = new mupdf.Path();
      border.rect(2, 2, width - 2, height - 2);
      stroke = new mupdf.StrokeState({ lineCap: 'Round', lineJoin: 'Round', lineWidth: 1.5, miterLimit: 10 });
      device.strokePath(border, stroke, IDENTITY, mupdf.ColorSpace.DeviceRGB, color, 1);
    }
    layout.lines.forEach((line, index) => {
      let x = layout.padding + 1 - line.x0;
      if (kind === 'stamp') x += (layout.availableWidth - (line.x1 - line.x0 + 2)) / 2;
      const y = layout.baseline + index * layout.leading;
      for (const glyph of line.glyphs) {
        text.showGlyph(glyph.font, [layout.size, 0, 0, -layout.size, x, y], glyph.glyph, glyph.code);
        x += glyph.advance * layout.size;
      }
    });
    // Check actual glyph bounds, including the engine's antialiasing margin.
    const box = text.getBounds(null, IDENTITY);
    if (box[0] < -.02 || box[1] < -.02 || box[2] > width + .02 || box[3] > height + .02) fail('The annotation appearance would clip text. Select a larger area.', 'ANNOTATION_TEXT_OVERFLOW');
    device.fillText(text, IDENTITY, mupdf.ColorSpace.DeviceRGB, color, 1);
    device.close();
    return list;
  } catch (error) { list.destroy(); throw error; }
  finally { close(stroke); close(border); text.destroy(); device.destroy(); }
}

/**
 * Create a transparent FreeText comment or a real Stamp with a custom,
 * transparent, vector text/border appearance. Uses MuPDF page coordinates.
 * The complete text is wrapped and shrunk to a minimum of 4pt, or rejected.
 * Returns a native PDFAnnotation. Caller owns it and must destroy() it.
 */
export function createTextAnnotation(doc, page, options) {
  if(options.appearance)return createSystemFontAnnotation(doc,page,options);
  const settings = validate(page, options);
  const fonts = { latin: new mupdf.Font(settings.kind === 'stamp' ? 'Helvetica-Bold' : 'Helvetica'), cjk: new mupdf.Font('zh-Hans') };
  let list, annotation;
  try {
    const paragraphs = prepareCharacters(settings.source, fonts);
    const width = settings.rect[2] - settings.rect[0], height = settings.rect[3] - settings.rect[1];
    const layout = fitLayout(paragraphs, width, height, settings.size, settings.kind);
    list = makeAppearance(layout, width, height, settings.color, settings.kind);
    // All validation precedes document mutation, so failures leave no empty box.
    annotation = page.createAnnotation(settings.kind === 'stamp' ? 'Stamp' : 'FreeText');
    annotation.setRect(settings.rect);
    annotation.setContents(settings.source);
    annotation.setAuthor(settings.author);
    annotation.setColor([]); // FreeText /C is a fill; keep it transparent.
    annotation.setOpacity(1);
    annotation.setFlags(annotation.getFlags() | mupdf.PDFAnnotation.IS_PRINT);
    if (settings.kind === 'freetext') {
      annotation.setBorderWidth(0);
      annotation.setDefaultAppearance('Helv', layout.size, settings.color);
    } else annotation.setIcon('Approved');
    // Install the custom appearance before update(). Generating the built-in
    // named Stamp appearance first would resize Rect to its fixed aspect ratio.
    const pageObject = page.getObject();
    let rotationObject, rotation;
    try {
      rotationObject = pageObject.getInheritable('Rotate');
      rotation = rotationObject.asNumber() || 0;
    } finally { close(rotationObject); pageObject.destroy(); }
    annotation.setAppearanceFromDisplayList('N', null, mupdf.Matrix.rotate(rotation), list);
    annotation.update();
    annotation.pdfproLayout = Object.freeze({ size: layout.size, lineCount: layout.lines.length, shrunk: layout.size < settings.size - .01, kind: settings.kind });
    return annotation;
  } catch (error) {
    if (annotation) { page.deleteAnnotation(annotation); annotation.destroy(); }
    throw error;
  } finally { close(list); fonts.latin.destroy(); fonts.cjk.destroy(); }
}

// Device fonts are rendered locally to a transparent high-resolution image.
// The complete comment stays in Contents, with a normal native annotation subtype.
function createSystemFontAnnotation(doc,page,options){
  const settings=validate(page,options),appearance=options.appearance;
  const width=settings.rect[2]-settings.rect[0],height=settings.rect[3]-settings.rect[1];
  if(Math.abs(appearance.width-width)>.02||Math.abs(appearance.height-height)>.02||!appearance.png?.length)throw Error('Font appearance does not match the annotation area.');
  let image,list,device,border,stroke,annotation;
  try{
    image=new mupdf.Image(appearance.png);
    list=new mupdf.DisplayList([0,0,width,height]);device=new mupdf.DisplayListDevice(list);
    if(settings.kind==='stamp'){
      border=new mupdf.Path();border.rect(2,2,width-2,height-2);
      stroke=new mupdf.StrokeState({lineCap:'Round',lineJoin:'Round',lineWidth:1.5,miterLimit:10});
      device.strokePath(border,stroke,IDENTITY,mupdf.ColorSpace.DeviceRGB,settings.color,1);
    }
    device.fillImage(image,[width,0,0,height,0,0],1);device.close();
    annotation=page.createAnnotation(settings.kind==='stamp'?'Stamp':'FreeText');
    annotation.setRect(settings.rect);annotation.setContents(settings.source);annotation.setAuthor(settings.author);
    annotation.setColor([]);annotation.setOpacity(1);annotation.setFlags(annotation.getFlags()|mupdf.PDFAnnotation.IS_PRINT);
    if(settings.kind==='freetext'){annotation.setBorderWidth(0);annotation.setDefaultAppearance('Helv',appearance.size,settings.color)}else annotation.setIcon('Approved');
    const pageObject=page.getObject();let rotationObject,rotation;
    try{rotationObject=pageObject.getInheritable('Rotate');rotation=rotationObject.asNumber()||0}finally{close(rotationObject);pageObject.destroy()}
    annotation.setAppearanceFromDisplayList('N',null,mupdf.Matrix.rotate(rotation),list);annotation.update();
    annotation.pdfproLayout=Object.freeze({size:appearance.size,lineCount:appearance.lines.length,shrunk:appearance.shrunk,kind:settings.kind,font:appearance.font});
    return annotation;
  }catch(error){if(annotation){page.deleteAnnotation(annotation);annotation.destroy()}throw error}
  finally{close(stroke);close(border);close(device);close(list);close(image)}
}
