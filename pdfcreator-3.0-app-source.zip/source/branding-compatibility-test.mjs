/* PDFCreator branding, legacy workspace import and local recovery regression. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window,fileSelections,downloads}=context;
 equal(window.document.title,'PDFCreator · Offline PDF workspace','document title uses PDFCreator');check(document.querySelector('header .brand').textContent.includes('PDFCreator'),'header uses PDFCreator');equal(window.PDFCreator,window.PdfPro,'legacy API remains the same object');equal(app.name,'PDFCreator','new API identifies the app');equal(window.PDFCreatorSigning,window.PdfProSigning,'signing alias remains compatible');equal(app.local.store.name,'pdfpro-local-workspace','existing local database retained');
 await app.createDemo();equal(app.state.name,'pdfcreator-sample.pdf','sample filename uses the new name');check(text(app).includes('PDFCreator'),'sample PDF uses the new brand');
 $('about').click();await until(()=>$('modaltitle'),'About opens');equal($('modaltitle').textContent,'PDFCreator','About has no version suffix');check($('modalform').textContent.includes('Built by Tung Kian.'),'About includes authorship');check(!$('getlicenses')&&!$('getsource'),'removed About download buttons stay absent');$('modalcancel').click();
 app.state.page=1;app.state.font='Georgia';app.state.marks=[{page:1,rect:[40,80,100,120]}];await app.activate('project');const exported=downloads.at(-1);check(exported.name.endsWith('.pdfcreator'),'new workspace extension');const payload=await(await fetch(exported.href)).json();equal(payload.format,'pdfcreator-workspace','new workspace format identifier');equal(payload.page,1,'export retains page');equal(payload.font,'Georgia','export retains font');equal(payload.marks.length,1,'export retains pending marks');
 fileSelections.push([{name:'legacy.pdfpro',type:'application/json',text:async()=>JSON.stringify({...payload,format:'pdfpro-workspace',name:'Legacy workspace.pdf'})}]);await app.activate('restore');equal(app.state.name,'Legacy workspace.pdf','old workspace format imports');equal(app.state.page,1,'legacy workspace page retained');equal(app.state.font,'Georgia','legacy font retained');equal(app.state.marks.length,1,'legacy pending redaction retained');
 fileSelections.push([{name:'current.pdfcreator',type:'application/json',text:async()=>JSON.stringify({...payload,name:'Current workspace.pdf'})}]);await app.activate('restore');equal(app.state.name,'Current workspace.pdf','new workspace format imports');equal(app.state.marks.length,1,'new pending redaction retained');await app.local.flush();const owner=app.activeTabId,bytes=app.state.bytes.slice();
 const reader=new LocalWorkspaceStore();const saved=await reader.getDocument(owner);equal(saved.snapshot.bytes,bytes,'records remain readable under the legacy database name');reader.close();await context.close();context=await boot();({app,$,window}=context);equal(window.PDFCreator,app,'new API works after recovery');equal(app.activeTabId,owner,'active document recovers after rename');equal(app.state.name,'Current workspace.pdf','recovered name retained');equal(app.state.page,1,'recovered page retained');equal(app.state.font,'Georgia','recovered font retained');equal(app.state.marks.length,1,'recovered marks retained');equal(app.state.bytes,bytes,'recovered PDF bytes intact');
 await context.close();context=null;console.log('PDFCreator branding and compatibility: '+assertions+' assertions passed with native PDFs, old/new workspace files and IndexedDB recovery.');
}finally{if(context)await context.close()}
