import assert from 'node:assert/strict';
import {pageTouchAction,tapTolerance} from './touch-input.js';
for(const mode of ['select','search','objects','images','editfields'])assert.equal(pageTouchAction(mode),'manipulation',mode+' permits native navigation');
for(const mode of ['ink','eraser','highlight','rectangle'])assert.equal(pageTouchAction(mode),'none',mode+' retains deliberate editing gestures');
assert.equal(pageTouchAction('directedit','line'),'manipulation');assert.equal(pageTouchAction('directedit','chunk'),'none');
assert.equal(tapTolerance({pointerType:'touch'},4),12);assert.equal(tapTolerance({pointerType:'pen'},4),6);assert.equal(tapTolerance({pointerType:'mouse'},4),4);
console.log('PASS: gesture policy and finger/Pencil/mouse tolerances');
