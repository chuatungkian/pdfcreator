/* Local XLSX/CSV ingestion. Formula text is never evaluated. */
import {read,utils} from './vendor/sheetjs/xlsx.mjs';
export const DATA_LIMITS={fileBytes:20*1024*1024,rows:10200,records:10000,columns:256,cells:500000};
function decodeCSV(bytes){let encoding='utf-8';if(bytes[0]===255&&bytes[1]===254)encoding='utf-16le';else if(bytes[0]===254&&bytes[1]===255)encoding='utf-16be';try{return new TextDecoder(encoding,{fatal:true}).decode(bytes).replace(/^\uFEFF/,'')}catch{throw Error('Save the CSV as UTF-8 or UTF-16 before importing it.')}}
export function csvRows(text,delimiter=','){
 if(![',',';','\t'].includes(delimiter))throw Error('Choose comma, semicolon or tab as the CSV separator.');
 const rows=[];let row=[],value='',quoted=false,closed=false,line=1,startLine=1;
 const cell=()=>{row.push({text:value,raw:value});value='';closed=false;if(row.length>DATA_LIMITS.columns)throw Error('The table exceeds 256 columns.')};
 const finish=()=>{cell();rows.push({sourceRow:startLine,cells:row});row=[];startLine=line+1;if(rows.length>DATA_LIMITS.rows)throw Error('The CSV exceeds 10,200 table rows. Import a smaller file.')};
 for(let i=0;i<text.length;i++){const char=text[i];if(quoted){if(char==='"'){if(text[i+1]==='"'){value+='"';i++}else{quoted=false;closed=true}}else if(char==='\r'||char==='\n'){if(char==='\r'&&text[i+1]==='\n')i++;value+='\n';line++}else value+=char;continue}
  if(char==='"'){if(value||closed)throw Error('Unexpected quote near CSV line '+line+'.');quoted=true}
  else if(char===delimiter)cell();else if(char==='\r'||char==='\n'){finish();if(char==='\r'&&text[i+1]==='\n')i++;line++}
  else{if(closed&&!/[ \t]/.test(char))throw Error('Unexpected text after a closing quote near CSV line '+line+'.');if(!closed)value+=char}
 }
 if(quoted)throw Error('The CSV ends inside a quoted value.');if(value||row.length||closed)finish();if(rows.reduce((sum,r)=>sum+r.cells.length,0)>DATA_LIMITS.cells)throw Error('The table exceeds 500,000 cells.');return rows;
}
export function detectDelimiter(text){const candidates=[',',';','\t'],rows=[];let counts=[0,0,0],quoted=false,content=false;for(let i=0;i<text.length&&rows.length<12;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){i++;continue}quoted=!quoted;content=true;continue}if(quoted)continue;if(c==='\r'||c==='\n'){if(content)rows.push(counts);counts=[0,0,0];content=false;if(c==='\r'&&text[i+1]==='\n')i++;continue}const at=candidates.indexOf(c);if(at>=0)counts[at]++;if(c.trim())content=true}if(content)rows.push(counts);let best=0,score=-1;for(let i=0;i<3;i++){const populated=rows.map(r=>r[i]).filter(n=>n>0),consistent=populated.filter(n=>n===populated[0]).length,value=consistent*100+(populated[0]||0);if(value>score){score=value;best=i}}return candidates[best]}
export function parseFormData(input,{name='records.csv',delimiter='auto'}={}){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);if(!bytes.length)throw Error('This data file is empty.');if(bytes.length>DATA_LIMITS.fileBytes)throw Error('Choose a data file no larger than 20 MB.');
 if(/\.csv$/i.test(name)){const text=decodeCSV(bytes),separator=delimiter==='auto'?detectDelimiter(text):delimiter,rows=csvRows(text,separator);return{kind:'csv',delimiter:separator,sheets:[{name:'CSV',rows,defaultHeaderRow:rows.findIndex(r=>r.cells.some(c=>c.text.trim()))+1||1}]}}
 if(!/\.xlsx$/i.test(name))throw Error('Choose an .xlsx or .csv file.');if(bytes[0]!==80||bytes[1]!==75)throw Error('This is not an unencrypted XLSX workbook. Save it as .xlsx without a workbook password.');
 let workbook;try{workbook=read(bytes,{type:'array',cellDates:false,cellText:true,cellNF:true,cellFormula:true,bookVBA:false,bookDeps:false,sheetRows:DATA_LIMITS.rows+1})}catch(error){throw Error('Unable to read this XLSX workbook: '+error.message)}
 const sheets=[];let totalCells=0;if(workbook.SheetNames.length>100)throw Error('This workbook has more than 100 worksheets. Import a smaller workbook.');
 for(const name of workbook.SheetNames){const sheet=workbook.Sheets[name],reference=sheet['!fullref']||sheet['!ref'];if(!reference){sheets.push({name,rows:[],defaultHeaderRow:1,error:'This worksheet is empty.'});continue}const range=utils.decode_range(reference),rows=[];
  if(range.e.r>=DATA_LIMITS.rows||range.e.c>=DATA_LIMITS.columns){sheets.push({name,rows:[],defaultHeaderRow:1,error:'This worksheet exceeds 10,200 rows or 256 columns. Import a smaller table.'});continue}
  totalCells+=(range.e.r+1)*(range.e.c+1);if(totalCells>DATA_LIMITS.cells)throw Error('The workbook exceeds 500,000 cells. Import a smaller workbook.');
  for(let row=0;row<=range.e.r;row++){const cells=[];for(let col=0;col<=range.e.c;col++){const cell=sheet[utils.encode_cell({r:row,c:col})];let error='';if(cell?.f&&(cell.v===undefined||cell.v===null||cell.t==='z'))error='Formula has no saved result. Recalculate and save the workbook first.';else if(cell?.t==='e')error='Spreadsheet error '+(cell.w||cell.v||'unknown error');const raw=cell?.v??'';cells.push({raw,text:cell?.w??(cell&&cell.v!==undefined?utils.format_cell(cell):''),error,formula:!!cell?.f})}rows.push({sourceRow:row+1,cells})}
  sheets.push({name,rows,defaultHeaderRow:range.s.r+1});
 }
 return{kind:'xlsx',sheets};
}
