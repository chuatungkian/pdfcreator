/* Visible editing for outlined/scanned text. Recognition never changes the PDF. */
import {mupdf,openPDF} from './engine.js';
import {directTextTargets,directEditTargets,replaceDirectTextGroup,saveDirectEdit,flowOverlay,appendOverlay} from './direct-text.js';
const I=[1,0,0,1,0,0],union=rs=>[Math.min(...rs.map(r=>r[0])),Math.min(...rs.map(r=>r[1])),Math.max(...rs.map(r=>r[2])),Math.max(...rs.map(r=>r[3]))];
const intersects=(a,b)=>a[0]<b[2]-.4&&a[2]>b[0]+.4&&a[1]<b[3]-.4&&a[3]>b[1]+.4;
const equalBytes=(a,b)=>a===b||a?.length===b?.length&&a.every((v,i)=>v===b[i]);
export class OCRDirectCache{
 constructor(){this.maps=new WeakMap();this.history=[]}
 get(bytes){let map=this.maps.get(bytes);if(!map){map=this.history.find(e=>equalBytes(e.bytes,bytes))?.map||new Map();this.maps.set(bytes,map)}return map}
 set(bytes,page,targets){const map=new Map(this.get(bytes));map.set(page,targets);this.store(bytes,map)}
 store(bytes,map){this.maps.set(bytes,map);this.history=this.history.filter(e=>e.bytes!==bytes);this.history.unshift({bytes,map});while(this.history.length>8||this.history.length>1&&this.history.reduce((sum,e)=>sum+e.bytes.length,0)>60e6)this.history.pop()}
 carry(from,to,page,id){const map=new Map(this.get(from));if(id){const ids=Array.isArray(id)?id:[id];map.set(page,(map.get(page)||[]).filter(t=>!ids.includes(t.id)));}if(map.size)this.store(to,map)}
 clear(){this.maps=new WeakMap();this.history=[]}
}
function colours(pixels,rect){
 const {data,width,height}=pixels,[x0,y0,x1,y1]=rect.map(Math.round),counts=new Map(),inks=new Map();
 for(let y=Math.max(0,y0-3);y<Math.min(height,y1+3);y++)for(let x=Math.max(0,x0-3);x<Math.min(width,x1+3);x++){const i=(y*width+x)*4,c=[data[i],data[i+1],data[i+2]],key=c.map(v=>Math.round(v/8)*8).join(',');counts.set(key,(counts.get(key)||0)+1)}
 const background=[...(counts.entries())].sort((a,b)=>b[1]-a[1])[0]?.[0].split(',').map(v=>Math.min(255,+v))||[255,255,255];
 for(let y=Math.max(0,y0);y<Math.min(height,y1);y++)for(let x=Math.max(0,x0);x<Math.min(width,x1);x++){const i=(y*width+x)*4,c=[data[i],data[i+1],data[i+2]];if(c.reduce((s,v,j)=>s+Math.abs(v-background[j]),0)>180){const key=c.map(v=>Math.round(v/16)*16).join(',');inks.set(key,(inks.get(key)||0)+1)}}
 const ink=[...(inks.entries())].sort((a,b)=>b[1]-a[1])[0]?.[0].split(',').map(v=>Math.min(255,+v))||[0,0,0];return{background:background.map(v=>v/255),color:'#'+ink.map(v=>v.toString(16).padStart(2,'0')).join('')};
}
function horizontalRules(pixels,bounds,scale){const bands=[];let current=null;for(let y=0;y<pixels.height;y++){let start=-1,best=null;for(let x=0;x<=pixels.width;x++){const i=(y*pixels.width+x)*4,dark=x<pixels.width&&Math.min(pixels.data[i],pixels.data[i+1],pixels.data[i+2])<235;if(dark&&start<0)start=x;if(!dark&&start>=0){if(x-start>scale*30&&(!best||x-start>best[1]-best[0]))best=[start,x];start=-1}}if(best){if(current&&y===current[3]+1&&Math.abs(best[0]-current[0])<scale*2&&Math.abs(best[1]-current[2])<scale*2)current[3]=y;else{current=[best[0],y,best[1],y];bands.push(current)}}else current=null}return bands.filter(r=>r[3]-r[1]<=scale*2.5).map(r=>({type:'Rule',rect:[bounds[0]+r[0]/scale,bounds[1]+r[1]/scale,bounds[0]+r[2]/scale,bounds[1]+(r[3]+1)/scale]}))}
export function ocrEditTargets(result,{bounds,scale,pixels,native=[]}){
 const targets=[],columnBarriers=horizontalRules(pixels,bounds,scale);let id=0;const box=w=>[bounds[0]+w.bbox.x0/scale,bounds[1]+w.bbox.y0/scale,bounds[0]+w.bbox.x1/scale,bounds[1]+w.bbox.y1/scale];
 for(const line of result.lines){let group=[];const flush=()=>{if(!group.length)return;const words=group;group=[];const rect=union(words.map(box)),text=words.map(w=>w.text).join(' ');if(!text.trim()||native.some(t=>{const cx=(rect[0]+rect[2])/2,cy=(rect[1]+rect[3])/2;return cx>=t.rect[0]-1&&cx<=t.rect[2]+1&&cy>=t.rect[1]-1&&cy<=t.rect[3]+1}))return;
   const appearance=colours(pixels,[(rect[0]-bounds[0])*scale,(rect[1]-bounds[1])*scale,(rect[2]-bounds[0])*scale,(rect[3]-bounds[1])*scale]);
   const font=new mupdf.Font('Helvetica'),shape=new mupdf.Text();let unit;try{shape.showString(font,[100,0,0,-100,0,0],text);unit=shape.getBounds(null,I).map(v=>v/100)}finally{shape.destroy();font.destroy()}
   const size=Math.max(4,Math.min(144,(rect[3]-rect[1])/Math.max(.1,unit[3]-unit[1]),(rect[2]-rect[0])/Math.max(.1,unit[2]-unit[0]))),baseline=rect[1]-unit[1]*size;
   const wordRects=words.map(w=>{const r=box(w),pad=.65;return[Math.max(bounds[0],r[0]-pad),Math.max(bounds[1],r[1]-pad),Math.min(bounds[2],r[2]+pad),Math.min(bounds[3],r[3]+pad)]});
   let offset=0;const recognisedWords=words.map((w,i)=>{const value={text:w.text,confidence:w.confidence,rect:wordRects[i],start:offset,end:offset+Array.from(w.text).length};offset=value.end+1;return value});const sampleWidth=Math.min(180,Math.max(1,Math.round((rect[2]-rect[0])*scale))),sampleHeight=Math.min(64,Math.max(1,Math.round((rect[3]-rect[1])*scale))),mask=new Uint8Array(sampleWidth*sampleHeight);
   for(let y=0;y<sampleHeight;y++)for(let x=0;x<sampleWidth;x++){const px=Math.min(pixels.width-1,Math.max(0,Math.floor((rect[0]-bounds[0])*scale+x/sampleWidth*(rect[2]-rect[0])*scale))),py=Math.min(pixels.height-1,Math.max(0,Math.floor((rect[1]-bounds[1])*scale+y/sampleHeight*(rect[3]-rect[1])*scale))),p=(py*pixels.width+px)*4;mask[y*sampleWidth+x]=[0,1,2].reduce((n,j)=>n+Math.abs(pixels.data[p+j]-appearance.background[j]*255),0)>180?1:0;}
   targets.push({kind:'ocr',columnBarriers,words:recognisedWords,sample:{width:sampleWidth,height:sampleHeight,mask},id:'ocr-'+id++,scope:'paragraph',text,rect,size,fontName:'Helvetica',color:appearance.color,background:appearance.background,bold:false,italic:false,editable:true,confidence:words.reduce((s,w)=>s+w.confidence,0)/words.length,wordRects,baseline,layout:{width:Math.max(20,rect[2]-rect[0]+2),leading:size*1.3},parts:[],units:Array.from(text,ch=>({ch,style:0}))});
  };
  for(const word of line.words){if(native.some(t=>intersects(box(word),t.rect))){flush();continue}if(group.length){const last=group.at(-1),gap=word.bbox.x0-last.bbox.x1,height=Math.max(word.bbox.height,last.bbox.height);if(gap>Math.max(height*3,scale*18))flush()}group.push(word)}flush();
 }
 return targets;
}
function sourceOverlay(targets,bounds){
 const glyphs=[],fonts=[];try{for(const [index,target]of (Array.isArray(targets)?targets:[targets]).entries()){const font=new mupdf.Font(target.fontName||'Helvetica');fonts.push(font);let x=target.rect[0];const size=target.size,space=mupdf.ColorSpace.DeviceRGB,color=[1,3,5].map(i=>parseInt(target.color.slice(i,i+2),16)/255);for(const ch of target.text){const unicode=ch.codePointAt(0),gid=font.encodeCharacter(unicode);if(!gid)throw Error('The estimated font cannot represent “'+ch+'”. Edit a smaller recognised text region.');const matrix=[size,0,0,-size,x,target.baseline];glyphs.push({style:index,line:index,s:{font,space,color,alpha:1,size,underline:false,strikethrough:false},gid,unicode,matrix});x+=font.advanceGlyph(gid)*size}}return flowOverlay({glyphs,layout:{u:[1,0],v:[0,1]}},bounds)}finally{fonts.forEach(f=>f.destroy())}
}
function backgroundOverlay(target,bounds){const buffer=new mupdf.Buffer(),writer=new mupdf.DocumentWriter(buffer,'pdf','compress');let device;try{device=writer.beginPage(bounds);for(const region of target.regions||[target])for(const rect of region.wordRects){const p=new mupdf.Path();try{p.rect(rect[0],rect[1],rect[2],rect[3]);device.fillPath(p,false,I,mupdf.ColorSpace.DeviceRGB,region.background,1)}finally{p.destroy()}}writer.endPage();writer.close();return{bytes:buffer.asUint8Array().slice()}}finally{device?.destroy();writer.destroy();buffer.destroy()}}
export function replaceOCRText(doc,pageIndex,target,value,options={},others=[]){
 const page=doc.loadPage(pageIndex);let temporary;
 try{
  const bounds=page.getBounds();if(!target.wordRects?.length||target.wordRects.some(r=>r.length!==4||!r.every(Number.isFinite)||r[0]<bounds[0]||r[1]<bounds[1]||r[2]>bounds[2]||r[3]>bounds[3]||r[2]<=r[0]||r[3]<=r[1]))throw Error('Recognise this page again before editing.');
  const following=options.reflowFollowing||[],regions=[target,...following.map(i=>i.target)],wordRects=regions.flatMap(t=>t.wordRects),mask={...target,wordRects,regions};
  temporary=openPDF(sourceOverlay(regions,bounds).bytes);const lines=directEditTargets(temporary,0,'line'),find=t=>lines.filter(l=>l.text===t.text).sort((a,b)=>Math.abs(a.rect[1]-t.rect[1])-Math.abs(b.rect[1]-t.rect[1]))[0],original=find(target);if(!original)throw Error('The recognised text could not be prepared.');original.scope='paragraph';original.layout.width=target.layout.width;original.layout.leading=target.layout.leading;
  const reflowFollowing=following.map(i=>({target:find(i.target),matrix:i.matrix}));if(reflowFollowing.some(i=>!i.target))throw Error('Recognise the following text again.');
  const result=replaceDirectTextGroup(temporary,0,original,value,{...options,reflowFollowing,width:options.width??target.layout.width});const edited=directTextTargets(temporary,0),nearby=[...directTextTargets(doc,pageIndex),...others.filter(t=>!regions.some(r=>r.id===t.id))];
  if(options.allowTextOverlap!==true&&edited.some(t=>nearby.some(n=>intersects(t.rect,n.rect))))throw Object.assign(new Error('The edited text would overlap nearby text.'),{code:'DIRECT_TEXT_OVERLAP'});
  const prepared={bytes:saveDirectEdit(temporary)};
  const all=page.getAnnotations();try{if(all.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing redaction annotations before editing.')}finally{all.forEach(a=>a.destroy())}
  for(const rect of wordRects){const mark=page.createAnnotation('Redact');try{mark.setRect(rect);mark.update()}finally{mark.destroy()}}
  page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_PIXELS,mupdf.PDFPage.REDACT_LINE_ART_REMOVE_IF_COVERED,mupdf.PDFPage.REDACT_TEXT_REMOVE);
  appendOverlay(doc,page,backgroundOverlay(target,bounds));appendOverlay(doc,page,prepared);
  const sourcePage=temporary.loadPage(0),sourceObject=sourcePage.getObject(),destination=page.getObject();
  try{let saved=[],added=[];try{saved=JSON.parse(destination.get('PdfProDirectFlows').asString())}catch{}try{added=JSON.parse(sourceObject.get('PdfProDirectFlows').asString())}catch{}destination.put('PdfProDirectFlows',doc.newString(JSON.stringify([...(Array.isArray(saved)?saved:[]),...(Array.isArray(added)?added:[])].slice(-100))));
   const annotations=sourcePage.getAnnotations();try{for(const source of annotations){const original=source.getObject(),kind=original.get('PDFCreatorDirectDecoration').asName();try{if(!['underline','strikethrough'].includes(kind))continue;const copy=page.createAnnotation(source.getType());try{copy.setQuadPoints(source.getQuadPoints());copy.setColor(source.getColor());copy.setOpacity(source.getOpacity());const object=copy.getObject();try{object.put('PDFCreatorDirectDecoration',doc.newName(kind));object.put('PDFCreatorDirectRect',original.get('PDFCreatorDirectRect').asJS())}finally{object.destroy()}copy.update()}finally{copy.destroy()}}finally{original.destroy()}}}finally{annotations.forEach(a=>a.destroy())}
  }finally{sourceObject.destroy();destination.destroy();sourcePage.destroy()}
  return{...result,rects:result.rects,allRects:edited.map(t=>t.rect)};
 }finally{temporary?.destroy();page.destroy()}
}
