export {DIRECT_FONTS,directFormatting} from './direct-formatting-inline.js';
