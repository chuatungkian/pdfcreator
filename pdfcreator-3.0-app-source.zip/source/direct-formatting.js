/* Selection formatting for native PDF text. Offsets are Unicode characters. */
export const DIRECT_FONTS=Object.freeze([['original','Original font'],['Helvetica','Helvetica / Arial'],['Times-Roman','Times New Roman'],['Courier','Courier New']]);
const families={Helvetica:'Arial','Times-Roman':'Times New Roman',Courier:'Courier New'};
export function directFormatting({document,input,target}){
 const root=document.createElement('div');root.className='direct-formatting';
 root.innerHTML='<div class="direct-format-toolbar" role="group" aria-label="Text formatting"><label>Font<select data-direct-format="font" aria-label="Font">'+DIRECT_FONTS.map(([value,label])=>'<option value="'+value+'">'+label+'</option>').join('')+'</select></label><label>Size (pt)<input type="number" required min="4" max="144" step="any" data-direct-format="size" aria-label="Font size"></label><label>Colour<input type="color" data-direct-format="color" aria-label="Text colour"></label>'+[['bold','Bold','<b>B</b>'],['italic','Italic','<i>I</i>'],['underline','Underline','<u>U</u>'],['strikethrough','Strikethrough','<s>S</s>']].map(([key,label,icon])=>'<button type="button" data-direct-format="'+key+'" aria-label="'+label+'" title="'+label+'" aria-pressed="false">'+icon+'</button>').join('')+'</div><p class="direct-format-help">Select words to format, or leave the selection empty to format the whole block. Unchanged text keeps its PDF typeface. Font and emphasis changes use embedded PDF fonts.</p><div class="direct-format-preview" aria-label="Formatting preview"></div>';
 const control=key=>root.querySelector('[data-direct-format="'+key+'"]'),preview=root.querySelector('.direct-format-preview');
 let oldText=input.value,overrides=Array.from(oldText,()=>({})),selection=[0,input.value.length];
 const source=new Map((target.parts||[]).map(p=>[p.index,p]));
 let bases=Array.from(oldText,(_,i)=>source.get(target.units?.[i]?.style)||target);
 const remember=()=>{selection=[input.selectionStart||0,input.selectionEnd||0]};
 const effective=i=>({...bases[i]||target,...overrides[i]||{}});
 function show(){
  const i=Math.min(Array.from(input.value.slice(0,selection[0])).length,Math.max(0,overrides.length-1)),style=effective(i);
  control('font').value=style.font||'original';control('size').value=String(Math.round((style.size||target.size)*100)/100);control('color').value=style.color||target.color;
  for(const key of ['bold','italic','underline','strikethrough'])control(key).setAttribute('aria-pressed',String(!!style[key]));
  preview.replaceChildren();let current=null,last='';
  Array.from(input.value).forEach((ch,index)=>{const s=effective(index),family=families[s.font]||s.fontName||target.fontName,key=JSON.stringify([family,s.size,s.color,s.bold,s.italic,s.underline,s.strikethrough]);if(key!==last){current=document.createElement('span');Object.assign(current.style,{fontFamily:'"'+family.replace(/["\\]/g,'')+'",sans-serif',fontSize:(s.size||target.size)+'px',color:s.color,fontWeight:s.bold?'700':'400',fontStyle:s.italic?'italic':'normal',textDecorationLine:[s.underline?'underline':'',s.strikethrough?'line-through':''].filter(Boolean).join(' ')||'none'});preview.append(current);last=key}current.append(document.createTextNode(ch))});
 }
 function sync(){if(input.value===oldText)return;const a=Array.from(oldText),b=Array.from(input.value);let head=0,tail=0;while(head<a.length&&head<b.length&&a[head]===b[head])head++;while(tail<a.length-head&&tail<b.length-head&&a[a.length-1-tail]===b[b.length-1-tail])tail++;const style=overrides[Math.max(0,head-1)]||{},base=bases[Math.max(0,head-1)]||target;overrides=[...overrides.slice(0,head),...b.slice(head,b.length-tail).map(()=>({...style})),...overrides.slice(a.length-tail)];bases=[...bases.slice(0,head),...b.slice(head,b.length-tail).map(()=>base),...bases.slice(a.length-tail)];oldText=input.value;remember();show()}
 function format(key,value){sync();let [start,end]=selection.map(offset=>Array.from(input.value.slice(0,offset)).length);if(start===end){start=0;end=overrides.length}for(let i=start;i<end;i++)overrides[i]={...overrides[i],[key]:value};show()}
 for(const key of ['font','size','color']){const c=control(key);c.addEventListener('pointerdown',remember);c.onchange=()=>{if(key==='size'&&(!Number.isFinite(+c.value)||+c.value<4||+c.value>144)){c.setCustomValidity('Choose a font size from 4 to 144 pt.');c.reportValidity();return}c.setCustomValidity('');format(key,key==='size'?+c.value:c.value)}}
 for(const key of ['bold','italic','underline','strikethrough']){const c=control(key);c.onmousedown=e=>{e.preventDefault();remember()};c.onclick=()=>format(key,c.getAttribute('aria-pressed')!=='true')}
 for(const event of ['select','keyup','click'])input.addEventListener(event,()=>{remember();show()});input.addEventListener('input',sync);input.addEventListener('blur',remember);
 show();
 return{root,hasChanges:()=>overrides.some(s=>Object.keys(s).length),options:()=>{sync();const runs=[];for(const [i,style] of overrides.entries()){if(!Object.keys(style).length)continue;const previous=runs.at(-1);if(previous&&previous.end===i&&JSON.stringify(previous.style)===JSON.stringify(style))previous.end++;else runs.push({start:i,end:i+1,style})}return runs.length?{formatting:runs}:{}},setDisabled:value=>root.querySelectorAll('button,input,select').forEach(c=>c.disabled=value)};
}
