PDFCreator Word companion — Windows / Microsoft Word desktop

1. Extract every file in PDFCreator-Word-Companion.zip into one folder.
2. Run start-word-companion.cmd. Keep its console window open.
3. In PDFCreator, choose Create > Import from Word > Continue.
4. Paste the pairing code from the console. Leave port 17843 unless changed.
5. Choose a .docx or .doc file, then Convert and open.

The companion uses the Microsoft Word desktop installation on this PC. It does
not include or install Microsoft Word and does not call a cloud conversion API.
The selected file is sent only to 127.0.0.1. The browser may ask for local-network
access; allow it to use this feature. New and existing PDFs work without a companion.
The application does not contact the companion until you use the import controls.
The pairing code changes on every launch and is held only in app/process memory.
Close the companion window to stop accepting conversions. If a conversion is
already running, it may finish in its separate Word worker process.

Formatting and fidelity
Microsoft Word's native ExportAsFixedFormat renders the source, including visible
text styles, pictures, tables, headers, footers, section sizes and page layout.
This avoids converting the document through browser HTML. The result is a PDF of
Word's rendering, rather than a reconstruction of its text. Installed fonts,
missing linked content, licence restrictions and Word-specific document features
can still affect output. Use the source fonts and review complex files after import.
Word comments, tracked markup and interactive controls follow Word's PDF export
behaviour; this is not an editable Word document or a guarantee of every Word feature.
Document protection/labels are respected. Password-protected or restricted files
may require manual PDF export in Word, then Create > Open PDF in PDFCreator.

Operation
- Windows and Microsoft Word desktop are required; the browser HTML stays offline.
- No admin rights, Python packages, browser extensions or Office add-ins are needed.
- Binds only to 127.0.0.1, checks the Host and requires a random 256-bit pairing code.
- Accepts .docx/.doc uploads up to 64 MB; does not accept arbitrary filesystem paths.
- Creates temporary copies; never changes the chosen Word source file.
- Each conversion uses a separate Word instance. Existing Word windows are not used.
- Macros are disabled for opening the copy. Automatic external link/print-field
  updates are disabled during conversion and restored before the instance closes.
- Temporary files are removed after conversion when Word releases them. If cleanup
  fails, the companion reports the remaining local temporary folder.
- A 180-second watchdog stops a stalled worker and only its newly created Word process.
- The import can be cancelled in PDFCreator; a conversion already underway may finish.

The supplied executable is built from the included word-companion.cs. If it is
absent, start-word-companion.cmd compiles it using Windows .NET Framework's C#
compiler (Framework v4). No network access or dependency installation is used.
You can build manually from a command prompt:
  "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:exe /optimize+ /r:Microsoft.CSharp.dll /out:PDFCreator-Word-Companion.exe word-companion.cs
To choose a different port, run:
  PDFCreator-Word-Companion.exe --port 17844

Source licence: AGPL-3.0-or-later; see LICENSE.txt. Microsoft Word is a separately
licensed product. Its software and fonts are not redistributed with this companion.

API documentation:
https://learn.microsoft.com/en-us/office/vba/api/word.document.exportasfixedformat
https://learn.microsoft.com/en-us/office/vba/api/word.documents.open
https://learn.microsoft.com/en-us/office/vba/api/word.application.automationsecurity
