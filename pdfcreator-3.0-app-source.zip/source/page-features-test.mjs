/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {applyPageDecorations,timestampText} from './page-decorations.js';
import {watermarkGeometry} from './watermarks.js';
import {linkContentTargets} from './link-content.js';
import {inspectLinks} from './pdf-links.js';
let context;
try{
 context=await boot();const {app,$,window}=context,PDF=app.PDFLib,m=app.Engine.mupdf;
 const now=new Date('2026-10-29T09:35:00Z');
 check(timestampText('both',now).includes('29/10/2026'),'British timestamp date');equal(timestampText('none',now),'','timestamp optional');
 for(const rotation of [0,90,180,270]){
   let doc=await PDF.PDFDocument.create();const page=doc.addPage([620,860]);page.setCropBox(14,22,570,790);page.setRotation(PDF.degrees(rotation));page.drawText('ORIGINAL BODY',{x:100,y:300,size:14});
   let native=app.Engine.openPDF(await doc.save({useObjectStreams:false}));const g=watermarkGeometry(native,0);native.destroy();doc=await PDF.PDFDocument.load(await doc.save({useObjectStreams:false}));
   const reports=await applyPageDecorations(doc,[0],'header',{header:'Left header',headerAlign:'left',headerLine:true,headerThickness:2,footer:'Right footer',footerAlign:'right',footerLine:true,footerThickness:4,withNumbers:true,prefix:'Page ',start:1,numberAlign:'centre'},()=>g,{now});
   equal(reports.map(r=>r.slot),['header','footer','pageNumber'],'all three independent bands '+rotation);
   const b=new Uint8Array(await doc.save({useObjectStreams:false}));native=app.Engine.openPDF(b);let p=native.loadPage(0),pix=p.toPixmap(m.Matrix.identity,m.ColorSpace.DeviceRGB,true,true),pixels=pix.getPixels(),w=pix.getWidth(),h=pix.getHeight(),n=pix.getNumberOfComponents();
   function ink(xa,ya,xb,yb){let x0=w,y0=h,x1=-1,y1=-1,count=0;for(let y=Math.max(0,ya);y<Math.min(h,yb);y++)for(let x=Math.max(0,xa);x<Math.min(w,xb);x++)if(pixels[(y*w+x)*n+n-1]>20){count++;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}return{x0,y0,x1,y1,count}}
   const header=ink(0,0,w,40),footer=ink(0,h-52,w,h-30),number=ink(0,h-28,w,h);
   check(Math.abs(header.x0-24)<2,'left header pixels '+rotation);check(Math.abs(footer.x1+1-(w-24))<2,'right footer pixels '+rotation);check(Math.abs((number.x0+number.x1+1)/2-w/2)<2,'centred page number pixels '+rotation);
   equal(ink(0,46,w,48).count,w*2,'full-width 2pt header line '+rotation);equal(ink(0,h-58,w,h-54).count,w*4,'full-width 4pt footer line '+rotation);
   const extracted=p.toStructuredText('');const words=extracted.asText();extracted.destroy();for(const s of ['Left header','Right footer','Page 1','ORIGINAL BODY'])check(words.includes(s),'searchable band/body '+s+'/'+rotation);
   if(rotation===0)fs.writeFileSync('page-bands-proof.png',app.Engine.renderPagePNG(b,0,{scale:1}).bytes);pix.destroy();p.destroy();native.destroy();
   doc=await PDF.PDFDocument.load(b);await applyPageDecorations(doc,[0],'number',{prefix:'REV-',start:8,numberAlign:'right'},()=>g,{now});native=app.Engine.openPDF(await doc.save({useObjectStreams:false}));let contents=native.loadPage(0).toStructuredText('').asText();check(contents.includes('Left header')&&contents.includes('Right footer')&&contents.includes('REV-8')&&!contents.includes('Page 1'),'number replacement preserves footer/header '+rotation);native.destroy();
   doc=await PDF.PDFDocument.load(await doc.save({useObjectStreams:false}));await applyPageDecorations(doc,[0],'header',{footer:'Centre footer',footerAlign:'centre',footerStamp:'both'},()=>g,{now});native=app.Engine.openPDF(await doc.save({useObjectStreams:false}));contents=native.loadPage(0).toStructuredText('').asText();check(contents.includes('Left header')&&contents.includes('REV-8')&&contents.includes('Centre footer')&&!contents.includes('Right footer'),'footer replacement preserves header/number '+rotation);check(contents.includes(timestampText('both',now)),'timestamp is rendered/searchable '+rotation);native.destroy();
 }
 const pdf=await PDF.PDFDocument.create(),im=canvas.createCanvas(20,20);im.getContext('2d').fillStyle='#800020';im.getContext('2d').fillRect(0,0,20,20);const image=await pdf.embedPng(im.toBuffer('image/png'));
 for(let i=0;i<2;i++){const p=pdf.addPage([595,842]);p.drawText('Clickable existing words',{x:50,y:700,size:14});p.drawImage(image,{x:70,y:300,width:80,height:60});p.drawRectangle({x:220,y:300,width:70,height:50,color:PDF.rgb(.2,.3,.4)})}
 const source=new Uint8Array(await pdf.save({useObjectStreams:false}));await app.openFiles([file('First.pdf',source),file('Second.pdf',await fixture(app,'Second body')),file('Third.pdf',source)]);const ids=app.tabs.map(t=>t.id),owner=app.activeTabId;
 let targets=linkContentTargets(app.state.doc,0);check(targets.some(t=>t.label.startsWith('Text:')),'existing text selectable for links');check(targets.some(t=>t.label==='Image'),'existing images selectable for links');check(targets.some(t=>t.label==='Shape'),'native painted rectangle selectable for links');
 await app.activate('link');const obj=[...document.querySelectorAll('.link-object-target')].find(n=>n.title.includes('Clickable existing words'));check(!!obj,'existing-content hyperlink targets rendered');const first=app.state.bytes;obj.click();await until(()=>$('answer'),'object link dialog');$('answer').value='https://example.com/attached';await $('modalform').onsubmit({preventDefault(){}});await until(()=>app.state.bytes!==first&&!app.state.abort,'object link saved');equal(inspectLinks(app.state.doc,0)[0].href,'https://example.com/attached','existing text receives native hyperlink');check(text(app).includes('Clickable existing words'),'existing words preserved');
 await $('next').onclick();app.state.fit=false;app.state.zoom=1;await app.render();$('linkPlacement').value='text';$('linkPlacement').onchange({target:$('linkPlacement')});equal(app.state.linkMode,'text','linked text placement chosen');
 const overlay=$('overlay'),evt=(type,x,y)=>{const e=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(e,'pointerId',{value:7});return e};overlay.dispatchEvent(evt('pointerdown',50,180));overlay.dispatchEvent(evt('pointermove',330,230));overlay.dispatchEvent(evt('pointerup',330,230));await until(()=>$('linkedText'),'linked text dialog');check($('linkAddText').checked,'linked text enabled by placement mode');$('linkedText').value='Read this reference';$('linkedFont').value='Georgia';$('linkedSize').value='18';$('linkedColour').value='#101d3a';$('linkType').value='page';$('linkType').onchange();$('linkPage').value='1';const before=app.state.bytes,history=app.state.undo.length;await $('modalform').onsubmit({preventDefault(){}});await until(()=>app.state.bytes!==before&&!app.state.abort,'linked text saved');check(text(app).includes('Read this reference'),'linked display text searchable');fs.writeFileSync('linked-text-proof.png',app.Engine.renderPagePNG(app.state.bytes,1,{scale:1}).bytes);equal(inspectLinks(app.state.doc,1)[0].target,0,'linked text has internal page destination');equal(app.state.page,1,'insertion retains current page');equal(app.state.undo.length,history+1,'text/link is one undo action');await $('undo').onclick();check(!text(app).includes('Read this reference')&&!inspectLinks(app.state.doc,1).length,'undo removes text and link together');await $('redo').onclick();check(text(app).includes('Read this reference'),'redo restores linked text');
 let pending=app.activate('watermark');await until(()=>document.querySelector('[name=angle]'),'watermark dialog');equal(document.querySelector('[name=angle]').max,'360','full circle watermark range');equal(document.querySelector('[name=angle]').step,'0.1','fractional watermark degrees');$('modalcancel').click();await pending;
 pending=app.activate('header');await until(()=>document.querySelector('[name=headerAlign]'),'header dialog');for(const key of ['headerAlign','footerAlign','numberAlign'])equal([...document.querySelector(`[name=${key}]`).options].map(o=>o.value),['left','centre','right'],key+' choices');document.querySelector('[name=header]').value='UI HEADER';document.querySelector('[name=footer]').value='UI FOOTER';document.querySelector('[name=withNumbers]').checked=true;await $('modalform').onsubmit({preventDefault(){}});await pending;check(text(app).includes('UI HEADER')&&text(app).includes('UI FOOTER')&&text(app).includes('Page 2'),'header UI exports simultaneous bands');equal(app.state.page,1,'decoration retains current page');
 pending=app.activate('number');await until(()=>document.querySelector('[name=withFooter]'),'number dialog');document.querySelector('[name=withFooter]').checked=true;document.querySelector('[name=footer]').value='CHANGED FOOTER';document.querySelector('[name=numberAlign]').value='right';document.querySelector('[name=footerAlign]').value='centre';await $('modalform').onsubmit({preventDefault(){}});await pending;check(text(app).includes('CHANGED FOOTER')&&text(app).includes('UI HEADER')&&!text(app).includes('UI FOOTER'),'number UI can replace footer while retaining header');
 $('about').click();await until(()=>$('modaltitle'),'About');equal($('modaltitle').textContent,'PDFCreator','clean About title');check($('modalform').textContent.includes('Built by Tung Kian.')&&$('modalform').textContent.includes('chua_tung_kian@moe.edu.sg'),'authorship/contact');check(!$('getsource')&&!$('getlicenses'),'About buttons removed');for(const s of ['Offline edition','Private PDF workspace','The complete source ZIP'])check(!$('modalform').textContent.includes(s),'About removed '+s);$('modalcancel').click();check(!!$('saveBtn').querySelector('svg'),'Save PDF diskette is inline SVG');
 pending=app.activate('reorder');await until(()=>$('organiseDocument'),'organiser selector');equal([...$('organiseDocument').options].map(o=>o.value),ids,'organiser lists every open tab');equal($('organiseDocument').value,owner,'organiser defaults to active PDF');equal($('organiseSource').options.length,ids.length,'insertion chooser remains separate');
 const switchTo=async id=>{$('organiseDocument').value=id;$('organiseDocument').onchange();await until(()=>$('organiseDocument')?.value===id&&app.activeTabId===id,'organiser document switch')};
 await switchTo(ids[0]);equal($('organiseGrid').children.length,2,'switched organiser previews selected PDF');check(text(app).includes('Clickable existing words'),'actual active document switched');
 $('organiseBlank').click();$('organiseDocument').value=ids[1];$('organiseDocument').onchange();check(!$('organiseSwitchNotice').hidden,'staged changes require a choice');equal(app.activeTabId,ids[0],'pending switch leaves active document intact');$('organiseStay').click();equal($('organiseDocument').value,ids[0],'Stay resets chooser');equal($('organiseGrid').children.length,3,'Stay keeps staged changes');
 $('organiseDocument').value=ids[1];$('organiseDocument').onchange();$('organiseDiscardSwitch').click();await until(()=>app.activeTabId===ids[1]&&$('organiseDocument')?.value===ids[1],'discard switch');
 $('organiseBlank').click();$('organiseDocument').value=ids[2];$('organiseDocument').onchange();$('organiseApplySwitch').click();await until(()=>app.activeTabId===ids[2]&&$('organiseDocument')?.value===ids[2],'apply switch');$('modalcancel').click();await pending;await app.switchTab(ids[0]);equal(app.state.doc.countPages(),2,'discard preserves original pages');await app.switchTab(ids[1]);equal(app.state.doc.countPages(),3,'Apply and switch commits previous document changes');await $('undo').onclick();equal(app.state.doc.countPages(),2,'applied organiser switch is undoable');
 pending=app.activate('reorder');await until(()=>$('organiseDocument'),'cancel pending switch');$('organiseBlank').click();$('organiseDocument').value=ids[0];$('organiseDocument').onchange();$('modalcancel').click();await pending;equal(app.activeTabId,ids[1],'Cancel pending prompt does not switch');equal(app.state.doc.countPages(),2,'Cancel discards staged changes');
 const css=fs.readFileSync('refresh.css','utf8');check(css.includes('--tools-width:260px'),'narrower tools popup');check(css.includes('min-height:36px;gap:6px'),'compact tool tiles');check(css.includes('.layout:not(.pane-docked) .tool-pane{bottom:auto;max-height:'),'popup fits content with bounded scrolling');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator page features: '+assertions+' assertions passed with native pixels, PDF links and controlled UI.');
}finally{if(context)await context.close()}
