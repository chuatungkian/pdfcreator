/* Create new PDF documents without a template or external service. */
import {PDFDocument,PDFName,rgb} from 'pdf-lib';
export const PAPER_SIZES=Object.freeze({A4:[210,297],A5:[148,210],A3:[297,420],Letter:[215.9,279.4],Legal:[215.9,355.6]});
export const mmToPoints=value=>Number(value)*72/25.4;
export function newDocumentOptions(input={}){
  const paper=Object.hasOwn(PAPER_SIZES,input.paper)?input.paper:input.paper==='custom'?'custom':'A4';
  let [widthMM,heightMM]=paper==='custom'?[+input.width,+input.height]:PAPER_SIZES[paper];
  if(![widthMM,heightMM].every(v=>Number.isFinite(v)&&v>=50&&v<=1000))throw Error('Choose page dimensions from 50 to 1,000 mm.');
  if(input.orientation==='landscape'&&widthMM<heightMM||input.orientation==='portrait'&&widthMM>heightMM)[widthMM,heightMM]=[heightMM,widthMM];
  const width=mmToPoints(widthMM),height=mmToPoints(heightMM),pages=input.pages===undefined?1:Number(input.pages),margin=mmToPoints(input.margin===undefined?20:input.margin);
  if(!Number.isInteger(pages)||pages<1||pages>200)throw Error('Choose from 1 to 200 pages.');
  if(!Number.isFinite(margin)||margin<0||margin*2>Math.min(width,height)-36)throw Error('Reduce the margins to leave at least 36 pt for content.');
  const name=String(input.name||'Untitled').trim().replace(/[\\/:*?"<>|\x00-\x1f]/g,'-').replace(/\.pdf$/i,'').slice(0,120)||'Untitled';
  return{paper,width,height,pages,margin,name:name+'.pdf',guide:['ruled','squared'].includes(input.guide)?input.guide:'blank'};
}
export async function createBlankPDF(input={}){
  const options=newDocumentOptions(input),doc=await PDFDocument.create(),{width,height,pages,margin,guide}=options;
  doc.setTitle(options.name.replace(/\.pdf$/i,''));doc.setCreator('PDFCreator');doc.setProducer('PDFCreator');
  for(let i=0;i<pages;i++){
    const p=doc.addPage([width,height]);
    p.node.set(PDFName.of('PDFCreatorCreation'),doc.context.obj({Margin:margin,Guide:doc.context.obj(guide)}));
    if(guide!=='blank'){
      const spacing=mmToPoints(guide==='squared'?5:8),colour=rgb(.85,.87,.91);
      for(let y=height-margin-spacing;y>=margin;y-=spacing)p.drawLine({start:{x:margin,y},end:{x:width-margin,y},thickness:.35,color:colour});
      if(guide==='squared')for(let x=margin;x<=width-margin;x+=spacing)p.drawLine({start:{x,y:margin},end:{x,y:height-margin},thickness:.35,color:colour});
    }
  }
  return{...options,bytes:new Uint8Array(await doc.save({useObjectStreams:false}))};
}
export async function chooseNewDocument(modal){
 const sizes=Object.keys(PAPER_SIZES).map(p=>`<option>${p}</option>`).join('');
 return modal('New PDF',`<div id="createNewOptions"><label for="createName">Document name</label><input id="createName" value="Untitled" maxlength="120"><div class="create-fields"><div><label for="createPaper">Page size</label><select id="createPaper">${sizes}<option value="custom">Custom</option></select></div><div><label for="createOrientation">Orientation</label><select id="createOrientation"><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></div><div><label for="createPages">Pages</label><input id="createPages" type="number" min="1" max="200" value="1"></div><div><label for="createMargin">Margins (mm)</label><input id="createMargin" type="number" min="0" step="1" value="20"></div></div><div id="createCustom" class="create-fields" hidden><div><label for="createWidth">Width (mm)</label><input id="createWidth" type="number" min="50" max="1000" value="210"></div><div><label for="createHeight">Height (mm)</label><input id="createHeight" type="number" min="50" max="1000" value="297"></div></div><label for="createGuide">Paper style</label><select id="createGuide"><option value="blank">Blank</option><option value="ruled">Ruled</option><option value="squared">Squared</option></select><p class="help">Create your pages, then add text, pictures, shapes or form fields using the editing tools.</p></div>`,{
  wide:true,ok:'Create PDF',setup:()=>{const $=id=>document.getElementById(id);$('createPaper').onchange=()=>{$('createCustom').hidden=$('createPaper').value!=='custom';for(const input of $('createCustom').querySelectorAll('input'))input.disabled=$('createCustom').hidden};$('createPaper').onchange()},
  read:()=>{const $=id=>document.getElementById(id),input={name:$('createName').value,paper:$('createPaper').value,orientation:$('createOrientation').value,pages:$('createPages').value,margin:$('createMargin').value,width:$('createWidth').value,height:$('createHeight').value,guide:$('createGuide').value};newDocumentOptions(input);return input}
 });
}
