/* Regression for real subset fonts without cmap; exact text, repeated edits,
 * line/paragraph/chunk paths, transforms, Unicode and independent extraction. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import * as E from './engine.js';
import {convertOfflineWord} from './offline-word-converter.js';
import {wordFixture} from './offline-word-fixtures.mjs';
import {directTextTargets,directEditTargets,directChunkTarget,replaceDirectText,replaceDirectTextGroup,transformDirectText,saveDirectEdit} from './direct-text.js';
import {preserveNativeTextUnicode} from './native-text-unicode.js';
import {planReplacements,applyReplacements} from './find-replace.js';
let count=0;const check=(v,label)=>{count++;assert.ok(v,label)},equal=(a,b,label)=>{count++;assert.deepEqual(a,b,label)},fold=text=>text.replace(/\s+/gu,' ').trim();
const fonts=Object.fromEntries([['regular','Regular'],['bold','Bold'],['italic','Italic'],['boldItalic','BoldItalic']].map(([key,label])=>[key,new Uint8Array(fs.readFileSync('fonts/Arimo-'+label+'.ttf'))]));
const phrase='ReadCoach helps learners practise English. café résumé 0123456789: A+B / a=b.',replacement='ReadCoach helps learners practise English. résumé café 9876543210: B+A / b=a.';
const converted=await convertOfflineWord(wordFixture({text:phrase}),fonts);
for(const rotation of [0,90,180,270]){
 let bytes=converted.bytes;const original=E.openPDF(bytes);try{const page=original.loadPage(0);page.getObject().put('Rotate',rotation);page.destroy();bytes=saveDirectEdit(original)}finally{original.destroy()}
 for(const scope of ['paragraph','chunk']){
  let current=bytes;
  for(const value of [replacement,phrase,replacement]){
   const doc=E.openPDF(current);try{
    let target=directEditTargets(doc,0).find(t=>t.text.startsWith('ReadCoach'));
    check(target,'edited subset paragraph reopens with readable characters');
    if(scope==='chunk')target=directChunkTarget(doc,0,target.rect);
    const before=E.extractTextPDF(current)[0].text;
    replaceDirectTextGroup(doc,0,target,value,{width:target.layout.width});current=saveDirectEdit(doc);
    check(fold(E.extractTextPDF(current)[0].text).includes(value),'exact Unicode survives save/reopen');
    check(E.extractTextPDF(current)[0].text.includes('HEADER RETAINED')&&before.includes('HEADER RETAINED'),'unselected text survives');
    const reopened=E.openPDF(current);try{equal(directEditTargets(reopened,0).find(t=>t.text.startsWith('ReadCoach'))?.text,value,'editor target equals intended text after every edit')}finally{reopened.destroy()}
   }finally{doc.destroy()}
  }
  if(rotation===0&&scope==='paragraph'){
   const independent=spawnSync('pdftotext',['-layout','-','-'],{input:Buffer.from(current)});
   if(!independent.error){equal(independent.status,0,'independent PDF text extraction succeeds');check(fold(independent.stdout.toString()).includes(replacement),'Poppler reads exact edited words, numbers, accents and punctuation')}
   fs.mkdirSync('../../tmp',{recursive:true});fs.writeFileSync('../../tmp/text-unicode-proof.pdf',current);fs.writeFileSync('../../tmp/text-unicode-proof.png',E.renderPagePNG(current,0,{scale:1.2}).bytes);
  }
 }
}
for(const [original,replacement]of [['TABLE LEFT','LEFT TABLE'],['Italic and underline retained.','retained. Italic and underline']]){
 const doc=E.openPDF(converted.bytes);try{const target=directTextTargets(doc,0).find(t=>t.text===original);replaceDirectText(doc,0,target,replacement);const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);try{check(directTextTargets(reopened,0).some(t=>t.text===replacement),'single-line edit retains subset-font Unicode');replaceDirectText(reopened,0,directTextTargets(reopened,0).find(t=>t.text===replacement),original);check(E.extractTextPDF(saveDirectEdit(reopened))[0].text.includes(original),'single-line subset text supports a second edit')}finally{reopened.destroy()}}finally{doc.destroy()}
}
for(const action of ['transform','duplicate']){
 const doc=E.openPDF(converted.bytes);try{const target=directEditTargets(doc,0).find(t=>t.text.startsWith('ReadCoach'));transformDirectText(doc,0,target,{action,matrix:[1,0,0,1,0,2]});const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);try{const matches=directEditTargets(reopened,0).filter(t=>t.text.startsWith('ReadCoach'));check(matches.length>0,'transformed subset text remains readable');check(fold(E.extractTextPDF(bytes)[0].text).includes(phrase),'move/duplicate keeps searchable words')}finally{reopened.destroy()}}finally{doc.destroy()}
}
{
 const doc=E.openPDF(converted.bytes);try{const plan=planReplacements(doc,{query:'ReadCoach',replacement:'CoachRead',pages:[0],caseSensitive:true});equal(plan.length,1,'Find and replace locates the subset-font paragraph');applyReplacements(doc,plan);const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);try{check(fold(E.extractTextPDF(bytes)[0].text).includes(phrase.replace('ReadCoach','CoachRead')),'Find and replace preserves exact Unicode');check(directEditTargets(reopened,0).some(t=>t.text.startsWith('CoachRead')),'Find and replace output reopens in Direct edit')}finally{reopened.destroy()}}finally{doc.destroy()}
}
{
 const doc=E.openPDF(converted.bytes);try{const target=directEditTargets(doc,0).find(t=>t.text.startsWith('ReadCoach'));replaceDirectTextGroup(doc,0,target,replacement,{formatting:[{start:0,end:9,style:{font:'Courier',size:16,italic:true,underline:true,color:'#0044aa'}}]});const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);try{check(fold(E.extractTextPDF(bytes)[0].text).includes(replacement),'mixed original and new fonts retain exact words');check(directTextTargets(reopened,0).find(t=>t.text==='ReadCoach')?.underline,'mixed-font formatting survives with repaired text')}finally{reopened.destroy()}}finally{doc.destroy()}
}
// A valid cmap may map a glyph to several Unicode values. The writer's reverse
// map is not authoritative; use the requested scalar, including surrogate pairs.
{
 const fontPath=[process.env.PDFPRO_TEST_TTF,'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','fonts/Arimo-Regular.ttf'].find(p=>p&&fs.existsSync(p));
 const font=new E.mupdf.Font('UnicodeFixture',fs.readFileSync(fontPath)),text=new E.mupdf.Text(),buffer=new E.mupdf.Buffer(),writer=new E.mupdf.DocumentWriter(buffer,'pdf','compress'),glyphs=[];
 try{const value='café Ω Ж'+(font.encodeCharacter(0x1f600)?' 😀':''),matrix=[18,0,0,-18,40,60];let x=40;for(const ch of value){const unicode=ch.codePointAt(0),gid=font.encodeCharacter(unicode);check(gid>0,'Unicode fixture has glyph '+ch);text.showGlyph(font,[...matrix.slice(0,4),x,60],gid,unicode);glyphs.push({font,gid,unicode});x+=font.advanceGlyph(gid)*18}const device=writer.beginPage([0,0,500,200]);try{device.fillText(text,E.mupdf.Matrix.identity,E.mupdf.ColorSpace.DeviceRGB,[0,0,0],1)}finally{device.destroy()}writer.endPage();writer.close();const result=preserveNativeTextUnicode(buffer.asUint8Array(),glyphs);equal(E.extractTextPDF(result)[0].text.trim(),value,'BMP and supplementary Unicode are stored correctly');count++;assert.throws(()=>preserveNativeTextUnicode(buffer.asUint8Array(),[glyphs[0],{...glyphs[0],unicode:66}]),/cannot preserve/,'ambiguous glyph aliases are refused before source mutation')}
 finally{writer.destroy();buffer.destroy();text.destroy();font.destroy()}
}
console.log('Native text Unicode: '+count+' assertions passed with subset fonts, repeated edits, transforms, formatting and independent PDF extraction.');
