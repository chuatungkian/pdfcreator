/* Device-font rich text, a safe run model and on-page preview. No HTML is stored in PDFs. */
import {SYSTEM_FONTS,systemFontFamily} from './system-fonts.js';
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const validColor=c=>/^#[a-f\d]{6}$/i.test(c);
export function normaliseRich(input,defaults={}){
  const base={font:SYSTEM_FONTS.includes(defaults.font)?defaults.font:'Arial',size:Math.max(4,Math.min(144,+defaults.size||14)),color:validColor(defaults.color)?defaults.color:'#800020',bold:false,italic:false};
  const doc=typeof input==='string'?{paragraphs:input.split('\n').map(text=>({runs:[{text}]}))}:input;
  if(!Array.isArray(doc?.paragraphs)||doc.paragraphs.length>1000)throw Error('Use up to 1,000 paragraphs.');
  let length=0,runCount=0;for(const p of doc.paragraphs){if(!Array.isArray(p.runs)||p.runs.length>10000||(runCount+=p.runs.length)>20000)throw Error('Too many formatting runs.');}
  const paragraphs=doc.paragraphs.map(p=>({align:['left','center','right'].includes(p.align)?p.align:'left',bullet:!!p.bullet,runs:(p.runs||[]).map(r=>{
    const text=String(r.text||'').replace(/\r\n?/g,'\n');length+=Array.from(text).length;
    if(/[\u0000-\u0008\u000b-\u001f\u007f]/u.test(text))throw Error('Text contains unsupported control characters.');
    return{text,font:SYSTEM_FONTS.includes(r.font)?r.font:base.font,size:Math.max(4,Math.min(144,+r.size||base.size)),color:validColor(r.color)?r.color:base.color,bold:!!r.bold,italic:!!r.italic};
  })}));
  if(length>10000)throw Error('Use up to 10,000 characters.');
  return{paragraphs,lineSpacing:Math.max(1,Math.min(3,+doc.lineSpacing||1.35)),paragraphSpacing:Math.max(0,Math.min(72,+doc.paragraphSpacing||0))};
}
export const richPlain=doc=>doc.paragraphs.map(p=>(p.bullet?'• ':'')+p.runs.map(r=>r.text).join('')).join('\n');
const cssFont=r=>(r.italic?'italic ':'')+(r.bold?'700 ':'')+r.size+'px '+systemFontFamily(r.font);
export async function renderRichText(input,{font='Arial',size=14,color='#800020',width=240,height=60,kind='text',shrink=false}={}){
  const rich=normaliseRich(input,{font,size,color}),text=richPlain(rich);if(!text.trim())throw Error('Enter some text.');
  if(![width,height].every(Number.isFinite)||width<8||height<8||width*height>48000000)throw Error('Select a text area of at least 8 × 8 pt.');
  const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d'),pad=kind==='stamp'?6:3,available=width-2*pad;
  function layout(factor){
    let y=pad;const segments=[];
    for(const p of rich.paragraphs){let line=[],used=0;const defaultSize=(p.runs[0]?.size||size)*factor;
      const flush=()=>{const max=Math.max(defaultSize,...line.map(s=>s.run.size)),baseline=y+max*.95,indent=p.align==='center'?Math.max(0,(available-used)/2):p.align==='right'?Math.max(0,available-used):0;for(const s of line)segments.push({text:s.text,x:pad+s.x+indent,y:baseline,width:s.width,run:s.run});y+=max*rich.lineSpacing;line=[];used=0};
      const runs=p.bullet?[{...(p.runs[0]||{font,size,color}),text:'• '},...p.runs]:p.runs;
      for(const original of runs){const r={...original,size:original.size*factor};ctx.font=cssFont(r);
        for(const token of r.text.match(/\n|[^\S\n]+|[^\s]+/gu)||[]){if(token==='\n'){flush();continue}const tokenWidth=ctx.measureText(token).width;if(used&&used+tokenWidth>available){flush();if(/^\s+$/u.test(token))continue}
          let chunk='',chunkWidth=0;const emit=()=>{if(chunk){line.push({text:chunk,x:used,width:chunkWidth,run:r});used+=chunkWidth;chunk='';chunkWidth=0}};
          for(const ch of token){const w=ctx.measureText(chunk+ch).width;if(used+w>available&&chunk){emit();flush()}else if(used+w>available&&used){flush()}chunk+=ch;chunkWidth=ctx.measureText(chunk).width;if(chunkWidth>available+.01)throw Error('A glyph is wider than the text area. Increase its width.')}emit();
        }
      }
      flush();y+=rich.paragraphSpacing*factor;
    }
    return{segments,fits:y-rich.paragraphSpacing*factor<=height-pad+.01};
  }
  let factor=1,result=layout(factor);if(!result.fits&&shrink){let lo=4/Math.min(...rich.paragraphs.flatMap(p=>p.runs.map(r=>r.size))),hi=1;result=layout(lo);if(result.fits){factor=lo;for(let i=0;i<12;i++){const mid=(lo+hi)/2,next=layout(mid);if(next.fits){factor=lo=mid;result=next}else hi=mid}}}
  if(!result.fits)throw Error('The complete text does not fit. Enlarge the area or reduce the size or spacing.');
  const scale=Math.min(4,Math.sqrt(12000000/(width*height)));canvas.width=Math.ceil(width*scale);canvas.height=Math.ceil(height*scale);const paint=canvas.getContext('2d');paint.scale(scale,scale);paint.textBaseline='alphabetic';
  for(const s of result.segments){paint.font=cssFont(s.run);paint.fillStyle=s.run.color;paint.fillText(s.text,s.x,s.y)}
  const blob=await new Promise(r=>canvas.toBlob(r,'image/png'));if(!blob)throw Error('Unable to render the text preview.');const png=new Uint8Array(await blob.arrayBuffer());canvas.width=canvas.height=0;
  return{png,width,height,text,rich:normaliseRich({...rich,paragraphs:rich.paragraphs.map(p=>({...p,runs:p.runs.map(r=>({...r,size:r.size*factor}))}))}),font,size:size*factor,color,kind,shrunk:factor<.999,inkRect:[0,0,width,height],lines:result.segments};
}
export function openRichEditor({overlay,rect,bounds,zoom,layoutWidth=rect[2]-rect[0],layoutHeight=rect[3]-rect[1],previewMatrix=null,initial='Your text',defaults={},kind='text',apply,onClose}){
  let model=normaliseRich(initial,defaults),closed=false,version=0,range=null,lastAppearance=null,working=false;
  const root=document.createElement('section');root.className='rich-editor';root.setAttribute('role','dialog');root.setAttribute('aria-label','Rich text editor');
  root.innerHTML=`<div class="rich-toolbar"><select aria-label="Font" data-rich="font">${SYSTEM_FONTS.map(f=>`<option>${escape(f)}</option>`).join('')}</select><input aria-label="Text size" data-rich="size" type="number" min="4" max="144"><input aria-label="Text colour" data-rich="color" type="color"><button type="button" data-style="bold" aria-label="Bold"><b>B</b></button><button type="button" data-style="italic" aria-label="Italic"><i>I</i></button><select data-rich="align" aria-label="Alignment"><option value="left">Left</option><option value="center">Centre</option><option value="right">Right</option></select><button type="button" data-style="bullet" aria-label="Bullet list">• List</button><label>Line <input data-rich="lineSpacing" aria-label="Line spacing" type="number" min="1" max="3" step="0.1" value="${model.lineSpacing}"></label><label>Gap <input data-rich="paragraphSpacing" aria-label="Paragraph spacing" type="number" min="0" max="72" value="${model.paragraphSpacing}"></label></div><div class="rich-input" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Text to add" spellcheck="true"></div><div class="rich-footer"><label class="rich-fit"><input type="checkbox" data-rich="fit" checked>Fit to area</label><span role="alert" class="rich-error"></span><button type="button" data-cancel>Cancel</button><button type="button" data-apply class="primary">Apply</button></div>`;
  const input=root.querySelector('.rich-input'),error=root.querySelector('.rich-error'),preview=document.createElement('canvas');preview.className='rich-preview';preview.setAttribute('aria-hidden','true');
  Object.assign(preview.style,{left:(rect[0]-bounds[0])*zoom+'px',top:(rect[1]-bounds[1])*zoom+'px',width:(rect[2]-rect[0])*zoom+'px',height:(rect[3]-rect[1])*zoom+'px'});
  if(previewMatrix)Object.assign(preview.style,{left:'0px',top:'0px',width:layoutWidth*zoom+'px',height:layoutHeight*zoom+'px',transformOrigin:'0 0',transform:`matrix(${previewMatrix.slice(0,4).join(',')},${(previewMatrix[4]-bounds[0])*zoom},${(previewMatrix[5]-bounds[1])*zoom})`});
  input.innerHTML=model.paragraphs.map(p=>`<div style="text-align:${p.align}" data-bullet="${p.bullet}">${p.runs.map(r=>`<span style="font-family:${escape(r.font)};font-size:${r.size}px;color:${r.color};font-weight:${r.bold?'700':'400'};font-style:${r.italic?'italic':'normal'}">${escape(r.text).replace(/\n/g,'<br>')}</span>`).join('')||'<br>'}</div>`).join('');
  const sel=name=>root.querySelector(`[data-rich="${name}"]`);sel('font').value=defaults.font||model.paragraphs[0]?.runs[0]?.font||'Arial';sel('size').value=defaults.size||14;sel('color').value=defaults.color||'#800020';
  function read(){const paragraphs=[];const walk=(node,style,runs)=>{if(node.nodeType===3){runs.push({...style,text:node.nodeValue.replace(/\u200b/g,'')});return}if(node.nodeName==='BR'){runs.push({...style,text:'\n'});return}const s=node.style||{},next={...style};if(SYSTEM_FONTS.includes(s.fontFamily.replace(/["']/g,'')))next.font=s.fontFamily.replace(/["']/g,'');if(s.fontSize)next.size=parseFloat(s.fontSize);if(s.color){const m=s.color.match(/\d+/g);if(m?.length>=3)next.color='#'+m.slice(0,3).map(n=>(+n).toString(16).padStart(2,'0')).join('');else if(validColor(s.color))next.color=s.color}if(s.fontWeight)next.bold=+s.fontWeight>=600||s.fontWeight==='bold';if(['B','STRONG'].includes(node.nodeName))next.bold=true;if(s.fontStyle)next.italic=s.fontStyle==='italic';if(['I','EM'].includes(node.nodeName))next.italic=true;for(const child of node.childNodes)walk(child,next,runs)};
    let loose=[];const flush=()=>{if(loose.length){paragraphs.push({align:sel('align').value,runs:loose});loose=[]}};
    for(const child of input.childNodes){if(['DIV','P','LI'].includes(child.nodeName)){flush();const runs=[];walk(child,{font:sel('font').value,size:+sel('size').value,color:sel('color').value},runs);paragraphs.push({align:child.style.textAlign||'left',bullet:child.dataset.bullet==='true',runs})}else walk(child,{font:sel('font').value,size:+sel('size').value,color:sel('color').value},loose)}flush();return normaliseRich({paragraphs:paragraphs.length?paragraphs:[{runs:[]}],lineSpacing:+sel('lineSpacing').value,paragraphSpacing:+sel('paragraphSpacing').value});
  }
  async function update(){const id=++version;lastAppearance=null;try{model=read();const appearance=await renderRichText(model,{...defaults,width:layoutWidth,height:layoutHeight,kind,shrink:root.querySelector('[data-rich=fit]').checked});if(id!==version||closed)return;const image=new window.Image();image.onload=()=>{if(id!==version||closed)return;preview.width=image.width;preview.height=image.height;preview.getContext('2d').drawImage(image,0,0)};image.src='data:image/png;base64,'+btoa(Array.from(appearance.png,b=>String.fromCharCode(b)).join(''));lastAppearance=appearance;error.textContent=appearance.shrunk?'Live preview · fitted to area':'Live preview on page';}catch(e){if(id===version){error.textContent=e.message;preview.width=preview.height=1}}}
  function remember(){const s=window.getSelection();if(s?.rangeCount&&input.contains(s.anchorNode)&&input.contains(s.focusNode))range=s.getRangeAt(0).cloneRange()}
  const selectionListener=()=>{remember();const selection=window.getSelection();if(!input.contains(selection?.anchorNode))return;const element=selection.anchorNode.nodeType===1?selection.anchorNode:selection.anchorNode.parentElement,style=window.getComputedStyle(element);root.querySelector('[data-style=bold]').setAttribute('aria-pressed',String(+style.fontWeight>=600||style.fontWeight==='bold'));root.querySelector('[data-style=italic]').setAttribute('aria-pressed',String(style.fontStyle==='italic'))};document.addEventListener('selectionchange',selectionListener);
  function selectedBlocks(){if(!range)return [...input.children];return [...input.children].filter(n=>range.intersectsNode(n))}
  function format(key,value){if(key==='align'||key==='bullet'){for(const block of selectedBlocks()){if(key==='align')block.style.textAlign=value;else block.dataset.bullet=block.dataset.bullet!=='true'}void update();return}
    const span=document.createElement('span');const css={font:'fontFamily',size:'fontSize',color:'color',bold:'fontWeight',italic:'fontStyle'};span.style[css[key]]=key==='size'?value+'px':key==='bold'?(value?'700':'400'):key==='italic'?(value?'italic':'normal'):value;
    if(range&&input.contains(range.commonAncestorContainer)){span.append(range.extractContents());if(!span.textContent)span.textContent='\u200b';range.insertNode(span);const s=window.getSelection();s.removeAllRanges();range=document.createRange();range.selectNodeContents(span);s.addRange(range)}else{for(const block of input.children)block.style[css[key]]=span.style[css[key]]}void update();
  }
  root.querySelectorAll('[data-style]').forEach(b=>{b.onmousedown=e=>{e.preventDefault();remember()};b.onclick=()=>{const k=b.dataset.style;b.setAttribute('aria-pressed',String(b.getAttribute('aria-pressed')!=='true'));format(k,b.getAttribute('aria-pressed')==='true')}});
  for(const k of ['font','size','color','align'])sel(k).onchange=()=>format(k,sel(k).value);for(const k of ['lineSpacing','paragraphSpacing'])sel(k).oninput=update;
  root.querySelector('[data-rich=fit]').onchange=update;input.oninput=update;input.onpaste=e=>{e.preventDefault();const text=e.clipboardData?.getData('text/plain')||'',s=window.getSelection();if(!s?.rangeCount)return;const r=s.getRangeAt(0);r.deleteContents();const n=document.createTextNode(text);r.insertNode(n);r.setStartAfter(n);r.collapse(true);s.removeAllRanges();s.addRange(r);void update()};
  function close(){if(closed)return;closed=true;version++;document.removeEventListener('selectionchange',selectionListener);root.remove();preview.remove();onClose?.()}
  root.querySelector('[data-cancel]').onclick=close;root.querySelector('[data-apply]').onclick=async()=>{if(working)return;working=true;try{const appearance=await renderRichText(read(),{...defaults,width:layoutWidth,height:layoutHeight,kind,shrink:root.querySelector('[data-rich=fit]').checked});if(await apply(appearance)!==false)close()}catch(e){error.textContent=e.message}finally{working=false}};
  root.onpointerdown=e=>e.stopPropagation();root.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();close()}if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();root.querySelector('[data-apply]').click()}};
  overlay.append(preview,root);const pageY=(rect[3]-bounds[1])*zoom,main=document.getElementById('main'),view=main.getBoundingClientRect(),ob=overlay.getBoundingClientRect();Object.assign(root.style,{left:Math.max(0,Math.min((rect[0]-bounds[0])*zoom,overlay.clientWidth-620))+'px',top:Math.max(0,Math.min(pageY+10,(view.bottom||window.innerHeight)-ob.top-220))+'px'});void update();input.focus();return{close,hasChanges:()=>true};
}
