/* Centred, identifiable watermark layers and conservative imported-layer discovery. */
import {PDFName,PDFArray,PDFHexString,PDFOperator} from 'pdf-lib';
import {mupdf} from './engine.js';
import {renderSystemText,measureSystemText,SYSTEM_FONTS} from './system-fonts.js';
import {drawSystemText} from './pdf-font-text.js';
import {pageObjects,readPageContent,contentTokens} from './object-tools.js';
import {directTextTargets} from './direct-text.js';
const KEY='PDFCreatorWatermarks',I=[1,0,0,1,0,0],concat=mupdf.Matrix.concat;
const binary=s=>Uint8Array.from(s,c=>c.charCodeAt(0));
export function watermarkGeometry(doc,index){const page=doc.loadPage(index);try{return{bounds:page.getBounds(),transform:page.getTransform()}}finally{page.destroy()}}
export function watermarkSettings(value={}){
  const text=String(value.text??'').trim(),font=value.font||'Arial',size=+(value.size??60),opacity=+(value.opacity??.15),angle=+(value.angle??28),color=value.color||'#800020';
  if(!text||Array.from(text).length>300||/[\r\n\x00-\x1f]/.test(text))throw Error('Enter one line of watermark text, up to 300 characters.');
  if(!SYSTEM_FONTS.includes(font)||!/^#[a-f\d]{6}$/i.test(color))throw Error('Choose a valid watermark font and colour.');
  if(![size,opacity,angle].every(Number.isFinite)||size<4||size>144||opacity<.05||opacity>1||angle< -180||angle>180)throw Error('Use 4–144 pt, opacity 0.05–1 and an angle from −180° to 180°.');
  return{text,font,size,opacity,angle,color};
}
export async function addWatermark(doc,index,input,geometry){
  const settings=watermarkSettings(input),page=doc.getPage(index),{bounds,transform}=geometry;
  const w=bounds[2]-bounds[0],h=bounds[3]-bounds[1],natural=measureSystemText(settings.text,{font:settings.font,size:settings.size});
  const size=Math.max(4,Math.min(settings.size,settings.size*Math.max(8,w-48)/Math.max(1,natural))),width=Math.max(16,measureSystemText(settings.text,{font:settings.font,size})+14),height=size*2.1+8;
  const appearance=await renderSystemText(settings.text,{font:settings.font,size,color:settings.color,width,height,shrink:false,inkAngle:-settings.angle*Math.PI/180});
  const ink=appearance.inkRect,cx=(ink[0]+ink[2])/2,cy=(ink[1]+ink[3])/2,angle=-settings.angle*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),iw=ink[2]-ink[0],ih=ink[3]-ink[1];
  const rotated=appearance.rotatedInk||mupdf.Rect.transform(ink,[c,s,-s,c,0,0]),rw=rotated[2]-rotated[0],rh=rotated[3]-rotated[1];
  const fit=Math.min(1,Math.max(8,w-48)/rw,Math.max(8,h-48)/rh),dx=(bounds[0]+bounds[2])/2-fit*(rotated[0]+rotated[2])/2,dy=(bounds[1]+bounds[3])/2-fit*(rotated[1]+rotated[3])/2;
  const view=[c*fit,s*fit,-s*fit,c*fit,dx,dy];
  const matrix=concat(concat([1,0,0,-1,0,height],view),mupdf.Matrix.invert(transform));
  page.pushOperators(PDFOperator.of('BDC',[PDFName.of('Artifact'),doc.context.obj({Type:'Pagination',Subtype:'Watermark'})]));
  const result=await drawSystemText(doc,page,appearance,{x:matrix[4],y:matrix[5],matrix,opacity:settings.opacity,track:false});
  page.pushOperators(PDFOperator.of('EMC'));
  let records=page.node.lookupMaybe(PDFName.of(KEY),PDFArray);if(!records){records=doc.context.obj([]);page.node.set(PDFName.of(KEY),records)}
  records.push(doc.context.obj({ID:PDFHexString.fromText(globalThis.crypto?.randomUUID?.()||'wm-'+Date.now()+'-'+Math.random()),Resource:PDFName.of(result.resource),Settings:PDFHexString.fromText(JSON.stringify({...settings,actualSize:size*fit,width,height,ink}))}));
  return{matrix,ink,appearance,settings,rect:[rotated[0]*fit+dx,rotated[1]*fit+dy,rotated[2]*fit+dx,rotated[3]*fit+dy]};
}
function textForCommands(source,pageObject,commands){
  const doc=new mupdf.PDFDocument();let page,st;
  try{
    const resources=doc.graftObject(pageObject.getInheritable('Resources')),media=pageObject.getInheritable('MediaBox').asJS(),rotation=pageObject.getInheritable('Rotate').asNumber()||0;
    const object=doc.addPage(media,rotation,resources,binary(commands)),crop=pageObject.getInheritable('CropBox'),unit=pageObject.get('UserUnit');
    if(crop.isArray())object.put('CropBox',crop.asJS());if(unit.isNumber())object.put('UserUnit',unit.asNumber());crop.destroy();unit.destroy();doc.insertPage(-1,object);object.destroy();resources.destroy();
    page=doc.loadPage(0);st=page.toStructuredText('');const text=st.asText().trim().replace(/\s+/g,' '),runs=directTextTargets(doc,0);return{text,runs};
  }catch{return{text:'',runs:[]}}finally{st?.destroy();page?.destroy();doc.destroy()}
}
function union(rects){return[Math.min(...rects.map(r=>r[0])),Math.min(...rects.map(r=>r[1])),Math.max(...rects.map(r=>r[2])),Math.max(...rects.map(r=>r[3]))]}
function fontFor(name){return SYSTEM_FONTS.find(f=>name.replace(/[^a-z]/gi,'').toLowerCase().includes(f.replace(/[^a-z]/gi,'').toLowerCase()))||(/times/i.test(name)?'Times New Roman':/courier/i.test(name)?'Courier New':'Arial')}
export function scanWatermarks(doc){
  const rows=[];
  for(let index=0;index<doc.countPages();index++){
    const page=doc.loadPage(index),object=page.getObject(),source=readPageContent(page),geometry={bounds:page.getBounds(),transform:page.getTransform()},tokens=contentTokens(source),resources=object.getInheritable('Resources');
    try{
      const tracked=new Map(),records=object.get(KEY);try{if(records.isArray())records.forEach(r=>{try{tracked.set(r.get('Resource').asName(),{id:r.get('ID').asString(),settings:JSON.parse(r.get('Settings').asString())})}catch{}})}finally{records.destroy()}
      for(const item of pageObjects(doc,index)){
        if(item.kind==='annotation'){if(item.type==='Watermark')rows.push({id:index+':annotation:'+item.index,page:index,kind:'annotation',index:item.index,rect:item.rect,text:item.text,source:'Watermark annotation',confirmed:true,settings:{text:item.text,font:'Arial',size:60,color:'#800020',opacity:.15,angle:28}});continue}
        const metadata=tracked.get(item.name),form=resources.get('XObject').get(item.name),oc=form.get('OC'),ocName=form.get('OC','Name'),printSubtype=form.get('OC','Usage','Print','Subtype');let explicit=item.watermark;
        try{explicit=explicit||/watermark/i.test(ocName.asString())||printSubtype.asName()==='Watermark'}finally{ocName.destroy();printSubtype.destroy();oc.destroy()}
        let legacy=false;
        if(!metadata&&!explicit&&item.type==='Content group'&&item.opacity<.5){const buffer=form.readStream();try{const raw=buffer.asString(),m=item.paintMatrix;legacy=/ActualText/.test(raw)&&/\b3\s+Tr\b/.test(raw)&&Math.abs(m[1])+Math.abs(m[2])>.1}catch{}finally{buffer.destroy()}}
        form.destroy();if(!metadata&&!explicit&&!legacy)continue;
        const extracted=metadata?{text:metadata.settings.text}:textForCommands(source,object,'q '+source.slice(item.start,item.end)+' Q');
        // Copy the current invocation transform so the form's text can be extracted at its normal scale.
        const label=metadata?.settings.text||extracted.text||'Image or vector watermark',settings=metadata?.settings||{text:extracted.text,font:'Arial',size:60,color:'#800020',opacity:item.opacity,angle:-Math.atan2(item.paintMatrix[1],item.paintMatrix[0])*180/Math.PI};
        let rect=item.rect;if(metadata?.settings.ink){const s=metadata.settings,b=[s.ink[0],s.height-s.ink[3],s.ink[2],s.height-s.ink[1]];rect=mupdf.Rect.transform(b,item.paintMatrix)}
        rows.push({...item,id:index+':object:'+item.index,page:index,kind:'object',text:label,rect,settings,recordId:metadata?.id||null,source:metadata?'PDFCreator':explicit?'Tagged watermark':'Legacy PDFCreator candidate',confirmed:!!metadata||explicit});
      }
      // Inspect isolated text objects. Removal keeps font/spacing state and strips only their text-show operators.
      let ctm=I,alpha=1,stack=[],operands=[],font=null,fontSize=12,renderMode=0,block=null,marked=[],attempts=0,sourceRuns=null;
      for(const token of tokens){if(token.kind!=='operator'){operands.push(token);continue}
        const op=token.text;
        if(op==='q')stack.push({ctm:[...ctm],alpha,font,fontSize,renderMode});else if(op==='Q'&&stack.length)({ctm,alpha,font,fontSize,renderMode}=stack.pop());else if(op==='cm'&&operands.length>=6)ctm=concat(operands.slice(-6).map(t=>+t.text),ctm);
        else if(op==='gs'){const gs=resources.get('ExtGState',operands.at(-1)?.text.slice(1)||''),ca=gs.get('ca');try{if(ca.isNumber())alpha=ca.asNumber()}finally{ca.destroy();gs.destroy()}}
        else if(op==='Tr')renderMode=+operands.at(-1)?.text||0;
        else if(op==='Tf'&&operands.length>=2){font=operands.at(-2).text;fontSize=+operands.at(-1).text}
        else if(op==='BDC'||op==='BMC')marked.push(/\/Subtype\s*\/Watermark/.test(source.slice(operands[0]?.start??token.start,token.end)));
        else if(op==='EMC')marked.pop();
        else if(op==='BT')block={start:token.start,ctm:[...ctm],alpha,font,fontSize,renderMode,explicit:marked.some(Boolean)};
        else if(op==='ET'&&block){const current=block;block=null;const raw=source.slice(current.start,token.end),t=contentTokens(raw),angled=t.some((v,i)=>v.text==='Tm'&&t[i-5]?.kind==='number'&&(Math.abs(+t[i-5].text)+Math.abs(+t[i-4].text)>.02));
          if(!current.explicit&&current.alpha>=.5&&!angled)continue;if(++attempts>300)continue;if(current.renderMode>=4||t.some((v,i)=>v.text==='Tr'&&+t[i-1]?.text>=4))continue;
          const prefix='q '+current.ctm.join(' ')+' cm '+(current.font?'BT '+current.font+' '+current.fontSize+' Tf ET ':'');
          const sample=textForCommands(source,object,prefix+raw+' Q'),runs=sample.runs;if(!runs.length||!sample.text||sample.text.length>1000)continue;
          if(!current.explicit&&!runs.every(r=>r.size>=18&&(current.alpha<.5||Math.abs(r.matrix[1])>.1)))continue;
          const rect=union(runs.map(r=>r.rect));if(rows.some(r=>r.kind==='object'&&rect[0]>=r.rect[0]-2&&rect[2]<=r.rect[2]+2&&rect[1]>=r.rect[1]-2&&rect[3]<=r.rect[3]+2))continue;
          sourceRuns ||= directTextTargets(doc,index);const first=sourceRuns.find(r=>r.text.trim()===runs[0].text.trim()&&r.rect.every((n,i)=>Math.abs(n-runs[0].rect[i])<1))||runs[0];rows.push({id:index+':text:'+current.start,page:index,kind:'text',start:current.start,end:token.end,command:raw,matrix:concat(current.ctm,geometry.transform),rect,text:sample.text,source:current.explicit?'Tagged text watermark':'Possible text watermark',confirmed:current.explicit,settings:{text:sample.text,font:fontFor(first.fontName),size:first.size,color:first.color,opacity:current.alpha,angle:-Math.atan2(first.matrix[1],first.matrix[0])*180/Math.PI}});
        }operands=[];
      }
    }finally{resources.destroy();object.destroy();page.destroy()}
  }return rows;
}
export function removeWatermarks(doc,selected){
  const fresh=scanWatermarks(doc),byPage=new Map();
  for(const row of selected){const current=fresh.find(r=>r.id===row.id);if(!current||current.text!==row.text||current.rect.some((n,i)=>Math.abs(n-row.rect[i])>.1))throw Error('A watermark changed. Scan the document again.');if(!byPage.has(row.page))byPage.set(row.page,[]);byPage.get(row.page).push(current)}
  for(const [index,rows]of byPage){const page=doc.loadPage(index),object=page.getObject(),source=readPageContent(page),ranges=[];
    try{
      const annotations=[...page.getAnnotations()];try{for(const row of rows){if(row.kind==='annotation'){page.deleteAnnotation(annotations[row.index]);continue}let replacement='';if(row.kind==='text'){
          const t=contentTokens(row.command),edits=[];let start=0;for(const [i,token]of t.entries()){if(token.kind==='operator'){if(['Tj','TJ',"'",'"'].includes(token.text))edits.push([start,token.end,token.text==='"'?t[i-3].text+' Tw '+t[i-2].text+' Tc ':'']);start=token.end}}
          replacement=row.command;for(const [a,b,keep]of edits.reverse())replacement=replacement.slice(0,a)+keep+replacement.slice(b);
        }ranges.push({start:row.start,end:row.end,replacement})}}finally{annotations.forEach(a=>a.destroy())}
      let updated=source;for(const row of ranges.sort((a,b)=>b.start-a.start))updated=updated.slice(0,row.start)+row.replacement+updated.slice(row.end);
      if(ranges.length){const stream=doc.addStream(binary(updated),{});try{object.put('Contents',stream)}finally{stream.destroy()}}
      const records=object.get(KEY);try{if(records.isArray()){const remaining=[];records.forEach(r=>{if(!rows.some(row=>row.recordId&&row.recordId===r.get('ID').asString()))remaining.push(r)});object.put(KEY,remaining)}}finally{records.destroy()}
    }finally{object.destroy();page.destroy()}
  }
}
