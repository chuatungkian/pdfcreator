/* App recovery integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8'),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;
 check(app.local.autosave.enabled,'IndexedDB autosave starts when available');
 equal($('storageLabel').textContent,'Saved on this device','storage availability is visible');
 equal(window.document.querySelectorAll('#nav .nav-icon svg').length,8,'expanded navigation shows all group icons');
 equal(window.document.querySelectorAll('#nav .nav-label').length,8,'expanded navigation retains labels');
 const alpha=await fixture(app,'ALPHA'),beta=await fixture(app,'BETA');
 await app.openFiles([file('Alpha.pdf',alpha),file('Beta.pdf',beta)]);
 const aid=app.tabs.find(tab=>tab.snapshot.name==='Alpha.pdf').id,bid=app.activeTabId;
 equal((await app.local.store.listDocuments()).length,2,'uploaded files are saved into local library');
 await app.editPDF('Beta edited',doc=>doc.getPage(0).drawText('PERSISTED EDIT',{x:40,y:710,size:13}));
 const edited=app.state.bytes;check(text(app).includes('PERSISTED EDIT'),'working PDF edit is real');
 equal((await app.local.store.getDocument(bid)).snapshot.bytes,edited,'committed edit is saved before edit handler finishes');
 app.state.page=1;app.state.fit=false;app.state.zoom=.9;await app.render();$('main').scrollTop=322;$('main').scrollLeft=18;
 app.state.marks=[{page:1,rect:[40,50,120,90]}];app.state.font='Georgia';app.state.searchQuery='BETA';
 $('toggleNav').click();await until(()=>app.state.navCollapsed,'collapse navigation');await pause();
 check(window.document.body.classList.contains('nav-compact'),'navigation can collapse to icon bar');equal($('toggleNav').getAttribute('aria-expanded'),'false','collapsed navigation reports state');
 equal(window.document.querySelectorAll('#nav [data-group]').length,8,'collapse keeps every group available');
 check([...window.document.querySelectorAll('#nav [data-group]')].every(button=>button.title&&button.getAttribute('aria-label')),'icon-only groups have labels and tooltips');
 const navBytes=app.state.bytes;window.document.querySelector('[data-group=Annotate]').click();await pause();check(app.state.paneOpen&&app.state.group==='Annotate','collapsed navigation opens requested tools');check(app.state.bytes===navBytes,'navigation collapse/group selection leaves PDF bytes unchanged');
 $('togglePages').click();$('theme').click();$('dockTools').click();await pause();await app.local.flush();
 check(app.local.autosave.isCurrent(),'full workspace becomes current');
 const saved=await app.local.store.readSession();equal(saved.openIds,[aid,bid],'open tab ordering is stored');equal(saved.activeId,bid,'active tab is stored');
 check(saved.preferences.navCollapsed&&saved.preferences.pagesCompact&&saved.preferences.dark&&saved.preferences.paneDocked,'interface choices are stored');
 const unload=new window.Event('beforeunload',{cancelable:true});window.dispatchEvent(unload);check(!unload.defaultPrevented,'saved edits do not trigger data-loss warning');
 await context.close();context=await boot();({app,$,window}=context);
 equal(app.tabs.length,2,'new app instance restores both tabs');equal(app.activeTabId,bid,'new instance restores active tab');equal(app.state.bytes,edited,'latest PDF bytes recovered');
 check(text(app).includes('PERSISTED EDIT'),'recovered PDF contains edit');equal(app.state.undo.length,1,'undo history recovered');equal(app.state.page,1,'page recovered');equal(app.state.zoom,.9,'zoom recovered');
 equal($('main').scrollTop,322,'vertical scroll recovered');equal($('main').scrollLeft,18,'horizontal scroll recovered');
 equal(app.state.marks,[{page:1,rect:[40,50,120,90]}],'pending redactions recovered');equal(app.state.font,'Georgia','font recovered');equal(app.state.searchQuery,'BETA','search query recovered');
 check(app.state.navCollapsed&&app.state.pagesCompact&&app.state.paneDocked&&window.document.body.classList.contains('dark'),'interface recovered');
 await app.activate('clearmarks');const beforeUndo=app.state.bytes;$('undo').click();await until(()=>app.state.bytes!==beforeUndo&&!app.state.abort,'recovered undo');await pause();await app.local.flush();
 check(!text(app).includes('PERSISTED EDIT'),'recovered undo operates on recovered document');equal(app.state.redo.length,1,'redo history created and saved');
 // A quota error must leave the working edit usable and must never show Saved.
 const commit=app.local.store.commit.bind(app.local.store);app.local.store.commit=async()=>{throw new DOMException('Test quota','QuotaExceededError')};
 await app.editPDF('Unsaved local edit',doc=>doc.getPage(0).drawText('QUOTA EDIT',{x:40,y:680,size:13}));
 check(text(app).includes('QUOTA EDIT'),'failed autosave does not discard in-memory work');equal($('storageStatus').dataset.state,'error','failed save is visible');
 check(app.local.autosave.failed&&!app.local.autosave.isCurrent(),'failed save is never current');
 const warning=new window.Event('beforeunload',{cancelable:true});window.dispatchEvent(warning);check(warning.defaultPrevented,'unsaved edits warn before unload');
 app.local.store.commit=commit;check(await app.local.flush(),'local save can retry after quota failure');equal($('storageStatus').dataset.state,'saved','successful retry clears error');
 await app.closeTab(aid);equal(app.tabs.length,1,'saved tab closes without discarding its stored copy');
 await app.closeTab(bid);equal(app.tabs.length,0,'last saved tab closes');check(!$('modalform'),'locally saved dirty tabs do not need discard dialogue');
 equal((await app.local.store.listDocuments()).length,2,'closed working copies remain in library');equal((await app.local.store.readSession()).openIds,[],'closed tabs are not restored as open');
 // Library UI reopens the same stored ID and allows explicit deletion of closed copies.
 const library=app.local.library();await until(()=>$('libraryAction'),'library dialogue');check(window.document.querySelectorAll('.local-library-row').length===2,'library shows previous PDFs');
 window.document.querySelector(`[data-library-open="${bid}"]`).click();await library;
 equal(app.activeTabId,bid,'library reopens original stable tab ID');check(text(app).includes('QUOTA EDIT'),'library opens latest saved edits');equal(app.state.font,'Georgia','library preserves font choice');
 const deletion=app.local.library();await until(()=>$('libraryAction'),'library for deletion');window.document.querySelector(`[data-library-remove="${aid}"]`).click();
 await until(()=>$('modaltitle')?.textContent.startsWith('Remove Alpha'),'remove stored copy confirmation');$('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await deletion;
 equal(await app.local.store.getDocument(aid),null,'explicit removal deletes old closed PDF');equal((await app.local.store.listDocuments()).length,1,'library catalogue updated');
 await app.closeTab(bid);await context.close();context=await boot();({app,$,window}=context);
 equal(app.tabs.length,0,'reopening after all tabs closed starts welcome');equal((await app.local.store.listDocuments()).length,1,'closed PDF still retained across restart');
 await app.local.open(bid);check(text(app).includes('QUOTA EDIT'),'closed PDF reopens after fresh startup');
 // Competing windows cannot silently overwrite each other.
 const external=new LocalWorkspaceStore({indexedDB:globalThis.indexedDB});const externalSession=await external.readSession();await external.commit({session:externalSession});
 await app.editPDF('Conflicting edit',doc=>doc.getPage(0).drawText('CONFLICT MEMORY ONLY',{x:40,y:630,size:12}));
 check(app.local.autosave.conflict,'concurrent workspace conflict detected');equal($('storageStatus').dataset.state,'error','conflict has visible failure state');
 check(text(app).includes('CONFLICT MEMORY ONLY'),'conflicting edit remains available for export');
 check(!app.Engine.extractTextPDF((await external.getDocument(bid)).snapshot.bytes).some(page=>page.text.includes('CONFLICT MEMORY ONLY')),'conflict does not overwrite saved copy');external.close();
 // A damaged stored PDF is isolated rather than clearing the whole local library.
 await context.close();context=null;
 const repairStore=new LocalWorkspaceStore({indexedDB:globalThis.indexedDB});const repairSession=await repairStore.readSession(),valid=await repairStore.getDocument(bid);
 await repairStore.commit({documents:[{id:'broken',snapshot:{...valid.snapshot,name:'Broken.pdf',bytes:new Uint8Array([1,2,3])},pageCount:1,updatedAt:Date.now()}],session:{...repairSession,openIds:['broken',bid],activeId:'broken'}});repairStore.close();
 context=await boot();({app,$,window}=context);
 equal(app.tabs.length,1,'damaged stored document does not prevent good document recovery');equal(app.activeTabId,bid,'recovery selects a valid document');
 check((await app.local.store.listDocuments()).some(row=>row.id==='broken'),'damaged copy is retained for explicit removal');equal((await app.local.store.readSession()).openIds,[bid],'damaged entry is removed only from open tab list');
 await context.close();context=null;
 const available=globalThis.indexedDB;globalThis.indexedDB=null;context=await boot();({app,$,window}=context);
 check(!app.local.autosave.enabled,'storage-unavailable startup keeps application usable');equal($('storageStatus').dataset.state,'unavailable','unavailable storage is explicit');
 const unavailable=app.local.library();await until(()=>$('modaltitle'),'unavailable storage explanation');equal($('modaltitle').textContent,'Local library unavailable','library explains storage limitation');$('modalcancel').click();await unavailable;
 globalThis.indexedDB=available;
 console.log(`pdfpro persistence/navigation: ${assertions} assertions passed in test DOM with simulated IndexedDB and real PDFs.`);
}finally{if(context)await context.close()}
