/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 const source=await app.PDFLib.PDFDocument.create();
 for(let i=0;i<9;i++){const page=source.addPage(i%2?[360,500]:[300,420]);page.drawText('CONTINUOUS PAGE '+(i+1),{x:20,y:340,size:15});if(i===2)page.setRotation(app.PDFLib.degrees(90))}
 let bytes=new Uint8Array(await source.save({useObjectStreams:false}));const native=app.Engine.openPDF(bytes),reviewPage=native.loadPage(1),note=reviewPage.createAnnotation('Text');note.setRect([40,40,60,60]);note.setContents('Review on the neighbouring page');note.update();note.destroy();reviewPage.destroy();const savedNative=native.saveToBuffer('garbage=4,compress');bytes=savedNative.asUint8Array().slice();savedNative.destroy();native.destroy();await app.openFiles([file('Continuous.pdf',bytes)]);app.state.fit=false;app.state.zoom=1;await app.render();
 const main=$('main'),viewer=$('viewer'),overlay=$('overlay'),pages=app.continuousPages;Object.defineProperty(main,'clientHeight',{configurable:true,get:()=>600});viewer.style.paddingTop='52px';
 const origin={left:40,top:80};overlay.getBoundingClientRect=()=>{const current=pages.records[pages.current];return{left:origin.left,top:origin.top+pages.pageTop(pages.current)+22-main.scrollTop,width:current.width,height:current.height-22}};
 equal(viewer.querySelectorAll('.pdf-page-row').length,9,'every page has a continuous scroll slot');equal(pages.records.map(record=>record.height),[442,522,322,522,442,522,442,522,442],'mixed size/rotation layout');
 check(pages.records.every((record,i)=>!i||record.top===pages.records[i-1].top+pages.records[i-1].height+24),'page slots have contiguous offsets and a consistent gap');
 equal(document.querySelectorAll('#pagewrap').length,1,'one current-page wrapper ID');equal(document.querySelectorAll('#pagecanvas').length,1,'one active canvas ID');equal(document.querySelectorAll('#overlay').length,1,'one active overlay ID');
 equal(main.tabIndex,0,'PDF viewport supports keyboard focus');check(viewer.getAttribute('aria-label').includes('scroll'),'continuous viewport has accessible instruction');
 await pause(40);check(pages.cache.size<=6,'nearby render cache bounded');check(pages.records.filter(record=>record.painted).length<9,'distant pages do not rasterise eagerly');
 check(pages.records[0].canvas.width>1&&pages.records[1].canvas.width>1,'first and neighbouring page rasters coexist');check(pages.records[0].overlay.textContent.includes('CONTINUOUS PAGE 1')&&pages.records[1].overlay.textContent.includes('CONTINUOUS PAGE 2'),'multiple visible pages have selectable text layers');
 const badge=pages.records[1].overlay.querySelector('.annotation-badge');check(!!badge,'inactive visible page has its comment control');equal(window.getComputedStyle(badge).position,'absolute','neighbour comment control is positioned over its page');badge.click();await until(()=>$('modalform'),'neighbour comment dialogue');equal(app.state.page,1,'keyboard/click comment action activates its page');check($('modalform').textContent.includes('Review on the neighbouring page'),'neighbour comment contents open');$('modalcancel').click();await until(()=>!$('modalform'),'comment closes');await pause();await $('prev').onclick();
 const wheel=new window.WheelEvent('wheel',{bubbles:true,cancelable:true,deltaY:500});main.dispatchEvent(wheel);check(!wheel.defaultPrevented,'native wheel scrolling is unrestricted');
 const scroll=async index=>{main.scrollTop=pages.pageTop(index)-52;main.dispatchEvent(new window.Event('scroll'));await until(()=>app.state.page===index,'scroll to page '+(index+1));await pause(20)};
 await scroll(1);equal($('pageinput').value,'2','page field follows scrolling');equal($('toolbarCompactSummary').textContent.trim(),'Page 2 / 9','compact toolbar follows scrolling');check(main.scrollTop===pages.records[1].top,'scrolling does not snap or reset viewport');check($('thumbs').querySelector('[data-page="1"]').getAttribute('aria-current')==='page','bottom preview follows scrolling');equal($('overlay'),overlay,'interactive overlay identity survives page changes');
 await scroll(6);equal(pages.current,6,'long scroll chooses visible page');check(pages.records[6].painted,'visible page renders');check(pages.cache.size<=6&&[...pages.cache.values()].reduce((a,b)=>a+b,0)<=45000000,'far scroll retains bounded canvas storage');
 Object.defineProperty(main,'scrollHeight',{configurable:true,get:()=>pages.pageTop(pages.records.length-1)+pages.records.at(-1).height+36});main.scrollTop=main.scrollHeight-main.clientHeight;main.dispatchEvent(new window.Event('scroll'));await until(()=>app.state.page===8,'last page at bottom');equal($('pageinput').value,'9','bottom of document identifies last page');await scroll(6);
 equal(document.querySelectorAll('#overlay').length,1,'active overlay ID remains unique after scrolling');check(app.state.bytes===bytes||Buffer.from(app.state.bytes).equals(Buffer.from(bytes)),'scrolling leaves PDF bytes unchanged');
 await $('prev').onclick();equal(app.state.page,5,'previous button remains available');equal(main.scrollTop,pages.records[5].top,'previous jumps within continuous stack');
 $('pageinput').value='3';await $('pageinput').onchange({target:$('pageinput')});equal(app.state.page,2,'page number jump works');equal(main.scrollTop,pages.records[2].top,'page number jumps to matching slot');
 await $('thumbs').querySelector('[data-page="7"]').onclick();equal(app.state.page,7,'bottom thumbnail jumps to selected page');equal(main.scrollTop,pages.records[7].top,'thumbnail scroll target');
 main.scrollTop=pages.pageTop(7)+80;const oldZoom=app.state.zoom;await $('zoomIn').onclick();check(app.state.zoom>oldZoom,'zoom remains functional');check(Math.abs(main.scrollTop-(pages.pageTop(7)+80*app.state.zoom/oldZoom))<1,'zoom preserves relative reading position');
 // A pointer on another visible page activates it before the pen handlers run.
 await app.activate('ink');app.state.color='#800020';app.state.size=21;
 function pointer(target,type,index,point,id=2){const record=pages.records[index],event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:origin.left+point[0]*app.state.zoom,clientY:origin.top+pages.pageTop(index)+22-main.scrollTop+point[1]*app.state.zoom,button:0});Object.defineProperties(event,{pointerId:{value:id},isPrimary:{value:true}});target.dispatchEvent(event);return event}
 const previous=app.state.bytes,target=pages.records[4].overlay;pointer(target,'pointerdown',4,[40,80]);equal(app.state.page,4,'pointer activates clicked page before annotation');check(!!$('inkPreview'),'first pointer starts drawing immediately');pointer(overlay,'pointermove',4,[80,110]);pointer(overlay,'pointerup',4,[120,90]);await until(()=>app.state.bytes!==previous&&!app.state.abort,'stroke committed');
 let annotationPage=app.state.doc.loadPage(4),annotations=annotationPage.getAnnotations();equal(annotations.filter(a=>a.getType()==='Ink').length,1,'stroke saved to clicked page');const points=annotations.find(a=>a.getType()==='Ink').getInkList()[0];check(points.every((point,i)=>Math.abs(point[0]-[40,80,120][i])<.01&&Math.abs(point[1]-[80,110,90][i])<.01),'continuous placement retains PDF coordinates');annotations.forEach(a=>a.destroy());annotationPage.destroy();equal(app.state.tool,'ink','draw remains selected across page activation');
 annotationPage=app.state.doc.loadPage(7);annotations=annotationPage.getAnnotations();equal(annotations.length,0,'formerly active page was not edited');annotations.forEach(a=>a.destroy());annotationPage.destroy();
 pointer(overlay,'pointerdown',4,[40,120]);check(!!$('inkPreview'),'another stroke begins');main.dispatchEvent(new window.Event('scroll'));check(!$('inkPreview'),'scroll cancels unfinished drawing');pointer(overlay,'pointerup',4,[80,140]);await pause();
 // Scrolling while an edit dialogue/job is pending cannot redirect its target page.
 await app.activate('select');await scroll(3);let finish;const busy=app.job('Fixture job',async()=>new Promise(resolve=>finish=resolve));await until(()=>finish,'job active');main.scrollTop=pages.pageTop(5);main.dispatchEvent(new window.Event('scroll'));await pause(70);equal(app.state.page,3,'busy operation keeps its target page');finish();await busy;main.dispatchEvent(new window.Event('scroll'));await until(()=>app.state.page===5,'scroll resumes after job');check(true,'scroll updates after operation completes');
 const restoredTop=pages.pageTop(5)+37;main.scrollTop=restoredTop;main.scrollLeft=12;await app.local.flush();const firstId=app.activeTabId;
 await app.newDocument();check(pages.records.length===1,'switching documents replaces page slots');await app.switchTab(firstId);equal(main.scrollTop,restoredTop,'tab switch restores continuous vertical position');equal(main.scrollLeft,12,'tab switch restores horizontal position');equal(app.state.page,5,'tab switch restores reading page');
 await $('homeBtn').onclick();check(viewer.classList.contains('hidden'),'Home hides continuous pages');main.scrollTop=0;main.dispatchEvent(new window.Event('scroll'));await pause(60);equal(app.state.page,5,'Home scrolling does not change document page');await app.switchTab(firstId);equal(main.scrollTop,restoredTop,'Resume restores scroll position');
 await app.activate('split');check(!msVisible(viewer),'split workspace hides continuous PDF stack');main.scrollTop=100;main.dispatchEvent(new window.Event('scroll'));await pause(60);equal(app.state.page,5,'split workspace scrolling cannot navigate owner PDF');await $('msBack').onclick();equal(main.scrollTop,restoredTop,'Back from split restores continuous scroll');
 function msVisible(node){return !node.classList.contains('hidden')}
 await app.local.flush();const savedZoom=app.state.zoom;await context.close();context=await boot();({app,$,window}=context);equal(app.activeTabId,firstId,'fresh instance restores active tab');equal(app.state.page,5,'fresh instance restores page');equal($('main').scrollTop,restoredTop,'fresh instance restores continuous scroll');equal(app.state.zoom,savedZoom,'fresh instance restores zoom');check(app.state.continuousView,'continuous view marker persisted');
 const saved=await app.local.store.getDocument(firstId);saved.snapshot.continuousView=false;saved.snapshot.page=2;saved.snapshot.scrollTop=31;await app.local.store.commit({documents:[saved],views:[{id:firstId,view:{...saved.snapshot}}]});await context.close();context=await boot();({app,$,window}=context);equal(app.state.page,2,'legacy single-page view keeps selected page');equal($('main').scrollTop,app.continuousPages.pageTop(2)+31,'legacy offset migrates onto selected page');check(app.state.continuousView,'legacy view marked as converted');
 const large=await app.PDFLib.PDFDocument.create();for(let i=0;i<75;i++)large.addPage([100,140]);await app.openFiles([file('Large.pdf',await large.save())]);equal(app.continuousPages.records.length,75,'all large-document slots exist');await pause(80);check(app.continuousPages.cache.size<=6,'large document does not eagerly rasterise all pages');
 await context.close();context=null;console.log('pdfpro continuous pages: '+assertions+' assertions passed using real PDFs and controlled viewport geometry/IndexedDB.');
}finally{if(context)await context.close()}
