/* Paragraph detection, style inheritance and bounded text reflow. No font downloads. */
const dot=(p,v)=>p[0]*v[0]+p[1]*v[1];
const corners=r=>[[r[0],r[1]],[r[2],r[1]],[r[0],r[3]],[r[2],r[3]]];
export const union=rects=>[Math.min(...rects.map(r=>r[0])),Math.min(...rects.map(r=>r[1])),Math.max(...rects.map(r=>r[2])),Math.max(...rects.map(r=>r[3]))];
const median=values=>{const sorted=values.slice().sort((a,b)=>a-b);return sorted.length?sorted[Math.floor(sorted.length/2)]:0};
const spread=values=>Math.max(...values)-Math.min(...values);
const inferAlignment=lines=>{if(lines.length<2)return 'left';const tol=Math.max(1,lines[0].size*.22),lefts=lines.map(l=>l.left),rights=lines.map(l=>l.right);if(spread(lefts)<=tol)return 'left';if(spread(rights)<=tol)return 'right';return spread(lines.map(l=>(l.left+l.right)/2))<=tol?'center':'left'};
const canonical=s=>s.replace(/\s+/gu,' ').trim();
function axes(part){const [a,b,c,d]=part.matrix,n=Math.hypot(a,b)||1,sign=a*d-b*c<0?1:-1;return{u:[a/n,b/n],v:[-b/n*sign,a/n*sign]}}
function localRect(rect,u,v){const points=corners(rect);return[Math.min(...points.map(p=>dot(p,u))),Math.min(...points.map(p=>dot(p,v))),Math.max(...points.map(p=>dot(p,u))),Math.max(...points.map(p=>dot(p,v)))]}
function sameDirection(a,b){const x=axes(a),y=axes(b);return dot(x.u,y.u)>.995&&dot(x.v,y.v)>.995}
function linesFor(parts,blocks){
  const lines=[],assigned=new Set();
  blocks.forEach((block,bi)=>{if(block.type!=='text')return;(block.lines||[]).forEach((line,li)=>{if(line.wmode||!line.bbox)return;lines.push({block:bi,order:li,source:line,parts:[]})})});
  for(const part of parts){const mid=[(part.rect[0]+part.rect[2])/2,(part.rect[1]+part.rect[3])/2],{v}=axes(part);let best=null,score=Infinity;
    for(const line of lines){const b=line.source.bbox;if(mid[0]<b.x-2||mid[0]>b.x+b.w+2||mid[1]<b.y-2||mid[1]>b.y+b.h+2)continue;const distance=Math.abs(dot(part.matrix.slice(4),v)-dot([line.source.x,line.source.y],v));if(distance<score){best=line;score=distance}}
    if(best){best.parts.push(part);assigned.add(part.index)}
  }
  for(const part of parts)if(!assigned.has(part.index))lines.push({block:blocks.length+part.index,order:0,parts:[part]});
  const populated=lines.filter(line=>line.parts.length).map(line=>{
    const {u,v}=axes(line.parts[0]);line.parts.sort((a,b)=>dot(a.matrix.slice(4),u)-dot(b.matrix.slice(4),u));
    return{...line,u,v,left:Math.min(...line.parts.map(p=>dot(p.matrix.slice(4),u))),right:Math.max(...line.parts.map(p=>Math.max(dot(p.end,u),localRect(p.rect,u,v)[2]))),baseline:median(line.parts.map(p=>dot(p.matrix.slice(4),v))),size:Math.max(...line.parts.map(p=>p.size)),rect:union(line.parts.map(p=>p.rect))};
  });
  if(!parts.length)return populated;
  const {u,v}=axes(parts[0]),groups=new Map();for(const line of populated){let group=groups.get(line.block);if(!group){group=[];groups.set(line.block,group)}group.push(line)}
  const ordered=[...groups.values()].map(group=>({group,box:localRect(union(group.map(l=>l.rect)),u,v)}));
  ordered.sort((a,b)=>{const x=a.box,y=b.box;if(Math.min(x[3],y[3])-Math.max(x[1],y[1])>2&&(x[2]<y[0]-5||y[2]<x[0]-5))return x[0]-y[0];return x[1]-y[1]||x[0]-y[0]});
  return ordered.flatMap(({group})=>group.sort((a,b)=>a.baseline-b.baseline||a.left-b.left));
}
function lineUnits(line){const units=[];let previous=null;
  for(const part of line.parts){
    if(previous&&units.length&&!/\s$/u.test(units.at(-1).ch)&&!/^\s/u.test(part.text)&&dot(part.matrix.slice(4),line.u)-dot(previous.end,line.u)>Math.max(1,part.size*.16))units.push({ch:' ',style:previous.index});
    for(const ch of part.text)units.push({ch:ch==='\u00a0'?' ':ch,style:part.index});previous=part;
  }
  return units;
}
function paragraphsFor(lines){const paragraphs=[];let current=null,previous=null;
  for(const line of lines){
    const text=line.parts.map(p=>p.text).join(''),gap=previous?line.baseline-previous.baseline:0;
    const sharedEdge=previous&&(Math.abs(line.left-previous.left)<=line.size*.6||Math.abs(line.right-previous.right)<=line.size*.25||Math.abs((line.left+line.right)-(previous.left+previous.right))<=line.size*.5);
    const compatible=previous&&gap>=line.size*.8&&gap<=line.size*1.6&&sharedEdge&&Math.abs(line.size-previous.size)<line.size*.08&&previous.parts[0].bold===line.parts[0].bold&&previous.parts[0].italic===line.parts[0].italic;
    const split=!current||(previous.block!==line.block&&!compatible)||!sameDirection(previous.parts[0],line.parts[0])||gap<line.size*.35||gap>Math.max(line.size,previous.size)*1.9||!sharedEdge&&Math.abs(line.left-previous.left)>Math.max(line.size,previous.size)*3||Math.max(line.size,previous.size)/Math.min(line.size,previous.size)>1.4||/^(?:[•●▪]|\d+[.)])\s/u.test(text);
    if(split){current=[];paragraphs.push(current)}current.push(line);previous=line;
  }
  return paragraphs;
}
function selection(lines,scope,breaks=new Set(),saved=[]){
  const first=lines[0].parts[0],{u,v}=axes(first),parts=lines.flatMap(l=>l.parts),left=Math.min(...lines.map(l=>l.left));let units=[];
  for(const [i,line]of lines.entries()){
    let next=lineUnits(line);
    if(scope!=='line'){
      next=next.filter((unit,index)=>unit.ch!==' '||index>0&&next[index-1].ch!==' ');while(next[0]?.ch===' ')next.shift();while(next.at(-1)?.ch===' ')next.pop();
    }
    if(i&&next.length){const separator=breaks.has(i)?'\n\n':units.at(-1)?.ch==='-'?'':' ';for(const ch of separator)units.push({ch,style:next[0].style})}
    units.push(...next);
  }
  const gaps=lines.slice(1).map((l,i)=>l.baseline-lines[i].baseline).filter(g=>g>first.size*.5&&g<first.size*1.9),rect=union(parts.map(p=>p.rect));
  const layout={u,v,left,align:inferAlignment(lines),top:lines[0].baseline,width:Math.max(20,...lines.map(l=>l.right-left)),leading:median(gaps)||first.size*1.3,firstIndent:lines[0].left-left,restIndent:lines[1]?median(lines.slice(1).map(l=>l.left-left)):0,offsets:Object.fromEntries(lines.flatMap(l=>l.parts.map(p=>[p.index,dot(p.matrix.slice(4),v)-l.baseline])))};
  const text=units.map(p=>p.ch).join('');let frame=null;
  for(const record of saved){
    const l=record?.layout,r=record?.rect;if(!l||!Array.isArray(r)||r.length!==4||![l.width,l.leading,l.left].every(Number.isFinite)||l.width<20||l.width>20000||l.leading<1||l.leading>1000||!Array.isArray(l.u)||dot(l.u,u)<.995||!canonical(record.text||'').includes(canonical(text)))continue;
    const centre=[(rect[0]+rect[2])/2,(rect[1]+rect[3])/2];if(centre[0]<r[0]-3||centre[0]>r[2]+3||centre[1]<r[1]-3||centre[1]>r[3]+3)continue;
    if(scope!=='line'){layout.width=l.width;layout.leading=l.leading;if(['left','center','right'].includes(l.align))layout.align=l.align;layout.left=l.left;layout.firstIndent=lines[0].left-l.left;layout.restIndent=lines[1]?median(lines.slice(1).map(line=>line.left-l.left)):0}if(scope!=='line'&&Array.isArray(record.frame)&&record.frame.length===4&&record.frame.every(Number.isFinite)&&canonical(record.text||'')===canonical(text))frame=[...record.frame];break;
  }
  return{...first,kind:'flow',scope,parts,units,layout,rect:frame||rect,inkRect:rect,frame,text,editable:parts.every(p=>p.editable)&&parts.every(p=>sameDirection(first,p)),mixed:parts.some(p=>p.fontName!==first.fontName||p.color!==first.color||Math.abs(p.size-first.size)>.1),seed:first.index};
}
export function makeDirectSelections(parts,blocks,mode='paragraph',saved=[]){
  const lines=linesFor(parts,blocks);if(mode==='line'||mode==='chunk')return lines.map(line=>selection([line],'line',new Set(),saved));
  const boxed=[],used=new Set();for(const record of [...saved].reverse()){if(!Array.isArray(record.frame)||!Array.isArray(record.rect)||/\n\s*\n/u.test(record.text))continue;const candidates=parts.filter(p=>!used.has(p.index)&&(p.rect[0]+p.rect[2])/2>=record.rect[0]-2&&(p.rect[0]+p.rect[2])/2<=record.rect[2]+2&&(p.rect[1]+p.rect[3])/2>=record.rect[1]-2&&(p.rect[1]+p.rect[3])/2<=record.rect[3]+2);if(!candidates.length)continue;const box=selection(linesFor(candidates,blocks),'paragraph',new Set(),saved);if(box.text.replace(/\s/g,'')!==record.text.replace(/\s/g,''))continue;const source=box.units.filter(u=>!/\s/u.test(u.ch));let cursor=0;box.units=Array.from(record.text,ch=>({ch,style:/\s/u.test(ch)?source[Math.max(0,cursor-1)]?.style:source[cursor++]?.style??box.parts[0].index}));box.text=record.text;box.frame=[...record.frame];box.rect=[...record.frame];boxed.push(box);for(const p of candidates)used.add(p.index)}
  return [...boxed,...paragraphsFor(linesFor(parts.filter(p=>!used.has(p.index)),blocks)).map(lines=>selection(lines,'paragraph',new Set(),saved))].sort((a,b)=>Math.min(...a.parts.map(p=>p.index))-Math.min(...b.parts.map(p=>p.index)));
}
export function selectDirectChunk(parts,blocks,region,saved=[]){
  const selected=parts.filter(p=>p.rect[0]<region[2]&&p.rect[2]>region[0]&&p.rect[1]<region[3]&&p.rect[3]>region[1]);if(!selected.length)return null;
  const lines=linesFor(selected,blocks),paragraphs=paragraphsFor(lines),breaks=new Set();let n=0;for(const p of paragraphs){if(n)breaks.add(n);n+=p.length}
  for(let i=0;i<lines.length;i++)for(let j=i+1;j<lines.length;j++)if(Math.abs(lines[i].baseline-lines[j].baseline)<Math.min(lines[i].size,lines[j].size)*.5&&(lines[i].right<lines[j].left-20||lines[j].right<lines[i].left-20))throw Error('Select a single text column for reflow.');
  return selection(paragraphs.flat(),'chunk',breaks,saved);
}
function tokens(units){const result=[];let cursor=0;for(const value of units.map(u=>u.ch).join('').match(/\s+|\S+/gu)||[]){const size=Array.from(value).length;result.push({value,units:units.slice(cursor,cursor+size)});cursor+=size}return result}
function styledReplacement(source,text){
  const original=tokens(source),next=tokens(Array.from(text,ch=>({ch}))),matches=[];let a=0,b=0,endA=original.length,endB=next.length;
  while(a<endA&&b<endB&&original[a].value===next[b].value){matches.push([a++,b++])}
  const tail=[];while(endA>a&&endB>b&&original[endA-1].value===next[endB-1].value)tail.unshift([--endA,--endB]);
  const m=endA-a,n=endB-b;
  if(m*n<=2000000){const stride=n+1,table=new Uint16Array((m+1)*stride);for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--)table[i*stride+j]=original[a+i].value===next[b+j].value?table[(i+1)*stride+j+1]+1:Math.max(table[(i+1)*stride+j],table[i*stride+j+1]);let i=0,j=0;while(i<m&&j<n){if(original[a+i].value===next[b+j].value){matches.push([a+i++,b+j++])}else if(table[(i+1)*stride+j]>=table[i*stride+j+1])i++;else j++}}
  else{let i=a;for(let j=b;j<endB;j++){const found=original.findIndex((t,k)=>k>=i&&k<endA&&t.value===next[j].value);if(found>=0){matches.push([found,j]);i=found+1}}}
  matches.push(...tail,[original.length,next.length]);let previousA=-1,previousB=-1;
  for(const [ai,bi]of matches){const removed=original.slice(previousA+1,ai).flatMap(t=>t.units),style=removed.find(u=>!/\s/u.test(u.ch))?.style??removed[0]?.style??original[previousA]?.units.at(-1)?.style??source[0]?.style;
    for(let j=previousB+1;j<bi;j++)next[j].units=next[j].units.map(u=>({...u,style}));if(bi<next.length)next[bi].units=original[ai].units.map(u=>({...u}));previousA=ai;previousB=bi;
  }
  return next.flatMap(t=>t.units);
}
export function flowGlyphs(target,replacement,styles,{width=target.layout.width,formatting=[],resolveStyle,align=target.layout.align||'left'}={}){
  const raw=String(replacement).replace(/\r\n?/g,'\n').replace(/\u00a0/g,' '),text=raw.trim(),offset=Array.from(raw).length-Array.from(raw.trimStart()).length;if(text.length>10000||/[\x00-\x08\x0b-\x1f\x7f]/u.test(text))throw Error('Use up to 10,000 characters of text.');
  if(!Number.isFinite(width)||width<20||width>20000)throw Error('Choose a text width from 20 to 20,000 pt.');
  if(target.scope==='line'&&text.includes('\n'))throw Error('Choose Paragraph or Text chunk to edit several lines.');
  if(!['left','center','right'].includes(align))throw Error('Choose Left, Centre or Right text alignment.');
  const units=styledReplacement(target.units,text),l={...target.layout,...align!=='left'||target.layout.align&&target.layout.align!=='left'?{firstIndent:0,restIndent:0}:{}},glyphs=[],lines=[];
  if(!Array.isArray(formatting)||formatting.length>20000)throw Error('Too many formatting ranges.');
  let previousEnd=0;for(const range of formatting){if(!Number.isInteger(range.start)||!Number.isInteger(range.end)||range.start<previousEnd||range.end<=range.start||range.end>Array.from(raw).length||!resolveStyle)throw Error('Invalid text formatting range.');previousEnd=range.end;for(let i=Math.max(0,range.start-offset);i<Math.min(units.length,range.end-offset);i++)units[i].style=resolveStyle(units[i].style,range.style)}
  let baseline=l.top,x=l.left+l.firstIndent,indent=l.firstIndent,line=0,largeSize=0;
  const newLine=explicit=>{line++;baseline+=Math.max(l.leading,largeSize*1.15);largeSize=0;indent=explicit?l.firstIndent:l.restIndent;x=l.left+indent};
  function measured(unit){const s=styles.get(unit.style);if(!s)throw Error('This text style changed. Select the text again.');const unicode=unit.ch.codePointAt(0),gid=s.glyphMap.get(unicode)||s.font.encodeCharacter(unicode);if(!gid)throw Error('The original PDF font does not contain “'+unit.ch+'”. Your text has not been changed.');return{...unit,s,gid,unicode,advance:s.font.advanceGlyph(gid)*Math.hypot(s.matrix[0],s.matrix[1])}}
  const tokens=units.map(u=>u.ch).join('').match(/\n|[^\S\n]+|[^\s]+/gu)||[];let cursor=0,pending=[];
  function place(g){const y=baseline+(g.s.baselineOffset??l.offsets[g.style]??0),matrix=[...g.s.matrix.slice(0,4),l.u[0]*x+l.v[0]*y,l.u[1]*x+l.v[1]*y];glyphs.push({...g,matrix,line});x+=g.advance;lines[line]=true;if(g.s.size>target.size*1.15)largeSize=Math.max(largeSize,g.s.size)}
  for(const token of tokens){const length=Array.from(token).length,group=units.slice(cursor,cursor+length);cursor+=length;
    if(token==='\n'){pending=[];newLine(true);continue}if(/^\s+$/u.test(token)){pending=group.map(measured);continue}
    const word=group.map(measured),space=pending.reduce((n,g)=>n+g.advance,0),measure=word.reduce((n,g)=>n+g.advance,0),hasText=x>l.left+indent+.01;
    if(target.scope!=='line'&&hasText&&x+space+measure>l.left+width+.05){newLine(false);pending=[]}
    if(x>l.left+indent+.01)for(const g of pending)place(g);pending=[];
    for(const g of word){if(target.scope!=='line'&&x>l.left+indent+.01&&x+g.advance>l.left+width+.05)newLine(false);if(g.advance>width-indent+.05)throw Error('The text width is too narrow for the original font size.');place(g)}
  }
  if(align!=='left'){const groups=new Map();for(const g of glyphs){if(!groups.has(g.line))groups.set(g.line,[]);groups.get(g.line).push(g)}for(const row of groups.values()){const start=dot(row[0].matrix.slice(4),l.u),last=row.at(-1),end=dot(last.matrix.slice(4),l.u)+last.advance,offset=align==='right'?l.left+width-end:l.left+(width-(end-start))/2-start;for(const g of row){g.matrix[4]+=l.u[0]*offset;g.matrix[5]+=l.u[1]*offset}}}
  return{text,glyphs,width,lineCount:lines.length,layout:{...l,width,align}};
}
