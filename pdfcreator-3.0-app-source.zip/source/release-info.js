/* package.json is the one version source for About, the runtime and the manifest. */
import metadata from './package.json' with {type:'json'};
export const RELEASE=Object.freeze({app:'PDFCreator',version:metadata.version,build:typeof __PDFCREATOR_BUILD_ID__==='string'?__PDFCREATOR_BUILD_ID__:'development'});
