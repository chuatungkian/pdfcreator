/* The portable builder embeds a fresh release ID without modifying source files. */
export const RELEASE=Object.freeze({app:'PDFCreator',version:'3.0.1',build:typeof __PDFCREATOR_BUILD_ID__==='string'?__PDFCREATOR_BUILD_ID__:'development'});
