/* Remove certificate signatures in a rewritten, unsigned working copy. */
const read=(obj,key,fn)=>{const v=obj.get(key);try{return fn(v)}finally{v.destroy()}};
const name=(obj,key)=>read(obj,key,v=>v.isName()?v.asName():'');
const isSignature=obj=>obj.isDictionary()&&(name(obj,'Type')==='Sig'||read(obj,'ByteRange',v=>v.isArray())&&read(obj,'Contents',v=>v.isString()));
const key=obj=>obj.isIndirect()?'ref:'+obj.asIndirect():'direct:'+obj.toString();
function scan(doc,mutate){
 const trailer=doc.getTrailer(),root=trailer.get('Root'),form=root.get('AcroForm'),policies=root.get('Perms'),signatures=new Set(),removed=new Set();let fields=0,widgets=0;
 function scrub(sig){const id=key(sig);signatures.add(id);if(mutate){const keys=[];sig.forEach((value,k)=>{keys.push(k);value.destroy()});for(const k of keys)sig.delete(k)}}
 function subtree(object,seen=new Set(),depth=0){if(depth>40)throw Error('The signature field hierarchy is too deep.');const id=key(object);if(seen.has(id))return;seen.add(id);removed.add(id);if(mutate){object.delete('V');object.delete('DV');object.delete('AP');object.delete('AS')}
  const kids=object.get('Kids');try{if(kids.isArray())kids.forEach(child=>{try{subtree(child,seen,depth+1)}finally{child.destroy()}})}finally{kids.destroy()}
 }
 function prune(array,inherited='',seen=new Set(),depth=0){if(depth>40)throw Error('The form field hierarchy is too deep.');const keep=[];array.forEach(field=>{try{if(!field.isDictionary()){keep.push(field);return}const id=key(field);if(seen.has(id))throw Error('The form field hierarchy contains a cycle.');const type=name(field,'FT')||inherited,value=field.get('V');let signed;try{signed=type==='Sig'&&value.isDictionary();if(signed)scrub(value)}finally{value.destroy()}
   if(signed){fields++;subtree(field);return}const kids=field.get('Kids');try{if(kids.isArray()){const before=kids.length,remaining=prune(kids,type,new Set([...seen,id]),depth+1);try{if(mutate)field.put('Kids',remaining)}finally{remaining.forEach(v=>v.destroy())}if(before&&remaining.length===0&&!type){removed.add(id);return}}}finally{kids.destroy()}keep.push(field);
  }finally{if(!keep.includes(field))field.destroy()}});return keep}
 try{
  // Remove policy signatures before clearing their referenced dictionaries.
  if(policies.isDictionary()){const keys=[];policies.forEach((value,k)=>{try{if(isSignature(value)){keys.push(k);scrub(value)}}finally{value.destroy()}});if(mutate){for(const k of keys)policies.delete(k);let remaining=0;policies.forEach(v=>{remaining++;v.destroy()});if(!remaining)root.delete('Perms')}}
  if(form.isDictionary()){const all=form.get('Fields');try{if(all.isArray()){const kept=prune(all);try{if(mutate)form.put('Fields',kept)}finally{kept.forEach(v=>v.destroy())}}}finally{all.destroy()}}
  for(let i=0;i<doc.countPages();i++){const page=doc.loadPage(i),object=page.getObject(),annotations=object.get('Annots'),keep=[];try{if(!annotations.isArray())continue;annotations.forEach(annotation=>{try{let remove=removed.has(key(annotation));if(!remove&&name(annotation,'Subtype')==='Widget'){const ft=annotation.getInheritable('FT'),v=annotation.getInheritable('V');try{if(ft.isName()&&ft.asName()==='Sig'&&v.isDictionary()){scrub(v);subtree(annotation);remove=true}}finally{v.destroy();ft.destroy()}}if(remove){widgets++;if(mutate){annotation.delete('V');annotation.delete('AP');annotation.delete('AS')}}else keep.push(annotation)}finally{if(!keep.includes(annotation))annotation.destroy()}});if(mutate)object.put('Annots',keep)}finally{keep.forEach(v=>v.destroy());annotations.destroy();object.destroy();page.destroy()}}
  if(signatures.size&&mutate){root.delete('DSS');if(form.isDictionary()){form.delete('SigFlags');const calculations=form.get('CO');try{if(calculations.isArray()){const kept=[];calculations.forEach(v=>{if(removed.has(key(v)))v.destroy();else kept.push(v)});try{form.put('CO',kept)}finally{kept.forEach(v=>v.destroy())}}}finally{calculations.destroy()}}}
  return{signatures:signatures.size,fields,widgets};
 }finally{policies.destroy();form.destroy();root.destroy();trailer.destroy()}
}
export const inspectRemovableSignatures=doc=>scan(doc,false);
export const removeDigitalSignatures=doc=>scan(doc,true);
