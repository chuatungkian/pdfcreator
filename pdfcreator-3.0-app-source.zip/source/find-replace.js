/* Literal, document-wide replacement planning with per-paragraph previews. */
import {directEditTargets,addedTextTargets,replaceDirectTextGroup} from './direct-text.js';
export function literalMatches(text,query,{caseSensitive=false,wholeWord=false}={}){
  if(!query)return[];const pattern=query.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),re=new RegExp(pattern,caseSensitive?'gu':'giu'),matches=[];
  for(const m of text.matchAll(re)){const start=m.index,end=start+m[0].length,before=Array.from(text.slice(0,start)).at(-1)||'',after=Array.from(text.slice(end))[0]||'';if(wholeWord&&(/[\p{L}\p{N}_]/u.test(before)||/[\p{L}\p{N}_]/u.test(after)))continue;matches.push({start,end,text:m[0]})}return matches;
}
export function replaceLiteral(text,query,replacement,options){const matches=literalMatches(text,query,options);let result=text;for(const m of [...matches].reverse())result=result.slice(0,m.start)+replacement+result.slice(m.end);return{text:result,count:matches.length}}
export function planReplacements(doc,{query,replacement,caseSensitive=false,wholeWord=false,pages}={}){
  if(!query||query.length>1000)throw Error('Enter a search phrase of up to 1,000 characters.');if(String(replacement).length>10000)throw Error('Use up to 10,000 replacement characters.');
  const rows=[];
  for(const page of pages||Array.from({length:doc.countPages()},(_,i)=>i))for(const target of [...directEditTargets(doc,page,'paragraph'),...addedTextTargets(doc,page)]){
    const next=replaceLiteral(target.text,query,String(replacement),{caseSensitive,wholeWord});if(next.count)rows.push({page,rect:target.rect,before:target.text,after:next.text,count:next.count,editable:target.editable,kind:target.kind==='added'?'added':'native',...(target.kind==='added'?{target,query,replacement:String(replacement),options:{caseSensitive,wholeWord}}:{})});
  }return rows;
}
export function replaceRichLiteral(rich,query,replacement,options){
  const paragraphs=rich.paragraphs.map(p=>{const units=p.runs.flatMap(r=>Array.from(r.text,ch=>({ch,style:r}))),plain=units.map(u=>u.ch).join('');for(const m of literalMatches(plain,query,options).reverse()){
    // match offsets are UTF-16 offsets; convert before slicing Unicode character units.
    const start=Array.from(plain.slice(0,m.start)).length,end=Array.from(plain.slice(0,m.end)).length,style=units[start]?.style||p.runs[0]||{};units.splice(start,end-start,...Array.from(replacement,ch=>({ch,style})));}
    const runs=[];for(const unit of units){const last=runs.at(-1);if(last&&last.source===unit.style)last.text+=unit.ch;else runs.push({...unit.style,text:unit.ch,source:unit.style})}return{...p,runs:runs.map(({source,...r})=>r)};
  });return{...rich,paragraphs};
}
export function applyReplacements(doc,rows){
  const ordered=[...rows].sort((a,b)=>b.page-a.page||b.rect[1]-a.rect[1]||b.rect[0]-a.rect[0]);let count=0;
  for(const row of ordered){const target=directEditTargets(doc,row.page,'paragraph').find(t=>t.text===row.before&&t.rect.every((v,i)=>Math.abs(v-row.rect[i])<.1));if(!target)throw Error('A selected paragraph changed. Preview replacements again.');if(!target.editable)throw Error('A selected paragraph uses an unsupported font encoding.');replaceDirectTextGroup(doc,row.page,target,row.after);count+=row.count}
  return count;
}
