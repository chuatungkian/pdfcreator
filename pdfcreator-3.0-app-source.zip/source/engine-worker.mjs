import * as Engine from './engine.js';
self.postMessage({ready:true});
self.onmessage = async event => {
  const {id,method,args}=event.data;
  try {
    if (!['redactPDF','sanitizePDF','protectPDF','optimizePDF','replaceTextPDF','extractTextPDF','renderPagePNG'].includes(method)) throw Error('Unsupported background task');
    const result=await Engine[method](...args);
    self.postMessage({id,result});
  } catch(error) { self.postMessage({id,error:{message:error.message,name:error.name}}); }
};
