import * as Engine from './engine.js';
import {removeSecurityPDF} from './remove-security.js';
import {compressPDF} from './pdf-compression.js';
self.postMessage({ready:true});
self.onmessage = async event => {
  const {id,method,args}=event.data;
  try {
    if (!['removeSecurityPDF','compressPDF','redactPDF','sanitizePDF','protectPDF','optimizePDF','replaceTextPDF','extractTextPDF','renderPagePNG'].includes(method)) throw Error('Unsupported background task');
    const result=method==='removeSecurityPDF'?removeSecurityPDF(...args,(progress,message)=>self.postMessage({id,progress,message})):method==='compressPDF'?await compressPDF(...args,(progress,message)=>self.postMessage({id,progress,message})):await Engine[method](...args);
    self.postMessage({id,result});
  } catch(error) { self.postMessage({id,error:{message:error.message,name:error.name}}); }
};
