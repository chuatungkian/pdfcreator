/* Clickable link targets for existing PDF text, images and painted shapes. */
import {mupdf} from './engine.js';
import {pageObjects} from './object-tools.js';
export function linkContentTargets(doc,index){
  const page=doc.loadPage(index),targets=[],keys=new Set();let st,device;
  function add(rect,label){if(!rect?.every(Number.isFinite)||rect[2]<=rect[0]||rect[3]<=rect[1]||rect[2]-rect[0]<3&&rect[3]-rect[1]<3)return;const key=rect.map(n=>Math.round(n)).join(':');if(keys.has(key))return;keys.add(key);targets.push({rect,label})}
  try{
    st=page.toStructuredText('');const data=JSON.parse(st.asJSON());for(const block of data.blocks||[])if(block.type==='text')for(const line of block.lines||[]){const b=line.bbox;if(line.text?.trim()&&b)add([b.x,b.y,b.x+b.w,b.y+b.h],'Text: '+line.text.slice(0,90))}
    try{for(const item of pageObjects(doc,index))add(item.rect,item.type==='Shape'?'Shape':item.type==='Image'?'Image':item.type==='Text box'?'Text box':item.kind==='annotation'?'Shape / annotation: '+item.type:'Content group')}catch{/* Native text and paths can still be linked when XObject parsing is unavailable. */}
    device=new mupdf.Device({fillPath(path,evenOdd,matrix,space){try{if(targets.length<1200)add(path.getBounds(null,matrix),'Shape')}finally{path.destroy();space?.destroy()}},strokePath(path,stroke,matrix,space){try{if(targets.length<1200)add(path.getBounds(stroke,matrix),'Shape')}finally{path.destroy();stroke.destroy();space?.destroy()}}});page.runPageContents(device,mupdf.Matrix.identity);device.close();
    return targets.sort((a,b)=>(b.rect[2]-b.rect[0])*(b.rect[3]-b.rect[1])-(a.rect[2]-a.rect[0])*(a.rect[3]-a.rect[1]));
  }finally{device?.destroy();st?.destroy();page.destroy()}
}
