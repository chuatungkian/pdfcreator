/* Edit visible PDF text with its original native font and graphics style. AGPL-3.0-or-later. */
import {mupdf} from './engine.js';
import {makeDirectSelections,selectDirectChunk,flowGlyphs,union} from './direct-layout.js';
import {preserveNativeTextUnicode} from './native-text-unicode.js';
const I=mupdf.Matrix.identity;
const near=(a,b,t=.03)=>a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<t);
export function saveDirectEdit(doc){
  // Compact and remove unreachable objects. Immediate dictionary/stream deduplication
  // (garbage=3/4) can lose a newly grafted Form in this MuPDF build; use level 2.
  const buffer=doc.saveToBuffer('garbage=2,compress');try{return buffer.asUint8Array().slice()}finally{buffer.destroy()}
}
function rgb(space,c){
  if(space.isRGB())return c.slice(0,3);if(space.isGray())return[c[0],c[0],c[0]];
  const pix=new mupdf.Pixmap(mupdf.ColorSpace.DeviceRGB,[0,0,1,1],false),path=new mupdf.Path();let device;
  try{path.rect(0,0,1,1);device=new mupdf.DrawDevice(I,pix);device.fillPath(path,false,I,space,c,1);device.close();return[...pix.getPixels()].slice(0,3).map(n=>n/255)}finally{device?.destroy();path.destroy();pix.destroy()}
}
const hexColor=(space,c)=>'#'+rgb(space,c).map(v=>Math.round(Math.max(0,Math.min(1,v))*255).toString(16).padStart(2,'0')).join('');
function dispose(runs){for(const r of runs)r.font.destroy();for(const space of new Set(runs.map(r=>r.space)))space.destroy()}
function directDecorations(page){const all=[...page.getAnnotations()],rows=[];try{for(const annotation of all){const object=annotation.getObject();try{const kind=object.get('PDFCreatorDirectDecoration').asName(),rect=object.get('PDFCreatorDirectRect').asJS();if(['underline','strikethrough'].includes(kind)&&Array.isArray(rect)&&rect.length===4)rows.push({annotation,kind,rect})}catch{}finally{object.destroy()}}return{rows,all,close:()=>all.forEach(a=>a.destroy())}}catch(e){all.forEach(a=>a.destroy());throw e}}
function clearDirectDecorations(page,parts){const decorations=directDecorations(page);try{if(decorations.all.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing PDF redaction annotations before editing text.');for(const row of decorations.rows){const cx=(row.rect[0]+row.rect[2])/2,cy=(row.rect[1]+row.rect[3])/2;if(parts.some(p=>cx>=p.rect[0]-.5&&cx<=p.rect[2]+.5&&cy>=p.rect[1]-.5&&cy<=p.rect[3]+.5))page.deleteAnnotation(row.annotation)}}finally{decorations.close()}}
function capture(doc,index){
  const page=doc.loadPage(index),runs=[];let current=null,device;
  try{
    device=new mupdf.Device({fillText(text,ctm,space,color,alpha){const before=runs.length;
      try{text.walk({beginSpan(){current=null},showGlyph(font,trm,glyph,unicode,wmode,bidi){
        const matrix=mupdf.Matrix.concat(trm,ctm),size=Math.sqrt(Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2]));
        const direction=[matrix[0],matrix[1]],norm=Math.hypot(...direction)||1;
        const off=current?Math.abs((matrix[4]-current.matrix[4])*(-direction[1]/norm)+(matrix[5]-current.matrix[5])*(direction[0]/norm)):0;
        const previous=current?.glyphs.at(-1),gap=previous?Math.hypot(matrix[4]-previous.matrix[4]-previous.matrix[0]*(previous.glyph>=0?current.font.advanceGlyph(previous.glyph):0),matrix[5]-previous.matrix[5]-previous.matrix[1]*(previous.glyph>=0?current.font.advanceGlyph(previous.glyph):0)):0;
        if(!current||!near(matrix.slice(0,4),current.matrix.slice(0,4))||off>Math.max(.2,size*.12)||gap>size*1.2){
          current={font:new mupdf.Font(font.pointer),space,color:[...color],alpha,matrix:[...matrix],size,glyphs:[],text:'',wmode,bidi};runs.push(current);
        }
        current.glyphs.push({matrix,glyph,unicode});if(unicode>=0)current.text+=String.fromCodePoint(unicode);else current.unmapped=true;if(glyph<0)current.unmapped=true;
      }});}finally{text.destroy();if(runs.length===before)space.destroy()}
    }});
    page.runPageContents(device,I);device.close();
    for(const r of runs){const shape=new mupdf.Text();try{for(const g of r.glyphs)shape.showGlyph(r.font,g.matrix,g.glyph,g.unicode,r.wmode);r.rect=shape.getBounds(null,I)}finally{shape.destroy()}}
    const decorations=directDecorations(page);try{for(const r of runs){const x=(r.rect[0]+r.rect[2])/2,y=(r.rect[1]+r.rect[3])/2;for(const d of decorations.rows)if(x>=d.rect[0]-.5&&x<=d.rect[2]+.5&&y>=d.rect[1]-.5&&y<=d.rect[3]+.5)r[d.kind]=true}}finally{decorations.close()}
    return runs;
  }catch(error){dispose(runs);throw error}finally{device?.destroy();page.destroy()}
}
const descriptor=(r,index)=>({index,text:r.text,rect:[...r.rect],matrix:[...r.matrix],end:r.glyphs.length?(()=>{const g=r.glyphs.findLast(g=>g.glyph>=0)||r.glyphs.at(-1),advance=g.glyph>=0?r.font.advanceGlyph(g.glyph):0;return[g.matrix[4]+g.matrix[0]*advance,g.matrix[5]+g.matrix[1]*advance]})():r.matrix.slice(4),size:r.size,fontName:r.font.getName(),bold:r.font.isBold(),italic:r.font.isItalic(),underline:!!r.underline,strikethrough:!!r.strikethrough,color:hexColor(r.space,r.color),alpha:r.alpha,editable:!r.wmode&&!r.bidi&&!r.unmapped&&r.text.trim().length>0});
export function directTextTargets(doc,pageIndex){const runs=capture(doc,pageIndex);try{return runs.map(descriptor).filter(r=>r.text.trim())}finally{dispose(runs)}}
function selectionData(doc,pageIndex){
  const page=doc.loadPage(pageIndex),text=page.toStructuredText('');
  try{let saved=[];try{saved=JSON.parse(page.getObject().get('PdfProDirectFlows').asString())}catch{}return{blocks:JSON.parse(text.asJSON()).blocks||[],saved:Array.isArray(saved)?saved:[]}}finally{text.destroy();page.destroy()}
}
export function directEditTargets(doc,pageIndex,mode='paragraph'){const data=selectionData(doc,pageIndex);return makeDirectSelections(directTextTargets(doc,pageIndex),data.blocks,mode,data.saved)}
export function directChunkTarget(doc,pageIndex,region){const data=selectionData(doc,pageIndex);return selectDirectChunk(directTextTargets(doc,pageIndex),data.blocks,region,data.saved)}
export function directFontData(doc,pageIndex,target){
  const page=doc.loadPage(pageIndex),visited=new Set(),clean=name=>String(name).replace(/^[A-Z]{6}\+/,'').toLowerCase();let result=null,steps=0;
  function scan(resources){
    if(result||++steps>200||resources.isNull())return;
    const fonts=resources.get('Font');if(fonts.isDictionary())fonts.forEach(font=>{
      if(result)return;const descendants=font.get('DescendantFonts');if(descendants.isArray())font=descendants.get(0);
      const descriptor=font.get('FontDescriptor'),names=[font.get('BaseFont'),descriptor.get('FontName')].filter(n=>n.isName()).map(n=>clean(n.asName()));
      if(!names.includes(clean(target.fontName)))return;
      const file2=descriptor.get('FontFile2'),file3=descriptor.get('FontFile3'),file=file2.isStream()?file2:file3.isStream()&&file3.get('Subtype').asName()==='OpenType'?file3:null;
      if(file){const buffer=file.readStream();try{const bytes=buffer.asUint8Array();if(bytes.length<=20000000)result=bytes.slice()}finally{buffer.destroy()}}
    });
    const objects=resources.get('XObject');if(objects.isDictionary())objects.forEach(form=>{if(result||form.get('Subtype').asName()!=='Form')return;const id=form.isIndirect()?form.asIndirect():form.pointer;if(visited.has(id))return;visited.add(id);scan(form.get('Resources'))});
  }
  try{scan(page.getObject().getInheritable('Resources'));return result}catch{return null}finally{page.destroy()}
}
// New pdfpro text boxes retain their device-font recipe beside their appearance.
// Older image-backed boxes and invisible OCR layers have no safe native text target.
export function addedTextTargets(doc,pageIndex){
  const page=doc.loadPage(pageIndex),targets=[];
  try{const object=page.getObject(),boxes=object.get('PdfProFontBoxes');if(!boxes.isArray())return targets;
    boxes.forEach((box,index)=>{try{
      const value=box.get('Style');if(!value.isString())return;const style=JSON.parse(value.asString());
      if(typeof style.text!=='string'||typeof style.font!=='string'||!/^#[\da-f]{6}$/i.test(style.color)||![style.x,style.y,style.size,style.width,style.height,style.rotation,style.scale,style.opacity].every(Number.isFinite)||style.scale<=0)return;
      if(style.matrix&&(!Array.isArray(style.matrix)||style.matrix.length!==6||!style.matrix.every(Number.isFinite)||Math.abs(style.matrix[0]*style.matrix[3]-style.matrix[1]*style.matrix[2])<.000001))return;
      const source=box.get('Rect').asJS(),resource=box.get('Resource').asName(),form=object.getInheritable('Resources').get('XObject').get(resource);
      if(form.get('Subtype').asName()!=='Form'||!Array.isArray(source)||source.length!==4)return;
      const transform=page.getTransform(),rect=mupdf.Rect.transform(source,transform),unit=Math.sqrt(Math.abs(transform[0]*transform[3]-transform[1]*transform[2]));
      targets.push({kind:'added',index,text:style.text,rect,size:style.size*style.scale*unit,fontName:style.font,color:style.color,alpha:style.opacity,editable:true,style,source,resource});
    }catch{}});return targets;
  }finally{page.destroy()}
}
function copyDict(doc,source){const out=doc.newDictionary();if(!source.isNull())source.forEach((value,key)=>out.put(key,value));return out}
function overlayPDF(run,text,glyphMap,bounds){
  const shape=new mupdf.Text(),buffer=new mupdf.Buffer(),glyphs=[];let writer,output;
  try{
    let x=run.matrix[4],y=run.matrix[5];
    for(const char of text){const unicode=char.codePointAt(0),gid=glyphMap.get(unicode)||run.font.encodeCharacter(unicode);if(!gid)throw Error('The original PDF font does not contain “'+char+'”. Your text has not been changed.');shape.showGlyph(run.font,[...run.matrix.slice(0,4),x,y],gid,unicode,0);glyphs.push({font:run.font,gid,unicode});const step=run.font.advanceGlyph(gid);x+=run.matrix[0]*step;y+=run.matrix[1]*step}
    const rect=shape.getBounds(null,I);if(rect[0]<bounds[0]-2||rect[1]<bounds[1]-2||rect[2]>bounds[2]+2||rect[3]>bounds[3]+2)throw Error('The replacement extends beyond the page. Shorten the text to retain its original size.');
    writer=new mupdf.DocumentWriter(buffer,'pdf','compress');const device=writer.beginPage(bounds);
    try{device.fillText(shape,I,run.space,run.color,run.alpha)}finally{device.destroy()}
    writer.endPage();writer.close();output=preserveNativeTextUnicode(buffer.asUint8Array().slice(),glyphs);return{bytes:output,rect};
  }finally{writer?.destroy();buffer.destroy();shape.destroy()}
}
export function replaceDirectText(doc,pageIndex,target,replacement){
  const text=String(replacement);if(text.length>10000||/[\x00-\x1f\x7f]/.test(text))throw Error('Direct edit changes one text line at a time, up to 10,000 characters.');
  const runs=capture(doc,pageIndex),run=runs[target.index];let page;
  try{
    if(!run||run.text!==target.text||!near(run.rect,target.rect)||!near(run.matrix,target.matrix))throw Error('This text changed. Select it again.');
    if(!descriptor(run,target.index).editable)throw Error('This text uses a writing mode or encoding that cannot be directly edited without changing its appearance.');
    if(text===run.text)return;
    page=doc.loadPage(pageIndex);const bounds=page.getBounds(),glyphMap=new Map();
    for(const r of runs)if(r.font.pointer===run.font.pointer)for(const g of r.glyphs)if(g.unicode>=0)glyphMap.set(g.unicode,g.glyph);
    const prepared=text?overlayPDF(run,text,glyphMap,bounds):null;
    if(prepared)for(const [index,other]of runs.entries())if(index!==target.index&&other.text.trim()&&prepared.rect[0]<other.rect[2]-.5&&prepared.rect[2]>other.rect[0]+.5&&prepared.rect[1]<other.rect[3]-.5&&prepared.rect[3]>other.rect[1]+.5)throw Error('The replacement would overlap other text. Shorten it to keep the original size.');
    const annotations=page.getAnnotations();try{if(annotations.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing PDF redaction annotations before Direct edit.')}finally{annotations.forEach(a=>a.destroy())}
    // Validate font/fit before removing glyphs. Images and vector artwork are preserved.
    const mark=page.createAnnotation('Redact');try{mark.setRect(run.rect);mark.update()}finally{mark.destroy()}
    page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
    const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>i!==target.index).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This text overlaps another item and cannot be safely edited on its own.')}finally{dispose(remaining)}
    if(!prepared)return;
    appendOverlay(doc,page,prepared);
  }finally{page?.destroy();dispose(runs)}
}

function appendOverlay(doc,page,prepared){
    const layer=mupdf.Document.openDocument(prepared.bytes,'application/pdf').asPDF();const lp=layer.loadPage(0);let stream;
    try{
      const object=lp.getObject(),contents=object.get('Contents'),parts=[];
      const read=ref=>{const b=ref.readStream();try{parts.push(b.asString())}finally{b.destroy()}};
      if(contents.isArray())contents.forEach(read);else read(contents);
      const resources=doc.graftObject(object.getInheritable('Resources')),media=object.getInheritable('MediaBox').asJS();
      const form=doc.addStream(parts.join('\n'),{Type:'XObject',Subtype:'Form',BBox:media,Resources:resources});
      const dest=page.getObject(),res=copyDict(doc,dest.getInheritable('Resources')),objects=copyDict(doc,res.get('XObject')),name='PdfProDirect'+form.asIndirect();objects.put(name,form);res.put('XObject',objects);dest.put('Resources',res);
      const transform=mupdf.Matrix.concat(lp.getTransform(),mupdf.Matrix.invert(page.getTransform()));
      // The prepared layer has an explicit, verified glyph-to-Unicode map.
      // Whole-Form ActualText can duplicate accented words in PDF consumers.
      stream=doc.addStream('q '+transform.join(' ')+' cm /'+name+' Do Q',{});
      const all=doc.newArray(),old=dest.get('Contents');if(old.isArray())old.forEach(value=>all.push(value));else if(!old.isNull())all.push(old);all.push(stream);dest.put('Contents',all);
    }finally{stream?.destroy();lp.destroy();layer.destroy()}
}
// Object manipulation keeps original glyphs, font programs and colours.
export function transformDirectText(doc,pageIndex,target,{matrix=I,action='transform'}={}){
  const runs=capture(doc,pageIndex),selected=new Set(target.parts.map(p=>p.index));let page;
  try{
    for(const part of target.parts){const r=runs[part.index];if(!r||r.text!==part.text||!near(r.matrix,part.matrix)||!descriptor(r,part.index).editable)throw Error('This text changed or cannot be moved with its original font.');}
    page=doc.loadPage(pageIndex);let prepared,flow;
    if(action!=='delete'){const glyphs=[];for(const index of selected){const r=runs[index];for(const g of r.glyphs){const transformed=mupdf.Matrix.concat(g.matrix,matrix);glyphs.push({style:index,line:index,s:{...r,size:Math.sqrt(Math.abs(transformed[0]*transformed[3]-transformed[1]*transformed[2]))},gid:g.glyph,unicode:g.unicode,matrix:transformed})}}const m=glyphs[0]?.matrix||I,n=Math.hypot(m[0],m[1])||1,sign=m[0]*m[3]-m[1]*m[2]<0?1:-1;flow={glyphs,layout:{u:[m[0]/n,m[1]/n],v:[-m[1]/n*sign,m[0]/n*sign]}};prepared=flowOverlay(flow,page.getBounds())}
    if(action!=='duplicate'){
      clearDirectDecorations(page,target.parts);
      for(const p of target.parts){const mark=page.createAnnotation('Redact');try{mark.setRect(p.rect);mark.update()}finally{mark.destroy()}}
      page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
      const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>!selected.has(i)).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This text overlaps another item and cannot be moved on its own.')}finally{dispose(remaining)}
    }
    if(prepared){appendOverlay(doc,page,prepared);writeDirectDecorations(doc,page,flow)}
    const o=page.getObject();try{o.delete('PdfProDirectFlows')}finally{o.destroy()}
  }finally{page?.destroy();dispose(runs)}
}
function flowOverlay(flow,bounds){
  const shapes=[],buffer=new mupdf.Buffer();let writer;
  try{
    let current=null;
    for(const glyph of flow.glyphs){
      if(!current||current.style!==glyph.style||current.line!==glyph.line){current={style:glyph.style,line:glyph.line,run:glyph.s,text:new mupdf.Text()};shapes.push(current)}
      current.text.showGlyph(glyph.s.font,glyph.matrix,glyph.gid,glyph.unicode,0);
    }
    const rects=shapes.map(s=>s.text.getBounds(null,I)),rect=rects.length?union(rects):null;
    if(rect&&(rect[0]<bounds[0]-2||rect[1]<bounds[1]-2||rect[2]>bounds[2]+2||rect[3]>bounds[3]+2))throw Error('The reflowed text extends beyond the page. Shorten the text or increase its width.');
    writer=new mupdf.DocumentWriter(buffer,'pdf','compress');const device=writer.beginPage(bounds);
    try{for(const s of shapes)device.fillText(s.text,I,s.run.space,s.run.color,s.run.alpha)}finally{device.destroy()}
    writer.endPage();writer.close();return{bytes:preserveNativeTextUnicode(buffer.asUint8Array().slice(),flow.glyphs.map(g=>({font:g.s.font,gid:g.gid,unicode:g.unicode}))),rect,rects};
  }finally{writer?.destroy();buffer.destroy();shapes.forEach(s=>s.text.destroy())}
}
export function replaceDirectTextGroup(doc,pageIndex,target,replacement,options={}){
  const runs=capture(doc,pageIndex),selected=new Set(target.parts.map(p=>p.index)),ownedFonts=[];let page;
  try{
    if(!selected.size||selected.size!==target.parts.length)throw Error('Select a text line, paragraph or chunk first.');
    for(const part of target.parts){const run=runs[part.index];if(!run||run.text!==part.text||!near(run.rect,part.rect)||!near(run.matrix,part.matrix))throw Error('This text changed. Select it again.');if(!descriptor(run,part.index).editable)throw Error('This text uses an unsupported writing direction or encoding.');}
    if(!target.editable)throw Error('Select text with one writing direction.');
    const maps=new Map();for(const r of runs){let map=maps.get(r.font.pointer);if(!map){map=new Map();maps.set(r.font.pointer,map)}for(const g of r.glyphs)if(g.unicode>=0&&g.glyph>=0){map.set(g.unicode,g.glyph);if(g.unicode===160&&!map.has(32))map.set(32,g.glyph)}}
    const styles=new Map(target.parts.map(p=>[p.index,{...runs[p.index],glyphMap:maps.get(runs[p.index].font.pointer)}]));
    const cache=new Map();const resolveStyle=(index,format)=>{if(!format||typeof format!=='object'||Array.isArray(format)||Object.keys(format).some(k=>!['font','size','color','bold','italic','underline','strikethrough'].includes(k)))throw Error('Invalid text formatting.');
      if(format.font&&!['original','Helvetica','Times-Roman','Courier'].includes(format.font))throw Error('Choose an available PDF font.');
      if(format.size!==undefined&&(!Number.isFinite(format.size)||format.size<4||format.size>144))throw Error('Choose a font size from 4 to 144 pt.');
      if(format.color!==undefined&&!/^#[a-f\d]{6}$/i.test(format.color))throw Error('Choose a valid text colour.');
      for(const k of ['bold','italic','underline','strikethrough'])if(format[k]!==undefined&&typeof format[k]!=='boolean')throw Error('Invalid text formatting.');
      const key=index+':'+JSON.stringify(format);if(cache.has(key))return cache.get(key);const source=styles.get(index);if(!source)throw Error('This text style changed. Select the text again.');
      const next={...source},bold=format.bold??source.font.isBold(),italic=format.italic??source.font.isItalic();
      if(format.font&&format.font!=='original'||bold!==source.font.isBold()||italic!==source.font.isItalic()){
        const family=format.font&&format.font!=='original'?format.font:/courier|mono/i.test(source.font.getName())?'Courier':/times|roman|serif/i.test(source.font.getName())&&!/sans/i.test(source.font.getName())?'Times-Roman':'Helvetica';
        const name=family==='Times-Roman'?(bold?(italic?'Times-BoldItalic':'Times-Bold'):(italic?'Times-Italic':'Times-Roman')):family+(bold?(italic?'-BoldOblique':'-Bold'):(italic?'-Oblique':''));
        next.font=new mupdf.Font(name);ownedFonts.push(next.font);next.glyphMap=new Map();
      }
      if(format.size!==undefined){const scale=format.size/source.size;next.matrix=[...source.matrix];for(let i=0;i<4;i++)next.matrix[i]*=scale;next.size=format.size}
      if(format.color!==undefined){next.space=mupdf.ColorSpace.DeviceRGB;next.color=[1,3,5].map(i=>parseInt(format.color.slice(i,i+2),16)/255)}
      for(const k of ['underline','strikethrough'])if(format[k]!==undefined)next[k]=format[k];
      next.baselineOffset=target.layout.offsets[index]||0;const id='formatted:'+cache.size;styles.set(id,next);cache.set(key,id);return id;
    };
    const flow=flowGlyphs(target,replacement,styles,{...options,resolveStyle});page=doc.loadPage(pageIndex);
    const prepared=flow.glyphs.length?flowOverlay(flow,page.getBounds()):null;
    if(prepared)for(const [index,other]of runs.entries())if(!selected.has(index)&&other.text.trim())for(const rect of prepared.rects)if(rect[0]<other.rect[2]-.5&&rect[2]>other.rect[0]+.5&&rect[1]<other.rect[3]-.5&&rect[3]>other.rect[1]+.5)throw Error('The reflowed text would overlap other text. Increase the width or select a larger Text chunk.');
    clearDirectDecorations(page,target.parts);
    for(const part of target.parts){const mark=page.createAnnotation('Redact');try{mark.setRect(part.rect);mark.update()}finally{mark.destroy()}}
    page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
    const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>!selected.has(i)).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This selection overlaps other text and cannot be safely edited on its own.')}finally{dispose(remaining)}
    if(prepared){appendOverlay(doc,page,prepared);writeDirectDecorations(doc,page,flow)}
    const object=page.getObject();let saved=[];try{saved=JSON.parse(object.get('PdfProDirectFlows').asString())}catch{}
    saved=(Array.isArray(saved)?saved:[]).filter(r=>Array.isArray(r.rect)&&!(r.rect[0]<target.rect[2]&&r.rect[2]>target.rect[0]&&r.rect[1]<target.rect[3]&&r.rect[3]>target.rect[1]));
    if(prepared&&target.scope!=='line')saved.push({rect:prepared.rect,text:flow.text,layout:flow.layout});object.put('PdfProDirectFlows',doc.newString(JSON.stringify(saved.slice(-100))));
    return{lineCount:flow.lineCount,width:flow.width};
  }finally{page?.destroy();ownedFonts.forEach(f=>f.destroy());dispose(runs)}
}

function writeDirectDecorations(doc,page,flow){
 const groups=[];let active=null;for(const glyph of flow.glyphs){if(!glyph.s.underline&&!glyph.s.strikethrough){active=null;continue}let group=active;if(!group||group.style!==glyph.style||group.line!==glyph.line){group={style:glyph.style,line:glyph.line,run:glyph.s,text:new mupdf.Text(),glyphs:[]};groups.push(group);active=group}group.text.showGlyph(glyph.s.font,glyph.matrix,glyph.gid,glyph.unicode,0);group.glyphs.push(glyph)}
 try{for(const group of groups){const rect=group.text.getBounds(null,I);for(const [key,type]of [['underline','Underline'],['strikethrough','StrikeOut']]){if(!group.run[key])continue;const annotation=page.createAnnotation(type);try{
   const first=group.glyphs[0],last=group.glyphs.at(-1),u=flow.layout.u,v=flow.layout.v,advance=last.s.font.advanceGlyph(last.gid)*Math.hypot(last.matrix[0],last.matrix[1]),start=first.matrix.slice(4),end=[last.matrix[4]+u[0]*advance,last.matrix[5]+u[1]*advance],size=group.run.size,at=(p,dy)=>[p[0]+v[0]*dy,p[1]+v[1]*dy];
   annotation.setQuadPoints([[...at(start,-size*.85),...at(end,-size*.85),...at(start,size*.15),...at(end,size*.15)]]);annotation.setColor(rgb(group.run.space,group.run.color));annotation.setOpacity(group.run.alpha);annotation.setAuthor('PDFCreator');annotation.update();
   const object=annotation.getObject();try{object.put('PDFCreatorDirectDecoration',doc.newName(key));object.put('PDFCreatorDirectRect',rect)}finally{object.destroy()}
  }finally{annotation.destroy()}}}}finally{groups.forEach(g=>g.text.destroy())}
}
