/* Edit visible PDF text with its original native font and graphics style. AGPL-3.0-or-later. */
import {mupdf} from './engine.js';
import {makeDirectSelections,selectDirectChunk,flowGlyphs,union} from './direct-layout.js';
const I=mupdf.Matrix.identity;
const near=(a,b,t=.03)=>a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<t);
export function saveDirectEdit(doc){
  // Compact and remove unreachable objects. Immediate dictionary/stream deduplication
  // (garbage=3/4) can lose a newly grafted Form in this MuPDF build; use level 2.
  const buffer=doc.saveToBuffer('garbage=2,compress');try{return buffer.asUint8Array().slice()}finally{buffer.destroy()}
}
function rgb(space,c){
  if(space.isRGB())return c.slice(0,3);if(space.isGray())return[c[0],c[0],c[0]];
  const pix=new mupdf.Pixmap(mupdf.ColorSpace.DeviceRGB,[0,0,1,1],false),path=new mupdf.Path();let device;
  try{path.rect(0,0,1,1);device=new mupdf.DrawDevice(I,pix);device.fillPath(path,false,I,space,c,1);device.close();return[...pix.getPixels()].slice(0,3).map(n=>n/255)}finally{device?.destroy();path.destroy();pix.destroy()}
}
const hexColor=(space,c)=>'#'+rgb(space,c).map(v=>Math.round(Math.max(0,Math.min(1,v))*255).toString(16).padStart(2,'0')).join('');
function dispose(runs){for(const r of runs)r.font.destroy();for(const space of new Set(runs.map(r=>r.space)))space.destroy()}
function capture(doc,index){
  const page=doc.loadPage(index),runs=[];let current=null,device;
  try{
    device=new mupdf.Device({fillText(text,ctm,space,color,alpha){const before=runs.length;
      try{text.walk({beginSpan(){current=null},showGlyph(font,trm,glyph,unicode,wmode,bidi){
        const matrix=mupdf.Matrix.concat(trm,ctm),size=Math.sqrt(Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2]));
        const direction=[matrix[0],matrix[1]],norm=Math.hypot(...direction)||1;
        const off=current?Math.abs((matrix[4]-current.matrix[4])*(-direction[1]/norm)+(matrix[5]-current.matrix[5])*(direction[0]/norm)):0;
        const previous=current?.glyphs.at(-1),gap=previous?Math.hypot(matrix[4]-previous.matrix[4]-previous.matrix[0]*(previous.glyph>=0?current.font.advanceGlyph(previous.glyph):0),matrix[5]-previous.matrix[5]-previous.matrix[1]*(previous.glyph>=0?current.font.advanceGlyph(previous.glyph):0)):0;
        if(!current||!near(matrix.slice(0,4),current.matrix.slice(0,4))||off>Math.max(.2,size*.12)||gap>size*1.2){
          current={font:new mupdf.Font(font.pointer),space,color:[...color],alpha,matrix:[...matrix],size,glyphs:[],text:'',wmode,bidi};runs.push(current);
        }
        current.glyphs.push({matrix,glyph,unicode});if(unicode>=0)current.text+=String.fromCodePoint(unicode);else current.unmapped=true;if(glyph<0)current.unmapped=true;
      }});}finally{text.destroy();if(runs.length===before)space.destroy()}
    }});
    page.runPageContents(device,I);device.close();
    for(const r of runs){const shape=new mupdf.Text();try{for(const g of r.glyphs)shape.showGlyph(r.font,g.matrix,g.glyph,g.unicode,r.wmode);r.rect=shape.getBounds(null,I)}finally{shape.destroy()}}
    return runs;
  }catch(error){dispose(runs);throw error}finally{device?.destroy();page.destroy()}
}
const descriptor=(r,index)=>({index,text:r.text,rect:[...r.rect],matrix:[...r.matrix],end:r.glyphs.length?(()=>{const g=r.glyphs.findLast(g=>g.glyph>=0)||r.glyphs.at(-1),advance=g.glyph>=0?r.font.advanceGlyph(g.glyph):0;return[g.matrix[4]+g.matrix[0]*advance,g.matrix[5]+g.matrix[1]*advance]})():r.matrix.slice(4),size:r.size,fontName:r.font.getName(),bold:r.font.isBold(),italic:r.font.isItalic(),color:hexColor(r.space,r.color),alpha:r.alpha,editable:!r.wmode&&!r.bidi&&!r.unmapped&&r.text.trim().length>0});
export function directTextTargets(doc,pageIndex){const runs=capture(doc,pageIndex);try{return runs.map(descriptor).filter(r=>r.text.trim())}finally{dispose(runs)}}
function selectionData(doc,pageIndex){
  const page=doc.loadPage(pageIndex),text=page.toStructuredText('');
  try{let saved=[];try{saved=JSON.parse(page.getObject().get('PdfProDirectFlows').asString())}catch{}return{blocks:JSON.parse(text.asJSON()).blocks||[],saved:Array.isArray(saved)?saved:[]}}finally{text.destroy();page.destroy()}
}
export function directEditTargets(doc,pageIndex,mode='paragraph'){const data=selectionData(doc,pageIndex);return makeDirectSelections(directTextTargets(doc,pageIndex),data.blocks,mode,data.saved)}
export function directChunkTarget(doc,pageIndex,region){const data=selectionData(doc,pageIndex);return selectDirectChunk(directTextTargets(doc,pageIndex),data.blocks,region,data.saved)}
export function directFontData(doc,pageIndex,target){
  const page=doc.loadPage(pageIndex),visited=new Set(),clean=name=>String(name).replace(/^[A-Z]{6}\+/,'').toLowerCase();let result=null,steps=0;
  function scan(resources){
    if(result||++steps>200||resources.isNull())return;
    const fonts=resources.get('Font');if(fonts.isDictionary())fonts.forEach(font=>{
      if(result)return;const descendants=font.get('DescendantFonts');if(descendants.isArray())font=descendants.get(0);
      const descriptor=font.get('FontDescriptor'),names=[font.get('BaseFont'),descriptor.get('FontName')].filter(n=>n.isName()).map(n=>clean(n.asName()));
      if(!names.includes(clean(target.fontName)))return;
      const file2=descriptor.get('FontFile2'),file3=descriptor.get('FontFile3'),file=file2.isStream()?file2:file3.isStream()&&file3.get('Subtype').asName()==='OpenType'?file3:null;
      if(file){const buffer=file.readStream();try{const bytes=buffer.asUint8Array();if(bytes.length<=20000000)result=bytes.slice()}finally{buffer.destroy()}}
    });
    const objects=resources.get('XObject');if(objects.isDictionary())objects.forEach(form=>{if(result||form.get('Subtype').asName()!=='Form')return;const id=form.isIndirect()?form.asIndirect():form.pointer;if(visited.has(id))return;visited.add(id);scan(form.get('Resources'))});
  }
  try{scan(page.getObject().getInheritable('Resources'));return result}catch{return null}finally{page.destroy()}
}
// New pdfpro text boxes retain their device-font recipe beside their appearance.
// Older image-backed boxes and invisible OCR layers have no safe native text target.
export function addedTextTargets(doc,pageIndex){
  const page=doc.loadPage(pageIndex),targets=[];
  try{const object=page.getObject(),boxes=object.get('PdfProFontBoxes');if(!boxes.isArray())return targets;
    boxes.forEach((box,index)=>{try{
      const value=box.get('Style');if(!value.isString())return;const style=JSON.parse(value.asString());
      if(typeof style.text!=='string'||typeof style.font!=='string'||!/^#[\da-f]{6}$/i.test(style.color)||![style.x,style.y,style.size,style.width,style.height,style.rotation,style.scale,style.opacity].every(Number.isFinite)||style.scale<=0)return;
      if(style.matrix&&(!Array.isArray(style.matrix)||style.matrix.length!==6||!style.matrix.every(Number.isFinite)||Math.abs(style.matrix[0]*style.matrix[3]-style.matrix[1]*style.matrix[2])<.000001))return;
      const source=box.get('Rect').asJS(),resource=box.get('Resource').asName(),form=object.getInheritable('Resources').get('XObject').get(resource);
      if(form.get('Subtype').asName()!=='Form'||!Array.isArray(source)||source.length!==4)return;
      const transform=page.getTransform(),rect=mupdf.Rect.transform(source,transform),unit=Math.sqrt(Math.abs(transform[0]*transform[3]-transform[1]*transform[2]));
      targets.push({kind:'added',index,text:style.text,rect,size:style.size*style.scale*unit,fontName:style.font,color:style.color,alpha:style.opacity,editable:true,style,source,resource});
    }catch{}});return targets;
  }finally{page.destroy()}
}
function copyDict(doc,source){const out=doc.newDictionary();if(!source.isNull())source.forEach((value,key)=>out.put(key,value));return out}
function overlayPDF(run,text,glyphMap,bounds){
  const shape=new mupdf.Text(),buffer=new mupdf.Buffer();let writer,output;
  try{
    let x=run.matrix[4],y=run.matrix[5];
    for(const char of text){const unicode=char.codePointAt(0),gid=run.font.encodeCharacter(unicode)||glyphMap.get(unicode);if(!gid)throw Error('The original PDF font does not contain “'+char+'”. Your text has not been changed.');shape.showGlyph(run.font,[...run.matrix.slice(0,4),x,y],gid,unicode,0);const step=run.font.advanceGlyph(gid);x+=run.matrix[0]*step;y+=run.matrix[1]*step}
    const rect=shape.getBounds(null,I);if(rect[0]<bounds[0]-2||rect[1]<bounds[1]-2||rect[2]>bounds[2]+2||rect[3]>bounds[3]+2)throw Error('The replacement extends beyond the page. Shorten the text to retain its original size.');
    writer=new mupdf.DocumentWriter(buffer,'pdf','compress');const device=writer.beginPage(bounds);
    try{device.fillText(shape,I,run.space,run.color,run.alpha)}finally{device.destroy()}
    writer.endPage();writer.close();output=buffer.asUint8Array().slice();return{bytes:output,rect};
  }finally{writer?.destroy();buffer.destroy();shape.destroy()}
}
export function replaceDirectText(doc,pageIndex,target,replacement){
  const text=String(replacement);if(text.length>10000||/[\x00-\x1f\x7f]/.test(text))throw Error('Direct edit changes one text line at a time, up to 10,000 characters.');
  const runs=capture(doc,pageIndex),run=runs[target.index];let page;
  try{
    if(!run||run.text!==target.text||!near(run.rect,target.rect)||!near(run.matrix,target.matrix))throw Error('This text changed. Select it again.');
    if(!descriptor(run,target.index).editable)throw Error('This text uses a writing mode or encoding that cannot be directly edited without changing its appearance.');
    if(text===run.text)return;
    page=doc.loadPage(pageIndex);const bounds=page.getBounds(),glyphMap=new Map();
    for(const r of runs)if(r.font.pointer===run.font.pointer)for(const g of r.glyphs)if(g.unicode>=0)glyphMap.set(g.unicode,g.glyph);
    const prepared=text?overlayPDF(run,text,glyphMap,bounds):null;
    if(prepared)for(const [index,other]of runs.entries())if(index!==target.index&&other.text.trim()&&prepared.rect[0]<other.rect[2]-.5&&prepared.rect[2]>other.rect[0]+.5&&prepared.rect[1]<other.rect[3]-.5&&prepared.rect[3]>other.rect[1]+.5)throw Error('The replacement would overlap other text. Shorten it to keep the original size.');
    const annotations=page.getAnnotations();try{if(annotations.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing PDF redaction annotations before Direct edit.')}finally{annotations.forEach(a=>a.destroy())}
    // Validate font/fit before removing glyphs. Images and vector artwork are preserved.
    const mark=page.createAnnotation('Redact');try{mark.setRect(run.rect);mark.update()}finally{mark.destroy()}
    page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
    const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>i!==target.index).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This text overlaps another item and cannot be safely edited on its own.')}finally{dispose(remaining)}
    if(!prepared)return;
    appendOverlay(doc,page,prepared);
  }finally{page?.destroy();dispose(runs)}
}

function appendOverlay(doc,page,prepared){
    const layer=mupdf.Document.openDocument(prepared.bytes,'application/pdf').asPDF();const lp=layer.loadPage(0);let stream;
    try{
      const object=lp.getObject(),contents=object.get('Contents'),parts=[];
      const read=ref=>{const b=ref.readStream();try{parts.push(b.asString())}finally{b.destroy()}};
      if(contents.isArray())contents.forEach(read);else read(contents);
      const resources=doc.graftObject(object.getInheritable('Resources')),media=object.getInheritable('MediaBox').asJS();
      const form=doc.addStream(parts.join('\n'),{Type:'XObject',Subtype:'Form',BBox:media,Resources:resources});
      const dest=page.getObject(),res=copyDict(doc,dest.getInheritable('Resources')),objects=copyDict(doc,res.get('XObject')),name='PdfProDirect'+form.asIndirect();objects.put(name,form);res.put('XObject',objects);dest.put('Resources',res);
      const transform=mupdf.Matrix.concat(lp.getTransform(),mupdf.Matrix.invert(page.getTransform()));
      // The writer supplies a ToUnicode map. Wrapping an entire Form in ActualText
      // can duplicate accented words in structured-text consumers.
      stream=doc.addStream('q '+transform.join(' ')+' cm /'+name+' Do Q',{});
      const all=doc.newArray(),old=dest.get('Contents');if(old.isArray())old.forEach(value=>all.push(value));else if(!old.isNull())all.push(old);all.push(stream);dest.put('Contents',all);
    }finally{stream?.destroy();lp.destroy();layer.destroy()}
}
// Object manipulation keeps original glyphs, font programs and colours.
export function transformDirectText(doc,pageIndex,target,{matrix=I,action='transform'}={}){
  const runs=capture(doc,pageIndex),selected=new Set(target.parts.map(p=>p.index));let page;
  try{
    for(const part of target.parts){const r=runs[part.index];if(!r||r.text!==part.text||!near(r.matrix,part.matrix)||!descriptor(r,part.index).editable)throw Error('This text changed or cannot be moved with its original font.');}
    page=doc.loadPage(pageIndex);let prepared;
    if(action!=='delete'){const glyphs=[];for(const index of selected){const r=runs[index];for(const g of r.glyphs)glyphs.push({style:index,line:index,s:r,gid:g.glyph,unicode:g.unicode,matrix:mupdf.Matrix.concat(g.matrix,matrix)})}prepared=flowOverlay({glyphs},page.getBounds())}
    if(action!=='duplicate'){
      const all=page.getAnnotations();try{if(all.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing redaction annotations first.')}finally{all.forEach(a=>a.destroy())}
      for(const p of target.parts){const mark=page.createAnnotation('Redact');try{mark.setRect(p.rect);mark.update()}finally{mark.destroy()}}
      page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
      const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>!selected.has(i)).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This text overlaps another item and cannot be moved on its own.')}finally{dispose(remaining)}
    }
    if(prepared)appendOverlay(doc,page,prepared);
    const o=page.getObject();try{o.delete('PdfProDirectFlows')}finally{o.destroy()}
  }finally{page?.destroy();dispose(runs)}
}
function flowOverlay(flow,bounds){
  const shapes=[],buffer=new mupdf.Buffer();let writer;
  try{
    let current=null;
    for(const glyph of flow.glyphs){
      if(!current||current.style!==glyph.style||current.line!==glyph.line){current={style:glyph.style,line:glyph.line,run:glyph.s,text:new mupdf.Text()};shapes.push(current)}
      current.text.showGlyph(glyph.s.font,glyph.matrix,glyph.gid,glyph.unicode,0);
    }
    const rects=shapes.map(s=>s.text.getBounds(null,I)),rect=rects.length?union(rects):null;
    if(rect&&(rect[0]<bounds[0]-2||rect[1]<bounds[1]-2||rect[2]>bounds[2]+2||rect[3]>bounds[3]+2))throw Error('The reflowed text extends beyond the page. Shorten the text or increase its width.');
    writer=new mupdf.DocumentWriter(buffer,'pdf','compress');const device=writer.beginPage(bounds);
    try{for(const s of shapes)device.fillText(s.text,I,s.run.space,s.run.color,s.run.alpha)}finally{device.destroy()}
    writer.endPage();writer.close();return{bytes:buffer.asUint8Array().slice(),rect,rects};
  }finally{writer?.destroy();buffer.destroy();shapes.forEach(s=>s.text.destroy())}
}
export function replaceDirectTextGroup(doc,pageIndex,target,replacement,options={}){
  const runs=capture(doc,pageIndex),selected=new Set(target.parts.map(p=>p.index));let page;
  try{
    if(!selected.size||selected.size!==target.parts.length)throw Error('Select a text line, paragraph or chunk first.');
    for(const part of target.parts){const run=runs[part.index];if(!run||run.text!==part.text||!near(run.rect,part.rect)||!near(run.matrix,part.matrix))throw Error('This text changed. Select it again.');if(!descriptor(run,part.index).editable)throw Error('This text uses an unsupported writing direction or encoding.');}
    if(!target.editable)throw Error('Select text with one writing direction.');
    const maps=new Map();for(const r of runs){let map=maps.get(r.font.pointer);if(!map){map=new Map();maps.set(r.font.pointer,map)}for(const g of r.glyphs)if(g.unicode>=0&&g.glyph>=0){map.set(g.unicode,g.glyph);if(g.unicode===160&&!map.has(32))map.set(32,g.glyph)}}
    const styles=new Map(target.parts.map(p=>[p.index,{...runs[p.index],glyphMap:maps.get(runs[p.index].font.pointer)}]));
    const flow=flowGlyphs(target,replacement,styles,options);page=doc.loadPage(pageIndex);
    const prepared=flow.glyphs.length?flowOverlay(flow,page.getBounds()):null;
    if(prepared)for(const [index,other]of runs.entries())if(!selected.has(index)&&other.text.trim())for(const rect of prepared.rects)if(rect[0]<other.rect[2]-.5&&rect[2]>other.rect[0]+.5&&rect[1]<other.rect[3]-.5&&rect[3]>other.rect[1]+.5)throw Error('The reflowed text would overlap other text. Increase the width or select a larger Text chunk.');
    const annotations=page.getAnnotations();try{if(annotations.some(a=>a.getType()==='Redact'))throw Error('Apply or remove existing PDF redaction annotations before Direct edit.')}finally{annotations.forEach(a=>a.destroy())}
    for(const part of target.parts){const mark=page.createAnnotation('Redact');try{mark.setRect(part.rect);mark.update()}finally{mark.destroy()}}
    page.applyRedactions(false,mupdf.PDFPage.REDACT_IMAGE_NONE,mupdf.PDFPage.REDACT_LINE_ART_NONE,mupdf.PDFPage.REDACT_TEXT_REMOVE);
    const remaining=capture(doc,pageIndex);try{if(remaining.map(r=>r.text).join('').replace(/\s/g,'')!==runs.filter((_,i)=>!selected.has(i)).map(r=>r.text).join('').replace(/\s/g,''))throw Error('This selection overlaps other text and cannot be safely edited on its own.')}finally{dispose(remaining)}
    if(prepared)appendOverlay(doc,page,prepared);
    const object=page.getObject();let saved=[];try{saved=JSON.parse(object.get('PdfProDirectFlows').asString())}catch{}
    saved=(Array.isArray(saved)?saved:[]).filter(r=>Array.isArray(r.rect)&&!(r.rect[0]<target.rect[2]&&r.rect[2]>target.rect[0]&&r.rect[1]<target.rect[3]&&r.rect[3]>target.rect[1]));
    if(prepared&&target.scope!=='line')saved.push({rect:prepared.rect,text:flow.text,layout:flow.layout});object.put('PdfProDirectFlows',doc.newString(JSON.stringify(saved.slice(-100))));
    return{lineCount:flow.lineCount,width:flow.width};
  }finally{page?.destroy();dispose(runs)}
}
