/* Serialize browser saves and avoid rewriting PDF binaries for view-only changes. */
export function contentSignature(snapshot){
  return [snapshot.bytes,snapshot.original,snapshot.undo,snapshot.undo?.length,snapshot.redo,snapshot.redo?.length,snapshot.selectedImage?.bytes,snapshot.selectedImage?.type];
}
const same=(a,b)=>!!a&&a.length===b.length&&a.every((value,index)=>Object.is(value,b[index]));
export function documentView(snapshot){
  return Object.fromEntries(['name','page','zoom','fit','scrollTop','scrollLeft','group','font','tool','marks','hits','searchQuery','dirty','splitPlan','continuousView'].map(key=>[key,snapshot[key]]));
}
function storedSnapshot(snapshot){
  return {...snapshot,splitPlan:snapshot.splitPlan?structuredClone(snapshot.splitPlan):null,undo:snapshot.undo.map(item=>({...item})),redo:snapshot.redo.map(item=>({...item})),marks:snapshot.marks.map(mark=>({...mark,rect:[...mark.rect]})),hits:snapshot.hits.map(hit=>({...hit,rect:[...hit.rect]}))};
}
export class WorkspaceAutosave{
  constructor({store,capture,onState=()=>{},delay=350}={}){
    this.store=store;this.capture=capture;this.onState=onState;this.delay=delay;
    this.enabled=false;this.failed=false;this.conflict=false;this.savedContent=new Map();this.savedViews=new Map();this.savedSession='';this.timer=null;this.queue=Promise.resolve(true);this.removedIds=new Set();
  }
  start({documents=[],session}={}){
    for(const record of documents){this.savedContent.set(record.id,contentSignature(record.snapshot));this.savedViews.set(record.id,JSON.stringify(documentView(record.snapshot)))}
    this.savedSession=JSON.stringify(session);this.enabled=true;this.failed=false;this.onState('saved');
  }
  isCurrent(){
    if(!this.enabled||this.failed||this.conflict)return false;
    const {documents,session}=this.currentWorkspace();
    return JSON.stringify(session)===this.savedSession&&documents.every(record=>same(this.savedContent.get(record.id),contentSignature(record.snapshot))&&this.savedViews.get(record.id)===JSON.stringify(documentView(record.snapshot)));
  }
  currentWorkspace(){
    const captured=this.capture(),documents=captured.documents.filter(record=>!this.removedIds.has(record.id)),session={...captured.session,openIds:(captured.session.openIds||[]).filter(id=>!this.removedIds.has(id))};
    if(this.removedIds.has(session.activeId))session.activeId=session.openIds[0]||null;
    return{documents,session};
  }
  schedule(){
    if(!this.enabled||this.conflict)return;
    clearTimeout(this.timer);if(!this.failed)this.onState('waiting');this.timer=setTimeout(()=>{this.timer=null;void this.flush()},this.delay);
  }
  flush(){
    clearTimeout(this.timer);this.timer=null;
    if(!this.enabled||this.conflict)return Promise.resolve(false);
    this.queue=this.queue.then(async()=>{
      if(!this.enabled||this.conflict)return false;
      const {documents,session}=this.currentWorkspace(),sessionText=JSON.stringify(session),changed=[],views=[],signatures=[];
      for(const record of documents){
        const signature=contentSignature(record.snapshot),view=documentView(record.snapshot),viewText=JSON.stringify(view);
        if(!same(this.savedContent.get(record.id),signature))changed.push({...record,updatedAt:Date.now(),snapshot:storedSnapshot(record.snapshot)});
        if(this.savedViews.get(record.id)!==viewText)views.push({id:record.id,view:structuredClone(view)});
        signatures.push({id:record.id,signature,viewText});
      }
      if(!changed.length&&!views.length&&sessionText===this.savedSession){this.failed=false;this.onState('saved');return true}
      this.onState('saving');
      try{
        await this.store.commit({documents:changed,views,session});
        for(const item of signatures){this.savedContent.set(item.id,item.signature);this.savedViews.set(item.id,item.viewText)}
        const open=new Set(documents.map(record=>record.id));
        for(const id of this.savedContent.keys())if(!open.has(id)){this.savedContent.delete(id);this.savedViews.delete(id)}
        this.savedSession=sessionText;this.failed=false;this.onState(this.isCurrent()?'saved':'waiting');return true;
      }catch(error){this.failed=true;this.conflict=error.name==='WorkspaceConflictError';this.onState('error',error);return false}
    }).catch(error=>{this.failed=true;this.onState('error',error);return false});
    return this.queue;
  }
  async remove(id,{onRemoved,activeId}={}){
    clearTimeout(this.timer);this.timer=null;
    const operation=this.queue.catch(()=>false).then(async()=>{
      if(this.conflict)throw Error('Reload this window after exporting your current work before changing the library.');
      const current=this.currentWorkspace();
      if(current.documents.some(record=>record.id===id)&&typeof onRemoved!=='function')throw Error('Close this project before removing its stored copy.');
      try{
        const session={...current.session,openIds:(current.session.openIds||[]).filter(openId=>openId!==id)};
        if(activeId!==undefined)session.activeId=activeId;
        if(session.activeId===id||!session.openIds.includes(session.activeId))session.activeId=session.openIds[0]||null;
        await this.store.commit({removeIds:[id],session});
        // Do not let a stale queued capture recreate an explicitly deleted project.
        this.removedIds.add(id);this.savedContent.delete(id);this.savedViews.delete(id);this.savedSession=JSON.stringify(session);
        onRemoved?.();this.failed=false;this.onState('waiting');return true;
      }
      catch(error){this.failed=true;this.conflict=error.name==='WorkspaceConflictError';this.onState('error',error);throw error}
    });
    this.queue=operation.catch(()=>false);await operation;await this.flush();return true;
  }
  async close(){clearTimeout(this.timer);this.enabled=false;await this.queue.catch(()=>{});this.store.close()}
}
