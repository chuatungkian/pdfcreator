// PDFCreator local Microsoft Word companion. AGPL-3.0-or-later.
// Build with the Windows .NET Framework C# compiler; no NuGet dependencies.
using System;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Reflection;

public static class PDFCreatorWordCompanion {
    const int MaxBytes = 64 * 1024 * 1024;
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    static string Token;
    static int Port;
    static string Json(string value) { return "\"" + value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ") + "\""; }
    static bool EqualSecret(string a, string b) { if (a == null || b == null || a.Length != b.Length) return false; int difference = 0; for (int i=0;i<a.Length;i++) difference |= a[i]^b[i]; return difference==0; }
    static void Reply(NetworkStream stream, int status, string origin, string contentType, byte[] body) {
        string header = "HTTP/1.1 " + status + " " + (status==200?"OK":status==204?"No Content":"Request failed") + "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nContent-Type: " + contentType + "\r\nContent-Length: " + body.Length + "\r\n";
        if (origin != null) header += "Access-Control-Allow-Origin: " + origin + "\r\nVary: Origin\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: X-PDFCreator-Token, X-PDFCreator-Filename, Content-Type\r\nAccess-Control-Allow-Private-Network: true\r\n";
        byte[] bytes=Encoding.ASCII.GetBytes(header+"\r\n"); stream.Write(bytes,0,bytes.Length); if(body.Length>0)stream.Write(body,0,body.Length);
    }
    static void Error(NetworkStream stream, int code, string origin, string message) { Reply(stream,code,origin,"application/json; charset=utf-8",Encoding.UTF8.GetBytes("{\"error\":"+Json(message)+"}")); }
    static void Handle(TcpClient client) {
        client.ReceiveTimeout=15000; client.SendTimeout=15000;
        using(client) using(NetworkStream stream=client.GetStream()) {
            string origin=null;
            try {
                var raw=new MemoryStream(); int state=0;
                while(state!=4) { int value=stream.ReadByte(); if(value<0)throw new IOException("Incomplete request.");raw.WriteByte((byte)value);if(raw.Length>32768)throw new IOException("Request headers are too large."); if((state==0||state==2)&&value==13)state++;else if((state==1||state==3)&&value==10)state++;else state=value==13?1:0; }
                string[] lines=Encoding.ASCII.GetString(raw.ToArray()).Split(new[]{"\r\n"},StringSplitOptions.None);string[] request=lines[0].Split(' ');
                var headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                foreach(string line in lines) { int colon=line.IndexOf(':');if(colon>0)headers[line.Substring(0,colon).Trim()]=line.Substring(colon+1).Trim(); }
                string valueHeader;
                if(headers.TryGetValue("Origin",out valueHeader) && valueHeader.Length<512 && (valueHeader=="null"||valueHeader.StartsWith("https://")||valueHeader.StartsWith("http://")))origin=valueHeader;
                if(request.Length!=3 || !headers.TryGetValue("Host",out valueHeader) || valueHeader!="127.0.0.1:"+Port) { Error(stream,400,null,"Use the companion's exact loopback address.");return; }
                string method=request[0],path=request[1];
                if(path!="/status"&&path!="/convert") { Error(stream,404,origin,"Unknown endpoint.");return; }
                if(method=="OPTIONS") { Reply(stream,204,origin,"text/plain",new byte[0]);return; }
                if(!headers.TryGetValue("X-PDFCreator-Token",out valueHeader)||!EqualSecret(valueHeader,Token)) { Error(stream,403,origin,"Pairing code is incorrect. Copy the current code from the companion window.");return; }
                if(method=="GET"&&path=="/status") { Reply(stream,200,origin,"application/json",Encoding.UTF8.GetBytes("{\"app\":\"PDFCreator Word companion\",\"protocol\":1,\"engine\":\"Microsoft Word\",\"available\":"+(Type.GetTypeFromProgID("Word.Application")!=null?"true":"false")+"}"));return; }
                if(method!="POST"||path!="/convert") { Error(stream,405,origin,"Unsupported request method.");return; }
                int length;
                if(headers.ContainsKey("Transfer-Encoding")||!headers.TryGetValue("Content-Length",out valueHeader)||!Int32.TryParse(valueHeader,out length)||length<8||length>MaxBytes) { Error(stream,413,origin,"Choose a Word file of up to 64 MB.");return; }
                string filename=headers.TryGetValue("X-PDFCreator-Filename",out valueHeader)?Uri.UnescapeDataString(valueHeader):"document.docx",extension=Path.GetExtension(filename).ToLowerInvariant();
                if(extension!=".docx"&&extension!=".doc") { Error(stream,415,origin,"Choose a .docx or .doc document.");return; }
                byte[] input=new byte[length];int offset=0;while(offset<length) { int got=stream.Read(input,offset,length-offset);if(got==0)throw new IOException("The upload was interrupted.");offset+=got; }
                bool zip=input[0]==80&&input[1]==75,ole=input[0]==208&&input[1]==207&&input[2]==17&&input[3]==224;
                if((extension==".docx"&&!zip)||(extension==".doc"&&!ole)) { Error(stream,415,origin,"The file does not have the expected Word format.");return; }
                string folder=Path.Combine(Path.GetTempPath(),"PDFCreator-Word-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
                try {
                    string source=Path.Combine(folder,"input"+extension),output=Path.Combine(folder,"output.pdf"),pidfile=Path.Combine(folder,"word.pid");File.WriteAllBytes(source,input);input=null;
                    var start=new ProcessStartInfo(Assembly.GetExecutingAssembly().Location,"--convert \""+source+"\" \""+output+"\" \""+pidfile+"\"");start.UseShellExecute=false;start.CreateNoWindow=true;start.RedirectStandardError=true;start.RedirectStandardOutput=true;
                    using(var worker=Process.Start(start)) {
                        if(!worker.WaitForExit(180000)) { try{worker.Kill();}catch{} StopOwnedWord(pidfile,worker.StartTime);Error(stream,504,origin,"Word conversion timed out. Close any Word prompts and try a local, unprotected copy.");return; }
                        string error=worker.StandardError.ReadToEnd();
                        if(worker.ExitCode!=0||!File.Exists(output)) { Error(stream,422,origin,String.IsNullOrWhiteSpace(error)?"Microsoft Word could not convert this document.":error.Trim());return; }
                    }
                    byte[] pdf=File.ReadAllBytes(output);if(pdf.Length<5||Encoding.ASCII.GetString(pdf,0,5)!="%PDF-")throw new IOException("Word did not return a PDF.");
                    Console.WriteLine("Converted a document locally ("+pdf.Length+" PDF bytes).");Reply(stream,200,origin,"application/pdf",pdf);
                } finally { try{Directory.Delete(folder,true);}catch{Console.WriteLine("A temporary conversion folder is still in use: "+folder);} }
            } catch(Exception e) { try{Error(stream,400,origin,"Unable to process the local conversion request: "+e.Message);}catch{} }
        }
    }
    static void StopOwnedWord(string file,DateTime started) {
        try{int pid=Int32.Parse(File.ReadAllText(file));using(var process=Process.GetProcessById(pid)){if(process.ProcessName.Equals("WINWORD",StringComparison.OrdinalIgnoreCase)&&process.StartTime>=started.AddSeconds(-2))process.Kill();}}catch{}
    }
    static int ConvertWord(string input,string output,string pidfile) {
        dynamic word=null,documents=null,document=null,options=null,scratch=null,window=null; bool own=false,securityRead=false; int security=3; bool links=false,fields=false,printLinks=false;
        try {
            var existing=new HashSet<int>();foreach(var p in Process.GetProcessesByName("WINWORD")){existing.Add(p.Id);p.Dispose();}
            Type type=Type.GetTypeFromProgID("Word.Application");if(type==null)throw new Exception("Microsoft Word desktop is not installed. Install Word, or export a PDF in Word and use Create > Open PDF.");
            word=Activator.CreateInstance(type);documents=word.Documents;if((int)documents.Count!=0)throw new Exception("A separate Word instance could not be started. Existing Word documents are left unchanged.");
            int pid=0,fresh=0;foreach(var p in Process.GetProcessesByName("WINWORD")){if(!existing.Contains(p.Id)){pid=p.Id;fresh++;}p.Dispose();}
            if(fresh!=1)throw new Exception("A separate Word process could not be identified. Existing Word windows have been left unchanged.");
            security=(int)word.AutomationSecurity;securityRead=true;word.AutomationSecurity=3;
            word.Visible=false;scratch=documents.Add(Visible:true);window=scratch.Windows[1];uint actualPid;GetWindowThreadProcessId(new IntPtr((int)window.Hwnd),out actualPid);
            if(actualPid!=pid||existing.Contains((int)actualPid))throw new Exception("Word process ownership could not be verified. Existing Word processes are left unchanged.");
            own=true;File.WriteAllText(pidfile,pid.ToString());
            word.Visible=false;word.DisplayAlerts=0;
            options=word.Options;links=(bool)options.UpdateLinksAtOpen;fields=(bool)options.UpdateFieldsAtPrint;printLinks=(bool)options.UpdateLinksAtPrint;options.UpdateLinksAtOpen=false;options.UpdateFieldsAtPrint=false;options.UpdateLinksAtPrint=false;
            string inaccessible=Guid.NewGuid().ToString("N");
            document=documents.Open(FileName:input,ConfirmConversions:false,ReadOnly:true,AddToRecentFiles:false,PasswordDocument:inaccessible,PasswordTemplate:inaccessible,WritePasswordDocument:inaccessible,WritePasswordTemplate:inaccessible,Visible:false,OpenAndRepair:false,NoEncodingDialog:true);
            document.ExportAsFixedFormat(output,17,false,0,0,1,1,0,true,true,1,true,true,false);
            return 0;
        } catch(Exception e) { Console.Error.WriteLine("Microsoft Word conversion failed: "+e.Message+" Password-protected or restricted documents must be exported from Word manually.");return 2; }
        finally {
            if((object)document!=null)try{document.Close(0);}catch{}
            if((object)word!=null){try{if((object)options!=null){options.UpdateLinksAtOpen=links;options.UpdateFieldsAtPrint=fields;options.UpdateLinksAtPrint=printLinks;}if(securityRead)word.AutomationSecurity=security;}catch{}if((object)scratch!=null)try{scratch.Close(0);}catch{}if(own)try{word.Quit(0);}catch{}}
            foreach(object obj in new object[]{(object)window,(object)scratch,(object)document,(object)documents,(object)options,(object)word})if(obj!=null&&Marshal.IsComObject(obj))try{Marshal.FinalReleaseComObject(obj);}catch{}
        }
    }
    [STAThread] public static int Main(string[] args) {
        if(args.Length==4&&args[0]=="--convert")return ConvertWord(args[1],args[2],args[3]);
        Port=17843;if(args.Length==2&&args[0]=="--port"&&(!Int32.TryParse(args[1],out Port)||Port<1024||Port>65535)){Console.Error.WriteLine("Use a port from 1024 to 65535.");return 2;}
        byte[] random=new byte[32];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(random);Token=BitConverter.ToString(random).Replace("-","").ToLowerInvariant();
        var listener=new TcpListener(IPAddress.Loopback,Port);
        try{listener.Start(4);}catch(Exception e){Console.Error.WriteLine("Cannot start on 127.0.0.1:"+Port+". "+e.Message);return 2;}
        Console.WriteLine("PDFCreator Word companion — local conversion only");Console.WriteLine("Address: http://127.0.0.1:"+Port);Console.WriteLine("Pairing code: "+Token);Console.WriteLine("In PDFCreator choose Create > Import from Word, then paste this code.");Console.WriteLine("Requires Microsoft Word desktop. Close this window to stop accepting imports.");
        Console.CancelKeyPress+=(sender,e)=>{e.Cancel=true;listener.Stop();};
        try{while(true)Handle(listener.AcceptTcpClient());}catch(SocketException){}finally{listener.Stop();}return 0;
    }
}
