/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;const check=(v,label)=>{assertions++;assert.ok(v,label)},equal=(a,b,label)=>{assertions++;assert.deepEqual(a,b,label)},pause=()=>new Promise(r=>setTimeout(r,0));async function until(fn,label){const end=Date.now()+7000;while(!fn()){if(Date.now()>end)throw Error('Timeout '+label);await pause()}}
let context;try{context=await boot();const {app,$,window}=context,f=window.forge,api=window.PdfProSigning,keys=f.pki.rsa.generateKeyPair({bits:2048,e:65537}),cert=f.pki.createCertificate();cert.publicKey=keys.publicKey;cert.serialNumber='0102';cert.validity.notBefore=new Date(Date.now()-86400000);cert.validity.notAfter=new Date(Date.now()+86400000*365);cert.setSubject([{name:'commonName',value:'Synthetic removal test'}]);cert.setIssuer(cert.subject.attributes);cert.sign(keys.privateKey,f.md.sha256.create());const credential={key:keys.privateKey,certificate:cert,chain:[cert]};const d=await app.PDFLib.PDFDocument.create();d.addPage([500,600]).drawText('Keep the body',{x:40,y:520,size:14});d.addPage([500,600]);const source=await api.signPdf(new Uint8Array(await d.save({useObjectStreams:false})),credential);await app.openFiles([{name:'Signed test.pdf',type:'application/pdf',arrayBuffer:async()=>source.slice().buffer}]);await $('next').onclick();equal(app.state.page,1,'start on second page');await document.querySelector('[data-group="Protect & sign"]').onclick();check(!!document.querySelector('[data-tool=removesignatures]'),'Protect & sign exposes removal action');let task=app.activate('removesignatures');await until(()=>$('modalform'),'signature warning');check($('modalform').textContent.includes('unsigned')&&$('modalform').textContent.includes('original file stays unchanged'),'concrete removal warning');equal($('modaltitle').textContent,'Remove digital signatures?','explicit confirmation');$('modalcancel').click();await task;equal(app.state.bytes,source,'Cancel keeps signed bytes');equal(app.state.undo.length,0,'Cancel creates no history');task=app.activate('removesignatures');await until(()=>$('modalform'),'second signature warning');await $('modalform').onsubmit(new window.Event('submit',{cancelable:true}));await task;const unsigned=app.state.bytes;check(unsigned!==source,'confirmation edits working copy');equal((await api.inspectSignatures(unsigned)).length,0,'working copy is unsigned');equal(app.state.undo.length,1,'removal is one undo step');equal(app.state.page,1,'removal keeps current page');check(app.Engine.extractTextPDF(unsigned)[0].text.includes('Keep the body'),'body retained');await $('undo').onclick();equal(app.state.bytes,source,'undo restores exact signed bytes');check((await api.verifyPdf(app.state.bytes)).currentFileCovered,'restored signature remains valid');await $('redo').onclick();equal(app.state.bytes,unsigned,'redo restores unsigned version');task=app.activate('removesignatures');await until(()=>$('modalform'),'unsigned message');check($('modalform').textContent.includes('No certificate signatures'),'unsigned PDF gets clear feedback');$('modalcancel').click();await task;equal(app.state.bytes,unsigned,'unsigned action is read-only');await app.local.flush();await context.close();context=await boot();equal(context.app.state.bytes,unsigned,'unsigned copy recovers locally');equal((await context.window.PdfProSigning.inspectSignatures(context.app.state.bytes)).length,0,'recovered PDF remains unsigned');await context.close();context=null;console.log('PDFCreator signature removal interactions: '+assertions+' assertions passed with real RSA signatures and controlled UI.');}finally{if(context)await context.close()}
