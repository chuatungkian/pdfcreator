/* Native PDF comments, threads and text selections. AGPL-3.0-or-later. */
import {mupdf} from './engine.js';
const skip=new Set(['Popup','Link','Widget']);
export function readComments(doc){
  const rows=[];
  for(let pageIndex=0;pageIndex<doc.countPages();pageIndex++){
    const page=doc.loadPage(pageIndex),annotations=[...page.getAnnotations()];
    try{annotations.forEach((a,index)=>{
      if(skip.has(a.getType()))return;const o=a.getObject();
      try{const parent=o.get('IRT'),resolved=o.get('PDFCreatorResolved'),state=o.get('State');
        rows.push({page:pageIndex,index,id:o.isIndirect()?o.asIndirect():`${pageIndex}:${index}`,parent:parent.isIndirect()?parent.asIndirect():null,type:a.getType(),name:a.getName()||'',text:a.getContents()||'',author:a.getAuthor()||'',rect:a.getBounds(),resolved:resolved.isBoolean()?resolved.asBoolean():state.asString()==='Completed'});
      }finally{o.destroy()}
    })}finally{annotations.forEach(a=>a.destroy());page.destroy()}
  }
  return rows;
}
export function changeComment(doc,row,{text,author,resolved,reply,remove=false}={}){
  const page=doc.loadPage(row.page),annotations=[...page.getAnnotations()],a=annotations[row.index];
  try{
    if(!a||a.getType()!==row.type||a.getContents()!==row.text)throw Error('This comment changed. Open it again.');
    if(remove){
      const ids=new Set([row.id]);let changed=true;
      while(changed){changed=false;for(const item of annotations){const o=item.getObject(),parent=o.get('IRT');try{if(parent.isIndirect()&&ids.has(parent.asIndirect())&&!ids.has(o.asIndirect())){ids.add(o.asIndirect());changed=true}}finally{parent.destroy();o.destroy()}}}
      for(const item of annotations){const o=item.getObject();try{if(ids.has(o.asIndirect()))page.deleteAnnotation(item)}finally{o.destroy()}}return;
    }
    const o=a.getObject();try{
      if(text!==undefined){if(String(text).length>10000)throw Error('Use up to 10,000 characters.');a.setContents(String(text));}
      if(author!==undefined&&reply===undefined)a.setAuthor(String(author).slice(0,200));
      if(resolved!==undefined){o.put('PDFCreatorResolved',!!resolved);o.put('StateModel',doc.newString('Review'));o.put('State',doc.newString(resolved?'Completed':'None'));}
      if(reply!==undefined){if(!String(reply).trim()||String(reply).length>10000)throw Error('Enter a reply of up to 10,000 characters.');const r=page.createAnnotation('Text');try{r.setRect(row.rect);r.setContents(String(reply));r.setAuthor(author||'PDFCreator');r.setIcon('Comment');r.setFlags(r.getFlags()|mupdf.PDFAnnotation.IS_PRINT);const ro=r.getObject();try{ro.put('IRT',o);ro.put('RT',doc.newName('R'))}finally{ro.destroy()}r.update()}finally{r.destroy()}}
      a.setModificationDate(new Date());a.update();
    }finally{o.destroy()}
  }finally{annotations.forEach(a=>a.destroy());page.destroy()}
}
export function textSelection(doc,index,start,end){
  const page=doc.loadPage(index),st=page.toStructuredText('');
  try{const quads=st.highlight(start,end,10000).filter(q=>q.length===8&&q.every(Number.isFinite));return{quads,text:quads.length?st.copy(start,end):''}}finally{st.destroy();page.destroy()}
}
const segmentDistance=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1)));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)};
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
function segmentsTouch(a,b,c,d,radius){
  const ab1=cross(a,b,c),ab2=cross(a,b,d),cd1=cross(c,d,a),cd2=cross(c,d,b);
  if(ab1*ab2<0&&cd1*cd2<0)return true;
  return Math.min(segmentDistance(a,c,d),segmentDistance(b,c,d),segmentDistance(c,a,b),segmentDistance(d,a,b))<=radius;
}
export function eraseInk(doc,index,points,radius=8){
  const p=doc.loadPage(index),all=[...p.getAnnotations()];let count=0;
  try{for(const a of all){if(a.getType()!=='Ink')continue;const strokes=a.getInkList(),kept=strokes.filter(stroke=>!stroke.some((v,i)=>points.some((point,j)=>segmentsTouch(stroke[Math.max(0,i-1)],v,points[Math.max(0,j-1)],point,radius+a.getBorderWidth()/2))));count+=strokes.length-kept.length;if(kept.length===strokes.length)continue;if(kept.length){a.setInkList(kept);a.update()}else p.deleteAnnotation(a)}return count}finally{all.forEach(a=>a.destroy());p.destroy()}
}
