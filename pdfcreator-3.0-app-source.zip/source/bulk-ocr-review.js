/* Page-grouped OCR follow-up in the existing inspector; no second modal or PDF writes. */
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function groupOCRIssues(items=[]){
 const pages=new Map();for(const [sourceIndex,item]of items.entries()){
  const page=Number(item?.page);if(!Number.isInteger(page)||page<1)continue;
  const issue={...item,page,text:String(item.text??''),confidence:Number.isFinite(+item.confidence)?Math.max(0,Math.min(100,+item.confidence)):null,sourceIndex};
  if(!pages.has(page))pages.set(page,[]);pages.get(page).push(issue);
 }
 return [...pages].sort((a,b)=>a[0]-b[0]).map(([page,issues])=>({page,issues}));
}
export function showBulkOCRReview({items=[],totalWords=0,inspector,go,editPage,isCurrent=()=>true,document:doc=globalThis.document,initialIndex=0}={}){
 const groups=groupOCRIssues(items),issues=groups.flatMap(group=>group.issues);if(!issues.length)return null;
 if(!inspector?.mount||typeof go!=='function')throw Error('OCR review needs the document inspector and page navigation.');
 const root=doc.createElement('section');root.className='experience-panel bulk-ocr-review';root.setAttribute('aria-label','Review uncertain OCR words');
 root.innerHTML='<p class="help">'+Number(totalWords||0).toLocaleString('en-GB')+' searchable words added · '+issues.length+' uncertain words on '+groups.length+' page(s). Check each word against the page.</p><label>Review page<select data-ocr-review-page aria-label="Review OCR issues on page">'+groups.map(group=>'<option value="'+group.page+'">Page '+group.page+' · '+group.issues.length+' issue(s)</option>').join('')+'</select></label><div class="experience-actions"><button type="button" data-ocr-review-prev>Previous issue</button><button type="button" data-ocr-review-next>Next issue</button></div><p data-ocr-review-current role="status" aria-live="polite"></p><div class="experience-actions"><button type="button" data-ocr-review-go>Go to page</button><button type="button" data-ocr-review-edit>Correct with Direct edit</button></div><p class="help">Direct edit recognises visible text for correction. Review its recognition and layout before applying.</p><p class="help" data-ocr-review-range></p><div data-ocr-review-list></div><p class="danger" role="alert" data-ocr-review-error></p>';
 const $=selector=>root.querySelector(selector);let current=Math.max(0,Math.min(issues.length-1,Math.floor(+initialIndex)||0)),closed=false,busy=false;
 const checkCurrent=()=>{if(!isCurrent())throw Error('This OCR review belongs to an earlier document. Return to that document or run OCR again.')};
 const confidence=item=>item.confidence===null?'Confidence unavailable':Math.round(item.confidence)+'% confidence';
 function render(){
  const item=issues[current],group=groups.find(group=>group.page===item.page),at=group.issues.indexOf(item),start=Math.floor(at/25)*25,visible=group.issues.slice(start,start+25);
  $('[data-ocr-review-page]').value=String(item.page);$('[data-ocr-review-current]').textContent='Issue '+(current+1)+' of '+issues.length+' · Page '+item.page+' · “'+item.text+'” · '+confidence(item);
  $('[data-ocr-review-range]').textContent='Page '+item.page+' issues '+(start+1)+'–'+(start+visible.length)+' of '+group.issues.length;
  $('[data-ocr-review-list]').innerHTML=visible.map(issue=>'<div class="experience-row bulk-ocr-issue-row" '+(issue===item?'aria-current="true"':'')+'><div><strong>'+esc(issue.text)+'</strong><small>'+esc(confidence(issue))+'</small></div><button type="button" data-ocr-review-issue="'+issues.indexOf(issue)+'" aria-label="Review '+esc(issue.text)+' on page '+issue.page+'">Review</button></div>').join('');
  for(const button of root.querySelectorAll('[data-ocr-review-issue]'))button.onclick=action(()=>select(+button.dataset.ocrReviewIssue,true));
  $('[data-ocr-review-prev]').disabled=busy||current===0;$('[data-ocr-review-next]').disabled=busy||current===issues.length-1;$('[data-ocr-review-page]').disabled=busy;$('[data-ocr-review-go]').disabled=busy;$('[data-ocr-review-edit]').disabled=busy||typeof editPage!=='function';
 }
 function action(task){return async()=>{if(closed||busy)return;busy=true;$('[data-ocr-review-error]').textContent='';render();try{checkCurrent();await task()}catch(problem){if(closed&&isCurrent())open();$('[data-ocr-review-error]').textContent=problem.message}finally{busy=false;render()}}}
 async function select(index,navigate=false){current=Math.max(0,Math.min(issues.length-1,index));render();if(navigate)await go(issues[current].page-1,issues[current])}
 function destroy(){closed=true;root.remove()}
 function close(){if(inspector.current?.node===root)inspector.close();else destroy()}
 function open(){checkCurrent();closed=false;inspector.mount(root,{title:'OCR review',preferredWidth:260,close:destroy});render();return controller}
 $('[data-ocr-review-page]').onchange=()=>{const page=+$('[data-ocr-review-page]').value;return action(()=>select(issues.findIndex(item=>item.page===page),true))()};
 $('[data-ocr-review-prev]').onclick=action(()=>select(current-1,true));$('[data-ocr-review-next]').onclick=action(()=>select(current+1,true));
 $('[data-ocr-review-go]').onclick=action(()=>go(issues[current].page-1,issues[current]));
 $('[data-ocr-review-edit]').onclick=action(async()=>{const item=issues[current];close();await editPage(item.page-1,item,{resume:open})});
 const controller={root,open,close,destroy,get current(){return issues[current]},get index(){return current},get count(){return issues.length}};open();return controller;
}
