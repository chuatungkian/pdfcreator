# pdfpro engine integration

`engine.js` imports the official `mupdf@1.28.1` ESM package. All exported operations are synchronous after MuPDF's top-level WebAssembly initialization has completed. Input/output PDF bytes use `Uint8Array`.

## Single HTML initialization

Set `globalThis['$libmupdf_wasm_Module'] = { wasmBinary: embeddedWasmBytes }` **before evaluating/importing the bundled engine**. The package reads that global during its top-level initialization. The parent build must bundle the JS and inline the WASM, with no external runtime fetch. `mupdf/dist/mupdf.js` conditionally imports `node:fs`; esbuild's browser bundle should mark `node:fs` and `module` external or eliminate those unreachable Node branches. The WASM loader's `import.meta.url` fallback is unused when `wasmBinary` is supplied.

## API

- `openPDF(bytes, password='')`: returns a MuPDF PDFDocument. Caller must `.destroy()` it. PDF JavaScript is always disabled. Wrong or missing passwords throw an Error with `.code='PASSWORD_REQUIRED'`.
- `inspectPDF(bytes, password='')`: `{pageCount,pages,metadata,encryption,permissions,forms,signatures,annotations,attachments,outline,tagged,hasXFA,version,repaired,versions}`. Signature count is detection only, not certificate verification.
- `readPagePDF(bytes,pageIndex=0,{password})`: `{page,bounds,width,height,text,lines,blocks,annotations}`. Lines have `{text,rect,font,x,y,wmode,...}` and may reflect source text grouping.
- `extractTextPDF(bytes,{password,pages})`: `[{page,text}]`. Scanned images have no text until OCR creates a layer.
- `searchPDF(bytes,needle,{password,maxHits=1000})`: `[{page,quads,rects}]`.
- `renderPagePNG(bytes,pageIndex,{password,scale=1,showExtras=true,format='png',quality=85})`: `{bytes,width,height,bounds,scale,mime}`. Set `format='jpeg'` for JPEG.
- `renderPagePixels(bytes,pageIndex,{password,scale=1,showExtras=true})`: `{pixels,width,height,components,stride,bounds,scale}`. RGB bytes, no alpha. The returned pixels are copied out of WASM memory.
- `decryptPDF(bytes,password='')`: full rewritten unencrypted PDF.
- `protectPDF(bytes,{password,ownerPassword,permissions=-4},inputPassword='')`: AES-256 encryption; if owner password is absent, the open password is used. Password strings with comma/NUL/newlines are rejected because of the native options grammar; 127 UTF-8 byte maximum. Permission flags are standard PDF integer masks; `-4` grants all permissions.
- `optimizePDF(bytes,{password,subsetFonts=true,sanitize=false})`: lossless content preservation, unused-object collection, deduplication, stream/font/image compression and optional font subsetting. Output can grow; size reduction is not guaranteed. `sanitize:true` removes interactive/hidden structures as described below.
- `redactPDF(bytes,regions,{password,sanitize=true,blackBoxes=true,rasterize=true,dpi=150})`: regions are `[{page,rect}]`. Native destructive content redaction runs first. Default raster reconstruction then creates an entirely new image-only PDF from every displayed page, applies masks again directly to final pixels, and discards all original PDF objects. Searchable text, tags, annotations, forms, attachments, bookmarks, document history and existing certificate signatures are lost. `rasterize:false` uses native content removal and sanitation with a nonincremental full rewrite; this mode needs document-specific review and should not be described as exhaustive hidden-data removal.
- `replaceTextPDF(bytes,replacements,{password})`: replacements are `[{page,rect,text,size=12,padding=1,color=[0,0,0]}]`. Removes actual text in each region, preserves graphics/images, writes Helvetica content, and rejects overflow. Basic printable Latin characters only. May remove partial words or adjacent letters intersecting a region. Does not reflow neighboring paragraphs.
- `updateMetadataPDF(bytes,metadata,{password})`: Info keys Title, Author, Subject, Keywords, Creator, Producer, CreationDate, ModDate. Removes stale document XMP.
- `flattenPDF(bytes,{password,annotations=true,forms=true})`: bakes the chosen interactive objects into static page appearance.
- `sanitizePDF(bytes,{password,rasterize=false,dpi=150})`: strips known non-page-content structures; optional complete raster reconstruction.
- `mupdf`: exported underlying namespace for advanced operations.

All rectangles and coordinates use unscaled **MuPDF page space**, top-left origin and y descending at 72 units/inch. Page indexes are zero-based. `readPagePDF`/rendering expose bounds so caller can account for nonzero origins. Raw PDF/user coordinates differ; use `mupdf.Matrix.invert(page.getTransform())` to map MuPDF coordinates into PDF user space in this version.

Rendering refuses more than 50 million pixels per page or scale above 8. Long operations should be run in a Web Worker for hard cancellation and UI responsiveness; the pure functions can be used in a worker bundle.

## Redaction semantics

Default image-only export provides a narrow, inspectable confidentiality guarantee: the new document contains only rendered page images with selected pixel rectangles overwritten, rather than original content objects. It does not remove similar information elsewhere on the page/document. Users must review selection and appearance. Existing signature cryptography is not preserved. Native redaction removes overlapping text, redacts image pixels, and removes line art touched by regions. Native sanitation deletes Info/XMP, names/embedded files, associated files, actions/JS, AcroForms, annotations, outlines, structure tags/alternate text, PieceInfo and several auxiliary catalog stores. It is not an exhaustive validator of every possible PDF extension.

## Licensing

MuPDF JavaScript and WASM are AGPL-3.0-or-later, with an alternative commercial license from Artifex. The delivered project is intended to be distributed as AGPL open source. Include the license, notices and complete corresponding source/build scripts alongside or within the distributable. This is a packaging requirement, not a runtime upload/service dependency.

Official references:

- https://www.npmjs.com/package/mupdf
- https://github.com/ArtifexSoftware/mupdf.js
- https://mupdf.readthedocs.io/en/latest/reference/javascript/types/PDFPage.html
- https://mupdf.readthedocs.io/en/latest/reference/common/pdf-write-options.html
- https://mupdf.readthedocs.io/en/latest/reference/javascript/types/PDFDocument.html

## Verified locally (Node + official WASM)

1. Created a synthetic vector/text PDF; inspected metadata/page count; extracted structured lines; rendered PNG and RGB.
2. AES-256 export reopened with the open password and reported `Standard V5 R6 256-bit AES`; wrong/missing-password handling exercised.
3. Native redaction removed `SECRET` while leaving `public text`; output reopened after full rewrite.
4. Default raster redaction produced zero extracted text, no annotations, correct page dimensions.
5. Added a visible FreeText annotation containing `SECRET ANNOTATION` over the redacted rectangle; verified every final mask pixel was black and no annotation/text layer survived.
6. Bounded text replacement returned searchable `REPLACED` text. Placement tested on pages with nonzero media-box origins and rotations 0/90/180/270; output text rectangle stayed at the requested page coordinates.
7. Compression/font-subset and metadata inspection completed on the synthetic fixture.
8. Independently loaded a two-page raster-redacted output through pdf-lib, decoded every output stream, confirmed two page-image objects, no `SECRET` string from source text/metadata/attachment, no title and no embedded attachments. Both open and owner passwords authenticated AES output; missing/wrong passwords failed.

Parent release tests should add independent PDF-reader reopening, screenshot inspection, file:// browser startup with networking disabled, encrypted/forms/attachments/rotated and scanned real-world fixtures, and a redaction test that decompresses/inspects all new objects. These local tests do not establish Acrobat equivalence or standards conformance.
