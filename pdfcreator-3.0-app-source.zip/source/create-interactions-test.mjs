/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';

import {createBlankPDF,newDocumentOptions} from './create-document.js';
import {companionAddress,companionStatus,convertWord,wordFileName} from './word-import.js';
let context,originalFetch=globalThis.fetch;
try{
 const landscape=await createBlankPDF({name:'My new document',paper:'A5',orientation:'landscape',pages:3,margin:12,guide:'ruled'});equal(landscape.name,'My new document.pdf','new document gets its chosen name');equal(landscape.pages,3,'configured page count');check(landscape.width>landscape.height,'landscape swaps paper dimensions');
 const native=await createBlankPDF({paper:'custom',width:220,height:180,margin:0,guide:'squared'});check(Math.abs(native.width-220*72/25.4)<.001,'custom dimensions are in millimetres');for(const options of [{pages:0},{pages:201},{paper:'custom',width:20,height:100},{margin:200}]){let failed=false;try{newDocumentOptions(options)}catch{failed=true}check(failed,'invalid creation settings are rejected')}
 context=await boot();const {app,$,window,fileSelections}=context;await app.createDocument();check(app.state.group==='Create'&&app.state.paneOpen&&!$('modalform'),'Create opens a pane on Home without a central dialogue');equal(document.querySelectorAll('#panel [data-tool]').length,3,'Home Create pane shows all three actions');check(window.getComputedStyle($('toolpane')).display!=='none','Home does not hide Create pane');await app.newDocument();const original=app.state.bytes,owner=app.activeTabId;
 check(!$('openBtn'),'old top Open files button is removed');check($('createBtn').closest('#nav')&&!document.querySelector('.app-header #createBtn'),'Create sits in the left toolbar');
 let pending=$('createBtn').onclick();await pending;check(app.state.group==='Create'&&app.state.paneOpen&&!$('modalform'),'Create opens the shared function pane');check($('createBtn').classList.contains('active')&&$('createBtn').getAttribute('aria-expanded')==='true','Create navigation reflects expanded state');equal([...document.querySelectorAll('#panel [data-tool]')].map(b=>b.dataset.tool),['createNew','createWord','createPDF'],'Create pane has all three functions');equal(window.getComputedStyle($('toolpane')).position,'absolute','Create uses the same positioned tool popup');check(document.querySelector('[data-tool=createPDF]').title.includes('Classify documents before loading'),'Open PDF retains requested description');equal(app.state.bytes,original,'opening Create leaves the document unchanged');await $('closeTools').onclick();equal(document.activeElement,$('createBtn'),'Close returns focus to Create trigger');await app.createDocument();
 document.body.dispatchEvent(new window.MouseEvent('pointerdown',{bubbles:true}));check(!app.state.paneOpen,'outside click dismisses Create pane');await app.createDocument();await $('toggleNav').onclick();check(app.state.navCollapsed,'collapsed Create navigation');check($('createBtn').title&&$('createBtn').getAttribute('aria-label'),'collapsed Create button has accessible label');
 pending=app.activate('createNew');await until(()=>$('createName'),'new PDF options');check(!document.querySelector('.create-choices'),'New PDF settings have no repeated central choice tiles');$('modalcancel').click();await pending;equal(app.state.bytes,original,'cancelling New PDF leaves document unchanged');
 pending=app.activate('createNew');await until(()=>$('createName'),'creation settings');$('createName').value='Project notes';$('createPaper').value='A5';$('createOrientation').value='landscape';$('createPages').value='3';$('createMargin').value='12';$('createGuide').value='ruled';await $('modalform').onsubmit({preventDefault(){}});await pending;equal(app.state.name,'Project notes.pdf','Create opens the named PDF');equal(app.state.doc.countPages(),3,'Create generates every configured page');check(app.state.group==='Edit'&&app.state.tool==='text','new PDFs start ready for text placement');check(app.tabs.some(t=>t.id===owner),'creation keeps the earlier document open');const info=app.Engine.inspectPDF(app.state.bytes);check(info.pages.every(p=>p.width>p.height),'configured landscape layout is saved');
 const editBefore=app.state.bytes;await app.editPDF('Write from scratch',doc=>doc.getPage(0).drawText('CREATED FROM SCRATCH',{x:40,y:250,size:14}));check(text(app).includes('CREATED FROM SCRATCH'),'new document can be authored with normal editing tools');check(app.state.bytes!==editBefore,'new edits are saved in the new PDF');
 const pdf=await fixture(app,'Existing file');await app.createDocument();check(!$('createName')&&!$('modalform'),'Open PDF uses the tool pane without central choice UI');fileSelections.push([file('Existing file.pdf',pdf)]);await app.activate('createPDF');equal(app.state.name,'Existing file.pdf','Create opens an existing PDF');equal(app.state.doc.countPages(),2,'existing PDF content and pages are retained');
 await app.createDocument();await $('dockTools').onclick();check(app.state.paneDocked,'dock Create pane');equal(document.querySelectorAll('#panel .tool-icon svg').length,3,'docked Create has all three icons');check(!$('toolSettings').isConnected||$('toolSettings').hidden,'Create does not show unrelated tool settings');await $('dockTools').onclick();check(!app.state.paneDocked,'undock Create pane');await document.querySelector('[data-group=View]').onclick();check(app.state.group==='View','switch from Create');check(!$('toolSettings').hidden,'other functions retain their settings controls');

 // Network protocol and failures use controlled responses; the separate native suite runs Word itself.
 const token='a'.repeat(64),config={port:17843,token};equal(companionAddress(17843),'http://127.0.0.1:17843','companion address is fixed to loopback');let rejected=false;try{companionAddress('https://example.com')}catch{rejected=true}check(rejected,'remote companion URLs cannot be supplied');
 const fallback=await app.PDFLib.PDFDocument.create();fallback.addPage([595.3,841.9]).drawText('TABLE LEFT',{x:40,y:700,size:14});fallback.addPage([841.9,595.3]).drawText('LANDSCAPE SECOND PAGE',{x:40,y:500,size:14});const wordPDF=fs.existsSync('word-import-fixture/converted.pdf')?fs.readFileSync('word-import-fixture/converted.pdf'):Buffer.from(await fallback.save()),wordBytes=fs.existsSync('word-import-fixture/fixture.docx')?fs.readFileSync('word-import-fixture/fixture.docx'):Buffer.from('PK synthetic fixture'),word={name:'Retained layout.docx',size:wordBytes.length,arrayBuffer:async()=>Uint8Array.from(wordBytes).buffer};
 const fetches=[];globalThis.fetch=async(url,options)=>{fetches.push({url,options});return url.endsWith('/status')?new Response(JSON.stringify({app:'PDFCreator Word companion',protocol:1,available:true,engine:'Microsoft Word'}),{status:200,headers:{'content-type':'application/json'}}):new Response(wordPDF,{status:200,headers:{'content-type':'application/pdf'}})};
 await companionStatus(config);const result=await convertWord(word,config);equal(result.name,'Retained layout.pdf','Word imports use a PDF filename');check(result.bytes.length===wordPDF.length,'Word export bytes are retained exactly');equal(fetches[1].options.headers['X-PDFCreator-Token'],token,'conversion carries the in-memory pairing token');check(fetches[1].url.startsWith('http://127.0.0.1:'),'Word data is sent only to the loopback companion');
 await app.createDocument();pending=app.activate('createWord');await until(()=>$('wordCode'),'Word import controls');$('wordCode').value=token;Object.defineProperty($('wordSource'),'files',{configurable:true,value:[word]});await $('modalform').onsubmit({preventDefault(){}});await pending;equal(app.state.name,'Retained layout.pdf','Create imports the Word PDF in a new tab');equal(app.state.doc.countPages(),2,'Word section pagination is retained in the app');check(text(app).includes('TABLE LEFT')&&text(app).includes('LANDSCAPE SECOND PAGE'),'Word content remains searchable after import');check(app.Engine.inspectPDF(app.state.bytes).pages[1].width>app.Engine.inspectPDF(app.state.bytes).pages[1].height,'Word landscape section is retained in the app');
 await app.local.flush();const session=await app.local.store.readSession();check(!JSON.stringify(session).includes(token),'pairing token is not saved in IndexedDB');
 globalThis.fetch=async()=>new Response(JSON.stringify({error:'Pairing refused'}),{status:403});let error='';try{await companionStatus(config)}catch(e){error=e.message}check(error.includes('Pairing refused'),'pairing failures are explained');let bad=false;try{wordFileName({name:'not-a-word.exe',size:100})}catch{bad=true}check(bad,'Word import refuses other file types');const beforeFailure=app.state.bytes;
 pending=app.importWordDocument();await until(()=>$('wordCode'),'retry import');$('wordCode').value=token;Object.defineProperty($('wordSource'),'files',{configurable:true,value:[word]});await $('modalform').onsubmit({preventDefault(){}});check($('modalerror').textContent.includes('Pairing refused'),'failed connection keeps the Word chooser open');equal(app.state.bytes,beforeFailure,'failed Word import preserves the active document');$('modalcancel').click();await pending;
 // A cancelled asynchronous modal must not close a later Create dialogue.
 let release;globalThis.fetch=()=>new Promise(resolve=>{release=resolve});pending=app.importWordDocument();await until(()=>$('wordCode'),'pending Word check');$('wordCode').value=token;Object.defineProperty($('wordSource'),'files',{configurable:true,value:[word]});const submitting=$('modalform').onsubmit({preventDefault(){}});await pause();$('modalcancel').click();await pending;await app.createDocument();const next=app.activate('createNew');await until(()=>$('createName'),'later New PDF dialogue');release(new Response(JSON.stringify({app:'PDFCreator Word companion',protocol:1,available:true})));await submitting;check(!!$('createName'),'late connection response cannot close the later dialogue');$('modalcancel').click();await next;
 await context.close();context=null;console.log('PDFCreator Create: '+assertions+' assertions passed using native PDF bytes and a controlled DOM/protocol.');
}finally{globalThis.fetch=originalFetch;if(context)await context.close()}
