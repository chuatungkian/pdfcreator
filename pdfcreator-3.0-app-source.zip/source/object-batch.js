/* Apply a selection as one native edit. Work on a disposable document until saved. */
import {pageObjects,transformObject} from './object-tools.js';
import {directEditTargets,transformDirectText} from './direct-text.js';
export function selectableObjects(doc,index){return [...pageObjects(doc,index),...directEditTargets(doc,index,'line').filter(t=>t.editable).map(t=>({...t,kind:'nativeText',type:'PDF text'}))]}
export const selectionBounds=items=>[Math.min(...items.map(t=>t.rect[0])),Math.min(...items.map(t=>t.rect[1])),Math.max(...items.map(t=>t.rect[2])),Math.max(...items.map(t=>t.rect[3]))];
export function transformObjectSelection(doc,index,targets,{action='transform',matrix}={}){
 if(!targets.length)throw Error('Select at least one object.');
 const all=selectableObjects(doc,index),seen=new Set();
 for(const target of targets){const key=target.kind+':'+target.index;if(seen.has(key))throw Error('The selection contains the same object twice.');seen.add(key);const current=all.find(t=>t.kind===target.kind&&t.index===target.index);if(!current||current.type!==target.type||current.text!==target.text||current.rect.some((v,i)=>Math.abs(v-target.rect[i])>.1))throw Error('These objects changed. Select them again.');}
 // A Form and its internal text represent the same painted content. Editing both
 // would apply a transform twice (and deletion can destroy the parent resource).
 for(const group of targets.filter(t=>['Content group','Text box'].includes(t.type)))if(targets.some(t=>t!==group&&t.kind==='nativeText'&&t.rect[0]>=group.rect[0]-.5&&t.rect[1]>=group.rect[1]-.5&&t.rect[2]<=group.rect[2]+.5&&t.rect[3]<=group.rect[3]+.5))throw Error('Select either the content group or its text, so the same content is changed once.');
 // Descending indices keep lower siblings stable when commands are inserted or
 // removed. Native text overlays are appended after the remaining source runs.
 const native=targets.filter(t=>t.kind==='nativeText');
 if(native.length){const parts=[...new Map(native.flatMap(t=>t.parts).map(p=>[p.index,p])).values()];transformDirectText(doc,index,{parts},{action,matrix})}
 const order=['path','xobject','annotation'];
 for(const target of targets.filter(t=>t.kind!=='nativeText').sort((a,b)=>order.indexOf(a.kind)-order.indexOf(b.kind)||b.index-a.index))transformObject(doc,index,target,{action,matrix});
}
