/* Apply a selection as one native edit. Work on a disposable document until saved. */
import {pageFormFields,deleteFormFields} from './pdf-form-fields.js';
import {updateObjectGroups} from './object-groups.js';
import {pageObjects,transformObject,rebindTrackedTextBoxes} from './object-tools.js';
import {directEditTargets,transformDirectText,reflowDirectTextBoxes} from './direct-text.js';
export function selectableObjects(doc,index){return [...pageObjects(doc,index),...pageFormFields(doc,index).filter(f=>['text','checkbox','radiobutton','combobox','listbox'].includes(f.type)&&!f.hidden&&f.rect[2]>f.rect[0]&&f.rect[3]>f.rect[1]).map(f=>({kind:'formField',index:f.index,type:({radiobutton:'Radio button',checkbox:'Checkbox',text:'Text field',combobox:'Dropdown',listbox:'List field',signature:'Signature field'})[f.type]||'Form field',text:f.label,rect:f.rect,field:f})),...directEditTargets(doc,index,'paragraph').filter(t=>t.editable).map(t=>({...t,kind:'nativeText',type:'PDF text'}))]}
export const selectionBounds=items=>[Math.min(...items.map(t=>t.rect[0])),Math.min(...items.map(t=>t.rect[1])),Math.max(...items.map(t=>t.rect[2])),Math.max(...items.map(t=>t.rect[3]))];
export function transformObjectSelection(doc,index,targets,{action='transform',matrix,matrices={},allowTextOverlap=false,groupTargets=targets,resolvedRects={},fieldScope='widget',textAlign='preserve',textAutoHeight=false}={}){
 if(!targets.length)throw Error('Select at least one object.');
 const forms=targets.filter(t=>t.kind==='formField');if(forms.length&&action!=='delete')throw Error('Use Edit form fields for field properties. This selection supports deletion.');
 const all=selectableObjects(doc,index),seen=new Set();
 for(const target of targets){const key=target.kind+':'+target.index;if(seen.has(key))throw Error('The selection contains the same object twice.');seen.add(key);const current=all.find(t=>t.kind===target.kind&&t.index===target.index);if(!current||current.type!==target.type||current.text!==target.text||current.rect.some((v,i)=>Math.abs(v-target.rect[i])>.1))throw Error('These objects changed. Select them again.');}
 // A Form and its internal text represent the same painted content. Editing both
 // would apply a transform twice (and deletion can destroy the parent resource).
 for(const group of targets.filter(t=>['Content group','Text box'].includes(t.type)))if(targets.some(t=>t!==group&&t.kind==='nativeText'&&t.rect[0]>=group.rect[0]-.5&&t.rect[1]>=group.rect[1]-.5&&t.rect[2]<=group.rect[2]+.5&&t.rect[3]<=group.rect[3]+.5))throw Error('Select either the content group or its text, so the same content is changed once.');
 // Descending indices keep lower siblings stable when commands are inserted or
 // removed. Native text overlays are appended after the remaining source runs.
 updateObjectGroups(doc,index,[],{action:'transform',matrix:[1,0,0,1,0,0],objects:all});
 const native=targets.filter(t=>t.kind==='nativeText');
 let reflow=null;if(native.length&&action!=='delete'&&(textAlign!=='preserve'||textAutoHeight||native.some(t=>{const m=matrices[t.kind+':'+t.index]||matrix;return Math.abs(Math.hypot(m[0],m[1])-1)>.0001||Math.abs(Math.hypot(m[2],m[3])-1)>.0001}))){reflow=reflowDirectTextBoxes(doc,index,native.map(target=>({target,matrix:matrices[target.kind+':'+target.index]||matrix})),{action,allowTextOverlap,textAlign,textAutoHeight});for(const box of reflow.boxes)resolvedRects[box.target.kind+':'+box.target.index]=box.frame;}else if(native.length){const parts=[...new Map(native.flatMap(t=>t.parts).map(p=>[p.index,p])).values()];transformDirectText(doc,index,{parts,matrices:Object.fromEntries(native.flatMap(t=>t.parts.map(p=>[p.index,matrices[t.kind+':'+t.index]||matrix])))},{action,matrix})}
 rebindTrackedTextBoxes(doc,index);
 const order=['path','xobject','annotation'];
 for(const target of targets.filter(t=>t.kind!=='nativeText'&&t.kind!=='formField').sort((a,b)=>order.indexOf(a.kind)-order.indexOf(b.kind)||b.index-a.index))transformObject(doc,index,target,{action,matrix:matrices[target.kind+':'+target.index]||matrix});
 if(forms.length)deleteFormFields(doc,forms.map(t=>t.field),{scope:fieldScope});
 updateObjectGroups(doc,index,groupTargets,{action,matrix,matrices,resolvedRects,objects:selectableObjects(doc,index)});return reflow;
}
