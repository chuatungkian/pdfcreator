/* Shared page assembly for the organiser and thumbnail strip. AGPL-3.0-or-later. */
export async function buildPageArrangement({PDFDocument,PDFLib,items,sources,dest=null,hasFormWidgets}){
 const doc=dest||await PDFDocument.create(),cache=new Map(),original=dest?doc.getPages():null,seen=new Set(),staged=[],rotations=new Map();
 for(const item of items){
  if(item.source===-1){const p=doc.addPage(item.size||[595,842]);staged.push(p);continue}
  let source=cache.get(item.source);if(!source){source=dest&&item.source===0?doc:await PDFDocument.load(sources[item.source].bytes,{updateMetadata:false});cache.set(item.source,source)}
  const key=item.source+':'+item.page;if(!rotations.has(key))rotations.set(key,source.getPage(item.page).getRotation().angle);
  let p;if(original&&item.source===0&&!seen.has(key))p=original[item.page];else{if(hasFormWidgets(source,[item.page]))throw Error('Flatten form fields before copying, extracting or duplicating their pages.');[p]=await doc.copyPages(source,[item.page])}
  seen.add(key);p.setRotation(PDFLib.degrees((rotations.get(key)+(item.rotation||0))%360));staged.push(p);
 }
 // Existing page objects keep annotations and internal destinations when reordered.
 while(doc.getPageCount())doc.removePage(doc.getPageCount()-1);for(const p of staged)doc.addPage(p);return doc;
}
export function movePageSelection(count,selected,boundary){
 const moving=Array.from({length:count},(_,i)=>i).filter(i=>selected.has(i)),rest=Array.from({length:count},(_,i)=>i).filter(i=>!selected.has(i));
 const at=rest.filter(i=>i<boundary).length;rest.splice(at,0,...moving);return rest;
}

/* Prepare both documents before changing either open tab. */
export async function preparePageTransfer({PDFDocument,hasFormWidgets,source,destination,pages,boundary,move}){
 const from=await PDFDocument.load(source,{updateMetadata:false});
 const to=await PDFDocument.load(destination,{updateMetadata:false});
 const selected=[...new Set(pages)].sort((a,b)=>a-b);
 const sourceCount=from.getPageCount();
 if(!selected.length||selected.some(page=>!Number.isInteger(page)||page<0||page>=sourceCount))throw Error('Select pages from the current PDF.');
 if(!Number.isInteger(boundary)||boundary<0||boundary>to.getPageCount())throw Error('Choose a valid insertion position.');
 if(move&&selected.length===sourceCount)throw Error('A PDF must retain at least one page.');
 if(hasFormWidgets(from,selected))throw Error('Selected pages contain form fields. Use Flatten form before transferring them.');
 const copied=await to.copyPages(from,selected);
 for(const [offset,page] of copied.entries())to.insertPage(boundary+offset,page);
 const destinationBytes=await to.save({useObjectStreams:false});
 if(!move)return {destinationBytes};
 for(const page of [...selected].reverse())from.removePage(page);
 return {destinationBytes,sourceBytes:await from.save({useObjectStreams:false})};
}
