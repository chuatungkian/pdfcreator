/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {toolbarPreferences} from './page-toolbar.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;
 const pdf=await fixture(app,'MOVABLE TOOLBAR');await app.openFiles([file('Toolbar.pdf',pdf)]);app.state.fit=false;app.state.zoom=.8;await app.render();await app.local.flush();
 function geometry(width=800,height=600){
  const host=$('pageToolbarHost'),bar=$('pageToolbar');
  Object.defineProperties(host,{clientWidth:{configurable:true,get:()=>width},clientHeight:{configurable:true,get:()=>height}});
  Object.defineProperties(bar,{offsetWidth:{configurable:true,get:()=>bar.dataset.position==='floating'?Math.min(bar.classList.contains('minimised')?130:400,width-16):width},offsetHeight:{configurable:true,get:()=>bar.classList.contains('minimised')?30:bar.dataset.position==='floating'?40:42}});
  host.getBoundingClientRect=()=>({left:130,top:101,width,height});bar.getBoundingClientRect=()=>({left:130+(parseFloat(bar.style.left)||0),top:101+(parseFloat(bar.style.top)||0),width:bar.offsetWidth,height:bar.offsetHeight});
  window.dispatchEvent(new window.Event('resize'));
 }
 geometry();let bar=$('pageToolbar'),handle=$('movePageToolbar');
 const bytes=app.state.bytes,name=app.state.name;
 check($('main').parentElement===$('documentStage')&&$('pageToolbarHost').parentElement===$('documentStage'),'toolbar is attached to the working area beside the scrolling main');
 check(!$('main').contains(bar),'toolbar does not scroll away with document content');
 equal(bar.dataset.position,'floating','toolbar defaults to Floating');equal(parseFloat(bar.style.left),200,'floating toolbar starts horizontally centred');equal(parseFloat(bar.style.top),8,'floating toolbar starts near the top');
 equal(bar.getAttribute('role'),'toolbar','page controls retain toolbar semantics');
 const nativeCommit=app.local.store.commit.bind(app.local.store),writes=[];app.local.store.commit=async update=>{writes.push(update);return nativeCommit(update)};
 $('main').scrollTop=177;$('main').scrollLeft=23;
 $('minimisePageToolbar').click();check($('pageToolbarControls').hidden&&!$('toolbarCompactSummary').hidden,'minimise hides controls and exposes a restore summary');
 equal($('minimisePageToolbar').getAttribute('aria-expanded'),'false','minimised state is accessible');equal($('minimisePageToolbar').getAttribute('aria-label'),'Restore page toolbar','minimised control explains restoration');
 equal($('toolbarCompactSummary').textContent,'Page 1 / 2','minimised summary retains current page');
 check(app.state.bytes===bytes&&app.state.name===name,'minimising leaves the active PDF unchanged');equal($('main').scrollTop,177,'minimising preserves document scroll');
 $('toolbarCompactSummary').click();check(!$('pageToolbarControls').hidden&&$('toolbarCompactSummary').hidden,'summary restores the full controls');
 equal($('minimisePageToolbar').getAttribute('aria-expanded'),'true','restored state is accessible');
 function pointer(type,x,y,{id=1,button=0}={}){const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button});Object.defineProperty(event,'pointerId',{value:id});handle.dispatchEvent(event)}
 function key(target,key,shiftKey=false){target.dispatchEvent(new window.KeyboardEvent('keydown',{key,shiftKey,bubbles:true,cancelable:true}))}
 pointer('pointerdown',220,130);pointer('pointermove',370,260);const left=parseFloat(bar.style.left),top=parseFloat(bar.style.top);
 equal(left,350,'drag shifts toolbar horizontally');equal(top,138,'drag shifts toolbar vertically');
 pointer('pointermove',0,0,{id:99});pointer('pointerup',0,0,{id:99});equal(parseFloat(bar.style.left),left,'foreign pointer cannot move or end the toolbar gesture');
 pointer('pointerup',370,260);check(!bar.classList.contains('dragging'),'pointer release finishes toolbar movement');
 pointer('pointerdown',0,0);pointer('pointermove',10000,10000);pointer('pointerup',10000,10000);
 equal(parseFloat(bar.style.left),392,'movement is bounded to the working area right edge');equal(parseFloat(bar.style.top),552,'movement is bounded to the working area bottom edge');
 const settled={left:bar.style.left,top:bar.style.top};await app.local.flush();const beforeCancel=(await app.local.store.readSession()).preferences.pageToolbar;
 pointer('pointerdown',100,100);pointer('pointermove',0,0);await app.local.flush();equal((await app.local.store.readSession()).preferences.pageToolbar,beforeCancel,'an in-progress drag is not persisted before release');pointer('pointercancel',0,0);
 equal({left:bar.style.left,top:bar.style.top},settled,'cancelled movement restores the previous position');
 pointer('pointerdown',100,100);pointer('pointermove',0,0);key(handle,'Escape');equal({left:bar.style.left,top:bar.style.top},settled,'Escape cancels an unfinished toolbar drag');
 pointer('pointerdown',100,100,{button:2});check(!bar.classList.contains('dragging'),'right mouse button does not start moving');
 const page=app.state.page;key(handle,'ArrowLeft');equal(parseFloat(bar.style.left),384,'arrow key moves the floating toolbar');key(handle,'ArrowUp',true);equal(parseFloat(bar.style.top),520,'Shift arrow moves further');equal(app.state.page,page,'moving with arrows does not change PDF pages');
 geometry(500,300);check(parseFloat(bar.style.left)+bar.offsetWidth<=492&&parseFloat(bar.style.top)+bar.offsetHeight<=292,'resizing keeps the floating toolbar inside the available area');geometry();
 $('pageToolbarOptions').click();check(!$('pageToolbarMenu').hidden,'position menu opens');equal($('pageToolbarOptions').getAttribute('aria-expanded'),'true','position menu reports its expanded state');
 const mode=name=>$('pageToolbarMenu').querySelector('[data-toolbar-mode="'+name+'"]');
 mode('top').click();equal(bar.dataset.position,'top','top mode selected');equal(bar.style.left,'0px','top lock is anchored to the working area left edge');equal(bar.style.top,'0px','top lock is anchored to the top');
 equal(window.getComputedStyle(bar).width,'100%','top lock spans its working area');check(handle.disabled,'locked toolbar cannot accidentally be dragged');check($('pageToolbarMenu').hidden,'choosing a mode closes the popup');
 pointer('pointerdown',100,100);pointer('pointermove',200,200);pointer('pointerup',200,200);equal(bar.style.top,'0px','locked toolbar ignores drag gestures');
 $('pageToolbarOptions').click();mode('bottom').click();equal(bar.dataset.position,'bottom','bottom mode selected');equal(bar.style.bottom,'0px','bottom lock stays at the bottom');equal(bar.style.top,'','bottom lock clears the old top offset');equal(window.getComputedStyle(bar).width,'100%','bottom lock spans the working area');
 $('minimisePageToolbar').click();check(bar.classList.contains('minimised')&&bar.dataset.position==='bottom','locked toolbar can minimise without undocking');
 await $('next').onclick();equal($('toolbarCompactSummary').textContent,'Page 2 / 2','minimised summary follows document navigation');
 $('minimisePageToolbar').click();check(!$('pageToolbarControls').hidden,'same button restores the locked toolbar');
 $('pageToolbarOptions').click();mode('floating').click();check(!handle.disabled&&bar.style.bottom==='','Floating unlocks movement and clears the bottom lock');
 $('pageToolbarOptions').click();$('resetPageToolbar').click();equal(parseFloat(bar.style.left),200,'reset restores the centred floating position');equal(parseFloat(bar.style.top),8,'reset restores the initial top position');
 $('pageToolbarOptions').click();$('main').dispatchEvent(new window.Event('pointerdown',{bubbles:true}));check($('pageToolbarMenu').hidden,'outside pointer dismisses the position menu');
 await app.activate('ink');$('pageToolbarOptions').click();key(mode('floating'),'Escape');check($('pageToolbarMenu').hidden&&app.state.tool==='ink','closing toolbar options with Escape keeps the chosen PDF tool');
 check(app.state.bytes===bytes,'all toolbar layout actions leave PDF bytes intact');
 $('pageToolbarOptions').click();mode('bottom').click();$('minimisePageToolbar').click();await app.local.flush();
 const preferences=(await app.local.store.readSession()).preferences.pageToolbar;
 check(preferences.mode==='bottom'&&preferences.minimised,'toolbar placement and minimisation are saved');check(writes.every(update=>!update.documents?.length),'toolbar changes do not rewrite stored PDF binaries');
 equal($('main').scrollLeft,23,'toolbar changes preserve horizontal document scroll');
 // Fullscreen keeps both the document and its toolbar in the fullscreen target.
 let fullscreen=null,requested=null;Object.defineProperty(window.document,'fullscreenElement',{configurable:true,get:()=>fullscreen});
 $('documentStage').requestFullscreen=async()=>{requested=$('documentStage');fullscreen=requested};window.document.exitFullscreen=async()=>{fullscreen=null};
 await $('fullscreen').onclick();check(requested?.contains($('main'))&&requested.contains($('pageToolbarHost')),'fullscreen target includes both the PDF and movable controls');await $('fullscreen').onclick();check(!fullscreen,'fullscreen toggle exits cleanly');
 await app.local.flush();await context.close();context=await boot();({app,$,window}=context);geometry();bar=$('pageToolbar');handle=$('movePageToolbar');
 check(bar.dataset.position==='bottom'&&bar.classList.contains('minimised'),'a fresh app instance restores toolbar layout');equal($('toolbarCompactSummary').textContent,'Page 2 / 2','restored compact toolbar shows the recovered page');equal(app.state.bytes,bytes,'recovery retains original PDF bytes');
 check(app.state.tool==='ink','toolbar recovery preserves the active PDF tool');
 $('pageToolbarOptions').click();mode('floating').click();geometry(220,140);check(parseFloat(bar.style.left)>=8&&parseFloat(bar.style.top)>=8,'restored floating toolbar stays reachable in a small working area');
 equal(toolbarPreferences({mode:'other',minimised:1,x:Infinity,y:-4}),{mode:'floating',minimised:false,x:.5,y:0},'invalid recovery preferences fall back safely');
 equal(toolbarPreferences({mode:'top',minimised:true,x:2,y:.25}),{mode:'top',minimised:true,x:1,y:.25},'recovery coordinates are bounded');
 console.log('pdfpro page toolbar: '+assertions+' assertions passed in a controlled DOM with simulated geometry/IndexedDB and real PDFs.');
}finally{if(context)await context.close()}
