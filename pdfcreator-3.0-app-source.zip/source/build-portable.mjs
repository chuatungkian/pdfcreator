/* Rebuild the current offline release from preferred app sources and exact vendor bytes. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {sourceCRC} from './source-package.js';
const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.resolve(process.argv[2]||path.join(root,'../../outputs'));fs.mkdirSync(out,{recursive:true});
const bytes=file=>fs.readFileSync(path.join(root,file)),text=file=>bytes(file).toString('utf8'),b64=file=>bytes(file).toString('base64');
const sha=content=>crypto.createHash('sha256').update(content).digest('hex');
export function zip(entries){const chunks=[],central=[];let offset=0;for(const[name,input]of entries){const content=Buffer.from(input),encoded=Buffer.from(name),data=zlib.deflateRawSync(content,{level:6}),crc=sourceCRC(content),local=Buffer.alloc(30),entry=Buffer.alloc(46);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt32LE(crc,14);local.writeUInt32LE(data.length,18);local.writeUInt32LE(content.length,22);local.writeUInt16LE(encoded.length,26);entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(8,10);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(data.length,20);entry.writeUInt32LE(content.length,24);entry.writeUInt16LE(encoded.length,28);entry.writeUInt32LE(offset,42);chunks.push(local,encoded,data);central.push(entry,encoded);offset+=30+encoded.length+data.length}const end=Buffer.alloc(22),size=central.reduce((sum,item)=>sum+item.length,0);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(size,12);end.writeUInt32LE(offset,16);return Buffer.concat([...chunks,...central,end])}
// Read source through Node so Windows sandboxed builds do not traverse drive roots.
const require=createRequire(import.meta.url),entryFile=path.join(root,'app.mjs');
function resolveFile(candidate){for(const item of [candidate,candidate+'.js',candidate+'.mjs',candidate+'.json',path.join(candidate,'index.js')])try{if(fs.statSync(item).isFile())return item}catch{}throw Error('Cannot resolve local source '+candidate)}
const filePlugin={name:'portable-source-files',setup(builder){
 builder.onResolve({filter:/.*/},args=>{if(['node:fs','module'].includes(args.path))return{path:args.path,external:true};if(args.path==='crypto')return{path:'crypto',namespace:'empty-browser'};const importer=args.importer||entryFile,resolve=createRequire(importer);let file;if(args.path.startsWith('.'))file=resolveFile(path.resolve(path.dirname(importer),args.path));else if(path.isAbsolute(args.path))file=resolveFile(args.path);else file=resolve.resolve(args.path);return{path:file,namespace:'source-files'}});
 builder.onLoad({filter:/.*/,namespace:'source-files'},args=>({contents:fs.readFileSync(args.path,'utf8'),loader:args.path.endsWith('.json')?'json':'js',resolveDir:path.dirname(args.path)}));builder.onLoad({filter:/.*/,namespace:'empty-browser'},()=>({contents:'module.exports={};',loader:'js'}));
}};
const bundle=async(file,format='esm')=>(await build({absWorkingDir:root,stdin:{contents:text(file),sourcefile:path.join(root,file),resolveDir:root,loader:'js'},plugins:[filePlugin],bundle:true,write:false,format,platform:'browser',target:['chrome110','firefox115','safari17'],minify:true,legalComments:'inline',tsconfigRaw:{}})).outputFiles[0].text;
const app=await bundle('app.mjs'),formDataWorker=await bundle('form-data-worker.mjs','iife');fs.writeFileSync(path.join(root,'vendor/form-data-worker.js'),formDataWorker);
const runtime={
 app,formDataWorker,engineWorker:text('vendor/engine-worker.js'),
 word:{workerSource:text('vendor/word-worker.js'),fonts:Object.fromEntries(['regular','bold','italic','boldItalic'].map((key,index)=>[key,b64('fonts/Arimo-'+['Regular','Bold','Italic','BoldItalic'][index]+'.ttf')])),version:'1.33.1',fontFamily:'Arimo'},
 wordCompanionBase64:b64('PDFCreator-Word-Companion.zip'),notices:text('THIRD-PARTY-NOTICES.txt'),mupdfBase64:b64('vendor/mupdf/dist/mupdf-wasm.wasm'),
 ocr:{workerSource:text('vendor/tesseract.js/dist/worker.min.js'),coreSource:text('vendor/tesseract.js-core/tesseract-core-lstm.js'),coreWasmBase64:b64('vendor/tesseract.js-core/tesseract-core-lstm.wasm'),languageDataBase64:b64('eng-fast.traineddata'),language:'eng'}
};
const shared=new Map();function share(key,content){shared.set(sha(content),{key,content})}
share('form-data-worker',Buffer.from(formDataWorker));
share('mupdf',Buffer.from(runtime.mupdfBase64,'base64'));share('ocr-wasm',Buffer.from(runtime.ocr.coreWasmBase64,'base64'));share('ocr-model',Buffer.from(runtime.ocr.languageDataBase64,'base64'));share('ocr-worker',Buffer.from(runtime.ocr.workerSource));share('ocr-core',Buffer.from(runtime.ocr.coreSource));share('inter',bytes('fonts/InterVariable.woff2'));share('notices',Buffer.from(runtime.notices));share('engine-worker',Buffer.from(runtime.engineWorker));share('word-worker',Buffer.from(runtime.word.workerSource));share('word-companion',Buffer.from(runtime.wordCompanionBase64,'base64'));for(const [key,value]of Object.entries(runtime.word.fonts))share('word-font-'+key,Buffer.from(value,'base64'));
const sources=[];function collect(directory,relative=''){for(const entry of fs.readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en'))){if(entry.isSymbolicLink()||entry.name==='.git'||relative===''&&['node_modules','word-dependencies'].includes(entry.name))continue;const next=relative?relative+'/'+entry.name:entry.name,full=path.join(directory,entry.name);if(entry.isDirectory())collect(full,next);else if(entry.isFile())sources.push(['source/'+next,fs.readFileSync(full)])}}collect(root);
const entries=[],chunks=[],locations=new Map();let offset=0;
for(const[name,content]of sources){const hash=sha(content),asset=shared.get(hash);let location;if(asset&&asset.content.equals(content))location={asset:asset.key};else if(locations.has(hash))location=locations.get(hash);else{const compressed=zlib.deflateRawSync(content,{level:6});location={offset,length:compressed.length};offset+=compressed.length;chunks.push(compressed);locations.set(hash,location)}entries.push({name,size:content.length,crc:sourceCRC(content),...location})}
runtime.sourceArchive={version:1,entries,poolBase64:Buffer.concat(chunks).toString('base64')};
const payload=zlib.gzipSync(Buffer.from(JSON.stringify(runtime)),{level:9}).toString('base64');
const originalBoot=text('vendor/bootstrap.html');
const boot=originalBoot.replace('PDFCREATOR_PAYLOAD',payload);
if(boot===originalBoot)throw Error('Missing bootstrap payload marker');
const fontCSS='@font-face{font-family:Inter;src:url(data:font/woff2;base64,'+b64('fonts/InterVariable.woff2')+') format("woff2");font-style:normal;font-weight:100 900;font-display:swap}';
const html=text('shell.html').replace('/* PDFPRO_FONT */',fontCSS).replace('/* PDFPRO_LAYOUT */',text('layout.css')).replace('/* PDFPRO_REFRESH */',text('refresh.css')).replace('<!-- PDFPRO_BOOT -->',boot);
if(Buffer.byteLength(html)>=25000000)throw Error('Single HTML exceeds 25,000,000 bytes');
const sourceZip=zip(sources);for(const name of ['index.html','pdfcreator.html','pdfpro.html'])fs.writeFileSync(path.join(out,name),html);
fs.writeFileSync(path.join(out,'pdfcreator-3.0-app-source.zip'),sourceZip);fs.writeFileSync(path.join(out,'PDFCreator-Word-Companion.zip'),Buffer.from(runtime.wordCompanionBase64,'base64'));
for(const name of ['README.md','README.txt','REAM-SOURCE.txt','LICENSE.txt','THIRD-PARTY-NOTICES.txt','RELEASE-NOTES.md','VALIDATION.txt','PACKAGE-VERIFICATION.txt','START-HERE.txt','SOURCE-COMMIT.txt'])if(fs.existsSync(path.join(root,name)))fs.copyFileSync(path.join(root,name),path.join(out,name));
for(const [template,name]of [['FEATURE-AUDIT.template.txt','FEATURE-AUDIT.txt']])if(fs.existsSync(path.join(root,template)))fs.writeFileSync(path.join(out,name),text(template).replaceAll('{{HTML_SHA256}}',sha(Buffer.from(html))));
fs.writeFileSync(path.join(out,'.nojekyll'),'');
fs.writeFileSync(path.join(out,'.gitattributes'),'* text=auto eol=lf\n*.html -text\n*.zip -text\n*.gz* -text\n*.woff2 -text\n*.wasm -text\n*.ttf -text\n*.pdf -text\n');
const ream=path.join(root,'word-dependencies');if(fs.existsSync(ream)){const items=[];function collectWord(dir,relative='word-dependencies'){for(const item of fs.readdirSync(dir,{withFileTypes:true})){if(item.isSymbolicLink())continue;const rel=relative+'/'+item.name,full=path.join(dir,item.name);if(item.isDirectory())collectWord(full,rel);else items.push(['source/'+rel,fs.readFileSync(full)])}}collectWord(ream);for(const [name,content]of sources.filter(([name])=>name.includes('/fonts/Arimo-')||name==='source/REAM-SOURCE.txt'))items.push([name,content]);fs.writeFileSync(path.join(out,'PDFCreator-Ream-Source.zip'),zip(items))}
// Existing upstream source parts remain alongside the release and are included in its hashes.
function list(dir,prefix=''){return fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en')).flatMap(item=>item.name==='.git'||item.name==='SHA256SUMS.txt'||item.name==='pdfcreator-current-release.zip'?[]:item.isDirectory()?list(path.join(dir,item.name),prefix+item.name+'/'):[prefix+item.name])}
const files=list(out);for(const name of files)if(/\.(txt|md|py)$/.test(name)){const file=path.join(out,name);fs.writeFileSync(file,fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n').replace(/[ \t]+(?=\r?$)/gm,''))}fs.writeFileSync(path.join(out,'SHA256SUMS.txt'),files.map(name=>sha(fs.readFileSync(path.join(out,name)))+'  '+name).join('\n')+'\n');
console.log(JSON.stringify({htmlBytes:Buffer.byteLength(html),sourceFiles:sources.length,sourceZipBytes:sourceZip.length,htmlSHA256:sha(Buffer.from(html)),output:out},null,2));
