/* Compose typed and drawn visual signatures without changing the drawing. AGPL-3.0-or-later. */
import {systemFontFamily} from './system-fonts.js';
export function signatureStyle({color='#101d3a',lineWidth=4,bold=false}={}){if(!/^#[a-f\d]{6}$/i.test(color)||!Number.isFinite(+lineWidth)||+lineWidth<.5||+lineWidth>16||typeof bold!=='boolean')throw Error('Choose a signature colour and line thickness from 0.5 to 16.');return{color,lineWidth:+lineWidth,bold}}
export function drawSignatureStrokes(canvas,strokes,options={}){const style=signatureStyle(options),ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);ctx.strokeStyle=ctx.fillStyle=style.color;ctx.lineWidth=style.lineWidth;ctx.lineCap=ctx.lineJoin='round';for(const points of strokes){if(!points.length)continue;ctx.beginPath();ctx.arc(points[0][0],points[0][1],style.lineWidth/2,0,Math.PI*2);ctx.fill();if(points.length>1){ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.stroke()}}}
export function visualSignatureCanvas(source,{text='',font='Arial',hasDrawing=false,color='#101d3a',bold=false}={},output=document.createElement('canvas')){
  text=String(text).trim();signatureStyle({color,bold});if(output===source)throw Error('Use a separate signature preview canvas.');output.width=source.width;output.height=source.height+(hasDrawing&&text?160:0);
  const context=output.getContext('2d');if(!context)throw Error('The signature image could not be created.');
  if(hasDrawing)context.drawImage(source,0,0);
  if(text){context.fillStyle=color;context.font=(bold?'700 ':'')+'100px '+systemFontFamily(font);context.fillText(text,25,hasDrawing?source.height+125:185,source.width-50)}
  return output;
}
export async function composeVisualSignature(source,options={}){
  if(!String(options.text||'').trim()&&!options.hasDrawing)throw Error('Type, draw, or import a signature.');const output=visualSignatureCanvas(source,options);
  const blob=await new Promise(resolve=>output.toBlob(resolve,'image/png'));if(!blob)throw Error('The signature image could not be saved.');
  return{bytes:new Uint8Array(await blob.arrayBuffer()),type:'image/png'};
}
