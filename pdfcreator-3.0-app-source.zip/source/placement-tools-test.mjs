/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();const {app,$,window,fileSelections}=context;
 await app.newDocument();app.state.fit=false;app.state.zoom=1;await app.render();
 const initialId=app.activeTabId,overlay=$('overlay');
 function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(event,'pointerId',{value:1});overlay.dispatchEvent(event)}
 function drag(rect){pointer('pointerdown',rect[0],rect[1]);pointer('pointermove',rect[2],rect[3]);pointer('pointerup',rect[2],rect[3])}
 const submit=()=> $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
 async function group(name){await window.document.querySelector('[data-group="'+name+'"]').onclick()}
 function nativeAnnotations(){const page=app.state.doc.loadPage(0),all=page.getAnnotations();try{return all.map(annotation=>({type:annotation.getType(),contents:annotation.getContents(),rect:annotation.getBounds()}))}finally{all.forEach(annotation=>annotation.destroy());page.destroy()}}
 async function place(rect,{input,value}={}){
  const before=app.state.bytes;drag(rect);
  if(input){if(['text','freetext','stamp'].includes(app.state.tool)){await until(()=>document.querySelector('.rich-input'),'rich placement editor');document.querySelector('.rich-input').textContent=value;await document.querySelector('.rich-editor [data-apply]').onclick()}else{await until(()=>$(input),'placement dialog');$(input).value=value;submit()}}
  await until(()=>app.state.bytes!==before&&!app.state.abort,'placement committed');await app.local.flush();
 }
 await group('Annotate');await $('dockTools').onclick();await app.activate('freetext');
 check(app.state.settingsOpen&&$('toolsettingsbody').classList.contains('text-settings'),'text comments open compact appearance settings');
 check(parseFloat(window.getComputedStyle($('fontSample')).fontSize)<=12,'font preview is smaller than the former 19px sample');
 check($('closeToolSettings').getAttribute('aria-label')==='Close tool settings','floating settings have an accessible close control');
 $('closeToolSettings').click();check(!app.state.settingsOpen&&app.state.tool==='freetext','closing settings keeps the comment tool selected');
 $('toolSettings').click();check(app.state.settingsOpen,'settings can reopen for the active tool');
 const rect=[45,240,340,300];await place(rect,{input:'annotationText',value:'First persistent text comment'});
 equal(app.state.tool,'freetext','text comment remains selected after placement');check(!app.state.settingsOpen,'page pointer dismisses settings before placement');
 equal(nativeAnnotations()[0].rect,rect,'settings dismissal preserves exact document selection coordinates');
 equal(window.document.querySelector('[data-tool=freetext]').getAttribute('aria-pressed'),'true','active comment button stays pressed');
 await place([45,330,340,390],{input:'annotationText',value:'Second persistent text comment'});
 equal(nativeAnnotations().filter(item=>item.type==='FreeText').length,2,'second comment is created without reselecting');
 equal((await app.local.store.getDocument(initialId)).snapshot.tool,'freetext','persistent selection is stored with the document');
 await group('View');equal(app.state.tool,'freetext','browsing categories does not cancel the active feature');await group('Annotate');
 await window.document.querySelector('[data-tool=freetext]').onclick();equal(app.state.tool,'select','clicking the same feature deselects it');
 check(!$('modalroot').firstChild,'deselection does not open a placement dialog');equal(window.document.querySelectorAll('.annotation-badge').length,2,'deselection restores comment viewing controls');

 await app.activate('note');await place([390,220,415,245],{input:'annotationText',value:'Sticky one'});
 equal(app.state.tool,'note','sticky note persists after placement');await place([440,220,465,245],{input:'annotationText',value:'Sticky two'});
 equal(nativeAnnotations().filter(item=>item.type==='Text').length,2,'two native sticky notes are created with one selection');
 await app.activate('stamp');equal(app.state.tool,'stamp','choosing another feature switches immediately');
 await place([350,310,560,355],{input:'annotationText',value:'APPROVED'});equal(app.state.tool,'stamp','stamp persists after placement');
 await place([350,380,560,425],{input:'annotationText',value:'REVIEWED'});equal(nativeAnnotations().filter(item=>item.type==='Stamp').length,2,'stamp can be repeated');
 await app.activate('rectangle');await place([40,450,170,510]);equal(app.state.tool,'rectangle','drawing tool persists');
 await place([190,450,320,510]);equal(nativeAnnotations().filter(item=>item.type==='Square').length,2,'drawing tool can be repeated');
 await app.activate('rectangle');equal(app.state.tool,'select','same drawing feature toggles off');

 await group('Edit');await app.activate('text');await place([45,540,340,585],{input:'answer',value:'First persistent page text'});
 equal(app.state.tool,'text','page text tool persists');await place([45,610,340,655],{input:'answer',value:'Second persistent page text'});
 const extracted=text(app);check(extracted.includes('First persistent page text')&&extracted.includes('Second persistent page text'),'both repeated text additions are searchable');
 const unchanged=app.state.bytes;drag([45,680,340,725]);await until(()=>document.querySelector('.rich-editor'),'cancelled text entry');document.querySelector('.rich-editor [data-cancel]').click();await pause();
 check(app.state.bytes===unchanged&&app.state.tool==='text','cancelling an entry retains the selected feature and PDF');
 await window.document.querySelector('[data-tool=text]').onclick();equal(app.state.tool,'select','same Add text button exits text placement');

 const image=canvas.createCanvas(20,20);image.getContext('2d').fillRect(0,0,20,20);const png=image.toBuffer('image/png');
 fileSelections.push([{name:'fixture.png',type:'image/png',arrayBuffer:async()=>new Uint8Array(png).buffer}]);
 await app.activate('image');const imageBytes=app.state.selectedImage.bytes;await place([360,460,420,520]);equal(app.state.tool,'image','image placement persists');
 await place([440,460,500,520]);check(app.state.selectedImage.bytes===imageBytes&&!fileSelections.length,'repeated image placement reuses the chosen image without another chooser');
 await app.activate('image');equal(app.state.tool,'select','same image feature toggles off without another chooser');

 await group('Forms');await app.activate('fieldText');await place([350,550,545,580],{input:'answer',value:'Persistent field one'});
 equal(app.state.tool,'fieldText','form-field placement persists');await place([350,610,545,640],{input:'answer',value:'Persistent field two'});
 const formDoc=await app.PDFLib.PDFDocument.load(app.state.bytes);equal(formDoc.getForm().getFields().length,2,'repeated field placement creates distinct real AcroForm fields');
 await app.activate('fieldText');equal(app.state.tool,'select','same form feature toggles off');

 await group('Protect & sign');const signature=app.activate('signature');await until(()=>$('sigtext'),'visual signature dialog');$('sigtext').value='Repeat signature';submit();await signature;
 equal(app.state.tool,'signatureImage','visual signature enters placement mode');equal(window.document.querySelector('[data-tool=signature]').getAttribute('aria-pressed'),'true','signature action reflects its placement state');
 await place([45,80,250,125]);equal(app.state.tool,'signatureImage','visual signature remains selected after placement');await place([310,80,515,125]);
 await window.document.querySelector('[data-tool=signature]').onclick();check(app.state.tool==='select'&&!$('sigtext'),'same signature button deselects without reopening signature entry');

 await group('Annotate');await app.activate('note');const savedBytes=app.state.bytes;
 await app.newDocument();await app.switchTab(initialId);check(app.state.tool==='note'&&app.state.bytes===savedBytes,'returning to a document restores its active tool and bytes');
 await group('View');const properties=app.activate('metadata');await until(()=>$('modalform'),'properties dialog');equal(app.state.tool,'select','choosing a document action exits the previous feature');$('modalcancel').click();await properties;
 check(app.state.bytes===savedBytes,'cancelled document action leaves PDF intact');
 console.log('pdfpro persistent placement tools: '+assertions+' assertions passed with real PDF bytes in a controlled DOM.');
}finally{if(context)await context.close()}
