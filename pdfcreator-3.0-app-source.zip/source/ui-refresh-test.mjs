/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;
 await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','empty home ready');
 check(window.document.body.classList.contains('home-visible'),'new session opens on Home');
 check(!$('recentEmpty').hidden,'empty library has a useful start state');
 check($('saveBtn').disabled,'Home does not export a hidden document');
 equal(window.document.querySelectorAll('.app-header .toptools').length,1,'document actions occupy the main header');
 check($('actionMenu').hidden,'secondary actions start dismissed');
 $('moreActions').dispatchEvent(new window.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));
 equal(window.document.activeElement,$('newBtn'),'keyboard opens and focuses the action list');
 $('newBtn').dispatchEvent(new window.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));
 equal(window.document.activeElement,$('libraryBtn'),'keyboard moves between enabled actions');
 $('libraryBtn').dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
 check($('actionMenu').hidden,'Escape closes secondary actions');equal(window.document.activeElement,$('moreActions'),'Escape returns focus');
 $('moreActions').click();$('main').dispatchEvent(new window.Event('pointerdown',{bubbles:true}));
 check($('actionMenu').hidden,'outside pointer dismisses secondary actions');
 $('moreActions').click();$('about').focus();check($('actionMenu').hidden,'tabbing outside dismisses secondary actions');

 const alpha=await fixture(app,'ALPHA'),beta=await fixture(app,'BETA');
 const alphaName='<img src=x onerror=bad()> Alpha.pdf';
 await app.openFiles([file(alphaName,alpha),file('Beta.pdf',beta)]);
 const aid=app.tabs[0].id,bid=app.activeTabId;
 app.state.fit=false;app.state.zoom=.8;app.state.page=1;await app.render();$('main').scrollTop=281;$('main').scrollLeft=17;
 await app.editPDF('Saved edit',doc=>doc.getPage(1).drawText('RESUME EDIT',{x:40,y:710,size:13}));
 const edited=app.state.bytes,history=app.state.undo.length;
 await $('homeBtn').onclick();
 await until(()=>$('recentDocuments').querySelectorAll('img').length===2&&$('recentDocuments').getAttribute('aria-busy')==='false','recent thumbnails');await pause();
 check(!$('welcome').classList.contains('hidden')&&$('viewer').classList.contains('hidden'),'Home can be visited while documents remain open');
 equal(app.tabs.length,2,'Home retains existing tabs');equal(app.state.bytes,edited,'Home preserves edits');equal(app.state.undo.length,history,'Home preserves undo');
 equal(app.state.scrollTop,281,'Home scroll does not replace document vertical position');equal(app.state.scrollLeft,17,'Home scroll does not replace horizontal position');
 equal($('main').getAttribute('aria-label'),'Documents','Home has its own accessible name');
 const cards=[...$('recentDocuments').children];
 equal(cards[0].dataset.recentId,bid,'recent files are ordered by use');
 equal(cards.find(card=>card.dataset.recentId===aid).querySelector('h3').textContent,alphaName,'untrusted filenames render literally');
 equal($('recentDocuments').querySelectorAll('img[onerror]').length,0,'filename cannot inject markup');
 const png=Buffer.from(cards[0].querySelector('img').src.split(',')[1],'base64');
 equal([...png.subarray(0,8)],[137,80,78,71,13,10,26,10],'first-page thumbnail is a real PNG');
 const thumb=await canvas.loadImage(png);check(thumb.width<=182&&thumb.height<=152,'Home thumbnails have bounded dimensions');
 check(cards.every(card=>card.querySelector('[data-resume]').getAttribute('aria-label').startsWith('Resume ')),'Resume actions have document-specific names');
 check(cards[0].querySelector('time').hasAttribute('datetime'),'recent date has machine-readable text');
 check($('saveBtn').disabled,'hidden active document is not a Home export target');
 await cards[0].querySelector('[data-resume]').onclick();
 await until(()=>!window.document.body.classList.contains('home-visible')&&!$('viewer').classList.contains('hidden'),'Resume active PDF');await pause();
 equal(app.activeTabId,bid,'Resume uses the existing active tab');equal(app.tabs.length,2,'Resume does not duplicate tabs');
 equal($('main').scrollTop,281,'Resume restores document scroll');equal(app.state.page,1,'Resume restores page');equal(app.state.zoom,.8,'Resume restores zoom');
 check(text(app).includes('RESUME EDIT'),'Resume retains real PDF edits');check(!$('saveBtn').disabled,'document actions return after Resume');

 // Preview keys survive view-only saves; edits must invalidate them.
 const originalGet=app.local.store.getDocument.bind(app.local.store);let reads=0;
 app.local.store.getDocument=async(...args)=>{reads++;return originalGet(...args)};
 app.state.page=0;await app.local.flush();await $('homeBtn').onclick();
 await until(()=>window.document.body.classList.contains('home-visible')&&$('recentDocuments').getAttribute('aria-busy')==='false','cached Home');await pause();
 equal(reads,0,'view-only saves reuse preview pixels without rereading PDF payloads');
 await app.switchTab(bid);await app.editPDF('New edit',doc=>doc.getPage(0).drawText('NEW PREVIEW CONTENT',{x:40,y:680,size:13}));
 const latest=app.state.bytes;await $('homeBtn').onclick();
 await until(()=>$('recentDocuments').querySelectorAll('img').length===2&&$('recentDocuments').getAttribute('aria-busy')==='false','updated Home');await pause();
 equal(reads,1,'PDF edits invalidate only the changed thumbnail');
 await app.switchTab(aid);await app.closeTab(bid);await $('homeBtn').onclick();
 await until(()=>$('recentDocuments').querySelectorAll('img').length===2&&$('recentDocuments').getAttribute('aria-busy')==='false','closed PDF remains recent');await pause();
 const closed=[...$('recentDocuments').children].find(card=>card.dataset.recentId===bid);
 check(!closed.querySelector('.recent-state'),'closed PDF is no longer labelled open');await closed.querySelector('button').onclick();
 await until(()=>app.activeTabId===bid&&!window.document.body.classList.contains('home-visible'),'Resume closed copy');await pause();
 equal(app.tabs.length,2,'Resume closed copy creates exactly one tab');equal(app.state.bytes,latest,'Resume closed copy loads latest saved edits');
 app.local.store.getDocument=originalGet;

 // Settings are contextual in the popup and in the pinned rail.
 async function group(name){await window.document.querySelector('[data-group="'+name+'"]').onclick()}
 const hidden=id=>!!$(id).closest('[hidden]');
 await group('Edit');check(hidden('toolFont')&&hidden('toolColor'),'no text settings before choosing a tool');
 await app.activate('text');check(!hidden('toolFont')&&!hidden('toolSize')&&!hidden('toolColor'),'text placement offers font, colour and size');
 equal($('toolFont').options.length,30,'contextual font selector retains all 30 fonts');
 $('toolFont').value='Georgia';$('toolFont').dispatchEvent(new window.Event('change'));equal(app.state.font,'Georgia','font choice updates active document');
 $('doneTool').click();check(hidden('toolFont'),'Done returns to document selection');equal(app.state.tool,'select','Done exits placement mode');
 await group('Annotate');await app.activate('highlight');check(hidden('toolFont')&&hidden('toolSize')&&!hidden('toolColor'),'highlight offers colour without text controls');
 await app.activate('rectangle');check(hidden('toolFont')&&!hidden('toolSize'),'drawing tools offer stroke width');
 $('toolSize').value='3';$('toolSize').dispatchEvent(new window.Event('change'));equal(app.state.size,21,'stroke width converts to the PDF drawing parameter');
 await app.activate('freetext');check(!hidden('toolFont'),'text comments show font controls');
 await group('View');await app.activate('search');check(!hidden('searchquery')&&hidden('toolFont')&&hidden('toolColor'),'search exposes only search controls');
 await $('dockTools').onclick();await pause();check(app.state.paneDocked,'right docking remains available');
 await group('Annotate');await app.activate('stamp');check(app.state.settingsOpen&&!hidden('toolFont'),'pinned stamp opens its contextual settings');
 $('main').dispatchEvent(new window.Event('pointerdown',{bubbles:true}));check(!app.state.settingsOpen&&app.state.paneDocked,'outside pointer closes settings and retains icon dock');

 // Action dialogs carry font choices instead of relying on a permanent settings panel.
 await group('Edit');const watermark=app.activate('watermark');await until(()=>$('dialogFont'),'watermark font dialog');
 equal($('dialogFont').value,'Georgia','watermark dialog begins with selected font');equal($('dialogFont').options.length,30,'watermark offers the whole font list');
 $('dialogFont').value='Consolas';$('modalform').elements.namedItem('text').value='UI REFRESH';
 $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await watermark;
 equal(app.state.font,'Consolas','approved watermark stores its chosen font');check(text(app).includes('UI REFRESH'),'contextual watermark dialog still creates searchable PDF text');
 const signature=app.activate('signature');await until(()=>$('dialogFont'),'signature font dialog');equal($('dialogFont').value,'Consolas','typed signatures offer font choice');$('modalcancel').click();await signature;
 const before=app.state.bytes;const cancel=app.activate('header');await until(()=>$('dialogFont'),'header font dialog');$('dialogFont').value='Arial';$('modalcancel').click();await cancel;
 equal(app.state.bytes,before,'cancelling appearance dialog leaves PDF unchanged');equal(app.state.font,'Consolas','cancelled font choice is not committed');

 // The latest document still recovers through a fresh app instance.
 await app.local.flush();await context.close();context=await boot();({app,$,window}=context);
 equal(app.tabs.length,2,'refreshed app recovers both open PDFs');check(text(app).includes('UI REFRESH'),'refreshed app recovers document edits');
 equal(app.state.font,'Consolas','contextual font selection recovers');
 const healthy=await app.local.store.getDocument(bid);
 await $('homeBtn').onclick();await until(()=>window.document.body.classList.contains('home-visible')&&$('recentDocuments').querySelectorAll('img').length===2,'recovered Home');await pause();
 await app.closeTab(bid);await until(()=>$('recentDocuments').querySelectorAll('.recent-state').length===1,'closed badge updates');
 check(window.document.body.classList.contains('home-visible'),'closing active tab from Home keeps Home visible');
 await app.closeTab(aid);await until(()=>$('recentDocuments').querySelectorAll('img').length===2&&!$('recentDocuments').querySelector('.recent-state'),'all tabs closed Home');
 equal(app.tabs.length,0,'all document tabs can close from Home');check($('recentEmpty').hidden,'closed documents still have recent cards');
 check($('saveBtn').disabled,'no-document state disables Save');
 const broken={...healthy,id:'broken',updatedAt:Date.now(),snapshot:{...healthy.snapshot,name:'Broken.pdf',bytes:new Uint8Array([1,2,3]),original:new Uint8Array([1,2,3])}};
 await app.local.store.commit({documents:[broken]});await $('homeBtn').onclick();
 await until(()=>$('recentDocuments').children.length===3&&$('recentDocuments').getAttribute('aria-busy')==='false','damaged preview fallback');await pause();
 const brokenCard=[...$('recentDocuments').children].find(card=>card.dataset.recentId==='broken');
 check(brokenCard.textContent.includes('Preview unavailable'),'damaged thumbnail has a truthful fallback');
 equal($('recentDocuments').querySelectorAll('img').length,2,'damaged preview leaves healthy previews intact');
 await brokenCard.querySelector('button').onclick();await until(()=>$('toast').textContent.includes('Unable to resume'),'failed Resume');await pause();
 equal(app.tabs.length,0,'failed Resume does not create a broken tab');check(window.document.body.classList.contains('home-visible'),'failed Resume preserves Home');
 const extra=Array.from({length:7},(_,i)=>({...healthy,id:'extra-'+i,updatedAt:Date.now()+i,snapshot:{...healthy.snapshot,name:'Extra '+i+'.pdf'}}));
 await app.local.store.commit({documents:extra});await $('homeBtn').onclick();
 await until(()=>$('recentDocuments').children.length===6&&$('recentDocuments').getAttribute('aria-busy')==='false','bounded recent previews');await pause();
 equal($('recentDocuments').querySelectorAll('img').length,6,'recent thumbnail work is capped at six documents');
 check($('recentSummary').textContent.startsWith('10 locally saved documents'),'library summary includes documents beyond the recent grid');
 await context.close();globalThis.indexedDB=null;context=await boot();({app,$,window}=context);
 equal($('recentEmpty').querySelector('strong').textContent,'Local library unavailable','unavailable storage has a Home explanation');
 check(!$('recentEmpty').hidden&&$('recentDocuments').getAttribute('aria-busy')==='false','unavailable Home is not stuck loading');
 await app.newDocument();check(app.state.doc&&!$('saveBtn').disabled,'manual PDF work remains available without local storage');
 console.log('pdfpro UI refresh: '+assertions+' assertions passed in test DOM with simulated IndexedDB and real PDF thumbnails.');
}finally{if(context)await context.close()}
