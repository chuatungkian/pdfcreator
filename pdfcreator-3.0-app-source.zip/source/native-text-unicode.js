/* Preserve the actual Unicode supplied to MuPDF's native PDF text writer.
 * Subset fonts may omit their own cmap, or map a glyph to a different character.
 * MuPDF 1.28.1 writes Identity-H glyph IDs and names fonts F0, F1, ... in
 * first-use order (source/pdf/pdf-device.c). Never infer text from those IDs.
 */
import {mupdf} from './engine.js';
const failure=()=>Error('The original font cannot preserve this text reliably. Your PDF has not been changed. Choose another font or use Add text.');
const hex=value=>value.toString(16).padStart(4,'0');
function unicodeHex(value){return String.fromCodePoint(value).split('').map(c=>hex(c.charCodeAt(0))).join('')}
function cmap(entries){
 const lines=['/CIDInit /ProcSet findresource begin','12 dict begin','begincmap','/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def','/CMapName /PDFCreatorTextUnicode def','/CMapType 2 def','1 begincodespacerange','<0000> <ffff>','endcodespacerange'];
 const rows=[...entries].sort((a,b)=>a[0]-b[0]);
 for(let i=0;i<rows.length;i+=100){const chunk=rows.slice(i,i+100);lines.push(chunk.length+' beginbfchar',...chunk.map(([gid,unicode])=>'<'+hex(gid)+'> <'+unicodeHex(unicode)+'>'),'endbfchar')}
 return [...lines,'endcmap','CMapName currentdict /CMap defineresource pop','end','end'].join('\n');
}
export function preserveNativeTextUnicode(bytes,glyphs){
 const fonts=new Map();let expected='';
 for(const {font,gid,unicode}of glyphs){
  if(!Number.isInteger(gid)||gid<0||gid>65535||!Number.isInteger(unicode)||unicode<0||unicode>0x10ffff||unicode>=0xd800&&unicode<=0xdfff)throw failure();
  let row=fonts.get(font.pointer);if(!row){row={name:font.getName(),map:new Map()};fonts.set(font.pointer,row)}
  if(row.map.has(gid)&&row.map.get(gid)!==unicode)throw failure();row.map.set(gid,unicode);expected+=String.fromCodePoint(unicode);
 }
 const doc=mupdf.Document.openDocument(bytes,'application/pdf').asPDF();let page,result;
 try{
  page=doc.loadPage(0);const resources=page.getObject().getInheritable('Resources').get('Font'),maps=new Map();let index=0;
  for(const row of fonts.values()){
   const font=resources.get('F'+index++);if(!font.isDictionary())throw failure();
   if(font.get('Encoding').asName()!=='Identity-H')continue;
   if(font.get('Subtype').asName()!=='Type0')throw failure();
   const key=font.isIndirect()?font.asIndirect():font.pointer;let item=maps.get(key);
   // Helvetica/NimbusSans and other aliases may share one font-program resource.
   // Check its first name once, then merge every alias's actual character uses.
   if(!item){if(font.get('BaseFont').asName()!==row.name)throw failure();item={font,map:new Map()};maps.set(key,item)}
   for(const [gid,unicode]of row.map){if(item.map.has(gid)&&item.map.get(gid)!==unicode)throw failure();item.map.set(gid,unicode)}
  }
  for(const {font,map}of maps.values()){const stream=doc.addStream(cmap(map),{});try{font.put('ToUnicode',stream)}finally{stream.destroy()}}
  const buffer=doc.saveToBuffer('garbage=2,compress');try{result=buffer.asUint8Array().slice()}finally{buffer.destroy()}
 }finally{page?.destroy();doc.destroy()}
 // Reopen before any source redaction: font caches and rendered appearance must
 // agree with the exact characters that the user will reopen in Direct edit.
 const check=mupdf.Document.openDocument(result,'application/pdf').asPDF();let checkPage,device,actual='';
 try{
  checkPage=check.loadPage(0);device=new mupdf.Device({fillText(text,ctm,space){try{text.walk({showGlyph(font,matrix,gid,unicode){if(unicode<0)throw failure();actual+=String.fromCodePoint(unicode)}})}finally{text.destroy();space.destroy()}}});
  checkPage.runPageContents(device,mupdf.Matrix.identity);device.close();if(actual!==expected)throw failure();
 }finally{device?.destroy();checkPage?.destroy();check.destroy()}
 return result;
}
