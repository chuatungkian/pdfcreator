/* Workspace history, form assistance and export inspection. AGPL-3.0-or-later. */
import {mupdf,openPDF} from './engine.js';
import {documentFormFields,pageFormFields} from './pdf-form-fields.js';
export const cleanTags=value=>[...new Set((Array.isArray(value)?value:String(value||'').split(',')).map(s=>String(s).trim().slice(0,40)).filter(Boolean))].slice(0,12);
export function historyEntry(state,label=state.changeLabel||'Opened document'){
 return {bytes:state.bytes,page:state.page,label:String(label).slice(0,200),time:state.changeTime||Date.now()};
}
export function addCheckpoint(state,name){
 name=String(name||'').trim().slice(0,100);if(!name)throw Error('Enter a checkpoint name.');
 const checkpoints=state.checkpoints||[],bytes=checkpoints.reduce((n,c)=>n+c.bytes.length,0)+state.bytes.length;
 if(checkpoints.length>=10||bytes>100*1048576)throw Error('Checkpoint limit reached (10 copies or 100 MB). Remove an older checkpoint first.');
 const record={...historyEntry(state,name),id:globalThis.crypto.randomUUID(),name,marks:structuredClone(state.marks||[])};state.checkpoints=[...checkpoints,record];return record;
}
export function fieldIssues(field){
 const issues=[],value=field.value,empty=field.type==='checkbox'?!field.checked:field.type==='radiobutton'?(!value||value==='Off'):Array.isArray(value)?!value.length:!String(value??'').trim();
 if(field.flags&2&&empty)issues.push('Required field is empty');
 if(field.type==='text'&&!field.password&&value){
  const size=field.style.size;if(size>0){let font;try{font=new mupdf.Font(/cour/i.test(field.style.resource)?'Courier':/times|tiro/i.test(field.style.resource)?'Times-Roman':'Helvetica');const width=Math.max(1,field.rect[2]-field.rect[0]-4),height=Math.max(1,field.rect[3]-field.rect[1]-4),lines=String(value).split(/\r\n?|\n/);let count=0,tooWide=false;
   for(const line of lines){let advance=0,wrapped=1;for(const c of line){const glyph=font.encodeCharacter(c.codePointAt(0));advance+=glyph?font.advanceGlyph(glyph)*size:size;if(field.multiline&&advance>width){wrapped++;advance=0}}count+=wrapped;if(advance>width)tooWide=true}
   if(tooWide||count*size*(field.multiline?1.2:1)>height)issues.push('Text may overflow — review its appearance');
  }catch{issues.push('Text fit needs visual review')}finally{font?.destroy()}}
 }
 return issues;
}
export function formReport(doc){return documentFormFields(doc).map(field=>({...field,issues:fieldIssues(field)}))}
const point=(x,y,m)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];
export function detectFormAreas(doc,index){
 const page=doc.loadPage(index),bounds=page.getBounds(),existing=pageFormFields(doc,index),found=[];let device;
 const offer=(rect,type)=>{
  rect=[Math.max(bounds[0]+2,rect[0]),Math.max(bounds[1]+2,rect[1]),Math.min(bounds[2]-2,rect[2]),Math.min(bounds[3]-2,rect[3])];const w=rect[2]-rect[0],h=rect[3]-rect[1];
  if(w<14||h<10||w>bounds[2]-bounds[0]-12||h>180||existing.some(f=>overlap(f.rect,rect)>.5)||found.some(f=>overlap(f.rect,rect)>.8))return;
  found.push({rect,type,label:'Detected '+type+' '+(found.length+1)});
 };
 try{device=new mupdf.Device({strokePath(path,stroke,ctm,space,colour,alpha){if(alpha<.1||stroke.getLineWidth()>4)return;let sub=[],curved=false;const finish=closed=>{if(curved){sub=[];curved=false;return}if(closed&&sub.length>=4){const xs=sub.map(p=>p[0]),ys=sub.map(p=>p[1]),r=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)];if(sub.every(p=>Math.abs(p[0]-r[0])<1||Math.abs(p[0]-r[2])<1)&&sub.every(p=>Math.abs(p[1]-r[1])<1||Math.abs(p[1]-r[3])<1))offer(r,'box')}
   else if(sub.length===2&&Math.abs(sub[0][1]-sub[1][1])<1&&Math.abs(sub[0][0]-sub[1][0])>=30)offer([Math.min(sub[0][0],sub[1][0]),sub[0][1]-17,Math.max(sub[0][0],sub[1][0]),sub[0][1]-1],'underline');sub=[];curved=false};
  path.walk({moveTo(x,y){finish(false);sub.push(point(x,y,ctm))},lineTo(x,y){sub.push(point(x,y,ctm))},curveTo(){curved=true},closePath(){finish(true)}});finish(false);
 }});page.runPageContents(device,mupdf.Matrix.identity);device.close();return found.slice(0,200)}finally{device?.destroy();page.destroy()}
}
function overlap(a,b){const area=Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]));return area/Math.max(1,Math.min((a[2]-a[0])*(a[3]-a[1]),(b[2]-b[0])*(b[3]-b[1])))}
export function exportReport(bytes,marks=[]){let doc;try{doc=openPDF(bytes);const fields=formReport(doc),required=fields.filter(f=>f.issues.some(i=>i.startsWith('Required'))),overflow=fields.filter(f=>f.issues.some(i=>i.startsWith('Text')));return {pages:doc.countPages(),bytes:bytes.length,fields:fields.length,required,overflow,pendingRedactions:marks.length}}finally{doc?.destroy()}}
