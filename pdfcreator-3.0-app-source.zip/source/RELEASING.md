# Publishing PDFCreator

Each updated app commit pushed to `chuatungkian/pdfcreator` must increase the patch version by one: 3.0.2, 3.0.3, 3.0.4, and so on. `package.json` is the single version source; About, the app API and the generated `version.json` read it. A unique build ID is also generated on each build.

1. Read the latest `main` commit and its `version.json` from the repository. Preserve any newer work.
2. Run `node release-version.mjs --from <published-version>` in the preferred app source directory. This reserves the next patch; repeating it for the same publication does not increment again.
3. Build the staged release with `node build.mjs <release-directory>`. Rebuilding keeps the reserved patch number.
4. Run the relevant source and compiled tests and `release-alignment-test.mjs` against the staged release. Run `node release-version.mjs --verify-from <published-version>` before publishing.
5. Recheck the remote head/version, then publish the matching HTML aliases, source kit and version manifest atomically. Use a non-forced branch update with the expected previous head. Recheck all published blob hashes and deployment status.
6. Regenerate the offline package from the verified published files. Keep the user's existing `pdfpro.html` path and never modify their browser project database.

Hosted and downloaded copies check a tiny public manifest after startup and every five minutes when online, including inactive tabs. A browser may throttle or suspend background pages; a due check runs on focus, resume, page restoration or reconnection. Hosted copies check their deployment's own `version.json`; file copies check only the official repository manifest. Checks upload no PDF data and do not reload automatically. File copies offer an explicit download; users retain their local projects by replacing the HTML at the same location.
