/* Home shortcut removal, independent activation and persisted preferences. */
import assert from 'node:assert/strict';
import {boot} from './experience-test-env.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import {ToolPreferences} from './tool-preferences.js';
let options={},bootCount=0;if(process.argv.includes('--compiled')){const html=fs.readFileSync(path.join(process.env.PDFCREATOR_RELEASE_DIR||'../../outputs','index.html'),'utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64'))),file=path.resolve('../../tmp/home-tools-compiled.mjs');fs.writeFileSync(file,assets.app);options={moduleURL:pathToFileURL(file).href,assets}}
const bootHere=()=>boot({...options,...options.moduleURL?{moduleURL:options.moduleURL+'?boot='+bootCount++}:{}});
let count=0,context;const check=(v,l)=>{count++;assert.ok(v,l)},equal=(a,b,l)=>{count++;assert.deepEqual(a,b,l)};
try{
 let saves=0;const prefs=new ToolPreferences([{id:'text'},{id:'image'}],save=>{if(save)saves++});prefs.restore({favourites:['text','image'],recent:['text']});check(prefs.remove('text'),'removes pinned and recent tool');equal(prefs.snapshot().favourites,['image'],'other pins retained');equal(prefs.recent,[],'removed tool does not remain as recent');equal(saves,1,'single persisted preference update');check(!prefs.remove('invalid'),'invalid tool ignored');check(!prefs.remove('text'),'already removed tool ignored');equal(saves,1,'no extra writes for no-op');prefs.record('text');equal(prefs.recent,['text'],'later use can restore a recent shortcut');
 context=await bootHere();let {app,$,window}=context;app.toolPreferences.restore({favourites:['text','image'],recent:['text','highlight']});
 const remove=id=>document.querySelector('[data-remove-quick-tool="'+id+'"]');const launch=id=>document.querySelector('[data-quick-tool="'+id+'"]');
 check(launch('text').disabled,'PDF shortcut disabled without a document');check(!remove('text').disabled,'remove remains available without a PDF');check(remove('text').getAttribute('aria-label').includes('Add text'),'remove has descriptive accessible name');check(!remove('text').closest('[data-quick-tool]'),'remove is not nested inside launcher');equal(document.querySelectorAll('.quick-tool-item').length,3,'favourite/recent tools are deduplicated');
 remove('text').click();check(!launch('text'),'pinned and recent shortcut disappears immediately');check(!app.toolPreferences.favourites.includes('text'),'favourite removed');check(!app.toolPreferences.recent.includes('text'),'recent entry removed too');equal(document.activeElement.dataset.removeQuickTool,'image','focus moves to next remove control');check(!!launch('image')&&!!launch('highlight'),'other shortcuts retained');equal(app.state.doc,null,'removal never opens or edits a PDF');
 await app.local.flush();await context.close();context=null;context=await bootHere();({app,$,window}=context);check(!launch('text'),'removed shortcut stays removed after restart');check(!app.toolPreferences.favourites.includes('text'),'unpin persists');
 remove('highlight').click();check(!launch('highlight'),'recent-only shortcut can be removed');remove('image').click();check(!document.querySelector('.quick-tool-item'),'last shortcut removed');check($('quickTools').textContent.includes('Pin tools'),'empty state restored');equal(document.activeElement.textContent,'Find and pin tools','focus returns to discovery control');
 $('functionSearchBtn').click();document.querySelector('[data-pin-function="text"]').click();check(!!launch('text'),'search can pin the tool again');$('closeFunctionSearch').click();
 await app.createDemo();await $('homeBtn').onclick();const bytes=app.state.bytes,owner=app.activeTabId,history=app.state.undo.length;await launch('text').onclick();equal(app.state.tool,'text','launcher still activates tool');await $('homeBtn').onclick();remove('text').click();equal(app.activeTabId,owner,'removal retains active document');equal(app.state.bytes,bytes,'removal retains exact PDF bytes');equal(app.state.undo.length,history,'removal does not create PDF history');await app.local.flush();await context.close();context=null;
 console.log('PDFCreator Home tools: '+count+' assertions passed for remove/unpin, keyboard focus, persistence and independent PDF activation.');
}finally{if(context)await context.close()}
