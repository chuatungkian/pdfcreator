/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {functionCatalogue,matchFunctions} from './function-search.js';
let context;
try{
 const index=functionCatalogue({View:[['search','Find text'],['findreplace','Find and replace']],Edit:[['findreplace','Find and replace'],['optimize','Optimise PDF'],['reorder','Page organiser']]});equal(index.filter(e=>e.id==='findreplace').length,1,'shared tools appear once');equal(matchFunctions(index,'edit find replace')[0].id,'findreplace','shared tool matches secondary group too');equal(matchFunctions(index,'compress')[0].id,'optimize','compression alias');equal(matchFunctions(index,'organize')[0].id,'reorder','American/British spelling matching');equal(matchFunctions(index,'FIND TEXT')[0].id,'search','case-insensitive exact label ranked first');equal(matchFunctions(index,'zzxyq').length,0,'no unrelated matches');
 context=await boot();const {app,$,window,fileSelections}=context;
 const search=()=>{$('functionSearchBtn').click();check(!!$('functionSearchPopup'),'search popup opens')},query=value=>{$('functionSearchQuery').value=value;$('functionSearchQuery').dispatchEvent(new window.Event('input',{bubbles:true}))},result=id=>$('functionSearchResults').querySelector(`[data-function="${id}"]`);
 equal($('about').textContent,'?','About displays question mark');equal($('about').getAttribute('aria-label'),'About & source','About retains accessible name');check(!!$('functionSearchBtn').querySelector('svg circle'),'search button displays magnifier');equal($('functionSearchBtn').nextElementSibling.id,'theme','magnifier is beside dark theme');
 search();equal($('functionSearchBtn').getAttribute('aria-expanded'),'true','search button reports expanded');equal(document.activeElement,$('functionSearchQuery'),'query receives focus');equal($('functionSearchResults').querySelectorAll('[data-function]').length,85,'all 80 distinct tools plus app actions indexed');check(result('directedit').disabled,'document tool disabled without PDF');check(!result('createNew').disabled&&!result('appLibrary').disabled,'creation/library available on Home');query('direct edit');result('directedit').click();check(!$('modalform')&&!!$('functionSearchPopup'),'disabled result never launches a PDF tool');query('<script>');check($('functionSearchStatus').textContent.includes('No matching'),'empty result message');check(!$('functionSearchPopup').querySelector('script'),'query cannot inject markup');
 query('');$('functionSearchQuery').dispatchEvent(new window.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true,cancelable:true}));equal(document.activeElement.dataset.function,'createNew','Down focuses first enabled result');document.activeElement.dispatchEvent(new window.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true,cancelable:true}));equal(document.activeElement.dataset.function,'createWord','result keyboard navigation');const space=new window.KeyboardEvent('keydown',{key:' ',bubbles:true,cancelable:true});document.activeElement.dispatchEvent(space);check(!space.defaultPrevented,'Space retains native button activation');document.dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));check(!$('functionSearchPopup'),'Escape closes');equal(document.activeElement,$('functionSearchBtn'),'Escape restores trigger focus');
 const key=new window.KeyboardEvent('keydown',{key:'k',ctrlKey:true,bubbles:true,cancelable:true});document.dispatchEvent(key);check(key.defaultPrevented&&!!$('functionSearchPopup'),'Ctrl+K opens function search');$('functionSearchBtn').click();check(!$('functionSearchPopup'),'magnifier toggles popup closed');search();document.body.dispatchEvent(new window.MouseEvent('pointerdown',{bubbles:true}));check(!$('functionSearchPopup'),'outside click dismisses search');
 search();query('create');await result('appCreate').onclick();check(app.state.group==='Create'&&app.state.paneOpen&&!$('modalform'),'search opens Create pane');check(!$('functionSearchPopup'),'launch closes search');
 search();query('new pdf');const creation=result('createNew').onclick();await until(()=>$('createName'),'New PDF result');$('modalcancel').click();await creation;check(!app.state.doc,'cancelled creation preserves empty workspace');
 const pdf=await fixture(app,'FUNCTION SEARCH');fileSelections.push([file('Search.pdf',pdf)]);search();query('open pdf');await result('createPDF').onclick();equal(app.state.name,'Search.pdf','search opens existing PDF through file chooser');await $('next').onclick();const bytes=app.state.bytes,owner=app.activeTabId,history=app.state.undo.length;
 search();query('direct edit');$('functionSearchQuery').dispatchEvent(new window.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));await until(()=>app.state.tool==='directedit','Enter launches exact result');await pause();equal(app.state.group,'Edit','search selects correct group');check(app.state.paneOpen,'matching tool pane is shown');equal(app.state.page,1,'function search retains viewed page');equal(app.state.bytes,bytes,'placement-tool launch does not change PDF');equal(app.activeTabId,owner,'function launch retains active tab');
 search();query('direct edit');await result('directedit').onclick();equal(app.state.tool,'directedit','searching active tool keeps it selected');search();query('hyperlink');await result('link').onclick();equal(app.state.tool,'link','alias launches hyperlink tool');
 search();query('rotate');await result('rotate').onclick();equal((await app.PDFLib.PDFDocument.load(app.state.bytes)).getPage(1).getRotation().angle,90,'action result runs on current PDF page');equal(app.state.undo.length,history+1,'action remains undoable');await $('undo').onclick();equal(app.state.bytes,bytes,'undo restores source after search action');
 search();query('delete page');const deletion=result('delete').onclick();await until(()=>$('modaltitle')?.textContent.includes('Delete page'),'destructive result retains confirmation');equal(app.state.bytes,bytes,'delete is not applied before confirmation');$('modalcancel').click();await deletion;
 const dark=document.body.classList.contains('dark');search();query('dark mode');await result('appTheme').onclick();equal(document.body.classList.contains('dark'),!dark,'theme action works');equal(app.state.bytes,bytes,'theme leaves PDF unchanged');
 search();query('contact');const about=result('appAbout').onclick();await until(()=>$('modaltitle'),'About search result');check($('modalform').textContent.includes('Built by Tung Kian.'),'search opens existing About content');$('functionSearchBtn').click();check(!$('functionSearchPopup'),'active modal blocks search opening');$('modalcancel').click();await about;
 const directAbout=$('about').onclick();await until(()=>$('modaltitle'),'question-mark About');equal($('modaltitle').textContent,'PDFCreator','question mark retains About action');$('modalcancel').click();await directAbout;
 await $('homeBtn').onclick();search();query('highlight');await result('highlight').onclick();check(app.state.tool==='highlight'&&!document.body.classList.contains('home-visible'),'document result resumes active PDF from Home');equal(app.activeTabId,owner,'Home result uses active PDF');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator function search: '+assertions+' assertions passed with controlled UI and native PDF actions.');
}finally{if(context)await context.close()}
