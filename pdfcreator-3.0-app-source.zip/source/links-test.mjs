/* Native PDF links and controlled viewer interactions. No browser or user files are opened. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {webLink,pageLink,inspectLinks,writeLink} from './pdf-links.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 for(const [input,expected]of [[' example.com/a b ','https://example.com/a%20b'],['https://example.com/日本語','https://example.com/%E6%97%A5%E6%9C%AC%E8%AA%9E'],['name@example.com','mailto:name@example.com'],['http://localhost:8080/','http://localhost:8080/'],['mailto:a@example.com?subject=Hello','mailto:a@example.com?subject=Hello']])equal(webLink(input),expected,'normalised destination');
 for(const input of ['https://','not a url','javascript:alert(1)','data:text/html,test','file:///secret','mailto:','https://example.com\n/bad']){assertions++;assert.throws(()=>webLink(input),/Enter|Only|invalid/)}
 equal(pageLink(2,3),'#page=2','internal page destination');for(const value of [0,4,1.2,'bad']){assertions++;assert.throws(()=>pageLink(value,3),/Choose a page/)}
 for(const rotation of [0,90,180,270]){
  const doc=new app.Engine.mupdf.PDFDocument();doc.insertPage(-1,doc.addPage([10,20,330,440],rotation,{},''));doc.insertPage(-1,doc.addPage([0,0,300,400],0,{},''));
  const rect=[30,40,180,90];writeLink(doc,0,rect,webLink('example.com/日本語'));writeLink(doc,0,[30,110,180,155],pageLink(2,2));let buffer=doc.saveToBuffer('garbage=4,compress');const bytes=buffer.asUint8Array().slice();buffer.destroy();doc.destroy();const reopened=app.Engine.openPDF(bytes);
  const links=inspectLinks(reopened,0);equal(links.length,2,'native links round-trip at '+rotation);check(links[0].rect.every((v,i)=>Math.abs(v-rect[i])<.01),'view coordinates survive '+rotation);equal(links[0].href,webLink('example.com/日本語'),'Unicode destination survives');equal(links[1].target,1,'internal destination resolves');
  writeLink(reopened,0,links[0].rect,webLink('other.example'),links[0]);equal(inspectLinks(reopened,0).find(link=>link.href)?.href,'https://other.example/','editing link updates URI');const current=inspectLinks(reopened,0);writeLink(reopened,0,current[0].rect,null,current[0]);equal(inspectLinks(reopened,0).length,1,'removal deletes only selected link');reopened.destroy();
 }
 const fixture=await app.PDFLib.PDFDocument.create();for(let i=0;i<3;i++)fixture.addPage([595,842]).drawText('LINK PAGE '+(i+1),{x:40,y:740});await app.openFiles([file('Links.pdf',await fixture.save())]);app.state.fit=false;app.state.zoom=1;await app.render();const owner=app.activeTabId,overlay=$('overlay');
 function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0});Object.defineProperties(event,{pointerId:{value:1},isPrimary:{value:true}});overlay.dispatchEvent(event)}
 function drag(){pointer('pointerdown',50,100);pointer('pointermove',250,140);pointer('pointerup',250,140)}
 const submit=()=> $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
 await app.activate('link');const original=app.state.bytes;drag();await until(()=>$('answer'),'link dialogue');$('answer').value='https://';submit();await pause();check(!!$('modalform')&&$('modalerror').textContent.includes('Enter'),'invalid URL stays editable in dialogue');equal(app.state.bytes,original,'invalid link does not rewrite PDF');$('answer').value='example.com/docs';submit();await until(()=>app.state.bytes!==original&&!app.state.abort,'link saved');await pause();
 equal(inspectLinks(app.state.doc,0)[0].href,'https://example.com/docs','bare hostname becomes usable HTTPS link');equal(app.state.tool,'link','link tool persists');check(!!overlay.querySelector('.link-placement-outline'),'saved link area remains visible while adding');
 await app.activate('link');equal(app.state.tool,'select','Done/same-feature returns to following links');let anchor=overlay.querySelector('.pdf-link');check(anchor?.tagName==='A','saved links have native clickable anchor');equal(anchor.href,'https://example.com/docs','click target matches PDF destination');equal(anchor.target,'_blank','website opens separately');check(anchor.rel.includes('noopener')&&anchor.rel.includes('noreferrer'),'external navigation isolates page');equal(anchor.style.left,'50px','click area starts at selected left');equal(anchor.style.width,'200px','click area matches selected width');
 let badge=overlay.querySelector('.pdf-link-badge');badge.click();await until(()=>$('linkType'),'edit link dialogue');equal($('answer').value,'https://example.com/docs','edit shows current destination');$('answer').value='name@example.com';const beforeEdit=app.state.bytes;submit();await until(()=>app.state.bytes!==beforeEdit&&!app.state.abort,'link edited');equal(inspectLinks(app.state.doc,0)[0].href,'mailto:name@example.com','edited email link stored');
 // Internal page links work in the continuous viewer without opening a website.
 await app.activate('link');drag();await until(()=>$('linkType'),'internal link dialogue');$('linkType').value='page';$('linkType').onchange();$('linkPage').value='3';const beforeInternal=app.state.bytes;submit();await until(()=>app.state.bytes!==beforeInternal&&!app.state.abort,'page link saved');await app.activate('link');
 const internal=inspectLinks(app.state.doc,0).find(link=>link.target===2);check(!!internal,'internal link written as PDF destination');anchor=[...overlay.querySelectorAll('.pdf-link')].find(node=>node.title==='Page 3');anchor.dispatchEvent(new window.MouseEvent('click',{bubbles:true,cancelable:true}));await until(()=>app.state.page===2&&document.getElementById('main').scrollTop===app.continuousPages.records[2].top,'internal page navigation');equal($('pageinput').value,'3','internal link updates page toolbar');equal($('main').scrollTop,app.continuousPages.records[2].top,'internal link scrolls to destination');
 await $('prev').onclick();await $('prev').onclick();badge=overlay.querySelector('.pdf-link-badge');badge.click();await until(()=>$('removePdfLink'),'remove control');const beforeRemove=app.state.bytes;$('removePdfLink').click();await until(()=>app.state.bytes!==beforeRemove&&!app.state.abort,'link removed');equal(inspectLinks(app.state.doc,0).length,1,'remove keeps other link');await $('undo').onclick();equal(inspectLinks(app.state.doc,0).length,2,'undo restores removed link');await $('redo').onclick();equal(inspectLinks(app.state.doc,0).length,1,'redo removes selected link');
 await app.local.flush();const finalBytes=app.state.bytes;await context.close();context=await boot();({app,$,window}=context);equal(app.activeTabId,owner,'link document recovers');equal(app.state.bytes,finalBytes,'native link bytes recover unchanged');equal(inspectLinks(app.state.doc,0).length,1,'recovered link remains a PDF link');check(!!$('overlay').querySelector('.pdf-link'),'recovered links are clickable');
 // Imported unsafe action URIs are represented but never used as browser hrefs.
 await app.editPDF('Unsafe fixture',doc=>{const page=doc.getPage(0),a=doc.context.obj({Type:'Annot',Subtype:'Link',Rect:[300,500,400,530],A:{S:'URI',URI:app.PDFLib.PDFString.of('javascript:alert(1)')}});page.node.addAnnot(doc.context.register(a))});const unsafe=[...$('overlay').querySelectorAll('.pdf-link')].find(node=>node.getAttribute('aria-disabled')==='true');check(!!unsafe,'unusable imported URI has explicit unavailable state');check(!unsafe.href.startsWith('javascript:'),'unsafe URI never becomes navigable href');unsafe.dispatchEvent(new window.MouseEvent('click',{bubbles:true,cancelable:true}));check($('toast').textContent.includes('Only HTTP'),'blocked URI reports why');
 await context.close();context=null;console.log('pdfpro links: '+assertions+' assertions passed with native PDF links, controlled DOM and simulated IndexedDB.');
}finally{if(context)await context.close()}
