/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {imageTargets} from './image-edit.js';
let context;
try{
 context=await boot();const {app,$,window,fileSelections}=context,PDF=app.PDFLib;
 const source=canvas.createCanvas(80,60),ctx=source.getContext('2d');ctx.fillStyle='#e08040';ctx.fillRect(0,0,80,60);ctx.fillStyle='#3050e0';ctx.fillRect(40,0,40,30);const png=source.toBuffer('image/png'),doc=await PDF.PDFDocument.create(),image=await doc.embedPng(png);for(let n=0;n<2;n++){const p=doc.addPage([500,600]);p.drawText('BODY REMAINS',{x:40,y:550,size:14});p.drawImage(image,{x:100,y:200,width:200,height:150})}await app.openFiles([file('Image editor.pdf',new Uint8Array(await doc.save({useObjectStreams:false})))]);app.state.fit=false;app.state.zoom=1;await app.render();
 const nativeBytes=app.state.bytes,pointer=(target,type,x,y)=>{const e=new window.MouseEvent(type,{bubbles:true,cancelable:true,button:0,clientX:x,clientY:y,altKey:true});Object.defineProperty(e,'pointerId',{value:8});target.dispatchEvent(e);return e},property=key=>document.querySelector(`[data-image-position="${key}"]`),crop=key=>document.querySelector(`[data-image-crop="${key}"]`),setting=key=>document.querySelector(`[data-image-setting="${key}"]`),apply=()=>document.querySelector('[data-image-apply]').onclick();
 const row=app.continuousPages.records[0];row.view.getBoundingClientRect=()=>({left:10,top:20,width:500,height:600,right:510,bottom:620});row.overlay.dispatchEvent(new window.MouseEvent('click',{bubbles:true,clientX:160,clientY:320}));await until(()=>$('imageInspector'),'normal click image');check(!!document.querySelector('.image-selection'),'normal viewer image click opens handles');equal(app.state.tool,'images','normal click automatically selects Edit images');equal(property('width').value,'200','existing image width shown');check(!!$('imageCropPreview'),'crop preview shown');equal(app.state.bytes,nativeBytes,'selection does not modify PDF');
 for(const key of ['opacity','brightness','contrast','saturation','hue','warmth'])check(!!setting(key),'appearance control '+key);
 crop('left').value='25';crop('left').dispatchEvent(new window.Event('input'));equal(property('width').value,'150','crop trims frame width');equal(property('x').value,'150','crop shifts frame to retained portion');setting('opacity').value='70';setting('opacity').dispatchEvent(new window.Event('input'));setting('brightness').value='15';setting('brightness').dispatchEvent(new window.Event('input'));setting('saturation').value='-40';setting('saturation').dispatchEvent(new window.Event('input'));property('x').value='70';await apply();check(!!$('imageInspector'),'properties reopen after apply');let target=imageTargets(app.state.doc,0)[0];check(Math.abs(target.rect[0]-70)<.01,'position saved');equal(target.settings.crop.left,.25,'crop saved');equal(target.settings.opacity,.7,'opacity saved');equal(target.settings.brightness,15,'brightness saved');equal(target.settings.saturation,-40,'saturation saved');equal(app.state.undo.length,1,'multiple draft adjustments apply in one undo step');check(text(app).includes('BODY REMAINS'),'image editing retains text');
 await $('undo').onclick();equal(app.state.bytes,nativeBytes,'undo restores exact source image and PDF');check(!$('imageInspector'),'undo clears stale image selection');await $('redo').onclick();check(imageTargets(app.state.doc,0)[0].settings.brightness===15,'redo restores appearance');
 await app.activate('select');await app.activate('images');equal(app.state.tool,'images','Edit images is an explicit persistent tool');check(document.querySelectorAll('.image-edit-target').length>=1,'clickable image targets present');await document.querySelector('.image-edit-target').onclick(new window.MouseEvent('click'));const beforeDrag=app.state.bytes,box=document.querySelector('.image-selection');pointer(box,'pointerdown',100,300);pointer(box,'pointermove',125,315);pointer(box,'pointerup',125,315);await until(()=>app.state.bytes!==beforeDrag&&!app.state.abort,'image move saved');check(Math.abs(imageTargets(app.state.doc,0)[0].rect[0]-95)<.02,'drag shifts image by pointer delta');equal(app.state.tool,'images','image edit mode persists after moving');
 const beforeResize=app.state.bytes,handle=document.querySelector('.image-resize');pointer(handle,'pointerdown',245,315);pointer(document.querySelector('.image-selection'),'pointermove',275,335);pointer(document.querySelector('.image-selection'),'pointerup',275,335);await until(()=>app.state.bytes!==beforeResize&&!app.state.abort,'resize saved');check(Math.abs(imageTargets(app.state.doc,0)[0].rect[2]-imageTargets(app.state.doc,0)[0].rect[0]-180)<.1,'resize handle updates width');
 const preview=$('imageCropPreview');preview.getBoundingClientRect=()=>({left:0,top:0,width:80,height:60,right:80,bottom:60});pointer(preview,'pointerdown',20,15);pointer(preview,'pointermove',60,45);pointer(preview,'pointerup',60,45);equal(+crop('left').value,25,'preview drag sets left crop');equal(+crop('right').value,25,'preview drag sets right crop');equal(+crop('top').value,25,'preview drag sets top crop');document.querySelector('[data-image-reset-crop]').click();equal(+crop('left').value,0,'crop reset available');
 const beforeDelete=app.state.bytes;await document.querySelector('[data-image-delete]').onclick();equal(imageTargets(app.state.doc,0).length,0,'Delete removes selected image');equal(app.state.tool,'images','delete leaves mode ready for another image');await $('undo').onclick();equal(app.state.bytes,beforeDelete,'undo restores deleted image');
 await app.activate('images');equal(app.state.tool,'select','same function toggles image editing off');
 // The Add image tool opens these same controls after placement and on old images.
 fileSelections.push([{name:'new.png',type:'image/png',arrayBuffer:async()=>new Uint8Array(png).buffer}]);await app.activate('image');const beforeAdd=app.state.bytes,overlay=$('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:500,height:600,right:500,bottom:600});pointer(overlay,'pointerdown',40,80);pointer(overlay,'pointermove',140,155);pointer(overlay,'pointerup',140,155);await until(()=>app.state.bytes!==beforeAdd&&!app.state.abort&&!!$('imageInspector'),'new image added with properties');equal(app.state.tool,'image','Add image stays selected');equal(imageTargets(app.state.doc,0).length,2,'new image added beside existing image');setting('contrast').value='25';setting('contrast').dispatchEvent(new window.Event('input'));setting('hue').value='45';setting('hue').dispatchEvent(new window.Event('input'));setting('warmth').value='30';setting('warmth').dispatchEvent(new window.Event('input'));await apply();target=imageTargets(app.state.doc,0).at(-1);equal(target.settings.contrast,25,'added image contrast editable');equal(target.settings.hue,45,'added image colour hue editable');equal(target.settings.warmth,30,'added image colour warmth editable');
 pointer($('imageInspector'),'pointerdown',0,0);equal(app.state.tool,'image','image controls do not deactivate tool');pointer(document.querySelector('.pdf-page-view'),'pointerdown',0,0);equal(app.state.tool,'image','PDF page remains working area');pointer($('main'),'pointerdown',600,600);equal(app.state.tool,'select','grey canvas click deactivates function');check(!$('imageInspector'),'outside click clears image properties');
 await app.activate('note');pointer($('panel'),'pointerdown',0,0);equal(app.state.tool,'note','tool pane controls preserve selected function');pointer($('pageToolbar'),'pointerdown',0,0);equal(app.state.tool,'note','page controls preserve selected function');pointer($('main'),'pointerdown',600,600);equal(app.state.tool,'select','outside click deactivates another placement function');
 await app.activate('images');await document.querySelector('.image-edit-target').onclick(new window.MouseEvent('click'));const savedBytes=app.state.bytes;await $('next').onclick();equal(app.state.page,1,'page navigation still works');check(!$('imageInspector'),'page change clears selection from previous page');equal(app.state.tool,'images','navigation preserves chosen tool');await $('undo').onclick();check(app.state.doc.countPages()===2,'undo retains document structure');await $('redo').onclick();
 $('pageinput').value='2';await $('pageinput').onchange({target:$('pageinput')});await app.activate('objects');const existing=[...document.querySelectorAll('.object-target')].find(b=>b.title==='Select Image');existing.onclick(new window.MouseEvent('click'));check(!!document.querySelector('.object-inspector [data-object=rotation]'),'Select objects retains rotation');check(!!document.querySelector('.object-inspector [data-action=duplicate]')&&!!document.querySelector('.object-inspector [data-align]'),'Select objects retains duplication and alignment');document.querySelector('[data-image-adjust]').click();check(!!$('imageInspector')&&!!setting('opacity'),'Select objects links to image adjustments');
 await app.local.flush();await context.close();context=await boot();equal(context.app.state.bytes,savedBytes,'edited image bytes recover locally');check(imageTargets(context.app.state.doc,0).some(t=>t.settings.hue===45),'image recipes recover across app instances');await context.close();context=null;
 console.log('PDFCreator image interactions: '+assertions+' assertions passed with native PDFs, pointer editing and local recovery.');
}finally{if(context)await context.close()}
