## Page organiser filename truncation — 16 November 2026

Long source filenames stay on one line and truncate with an ellipsis inside each page tile. Grid buttons and thumbnails shrink to the available tile width, preventing overlap and horizontal overflow in the compact organiser. Hover over a filename to see its full text; page buttons retain the full source filename in their accessible labels.

## PDFCreator 3.0.10 — 12 November 2026

Updated from the user-supplied standalone offline app. Build: `20261112T133033330Z-cb07c464`. The three HTML entry files are byte-identical to the uploaded app; `version.json` matches its embedded release metadata. The downloadable app source ZIP is reconstructed from its embedded source archive, with every entry verified against its recorded size and CRC32.

## PDFCreator 3.0.9

Local recovery for unfinished edits; responsive priority toolbars; per-page editing capability; attachment move/remove menus; and keyboard, focus and touch refinements. See the 3.0.9 section in README.txt for usage and validation.

## PDFCreator 3.0.8

Per-tab drafts, document-owned background OCR/compressed exports, steady top controls, target hover/overlap selection, live snapping guides, descriptive Undo/Redo and named appearance styles. Drafts and task results are kept in session memory; apply/use them before closing or updating. See the 3.0.8 section in README.txt for controls and validation.

Move attachment icons - 2 November 2026

In Read & select, drag a placed paperclip icon to move it within its PDF page. A destination preview follows the pointer; release to save its new position. A short click still opens the attachment preview/download menu. Movement preserves icon size and the original embedded file, stays inside the page bounds, and is one Undo step. Escape, scrolling, zoom changes or a cancelled pointer discard the drag. Unlock icons in Objects & layers before moving them.

Page attachment icons - 2 November 2026

Attachments are embedded inside the PDF. Use View > Attachments, choose a file (up to 50 MB), choose location, then click a PDF page to place its standard Paperclip icon. Nothing is embedded until the icon is placed. Done or Escape cancels placement. Existing embedded files without a page icon have a Place icon action. Filenames are kept unique so adding another file does not replace an earlier attachment.

In Read & select, click an icon for a local text or raster-image preview, Open PDF in a separate document tab, or Download. HTML, SVG and scripts are displayed as plain text. Other formats can be downloaded to open in an application on the device. Text previews show up to 1 MB; downloads retain the complete original file. No attachment is opened automatically. Icons remain in saved PDFs; external PDF viewer support for opening attachments varies. Move or delete an icon using Edit > Select objects or Objects & layers. Deleting an icon retains the file in the PDF attachment list. Adding a file and icon is one Undo step.

# PDFCreator

## Website update notifications — 1 November 2026

Hosted HTTP/HTTPS copies check a small same-origin version.json after startup and every five minutes when online, including inactive tabs. Downloaded file:// copies check the official repository manifest. No PDF/document data or credentials are sent. Browsers can throttle or suspend background pages; an overdue check runs when the page resumes, is restored, regains focus or reconnects. Heavy PDF jobs defer checking until idle; failed requests time out after eight seconds and retry with backoff. Checks do not open modal dialogues, steal focus, or reload automatically.

A new build shows Update now / Later. Later leaves an update badge and suppresses repeated banners for that build during this session. About & source (?) includes the embedded build ID and Check for updates. Only explicit Update now can reload. Apply your draft first through Keep editing, or confirm Discard draft and update. Running tasks and open merge/split workspaces must finish first. Applied PDFs, originals, retained history, open tabs and reading positions are saved locally before navigating to the same app path with a fresh build query. A failed local save keeps the app and draft open and offers a workspace ZIP backup; unapplied drafts are not included in that backup.

Deployment: use node build.mjs with the output directory. Every build embeds a unique release ID and emits a matching version.json. Deploy that manifest beside index.html, pdfcreator.html and pdfpro.html in one atomic release. Where hosting supports it, use Cache-Control: no-store for version.json and no-cache for HTML. The checker also bypasses browser caching and adds a fresh query to manifest requests and release reloads. Existing tabs that predate this checker need one initial refresh to install it. Downloaded offline copies require replacing their HTML file.

## Changes review scroll following — 1 November 2026

Changes review now follows the visible PDF page automatically while scrolling or using page navigation. Its page number, changed-page selection and Original/Current preview update together. Unchanged pages show Unchanged; Original mode follows each page without changing the working PDF. Opening review keeps the current reading position. Previous/Next still jumps between changed pages.

## Changes review — 1 November 2026

Open View > Changes review to compare the working PDF with its originally opened copy. Changed pages are marked in the page strip and page headings. Previous/Next and the page list navigate modified, added, removed and moved pages. Toggle Original/Current for read-only page previews or open the larger comparison. Retained edits have individual before/after views without restoring earlier versions. Save PDF > Export review also offers Review page changes before downloading; this returns to the panel without downloading until Save is chosen again.

Text-fit/reflow choices (feature 4) remain in Edit > Direct edit: Keep layout, Fit text into box, and Move following text in this column. Recognition buttons now use a pastel red background with visible hover/focus states.

Review is local and does not change document bytes or history. It checks rendered pages, text geometry, form values, comments and links; tiny visual differences and hidden PDF structures may need separate inspection. Page matching uses contents; repeated identical pages are paired by position. Undo history is bounded to 20 steps, and undone edits are excluded from retained edits. The original baseline survives local recovery.

## Editing workflow upgrade — 1 November 2026

Text boxes: in Edit > Select objects, resizing native text, added text and FreeText comments changes the container and wrapping without scaling font sizes. Boxes grow downward when needed, and Direct edit keeps the chosen width as words are added. Added text defaults to automatic growth; Fit text remains an explicit sizing choice. Mixed groups scale artwork while retaining text sizes. Growth that affects nearby content requires confirmation, and page-edge overflow requires moving or widening the box.

- **Live page preview:** typing, formatting, width and layout choices render a draft on the PDF page. Amber outlines mark nearby text/artwork affected; purple outlines show following text moving. Preview never writes document bytes or history. Cancel restores the original view; Apply uses the same preparation engine.
- **OCR correction:** expand **Review recognised words and source boxes**. Correct words individually, filter uncertain words, jump to the next uncertain word, and adjust source-lettering boxes by dragging/resizing or entering coordinates. **Match original appearance** compares the local Helvetica/Times/Courier families and emphasis against the source ink. Fonts/backgrounds remain estimates.
- **Object controls:** drag an empty page area to select fully enclosed objects; Shift/Ctrl/Cmd adds to the selection. Group/Ungroup persists PDFCreator group membership in the PDF without flattening members. Arrange objects relative to selection bounds, the first selected object or the page; distribute spacing and match widths/heights/sizes. Grouped copies remain grouped. Replacing a text member can make that member independent.
- **Text layout:** choose **Keep layout**, **Fit text into box**, or **Move following text in this column**. Fit reduces the requested sizes only as needed, with a 4 pt lower limit. Column reflow shifts following text on the same page, including pulling it up after deletion. It stops at artwork/table rules, another column and the page edge; rotated text can use Fit. Reflowing additional OCR regions requires confirmation because their words and formatting are reconstructed from recognition.

## Direct edit for outlined and scanned text — 1 November 2026

Choose **Edit → Direct edit**. A page with drawings or scans and no editable text is recognised automatically. On mixed pages or later pages, choose **Recognise text for editing** at the top right of the page. Recognition uses the embedded English engine and leaves the PDF unchanged.

Click a recognised region to review and change its words, font, size, colour and emphasis in the same editor. Applying replaces the selected visible lettering with editable, searchable PDF text. Other recognised regions remain selectable, and one Undo restores the exact previous PDF. The replacement supports normal Direct edit afterwards. Table columns are separated at large gaps; the surrounding page is retained.

Recognition can misread words. Fonts, spacing and solid background colours are estimates; complex backgrounds need careful visual review. This is region-based English editing, not reconstruction of an original Word document. Searchable OCR remains available separately and retains the original visible page.

## Confirm overlapping text edits — 1 November 2026

When Direct edit formatting or reflow would overlap nearby text, the app asks **Apply edit with overlapping text?** Choose **Apply anyway** to save the edit, or **Cancel** to keep your formatted draft open. Nearby text stays in place and can be obscured by the new layout. Each edit requires its own confirmation, and one Undo restores the original PDF.

## Multiple object selection and resizable panes — 1 November 2026

In **Edit → Select objects**, use Ctrl/Cmd-click or Shift-click to add or remove objects on the same page. The properties pane also offers **Click to add/remove objects**. Each selected object is outlined. Move, resize, rotate, align, duplicate or delete the selection together; each applied group operation is one undo step. Select a content group or its internal text separately to avoid changing the same content twice.

Object properties now starts at 260 px, with a compact two-column geometry grid and horizontal action buttons. Opening an object from **Objects & layers** provides a **← Back** button in the pane header. Back preserves unapplied changes until you choose to keep editing or discard them.

Drag the left edge of any right-hand properties pane or docked tool-settings popup to adjust its width. The divider also supports arrow keys (Shift for larger steps), Home/End, and double-click to reset. Width preferences are saved on this device.

## Inline editing and optional helper bar — 1 November 2026

Direct edit now shows fonts, sizes, colours and emphasis in the editable text box. Formatting controls appear first, and the separate formatting preview is removed. Text selection, plain-text paste, line breaks, composition input and draft undo/redo are retained. Apply still uses the verified native PDF writer and embedded-font Unicode fix.

Use the helper bar’s × button to hide it. Restore it from **⋯ → Show helper bar**. The preference is saved on this device and hiding the bar releases its reserved space.


A single-file offline PDF workspace for editing, organising, annotating, filling forms, OCR, comparison, redaction and signing. `index.html`, `pdfcreator.html` and the legacy `pdfpro.html` contain identical current app bytes.

## Open

Open one of the HTML files in a current desktop browser. PDF tools, English OCR and the **In-browser docx and doc converter** work on this device without an account or network download. The optional Microsoft Word companion uses installed desktop Word on Windows. Built-in conversion substitutes embedded Arimo fonts and can change pagination; review its output.

## Generate forms from XLSX or CSV

1. Open a PDF containing editable form fields and choose **Forms > Generate from XLSX / CSV**. Flat/scanned forms need fields added first.
2. Choose a data file, worksheet and header row. Select formatted text to preserve displayed dates and leading zeroes, or raw values when needed. CSV text is preserved literally.
3. Match PDF fields to columns, retain template values or enter fixed values. Preview records and PDF pages; correct required fields, invalid choices and character limits.
4. Select record ranges and an output filename pattern. For example, `Letter_{B}_{row}` uses column B and the record number. Duplicate filenames receive suffixes.
5. Keep fields editable or flatten them, then generate and download the ZIP. It includes a UTF-8 CSV report with source row numbers and any skipped records.

Formulas use saved workbook results and are never recalculated. Missing cached results and spreadsheet errors block affected mapped fields. Multi-select values use semicolons; checkboxes accept yes/no, true/false or 1/0. Invalid records require correction or explicit skipping. Read-only fields retain their values. Pending redactions and digitally signed templates require resolving first.

Data is read by an embedded, cancellable worker; no upload or external spreadsheet service is used. Source data and mappings are transient. The open template, tabs and undo history are retained. Limits are 20 MB input, 10,000 records, 256 columns, 500,000 workbook cells and 250 MB of generated PDFs.

## Workspace update — 31 October 2026

- A persistent active-tool guide explains the next gesture and provides Done, tool search and a favourite star.
- Pin tools in function search. Favourites appear before recent tools; Home provides shortcuts. Preferences recover with this browser's local session.
- Selecting PDF text offers Copy, Highlight, Underline, Edit paragraph and Add link. The selection must stay on one page. Native PDF edits use existing signature checks, undo and recovery.
- Image properties provide Crop, Adjust, Replace image and Add link. Replacement keeps other occurrences of a shared image intact and is one undo step; its proportions fit inside the selected image's displayed bounds.
- Dialogues have consistent sticky actions, bounded keyboard focus and an inert background. Page-range inputs provide All pages, Current page and a selected-page count. Background blur is removed.
- All HTML copies, embedded app sources, the separate source ZIP, licences and checksums are aligned in this release.

## Existing capabilities

Create blank/ruled/squared PDFs; use reusable templates; open document tabs; edit native text and rich text boxes; edit images and supported objects; organise/merge/split pages; add links and page decorations; annotate and review comments; create/fill/flatten forms; recognise English text; compare documents; compress to a target size; redact/sanitise; encrypt/unlock; apply visual/certificate signatures; export PDFs/images/text/workspaces; batch process; maintain a local library, Bin, backups, history and checkpoints. See [the user guide](README.txt) and [feature audit](FEATURE-AUDIT.txt).

## Source and rebuilding

Extract `pdfcreator-3.0-app-source.zip` and enter `source`. The HTML's `window.PDFCreator.downloadSource()` exports the same paths and bytes. With Node.js and pnpm installed:

```powershell
pnpm install --frozen-lockfile
node build.mjs C:\path\to\release-folder
node workspace-ux-test.mjs
node form-generation-test.mjs
node form-generation-interactions-test.mjs
$env:PDFCREATOR_RELEASE_DIR = 'C:\path\to\release-folder'
node release-alignment-test.mjs
```

The current build recompiles preferred app sources and retains the exact distributed PDF/OCR/Word engine bytes under `vendor/`. Runtime engines, fonts, source notices and English OCR data are local. No conversion runtime is fetched by the built app. `build-full.mjs` retains the earlier complete engine packaging workflow; its prerequisites are documented in that file and README.txt.

`PDFCreator-Ream-Source.zip` retains the Word converter's MIT dependency sources. Extract alongside the main source ZIP when rebuilding that worker. The official MuPDF corresponding source remains under `upstream/`; reconstruct it with `python upstream/assemble-mupdf-source.py`. Preserve these sources and third-party notices when redistributing.

## Verification and boundaries

See `VALIDATION.txt` for this release's completed checks. Controlled-DOM tests exercise real PDF engines with synthetic files and simulated geometry; they do not establish live browser layout, file-origin storage, clipboard or native download/print behaviour.

OCR is English-only. Direct text reflow stays within the selected page. Some PDF fonts, image types and advanced structures are unsupported. Visual signatures are separate from certificate signatures. Signature integrity checks do not establish trusted identity. Cropping/deleting images and workspace visibility controls are not secure redaction. Local recovery retains earlier content; manage stored copies when working with sensitive documents. No PDF/A, PDF/X or PDF/UA certification is claimed.

AGPL-3.0-or-later; component licences are retained in `THIRD-PARTY-NOTICES.txt` and the source kits.

OCR action and popup placement — 2 November 2026

The pastel red Recognise text for editing button stays below workspace popup layers. When a function/settings popup covers its usual page position, the action moves into clear space within the page and visible viewport. Closing or resizing the popup restores the usual position where possible. A completely covered control is temporarily hidden until room returns. Placement reacts to scrolling, resizing and popup changes without polling or changing PDF bytes.

Form control deletion, signature styling and privacy — 2 November 2026

Radio buttons and other supported form fields are now selectable in Edit > Select objects and Objects & layers. Delete selected (or keyboard Delete) removes selected widget instances, retaining unselected radio options and shared fields. A radio selection also offers Delete radio group, with confirmation covering options on other pages. Edit form fields has the same individual/group deletion controls. Empty field branches and calculation references are cleaned up, retained radio values/export labels stay aligned, and each operation is one Undo step. Printed option labels are separate PDF text and can be selected/deleted separately. Read-only/locked fields are protected.

Protect & sign > Visual signature now offers Colour and Line thickness (0.5–16), which redraw existing strokes and the live preview. Bold typed name changes typed lettering weight. Typed and drawn signatures use the chosen colour, retain transparent PNG backgrounds and preserve normal placement/Undo. Imported PNG/JPEG signatures retain their original pixels and bypass styling.

The ? > About popup includes: All information is processed locally on your device. No files are stored or uploaded to any cloud server or database. Your information remains yours.

## Workspace controls

Contextual selection properties now share a top bar with direct text editing. Use the header Focus icon (Ctrl+Alt+F, Escape to exit), choose interface density in the ellipsis menu, and drag or right-click document tabs for ordering, renaming and closing. The selected eight UI improvements and targeted verification are documented in [the user guide](README.txt).

## Automatic tool selection

Click text or shapes for Select objects, double-click text for on-page Direct edit, and click images or fields for their editing tools. Explicit drawing/placement gestures, dragged word selections, locks and drafts are protected. Use **More document actions > Automatic tool selection** to change the preference.

## Reflow while resizing text

Select a text object and drag its side handle to change the writing width. Words rewrap into the new shape while font sizes and alignment remain fixed; widening removes unused height and narrowing grows the box. Choose Text alignment in the top contextual bar or object properties. Dragging the body still moves the object, and each completed resize supports Undo.


Versioned background updates and compact top toolbars — 4 November 2026
PDFCreator is now 3.0.2. The ? heading, version details, app API, embedded metadata and version.json use package.json as their single version source. Each published app commit reserves exactly one patch above the latest repository version through release-version.mjs; rebuilding that same release keeps the reserved version. See RELEASING.md in the source kit. Older manifests cannot offer a downgrade.

A small manifest is checked after startup and every five minutes online, without requiring the ? panel or an active/visible tab. Focus, resume, page restoration and reconnection schedule overdue checks without bypassing the cooldown. Browsers can throttle/suspend background pages; the checker catches up on waking instead of trying to prevent suspension. Failed checks remain non-blocking and retry with backoff. No PDF data or credentials are transmitted.

Hosted copies check their deployment's version.json. Downloaded file copies check only the official public repository manifest; Download update opens the official updated HTML download on explicit user action and never navigates the existing local workspace. Apply unfinished edits, replace the HTML at its existing location, then reload to retain access to the same browser projects. Hosted Update now retains verified local saving, draft consent and failure backups; neither form of detection forces a reload.

Top object/image/form and on-page text toolbars use smaller desktop controls and tighter padding/gaps. Action names and field labels remain visible with tooltips, accessible names, focus outlines and larger touch targets. Density preferences still offer larger controls; the PDF font size and zoom are unchanged.

Validation: update-checker-test.mjs passes 61 deterministic assertions, website-updates-ui-test.mjs passes 63 source/compiled assertions, and release-version-test.mjs passes 20 assertions. Existing workspace polish (80) and on-page editing (52) checks pass. These use bounded mocked update responses, controlled DOM and native PDF processing; they do not certify browser-specific background timer policies or live layout.

### One top properties editor

Images, selected objects/annotations and form fields use a single grouped toolbar above the PDF. More expands advanced settings within that toolbar; it does not open another side pane. History, Changes review and Objects & layers retain their dedicated, nonduplicated lists.
