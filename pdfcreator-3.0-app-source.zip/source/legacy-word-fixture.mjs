/* Test-only fixture builder from Ream, MIT, Copyright (c) 2026 Alexandr Krassavin. Preferred TypeScript sources and licence accompany PDFCreator-Ream-Source.zip. */

// word-test-fixtures/build-cfb.ts
var SECTOR = 512;
var MINI = 64;
var CUTOFF = 4096;
var ENDOFCHAIN = 4294967294;
var FREESECT = 4294967295;
var FATSECT = 4294967293;
var NOSTREAM = 4294967295;
function buildCfb(streams, options = {}) {
  const sectors = [];
  const fat = [];
  const allocRegular = (data) => {
    const n = Math.max(1, Math.ceil(data.length / SECTOR));
    const start = sectors.length;
    for (let i = 0; i < n; i++) {
      const sec = new Uint8Array(SECTOR);
      sec.set(data.subarray(i * SECTOR, i * SECTOR + SECTOR));
      sectors.push(sec);
      fat.push(i === n - 1 ? ENDOFCHAIN : start + i + 1);
    }
    return start;
  };
  const storages = options.storages ?? [];
  const nestedStreams = storages.flatMap((st) => st.streams);
  const allStreams = [...nestedStreams, ...streams];
  const big = allStreams.filter((s) => s.data.length >= CUTOFF);
  const small = allStreams.filter((s) => s.data.length > 0 && s.data.length < CUTOFF);
  const miniParts = [];
  const miniStart = /* @__PURE__ */ new Map();
  const miniFat = [];
  let miniIdx = 0;
  for (const s of small) {
    const count = Math.ceil(s.data.length / MINI);
    miniStart.set(s, miniIdx);
    for (let k = 0; k < count; k++) miniFat.push(k === count - 1 ? ENDOFCHAIN : miniIdx + k + 1);
    for (let i = 0; i < count * MINI; i++) miniParts.push(i < s.data.length ? s.data[i] : 0);
    miniIdx += count;
  }
  const miniStream = Uint8Array.from(miniParts);
  const bigStart = /* @__PURE__ */ new Map();
  for (const s of big) bigStart.set(s, allocRegular(s.data));
  const miniStreamStart = miniStream.length > 0 ? allocRegular(miniStream) : ENDOFCHAIN;
  let firstMiniFatSector = ENDOFCHAIN;
  let numMiniFatSectors = 0;
  if (miniFat.length > 0) {
    const mfBytes = u32Array(miniFat, SECTOR, FREESECT);
    const start = allocRegular(mfBytes);
    firstMiniFatSector = start;
    numMiniFatSectors = mfBytes.length / SECTOR;
  }
  const dataStart = (s) => s.data.length === 0 ? ENDOFCHAIN : s.data.length >= CUTOFF ? bigStart.get(s) : miniStart.get(s);
  const hasTree = storages.length > 0;
  const nestedBase = 1;
  const storageBase = nestedBase + nestedStreams.length;
  const topBase = storageBase + storages.length;
  const dir = new Array(topBase + streams.length);
  const firstTop = hasTree ? storages.length > 0 ? storageBase : topBase : NOSTREAM;
  dir[0] = dirEntry("Root Entry", 5, miniStreamStart, miniStream.length, false, {
    child: firstTop
  });
  const storageChild = [];
  let ni = nestedBase;
  for (const st of storages) {
    storageChild.push(st.streams.length > 0 ? ni : NOSTREAM);
    st.streams.forEach((s, k) => {
      dir[ni] = dirEntry(s.name, 2, dataStart(s), s.data.length, options.garbageSizeHighDword, {
        right: k < st.streams.length - 1 ? ni + 1 : NOSTREAM
      });
      ni++;
    });
  }
  const topCount = storages.length + streams.length;
  const topSeqIdx = (p) => p < storages.length ? storageBase + p : topBase + (p - storages.length);
  const rightOf = (p) => hasTree && p < topCount - 1 ? topSeqIdx(p + 1) : NOSTREAM;
  storages.forEach((st, i) => {
    dir[storageBase + i] = dirEntry(st.name, 1, ENDOFCHAIN, 0, false, {
      right: rightOf(i),
      child: storageChild[i]
    });
  });
  streams.forEach((s, i) => {
    dir[topBase + i] = dirEntry(
      s.name,
      2,
      dataStart(s),
      s.data.length,
      options.garbageSizeHighDword,
      {
        right: rightOf(storages.length + i)
      }
    );
  });
  while (dir.length % 4 !== 0) dir.push(unallocatedEntry());
  const firstDirSector = allocRegular(concat(dir));
  const fatSectorIndex = sectors.length;
  let fatSectorCount = 1;
  while (fatSectorIndex + fatSectorCount > fatSectorCount * (SECTOR / 4)) fatSectorCount++;
  if (fatSectorCount > 109) throw new Error("buildCfb: streams too big for a header-only DIFAT");
  for (let i = 0; i < fatSectorCount; i++) fat.push(FATSECT);
  sectors.push(u32Array(fat, SECTOR, FREESECT));
  const header = new Uint8Array(SECTOR);
  const hv = new DataView(header.buffer);
  header.set([208, 207, 17, 224, 161, 177, 26, 225], 0);
  hv.setUint16(24, 62, true);
  hv.setUint16(26, 3, true);
  hv.setUint16(28, 65534, true);
  hv.setUint16(30, 9, true);
  hv.setUint16(32, 6, true);
  hv.setUint32(44, fatSectorCount, true);
  hv.setUint32(48, firstDirSector, true);
  hv.setUint32(56, CUTOFF, true);
  hv.setUint32(60, firstMiniFatSector, true);
  hv.setUint32(64, numMiniFatSectors, true);
  hv.setUint32(68, ENDOFCHAIN, true);
  hv.setUint32(72, 0, true);
  for (let i = 0; i < 109; i++) {
    hv.setUint32(76 + i * 4, i < fatSectorCount ? fatSectorIndex + i : FREESECT, true);
  }
  return concat([header, ...sectors]);
}
function dirEntry(name, type, startSector, size, garbageHigh = false, links = {}) {
  const e = new Uint8Array(DIR_ENTRY_SIZE);
  const v = new DataView(e.buffer);
  for (let i = 0; i < name.length && i < 31; i++) v.setUint16(i * 2, name.charCodeAt(i), true);
  v.setUint16(64, (Math.min(name.length, 31) + 1) * 2, true);
  v.setUint8(66, type);
  v.setUint8(67, 1);
  v.setUint32(68, links.left ?? NOSTREAM, true);
  v.setUint32(72, links.right ?? NOSTREAM, true);
  v.setUint32(76, links.child ?? NOSTREAM, true);
  v.setUint32(116, startSector, true);
  v.setUint32(120, size >>> 0, true);
  v.setUint32(124, garbageHigh ? 4294967295 : Math.floor(size / 4294967296), true);
  return e;
}
function unallocatedEntry() {
  const e = new Uint8Array(DIR_ENTRY_SIZE);
  new DataView(e.buffer).setUint8(66, 0);
  return e;
}
var DIR_ENTRY_SIZE = 128;
function u32Array(values, align, fill) {
  const count = Math.ceil(values.length * 4 / align) * (align / 4);
  const out = new Uint8Array(count * 4);
  const v = new DataView(out.buffer);
  for (let i = 0; i < count; i++) v.setUint32(i * 4, i < values.length ? values[i] : fill, true);
  return out;
}
function concat(parts) {
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}

// word-test-fixtures/build-doc.ts
var TEXT_BASE = 512;
var FKP_SIZE = 512;
function buildDoc(pieces, opts = {}) {
  const whichTable = opts.whichTable ?? "1Table";
  let cursor = TEXT_BASE;
  const placed = [];
  for (const p of pieces) {
    if (cursor % 2 !== 0) cursor++;
    const bytes = p.compressed ? encodeCp1252(p.text) : encodeUtf16(p.text);
    placed.push({ offset: cursor, bytes, chars: p.text.length, compressed: p.compressed });
    cursor += bytes.length;
  }
  const mainChars = placed.reduce((sum, p) => sum + p.chars, 0);
  let headerCps;
  if (opts.headerFooter) {
    const story = buildHeaderStream(opts.headerFooter);
    headerCps = story.cps;
    if (cursor % 2 !== 0) cursor++;
    const bytes = encodeUtf16(story.text);
    placed.push({ offset: cursor, bytes, chars: story.text.length, compressed: false });
    cursor += bytes.length;
  }
  const totalChars = placed.reduce((sum, p) => sum + p.chars, 0);
  const n = placed.length;
  const plc = new Uint8Array((n + 1) * 4 + n * 8);
  const pv = new DataView(plc.buffer);
  let cpAcc = 0;
  pv.setUint32(0, 0, true);
  for (let i = 0; i < n; i++) {
    cpAcc += placed[i].chars;
    pv.setUint32((i + 1) * 4, cpAcc, true);
  }
  const pcdBase = (n + 1) * 4;
  for (let i = 0; i < n; i++) {
    const pc = placed[i];
    const fc = pc.compressed ? (1073741824 | pc.offset * 2) >>> 0 : pc.offset;
    pv.setUint16(pcdBase + i * 8, 0, true);
    pv.setUint32(pcdBase + i * 8 + 2, fc, true);
    pv.setUint16(pcdBase + i * 8 + 6, 0, true);
  }
  const clx = new Uint8Array(5 + plc.length);
  clx[0] = 2;
  new DataView(clx.buffer).setUint32(1, plc.length, true);
  clx.set(plc, 5);
  const first = placed[0];
  const step = first?.compressed ? 1 : 2;
  const fkpPages = [];
  const binTables = [];
  const fibFields = [];
  let wdEnd = cursor;
  let tableEnd = clx.length;
  const addFkp = (page) => {
    const offset = Math.ceil(wdEnd / FKP_SIZE) * FKP_SIZE;
    fkpPages.push({ offset, page });
    wdEnd = offset + FKP_SIZE;
    return offset / FKP_SIZE;
  };
  const addBinTable = (data) => {
    const offset = Math.ceil(tableEnd / 4) * 4;
    binTables.push({ offset, data });
    tableEnd = offset + data.length;
    return offset;
  };
  const addBte = (page, fcFieldOff) => {
    const pageNumber = addFkp(page);
    const bte = buildPlcBte(first.offset, first.offset + totalChars * step, pageNumber);
    const tableOff = addBinTable(bte);
    fibFields.push({ fc: fcFieldOff, off: tableOff, lcb: bte.length });
  };
  if (first && opts.formatRuns && opts.formatRuns.length > 0) {
    addBte(buildChpxFkp(first.offset, step, opts.formatRuns), 250);
  }
  if (first && opts.paraRuns && opts.paraRuns.length > 0) {
    addBte(buildPapxFkp(first.offset, step, opts.paraRuns), 258);
  }
  if (headerCps) {
    const plcfHdd = new Uint8Array(headerCps.length * 4);
    const hv = new DataView(plcfHdd.buffer);
    headerCps.forEach((cp, i) => hv.setUint32(i * 4, cp, true));
    fibFields.push({ fc: 242, off: addBinTable(plcfHdd), lcb: plcfHdd.length });
  }
  if (opts.lists) {
    const { plfLst, lcbLstfs, plfLfo } = buildListTables(opts.lists);
    fibFields.push({ fc: 738, off: addBinTable(plfLst), lcb: lcbLstfs });
    fibFields.push({ fc: 746, off: addBinTable(plfLfo), lcb: plfLfo.length });
  }
  let sepx;
  if (opts.pageSizeTwips) {
    const grpprl = new Uint8Array(8);
    const gv = new DataView(grpprl.buffer);
    gv.setUint16(0, 45087, true);
    gv.setUint16(2, opts.pageSizeTwips.width, true);
    gv.setUint16(4, 45088, true);
    gv.setUint16(6, opts.pageSizeTwips.height, true);
    const sepxBytes = new Uint8Array(2 + grpprl.length);
    new DataView(sepxBytes.buffer).setUint16(0, grpprl.length, true);
    sepxBytes.set(grpprl, 2);
    sepx = { offset: wdEnd, bytes: sepxBytes };
    wdEnd += sepxBytes.length;
    const plcfSed = new Uint8Array(8 + 12);
    const sv = new DataView(plcfSed.buffer);
    sv.setUint32(4, mainChars, true);
    sv.setUint32(8 + 2, sepx.offset, true);
    sv.setUint32(8 + 8, 4294967295, true);
    fibFields.push({ fc: 202, off: addBinTable(plcfSed), lcb: plcfSed.length });
  }
  const table = new Uint8Array(tableEnd);
  table.set(clx, 0);
  for (const b of binTables) table.set(b.data, b.offset);
  const wd = new Uint8Array(wdEnd);
  const wv = new DataView(wd.buffer);
  wv.setUint16(0, 42476, true);
  wv.setUint16(2, 193, true);
  wv.setUint16(
    10,
    (whichTable === "1Table" ? 512 : 0) | (opts.encrypted ? 256 : 0),
    true
  );
  wv.setUint32(76, mainChars, true);
  if (headerCps) {
    wv.setUint32(80, 0, true);
    wv.setUint32(84, totalChars - mainChars, true);
  }
  for (const f of fibFields) {
    wv.setUint32(f.fc, f.off, true);
    wv.setUint32(f.fc + 4, f.lcb, true);
  }
  wv.setUint32(418, 0, true);
  wv.setUint32(422, clx.length, true);
  for (const p of placed) wd.set(p.bytes, p.offset);
  for (const f of fkpPages) wd.set(f.page, f.offset);
  if (sepx) wd.set(sepx.bytes, sepx.offset);
  return buildCfb([
    { name: "WordDocument", data: wd },
    { name: whichTable, data: table },
    ...opts.data ? [{ name: "Data", data: opts.data }] : []
  ]);
}
function buildListTables(lists) {
  const plfLfo = new Uint8Array(4 + lists.lfos.length * 16);
  const fv = new DataView(plfLfo.buffer);
  fv.setUint32(0, lists.lfos.length, true);
  lists.lfos.forEach((lsid, i) => fv.setInt32(4 + i * 16, lsid, true));
  const cLst = lists.lstfs.length;
  const lcbLstfs = 2 + cLst * 28;
  const lstfPart = new Uint8Array(lcbLstfs);
  const lv = new DataView(lstfPart.buffer);
  lv.setInt16(0, cLst, true);
  lists.lstfs.forEach((lst, i) => {
    const base = 2 + i * 28;
    lv.setInt32(base, lst.lsid, true);
    lstfPart[base + 26] = lst.simple ? 1 : 0;
  });
  const parts = [lstfPart];
  for (const lst of lists.lstfs) {
    const count = lst.simple ? 1 : 9;
    for (let l = 0; l < count; l++) {
      const lvl = lst.levels[l] ?? lst.levels[lst.levels.length - 1] ?? { nfc: 23, xst: [8226] };
      const lvlf = new Uint8Array(28);
      new DataView(lvlf.buffer).setInt32(0, lvl.iStartAt ?? 1, true);
      lvlf[4] = lvl.nfc;
      const xst = new Uint8Array(2 + lvl.xst.length * 2);
      const xv = new DataView(xst.buffer);
      xv.setUint16(0, lvl.xst.length, true);
      lvl.xst.forEach((cu, j) => xv.setUint16(2 + j * 2, cu, true));
      parts.push(lvlf, xst);
    }
  }
  const total = parts.reduce((n, p) => n + p.length, 0);
  const plfLst = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    plfLst.set(p, off);
    off += p.length;
  }
  return { plfLst, lcbLstfs, plfLfo };
}
function buildHeaderStream(hf) {
  const cr = String.fromCharCode(13);
  const slots = [
    "",
    "",
    "",
    "",
    "",
    "",
    // doc-wide separators
    hf.evenHeader,
    // 6
    hf.defaultHeader,
    // 7 (odd-page = primary)
    hf.evenFooter,
    // 8
    hf.defaultFooter,
    // 9 (odd-page = primary)
    hf.firstHeader,
    // 10
    hf.firstFooter
    // 11
  ].map((t) => t ? t + cr : "");
  const cps = [0];
  let text = "";
  for (const s of slots) {
    text += s;
    cps.push(text.length);
  }
  return { text, cps };
}
function buildPicf(image, widthTwips, heightTwips) {
  const cbHeader = 68;
  const out = new Uint8Array(cbHeader + image.length);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, out.length, true);
  dv.setUint16(4, cbHeader, true);
  dv.setUint16(6, 100, true);
  dv.setUint16(28, widthTwips, true);
  dv.setUint16(30, heightTwips, true);
  dv.setUint16(32, 1e3, true);
  dv.setUint16(34, 1e3, true);
  out.set(image, cbHeader);
  return out;
}
function buildChpxFkp(fcBase, step, runs) {
  const crun = runs.length;
  const page = new Uint8Array(FKP_SIZE);
  const dv = new DataView(page.buffer);
  dv.setUint32(0, fcBase, true);
  let cum = 0;
  for (let i = 0; i < crun; i++) {
    cum += runs[i].length;
    dv.setUint32((i + 1) * 4, fcBase + cum * step, true);
  }
  const rgbBase = (crun + 1) * 4;
  let blobOff = rgbBase + crun;
  for (let i = 0; i < crun; i++) {
    const grpprl = buildChpxGrpprl(runs[i]);
    if (grpprl.length === 0) {
      page[rgbBase + i] = 0;
      continue;
    }
    if (blobOff % 2 !== 0) blobOff++;
    page[blobOff] = grpprl.length;
    page.set(grpprl, blobOff + 1);
    page[rgbBase + i] = blobOff / 2;
    blobOff += 1 + grpprl.length;
  }
  page[FKP_SIZE - 1] = crun;
  return page;
}
function buildPapxFkp(fcBase, step, runs) {
  const cpara = runs.length;
  const page = new Uint8Array(FKP_SIZE);
  const dv = new DataView(page.buffer);
  dv.setUint32(0, fcBase, true);
  let cum = 0;
  for (let i = 0; i < cpara; i++) {
    cum += runs[i].length;
    dv.setUint32((i + 1) * 4, fcBase + cum * step, true);
  }
  const bxBase = (cpara + 1) * 4;
  let blobOff = bxBase + cpara * 13;
  for (let i = 0; i < cpara; i++) {
    const blob = buildPapxInFkp(buildPapxGrpprl(runs[i]));
    if (blobOff % 2 !== 0) blobOff++;
    page.set(blob, blobOff);
    page[bxBase + i * 13] = blobOff / 2;
    blobOff += blob.length;
  }
  page[FKP_SIZE - 1] = cpara;
  return page;
}
function buildPapxInFkp(grpprl) {
  const size = 2 + grpprl.length;
  if (size % 2 === 1) {
    return Uint8Array.from([(size + 1) / 2, 0, 0, ...grpprl]);
  }
  return Uint8Array.from([0, size / 2, 0, 0, ...grpprl]);
}
function buildChpxGrpprl(run) {
  const parts = [];
  const sprm = (op, ...operand) => {
    parts.push(op & 255, op >> 8 & 255, ...operand);
  };
  if (run.bold) sprm(2101, 1);
  if (run.italic) sprm(2102, 1);
  if (run.underlineKul) sprm(10814, run.underlineKul & 255);
  if (run.sizeHalfPts) sprm(19011, run.sizeHalfPts & 255, run.sizeHalfPts >> 8 & 255);
  if (run.picOffset !== void 0) {
    sprm(2133, 1);
    const fc = run.picOffset >>> 0;
    sprm(27139, fc & 255, fc >> 8 & 255, fc >> 16 & 255, fc >> 24 & 255);
  }
  return Uint8Array.from(parts);
}
function buildPapxGrpprl(run) {
  const parts = [];
  const sprm = (op, ...operand) => {
    parts.push(op & 255, op >> 8 & 255, ...operand);
  };
  const i16 = (v) => [v & 255, v >> 8 & 255];
  if (run.jc !== void 0) sprm(9219, run.jc & 255);
  if (run.indentLeftTwips !== void 0) sprm(33807, ...i16(run.indentLeftTwips));
  if (run.indentRightTwips !== void 0) sprm(33806, ...i16(run.indentRightTwips));
  if (run.indentFirstTwips !== void 0) sprm(33809, ...i16(run.indentFirstTwips));
  if (run.spaceBeforeTwips !== void 0) sprm(42003, ...i16(run.spaceBeforeTwips));
  if (run.spaceAfterTwips !== void 0) sprm(42004, ...i16(run.spaceAfterTwips));
  if (run.widowControl !== void 0) sprm(9265, run.widowControl ? 1 : 0);
  if (run.keepNext !== void 0) sprm(9222, run.keepNext ? 1 : 0);
  if (run.keepLines !== void 0) sprm(9221, run.keepLines ? 1 : 0);
  if (run.cellEdgesTwips) {
    const content = [run.cellEdgesTwips.length - 1 & 255, ...run.cellEdgesTwips.flatMap(i16)];
    if (run.cellTc) {
      const brc = (e) => e ? [e.widthEighthPt ?? 8, e.brcType ?? 1, e.ico ?? 1, 0] : [0, 0, 0, 0];
      for (const tc of run.cellTc) {
        const tcgrf = tc.vMerge === "restart" ? 96 : tc.vMerge === "continue" ? 32 : 0;
        content.push(
          ...i16(tcgrf),
          ...i16(0),
          ...brc(tc.borders?.top),
          ...brc(tc.borders?.left),
          ...brc(tc.borders?.bottom),
          ...brc(tc.borders?.right)
        );
      }
    }
    const cb = content.length + 1;
    sprm(54792, cb & 255, cb >> 8 & 255, ...content);
  }
  if (run.cellShadings) {
    const hex2 = (s, i) => parseInt(s.slice(i, i + 2), 16) & 255;
    const shd = [];
    for (const fill of run.cellShadings) {
      shd.push(0, 0, 0, 255);
      if (fill) shd.push(hex2(fill, 0), hex2(fill, 2), hex2(fill, 4), 0);
      else shd.push(0, 0, 0, 255);
      shd.push(0, 0);
    }
    sprm(54802, shd.length & 255, ...shd);
  }
  if (run.listIlvl !== void 0) sprm(9738, run.listIlvl & 255);
  if (run.listIlfo !== void 0) sprm(17931, run.listIlfo & 255, run.listIlfo >> 8 & 255);
  if (run.inTable) sprm(9238, 1);
  if (run.rowEnd) sprm(9239, 1);
  return Uint8Array.from(parts);
}
function buildPlcBte(fcStart, fcEnd, pageNumber) {
  const plc = new Uint8Array(12);
  const dv = new DataView(plc.buffer);
  dv.setUint32(0, fcStart, true);
  dv.setUint32(4, fcEnd, true);
  dv.setUint32(8, pageNumber, true);
  return plc;
}
function encodeUtf16(s) {
  const out = new Uint8Array(s.length * 2);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    out[i * 2] = c & 255;
    out[i * 2 + 1] = c >> 8 & 255;
  }
  return out;
}
var CP1252_HIGH = [
  8364,
  129,
  8218,
  402,
  8222,
  8230,
  8224,
  8225,
  710,
  8240,
  352,
  8249,
  338,
  141,
  381,
  143,
  144,
  8216,
  8217,
  8220,
  8221,
  8226,
  8211,
  8212,
  732,
  8482,
  353,
  8250,
  339,
  157,
  382,
  376
];
function encodeCp1252(s) {
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 128 || c >= 160 && c <= 255) out[i] = c;
    else {
      const idx = CP1252_HIGH.indexOf(c);
      out[i] = idx >= 0 ? 128 + idx : 63;
    }
  }
  return out;
}
export {
  buildDoc,
  buildPicf
};
