/* Password-authenticated encryption removal. Keeps document content interactive. */
import {openPDF} from './engine.js';
import {inspectRemovableSignatures} from './remove-signatures.js';
function encrypted(doc){const trailer=doc.getTrailer(),value=trailer.get('Encrypt');try{return!value.isNull()}finally{value.destroy();trailer.destroy()}}
export function inspectPDFSecurity(bytes,password=''){const doc=openPDF(bytes,password);try{return{encrypted:encrypted(doc),signatures:inspectRemovableSignatures(doc).signatures,pages:doc.countPages()}}finally{doc.destroy()}}
export function removeSecurityPDF(bytes,{password=''}={},progress=()=>{}){
 progress(0,'Opening PDF');const doc=openPDF(bytes,password);let output,changed;
 try{changed=encrypted(doc);if(!changed)output=new Uint8Array(bytes);else{progress(.3,'Removing password security');const buffer=doc.saveToBuffer('garbage=2,compress=yes,compress-fonts=yes,compress-images=yes,encrypt=none');try{output=buffer.asUint8Array().slice()}finally{buffer.destroy()}}}finally{doc.destroy()}
 progress(.9,'Checking password-free PDF');const check=openPDF(output);try{if(encrypted(check)||check.needsPassword())throw Error('The exported PDF still contains password security. No file was downloaded.')}finally{check.destroy()}
 progress(1,'Password-free PDF ready');return{bytes:output,changed,encrypted:false,before:bytes.length,after:output.length};
}
