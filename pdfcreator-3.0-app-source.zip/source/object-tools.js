/* Selectable native annotations and page XObjects. Changes preserve vector content. */
import {mupdf} from './engine.js';
const I=[1,0,0,1,0,0],concat=mupdf.Matrix.concat;
const point=(p,m)=>[m[0]*p[0]+m[2]*p[1]+m[4],m[1]*p[0]+m[3]*p[1]+m[5]];
export function objectMatrix(rect,{x=rect[0],y=rect[1],width=rect[2]-rect[0],height=rect[3]-rect[1],rotation=0}={}){
  if(![...rect,x,y,width,height,rotation].every(Number.isFinite)||width<1||height<1||width>20000||height>20000)throw Error('Use a width and height from 1 to 20,000 pt.');
  const cx=(rect[0]+rect[2])/2,cy=(rect[1]+rect[3])/2,angle=rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),sx=width/(rect[2]-rect[0]),sy=height/(rect[3]-rect[1]);
  return concat(concat([sx,0,0,sy,-cx*sx,-cy*sy],[c,s,-s,c,0,0]),[1,0,0,1,x+width/2,y+height/2]);
}
// Lex strings/names/comments correctly; operator-like text inside a string is data.
export function contentTokens(source){
  const result=[];let i=0;
  while(i<source.length){const start=i,c=source[i];if(/\s/.test(c)){i++;continue}if(c==='%'){while(i<source.length&&!/[\r\n]/.test(source[i]))i++;continue}
    if(c==='('){let depth=1;i++;while(i<source.length&&depth){if(source[i]==='\\')i+=2;else{if(source[i]==='(')depth++;if(source[i]===')')depth--;i++}}if(depth)throw Error('Unterminated PDF string.');result.push({text:source.slice(start,i),start,end:i,kind:'data'});continue}
    if(c==='<'&&source[i+1]!=='<'){i++;while(i<source.length&&source[i]!=='>')i++;i++;result.push({text:source.slice(start,i),start,end:i,kind:'data'});continue}
    if(c==='/'){i++;while(i<source.length&&!/[\s()[\]<>/%]/.test(source[i]))i++;result.push({text:source.slice(start,i),start,end:i,kind:'name'});continue}
    if(/[()[\]<>]/.test(c)){i+=(source.slice(i,i+2)==='<<'||source.slice(i,i+2)==='>>')?2:1;result.push({text:source.slice(start,i),start,end:i,kind:'data'});continue}
    while(i<source.length&&!/[\s()[\]<>/%]/.test(source[i]))i++;if(i===start)i++;
    const text=source.slice(start,i);result.push({text,start,end:i,kind:/^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(text)?'number':'operator'});
  }return result;
}
function content(page){const o=page.getObject(),c=o.get('Contents'),parts=[];try{const read=s=>{const b=s.readStream();try{const bytes=b.asUint8Array();let source='';for(let offset=0;offset<bytes.length;offset+=16000)source+=String.fromCharCode(...bytes.subarray(offset,offset+16000));parts.push(source)}finally{b.destroy()}};if(c.isArray())c.forEach(read);else if(c.isStream())read(c);return parts.join('\n')}finally{c.destroy();o.destroy()}}
export function pageObjects(doc,index){
  const page=doc.loadPage(index),items=[];
  try{
    const all=[...page.getAnnotations()];try{all.forEach((a,i)=>{if(['Popup','Link','Widget'].includes(a.getType())||(a.getFlags()&(1|2|32)))return;const rect=a.getBounds();if(rect[2]>rect[0]&&rect[3]>rect[1])items.push({kind:'annotation',index:i,type:a.getType(),text:a.getContents()||'',rect})})}finally{all.forEach(a=>a.destroy())}
    const source=content(page),tokens=contentTokens(source);if(tokens.some(t=>t.kind==='operator'&&t.text==='BI'))return items; // Inline binary images need a dedicated parser.
    const o=page.getObject(),resources=o.getInheritable('Resources'),xobjects=resources.get('XObject'),boxes=o.get('PdfProFontBoxes'),recipes=new Map();
    try{if(boxes.isArray())boxes.forEach(b=>{const r=b.get('Resource'),s=b.get('Style');try{if(s.isString())recipes.set(r.asName(),JSON.parse(s.asString()))}catch{}finally{r.destroy();s.destroy()}});
      let ctm=I,stack=[],operands=[],ordinal=0;
      for(const token of tokens){if(token.kind!=='operator'){operands.push(token);continue}
        if(token.text==='q')stack.push([...ctm]);else if(token.text==='Q'){if(!stack.length)throw Error('Unbalanced PDF graphics state.');ctm=stack.pop()}else if(token.text==='cm'&&operands.slice(-6).every(t=>t.kind==='number')&&operands.length>=6)ctm=concat(operands.slice(-6).map(t=>+t.text),ctm);
        else if(token.text==='Do'&&operands.at(-1)?.kind==='name'){
          const nameToken=operands.at(-1),name=nameToken.text.slice(1).replace(/#([a-f\d]{2})/gi,(_,h)=>String.fromCharCode(parseInt(h,16))),obj=xobjects.get(name),sub=obj.get('Subtype');
          try{const type=sub.asName();if(['Form','Image'].includes(type)){const bbox=type==='Image'?[0,0,1,1]:obj.get('BBox').asJS(),fm=obj.get('Matrix'),formMatrix=fm.isArray()?fm.asJS():I;fm.destroy();const matrix=concat(concat(formMatrix,ctm),page.getTransform()),rect=mupdf.Rect.transform(bbox,matrix);if(rect.every(Number.isFinite)&&rect[2]>rect[0]&&rect[3]>rect[1])items.push({kind:'xobject',index:ordinal,name,type:recipes.has(name)?'Text box':type==='Image'?'Image':'Content group',rect,matrix:concat(ctm,page.getTransform()),start:nameToken.start,end:token.end,command:source.slice(nameToken.start,token.end),recipe:recipes.get(name)||null})}}finally{sub.destroy();obj.destroy()}ordinal++;
        }operands=[];
      }
    }finally{boxes.destroy();xobjects.destroy();resources.destroy();o.destroy()}
    return items;
  }finally{page.destroy()}
}
export function transformObject(doc,pageIndex,target,{action='transform',matrix=I}={}){
  const current=pageObjects(doc,pageIndex).find(o=>o.kind===target.kind&&o.index===target.index);
  if(!current||current.type!==target.type||current.rect.some((n,i)=>Math.abs(n-target.rect[i])>.1))throw Error('This object changed. Select it again.');
  if(!matrix.every(Number.isFinite)||Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2])<.000001)throw Error('Invalid object transform.');
  const page=doc.loadPage(pageIndex);
  try{
    if(target.kind==='xobject'){
      const source=content(page),local=concat(concat(current.matrix,matrix),mupdf.Matrix.invert(current.matrix)),o=page.getObject();let resourceName=current.name;
      function cloneDict(source){const d=doc.newDictionary();source.forEach((v,k)=>d.put(k,v));return d}
      if(action==='duplicate'){
        const inherited=o.getInheritable('Resources'),resources=cloneDict(inherited),originals=resources.get('XObject'),objects=cloneDict(originals);let suffix=doc.countObjects();
        do{resourceName='PDFCreatorCopy'+suffix++}while(!objects.get(resourceName).isNull());objects.put(resourceName,originals.get(current.name));resources.put('XObject',objects);o.put('Resources',resources);objects.destroy();originals.destroy();resources.destroy();inherited.destroy();
      }
      const command='q '+local.map(n=>Number(n.toFixed(7))).join(' ')+' cm /'+resourceName+' Do Q',replacement=action==='delete'?'':action==='duplicate'?current.command+'\n'+command:command,updated=source.slice(0,current.start)+replacement+source.slice(current.end),stream=doc.addStream(Uint8Array.from(updated,ch=>ch.charCodeAt(0)),{});
      try{o.put('Contents',stream);
        if(current.recipe){const boxes=o.get('PdfProFontBoxes'),entries=[];try{boxes.forEach(b=>{const name=b.get('Resource');let matches;try{matches=name.asName()===current.name}finally{name.destroy()}if(!matches){entries.push(b);return}if(action==='delete')return;
          const update=action==='duplicate'?cloneDict(b):b;if(action==='duplicate')entries.push(b);
          const s={...current.recipe},r=s.rotation*Math.PI/180,original=s.matrix||[Math.cos(r)*s.scale,Math.sin(r)*s.scale,-Math.sin(r)*s.scale,Math.cos(r)*s.scale,s.x,s.y],pdfMatrix=concat(concat(page.getTransform(),matrix),mupdf.Matrix.invert(page.getTransform()));
          s.matrix=concat(original,pdfMatrix);s.x=s.matrix[4];s.y=s.matrix[5];update.put('Style',doc.newString(JSON.stringify(s)));const br=b.get('Rect');try{update.put('Rect',mupdf.Rect.transform(br.asJS(),pdfMatrix))}finally{br.destroy()}update.put('Resource',doc.newName(resourceName));entries.push(update);
        });o.put('PdfProFontBoxes',entries)}finally{boxes.destroy()}}
      }finally{stream.destroy();o.destroy()}return;
    }
    const all=[...page.getAnnotations()];let annotation=all[target.index],copy,list,device,transformed;
    try{
      if(annotation.getFlags()&(mupdf.PDFAnnotation.IS_READ_ONLY|mupdf.PDFAnnotation.IS_LOCKED))throw Error('This annotation is locked.');
      if(action==='delete'){page.deleteAnnotation(annotation);return}
      list=annotation.toDisplayList();const rect=mupdf.Rect.transform(annotation.getBounds(),matrix),w=rect[2]-rect[0],h=rect[3]-rect[1];
      transformed=new mupdf.DisplayList([0,0,w,h]);device=new mupdf.DisplayListDevice(transformed);list.run(device,concat(matrix,[1,0,0,1,-rect[0],-rect[1]]));device.close();
      if(action==='duplicate'){copy=page.createAnnotation(annotation.getType());const src=annotation.getObject(),dest=copy.getObject();try{src.forEach((value,key)=>{if(!['P','Popup','NM','IRT','StructParent'].includes(key))dest.put(key,value)})}finally{src.destroy();dest.destroy()}annotation=copy}
      if(annotation.hasInkList())annotation.setInkList(annotation.getInkList().map(stroke=>stroke.map(p=>point(p,matrix))));
      if(annotation.hasQuadPoints())annotation.setQuadPoints(annotation.getQuadPoints().map(q=>{const result=[];for(let i=0;i<8;i+=2)result.push(...point(q.slice(i,i+2),matrix));return result}));
      if(annotation.hasVertices())annotation.setVertices(annotation.getVertices().map(p=>point(p,matrix)));
      if(annotation.hasLine()){const ends=annotation.getLine();annotation.setLine(point(ends[0],matrix),point(ends[1],matrix))}
      if(annotation.hasRect())annotation.setRect(rect);else{const o=annotation.getObject();try{o.put('Rect',mupdf.Rect.transform(rect,mupdf.Matrix.invert(page.getTransform())))}finally{o.destroy()}}
      annotation.update();const o=page.getObject(),rotation=o.getInheritable('Rotate');try{annotation.setAppearanceFromDisplayList('N',null,mupdf.Matrix.rotate(rotation.asNumber()||0),transformed);annotation.update()}finally{rotation.destroy();o.destroy()}
    }finally{copy?.destroy();all.forEach(a=>a.destroy());device?.destroy();transformed?.destroy();list?.destroy()}
  }finally{page.destroy()}
}
export function snapRect(rect,bounds,others=[],tolerance=5){
  let dx=0,dy=0,bestX=tolerance,bestY=tolerance;const xs=[bounds[0],(bounds[0]+bounds[2])/2,bounds[2]],ys=[bounds[1],(bounds[1]+bounds[3])/2,bounds[3]];
  for(const r of others){xs.push(r[0],(r[0]+r[2])/2,r[2]);ys.push(r[1],(r[1]+r[3])/2,r[3])}
  for(const x of [rect[0],(rect[0]+rect[2])/2,rect[2]])for(const edge of xs)if(Math.abs(edge-x)<bestX){bestX=Math.abs(edge-x);dx=edge-x}
  for(const y of [rect[1],(rect[1]+rect[3])/2,rect[3]])for(const edge of ys)if(Math.abs(edge-y)<bestY){bestY=Math.abs(edge-y);dy=edge-y}
  return rect.map((v,i)=>v+(i%2?dy:dx));
}
