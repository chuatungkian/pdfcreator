/* Route stationary page clicks without changing PDF bytes or hijacking gestures. */
import {selectableObjects} from './object-batch.js';
import {directEditTargets,addedTextTargets} from './direct-text.js';
import {imageTargets} from './image-edit.js';
import {pageFormFields} from './pdf-form-fields.js';
const contains=(r,p)=>p[0]>=r[0]&&p[0]<=r[2]&&p[1]>=r[1]&&p[1]<=r[3];
const area=t=>Math.max(0,t.rect[2]-t.rect[0])*Math.max(0,t.rect[3]-t.rect[1]);
const excluded='a,.pdf-link-badge,.annotation-badge,.pdf-attachment-target,.on-page-text-surface,.direct-editor,.rich-editor,.image-resize,.object-resize,input,textarea,select,[contenteditable=true]';
export class ContextSelection{
 constructor({root,state,api}){Object.assign(this,{root,state,api,enabled:true,autoTool:null,last:null,gesture:null,cache:new WeakMap()});this.label=document.createElement('label');this.label.className='automatic-tool-choice';this.checkbox=document.createElement('input');this.checkbox.id='automaticToolSelection';this.checkbox.type='checkbox';this.checkbox.checked=true;this.checkbox.onchange=()=>{this.enabled=this.checkbox.checked;this.manual();api.onPreference();api.refreshHelp()};this.label.append(this.checkbox,document.createTextNode('Automatic tool selection'));this.label.title='Click text or shapes to select objects; double-click text to edit. Click images or fields for their tools.';document.getElementById('actionMenu').append(this.label);
  this.down=e=>{if(e.button!==0||e.isPrimary===false){this.gesture=null;return}const last=this.last,doubleHit=this.nearLast(e)&&this.available()&&!api.draftBlocked()&&(last.hit.kind==='text'||last.hit.rich)?last:null;this.gesture={pointer:e.pointerId,x:e.clientX,y:e.clientY,revision:state.bytes,owner:api.owner(),moved:false,doubleHit,handledSelection:!!e.target.closest?.('.object-selection')&&(e.ctrlKey||e.metaKey||e.shiftKey||document.querySelector('[data-object-add]')?.checked)};if(doubleHit&&!e.target.closest('.pdf-page-view')){e.preventDefault();e.stopPropagation()}};
  this.move=e=>{const g=this.gesture;if(g&&e.pointerId===g.pointer&&Math.hypot(e.clientX-g.x,e.clientY-g.y)>5)g.moved=true};this.cancel=()=>{this.gesture=null;this.last=null};
  this.click=e=>this.route(e,false);this.double=e=>this.route(e,true);root.addEventListener('pointerdown',this.down,true);root.addEventListener('pointermove',this.move,true);root.addEventListener('pointercancel',this.cancel,true);root.addEventListener('click',this.click,true);root.addEventListener('dblclick',this.double,true);
 }
 manual(){this.autoTool=null;this.last=null;this.gesture=null;this.handledDouble=null}
 preferences(){return{automaticToolSelection:this.enabled}}
 restore(preferences={}){this.enabled=preferences.automaticToolSelection!==false;this.checkbox.checked=this.enabled;this.manual()}
 nearLast(event){const last=this.last;return last&&last.owner===this.api.owner()&&last.revision===this.state.bytes&&Date.now()-last.time<500&&Math.hypot(event.clientX-last.x,event.clientY-last.y)<6&&!event.ctrlKey&&!event.metaKey&&!event.shiftKey}
 available(){return this.enabled&&this.api.available()&&['select','objects','images','editfields','directedit'].includes(this.state.tool)}
 pageData(index){let pages=this.cache.get(this.state.bytes);if(!pages){pages=new Map();this.cache.set(this.state.bytes,pages)}if(!pages.has(index)){const doc=this.state.doc,safe=read=>{try{return read()}catch{return[]}};pages.set(index,{objects:safe(()=>selectableObjects(doc,index)),lines:safe(()=>directEditTargets(doc,index,'line')),added:safe(()=>addedTextTargets(doc,index)),images:safe(()=>imageTargets(doc,index)),fields:safe(()=>pageFormFields(doc,index))})}return pages.get(index)}
 hit(index,point){const data=this.pageData(index),pick=items=>items.filter(t=>contains(t.rect,point)).sort((a,b)=>area(a)-area(b));const field=pick(data.fields.filter(f=>!f.hidden&&['text','checkbox','radiobutton','combobox','listbox'].includes(f.type)))[0];if(field)return{kind:'field',target:field,object:data.objects.find(t=>t.kind==='formField'&&t.index===field.index)};
  const annotations=pick(data.objects.filter(t=>t.kind==='annotation'&&t.type!=='FileAttachment'));if(annotations[0]&&['Text','FreeText','Stamp'].includes(annotations[0].type)){const t=annotations[0];return{kind:'object',target:t,object:t,rich:['FreeText','Stamp'].includes(t.type)}}
  const added=pick(data.added)[0],line=pick(data.lines)[0];if(added){const object=data.objects.find(t=>t.type==='Text box'&&(t.name===added.resource||t.rect.every((v,i)=>Math.abs(v-added.rect[i])<.5))&&contains(t.rect,point))||data.objects.find(t=>t.kind==='nativeText'&&contains(t.rect,point));if(object)return{kind:'text',target:added,object}}
  if(line){const object=data.objects.find(t=>t.kind==='nativeText'&&t.parts?.some(p=>line.parts?.some(q=>p.index===q.index)));if(object)return{kind:'text',target:object,object,line}}
  if(annotations[0])return{kind:'object',target:annotations[0],object:annotations[0]};const image=pick(data.images)[0];if(image)return{kind:'image',target:image,object:pick(data.objects.filter(t=>t.type==='Image'))[0]};
  const b=this.api.bounds(index),pageArea=(b[2]-b[0])*(b[3]-b[1]),object=pick(data.objects.filter(t=>!['nativeText','formField','annotation'].includes(t.kind)&&t.type!=='Image'&&area(t)<pageArea*.95))[0];return object?{kind:'object',target:object,object}:null;
 }
 route(event,doubleEvent){
  const cached=this.gesture?.doubleHit||(this.nearLast(event)?this.last:null),useCached=cached&&(cached.hit.kind==='text'||cached.hit.rich);
  if(event.button!==0||event.target.closest('.on-page-text-surface,.direct-editor,.rich-editor')||!useCached&&event.target.closest(excluded))return;
  const row=event.target.closest?.('.pdf-page-row'),index=useCached?cached.page:row?+row.dataset.pdfPage:null,view=useCached?this.root.querySelector('[data-pdf-page="'+index+'"] .pdf-page-view'):event.target.closest?.('.pdf-page-view');if(index===null||!view)return;
  const frame=view.getBoundingClientRect(),bounds=this.api.bounds(index),point=useCached?cached.point:[(event.clientX-frame.left)/this.state.zoom+bounds[0],(event.clientY-frame.top)/this.state.zoom+bounds[1]],now=Date.now();
  if(doubleEvent&&this.handledDouble&&now-this.handledDouble.time<800&&index===this.handledDouble.page&&this.handledDouble.revision===this.state.bytes){event.preventDefault();event.stopImmediatePropagation();return}
  // Keyboard-triggered native buttons keep their existing accessible actions.
  if(!this.available()||event.detail===0&&!event.clientX&&!event.clientY)return;
  const gesture=this.gesture;this.gesture=null;if(gesture&&(gesture.moved||gesture.handledSelection||gesture.revision!==this.state.bytes||gesture.owner!==this.api.owner())){this.last=null;return}
  const modified=event.ctrlKey||event.metaKey||event.shiftKey||this.state.tool==='objects'&&document.querySelector('[data-object-add]')?.checked,last=this.last,isDouble=!modified&&(doubleEvent||event.detail>=2||last&&last.revision===this.state.bytes&&last.owner===this.api.owner()&&last.page===index&&now-last.time<500&&Math.hypot(event.clientX-last.x,event.clientY-last.y)<6);
  if(!isDouble&&window.getSelection()?.isCollapsed===false)return;
  const hit=useCached?cached.hit:this.hit(index,point);if(!hit)return;if(this.state.tool==='directedit'&&this.autoTool!=='directedit'&&hit.kind==='text'&&!isDouble)return;if(this.api.draftBlocked()){event.preventDefault();event.stopImmediatePropagation();return}
  if(this.api.locked(index,hit.target.rect)||hit.kind==='field'&&hit.target.readOnly){event.preventDefault();event.stopImmediatePropagation();this.api.toast('This item is locked. Unlock it before editing.');return}
  event.preventDefault();event.stopImmediatePropagation();this.last={x:event.clientX,y:event.clientY,time:now,page:index,owner:this.api.owner(),revision:this.state.bytes,hit,point};
  const direct=isDouble&&(hit.kind==='text'||hit.rich),tool=modified?'objects':direct?'directedit':hit.kind==='image'?'images':hit.kind==='field'?'editfields':'objects';
  if(modified&&!hit.object)return;this.autoTool=tool;if(direct){this.last=null;this.handledDouble={time:now,page:index,revision:this.state.bytes}}
  void this.api.run(async()=>{if(!this.api.available()||this.api.draftBlocked())return;this.api.selectTool(tool,index,modified);if(direct){if(hit.rich)await this.api.rich(hit.target,index);else{const target=this.state.directMode==='line'&&hit.line?hit.line:hit.target;this.api.direct(target,index,bounds,useCached?[frame.left+(point[0]-bounds[0])*this.state.zoom,frame.top+(point[1]-bounds[1])*this.state.zoom]:[event.clientX,event.clientY])}}else if(tool==='images')this.api.image(hit.target,index);else if(tool==='editfields')this.api.field(hit.target,index,bounds);else this.api.object(hit.object,index,{add:modified})})();
 }
 destroy(){for(const [type,fn]of [['pointerdown',this.down],['pointermove',this.move],['pointercancel',this.cancel],['click',this.click],['dblclick',this.double]])this.root.removeEventListener(type,fn,true);this.label.remove();this.cache=new WeakMap();this.manual()}
}
