/* Multi-page thumbnail selection, reordering and contextual organisation. */
import {buildPageArrangement,movePageSelection} from './page-arrangement.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export class PageStrip{
 constructor({root,dock,state,api}){
  Object.assign(this,{root,dock,state,api});this.selected=new Set();this.anchor=null;
  this.outside=e=>{if(this.menu&&!this.menu.contains(e.target))this.closeMenu()};
  this.escape=e=>{if(!this.menu)return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();this.closeMenu(true)}else if(e.key==='Tab')this.closeMenu()};
  this.scroll=e=>{if(this.menu&&(e.type==='resize'||!this.menu.contains(e.target)))this.closeMenu()};
  document.addEventListener('pointerdown',this.outside);document.addEventListener('keydown',this.escape,true);document.addEventListener('scroll',this.scroll,true);window.addEventListener('resize',this.scroll);
  dock.oncontextmenu=e=>{if(!this.available())return;e.preventDefault();const tile=e.target.closest('[data-page]');this.openMenu(tile?+tile.dataset.page:null,e.clientX,e.clientY)};
  root.ondragover=e=>{if(!this.validDrag())return;e.preventDefault();const b=root.getBoundingClientRect();if(e.clientX<b.left+32)root.scrollLeft-=24;else if(e.clientX>b.right-32)root.scrollLeft+=24;if(e.target===root)this.clearDrop()};
  root.ondrop=api.guard(async e=>{if(e.target!==root||!this.validDrag())return;e.preventDefault();const d=this.drag;this.endDrag();await this.reorder(d.pages,state.doc.countPages())});
 }
 available(){return this.api.available()&&!!this.state.doc}
 bind(){
  this.closeMenu();this.endDrag();const id=this.api.activeId(),bytes=this.state.bytes;
  if(id!==this.documentId||bytes!==this.revision){this.documentId=id;this.revision=bytes;this.selected=new Set(this.state.doc?[this.state.page]:[]);this.anchor=this.state.page}
  this.root.querySelectorAll('[data-page]').forEach(tile=>{
   const index=+tile.dataset.page;tile.draggable=true;tile.title='Page '+(index+1)+' · Ctrl/Cmd-click or Shift-click to select; drag to move; right-click for actions';
   tile.onclick=this.api.guard(async(e={})=>{if(!this.available()||Date.now()<(this.suppressClick||0))return;this.closeMenu();if(e.shiftKey&&this.anchor!==null){if(!e.ctrlKey&&!e.metaKey)this.selected.clear();for(let i=Math.min(this.anchor,index);i<=Math.max(this.anchor,index);i++)this.selected.add(i)}else if(e.ctrlKey||e.metaKey){if(this.selected.has(index))this.selected.delete(index);else this.selected.add(index);this.anchor=index}else{this.selected=new Set([index]);this.anchor=index}this.update();if(!e.shiftKey&&!e.ctrlKey&&!e.metaKey)await this.api.go(index)});
   tile.onkeydown=this.api.guard(async e=>{if(!this.available())return;if(e.key==='ContextMenu'||e.key==='F10'&&e.shiftKey){e.preventDefault();e.stopPropagation();const b=tile.getBoundingClientRect();this.openMenu(index,b.left,b.top)}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='a'){e.preventDefault();e.stopPropagation();this.selectAll()}else if(e.altKey&&['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();e.stopPropagation();await this.action(e.key==='ArrowLeft'?'earlier':'later')}else if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();e.stopPropagation();await this.action('delete')}});
   tile.ondragstart=e=>{if(!this.available()){e.preventDefault();return}if(!this.selected.has(index)){this.selected=new Set([index]);this.anchor=index}this.update();this.closeMenu();this.drag={id:this.api.activeId(),bytes:this.state.bytes,pages:this.pages()};e.dataTransfer?.setData('application/x-pdfcreator-pages',JSON.stringify(this.drag.pages));if(e.dataTransfer)e.dataTransfer.effectAllowed='move'};
   tile.ondragover=e=>{if(!this.validDrag())return;e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect='move';this.clearDrop();const b=tile.getBoundingClientRect(),after=e.clientX>=b.left+b.width/2;tile.classList.add(after?'page-drop-after':'page-drop-before')};
   tile.ondragleave=()=>tile.classList.remove('page-drop-before','page-drop-after');
   tile.ondrop=this.api.guard(async e=>{if(!this.validDrag())return;e.preventDefault();e.stopPropagation();const b=tile.getBoundingClientRect(),boundary=index+(e.clientX>=b.left+b.width/2?1:0),d=this.drag;this.endDrag();this.suppressClick=Date.now()+250;await this.reorder(d.pages,boundary)});
   tile.ondragend=()=>this.endDrag();
  });this.update();
 }
 pages(){return[...this.selected].sort((a,b)=>a-b)}
 update(){
  for(const tile of this.root.querySelectorAll('[data-page]')){const chosen=this.selected.has(+tile.dataset.page);tile.classList.toggle('page-selected',chosen);tile.setAttribute('aria-pressed',String(chosen))}
  const label=document.getElementById('pageSelectionStatus');if(label)label.textContent=this.selected.size>1?this.selected.size+' selected':'';
 }
 selectAll(){this.selected=new Set(Array.from({length:this.state.doc.countPages()},(_,i)=>i));this.update()}
 clearDrop(){this.root.querySelectorAll('.page-drop-before,.page-drop-after').forEach(n=>n.classList.remove('page-drop-before','page-drop-after'))}
 endDrag(){this.drag=null;this.clearDrop()}
 validDrag(){return this.drag&&this.available()&&this.drag.id===this.api.activeId()&&this.drag.bytes===this.state.bytes}
 closeMenu(focus=false){this.menu?.remove();this.menu=null;if(focus)this.root.querySelector(`[data-page="${this.contextPage??this.state.page}"]`)?.focus()}
 openMenu(index,x,y){
  if(!this.available())return;this.closeMenu();if(index!==null&&!this.selected.has(index)){this.selected=new Set([index]);this.anchor=index}if(!this.selected.size)this.selected.add(this.state.page);this.update();this.contextPage=index??this.state.page;
  const menu=document.createElement('div');menu.id='pageContextMenu';menu.className='page-context-menu';menu.setAttribute('role','menu');menu.setAttribute('aria-label','Page actions');
  const actions=[['all','Select all pages'],['rotate','Rotate clockwise'],['duplicate','Duplicate'],['delete','Delete'],['extract','Extract to PDF'],['earlier','Move earlier'],['later','Move later'],['blankBefore','Insert blank page before'],['blankAfter','Insert blank page after'],['insert','Insert pages from PDF…'],['replace','Replace selected from PDF…'],['organiser','Open Page organiser…']];
  menu.innerHTML='<div class="page-menu-summary">'+this.selected.size+' page'+(this.selected.size===1?'':'s')+' selected</div>'+actions.map(([id,label])=>`<button type="button" role="menuitem" data-page-action="${id}" ${id==='delete'?'class="danger"':''}>${label}</button>`).join('');
  this.menu=menu;document.body.append(menu);const width=menu.offsetWidth||228,height=menu.offsetHeight||470;Object.assign(menu.style,{left:Math.max(8,Math.min(x,window.innerWidth-width-8))+'px',top:Math.max(8,Math.min(y,window.innerHeight-height-8))+'px'});
  menu.querySelectorAll('[data-page-action]').forEach(button=>button.onclick=this.api.guard(async()=>{const action=button.dataset.pageAction;this.closeMenu();await this.action(action)}));
  menu.onkeydown=e=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();e.stopPropagation();const buttons=[...menu.querySelectorAll('button')],at=buttons.indexOf(document.activeElement);buttons[e.key==='Home'?0:e.key==='End'?buttons.length-1:(at+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus()};menu.querySelector('button')?.focus();
 }
 items(){return Array.from({length:this.state.doc.countPages()},(_,page)=>({page,source:0,rotation:0}))}
 async commit(label,items,sources=[{bytes:this.state.bytes}],chosen=null){
  const revision=this.state.bytes,previous=this.state.page;let next=items.findIndex(i=>i.source===0&&i.page===previous);if(next<0)next=Math.min(previous,items.length-1);
  await this.api.editPDF(label,doc=>buildPageArrangement({...this.api,items,sources,dest:doc}));
  if(revision===this.state.bytes)return;await this.api.go(next);this.selected=new Set(chosen||[next]);this.anchor=this.pages()[0];this.revision=this.state.bytes;this.update();
 }
 async reorder(pages,boundary){
  const count=this.state.doc.countPages(),chosen=new Set(pages),order=movePageSelection(count,chosen,boundary);if(order.every((n,i)=>n===i))return;
  await this.commit('Moved selected pages',order.map(page=>({page,source:0})),undefined,order.flatMap((page,i)=>chosen.has(page)?[i]:[]));
 }
 async action(action){
  if(!this.available())return;if(action==='all'){this.selectAll();return}if(action==='organiser'){await this.api.organiser();return}
  const selected=this.pages();if(!selected.length)throw Error('Select one or more pages first.');const set=new Set(selected),items=this.items();
  if(action==='rotate'){for(const item of items)if(set.has(item.page))item.rotation=90;await this.commit('Rotated selected pages',items,undefined,selected)}
  else if(action==='duplicate'){const copies=items.flatMap(item=>set.has(item.page)?[item,{...item}]:[item]);await this.commit('Duplicated selected pages',copies,undefined,copies.flatMap((item,i)=>set.has(item.page)?[i]:[]))}
  else if(action==='delete'){if(selected.length===items.length)throw Error('A PDF must retain at least one page.');const revision=this.state.bytes;if(!await this.api.confirm('Delete '+selected.length+' selected page'+(selected.length===1?'?':'s?'),'The selected pages will be removed. You can undo this change.','Delete pages'))return;if(revision!==this.state.bytes)throw Error('The document changed. Select its pages again.');await this.commit('Deleted selected pages',items.filter(item=>!set.has(item.page)))}
  else if(action==='blankBefore'||action==='blankAfter'){const at=action==='blankBefore'?selected[0]:selected.at(-1)+1,p=this.state.doc.loadPage(this.contextPage??selected[0]);let size;try{const b=p.getBounds();size=[b[2]-b[0],b[3]-b[1]]}finally{p.destroy()}items.splice(at,0,{source:-1,size});await this.commit('Inserted blank page',items,undefined,[at])}
  else if(action==='earlier'||action==='later'){const order=items.map(i=>i.page);if(action==='earlier'){for(let n=1;n<order.length;n++)if(set.has(order[n])&&!set.has(order[n-1]))[order[n-1],order[n]]=[order[n],order[n-1]]}else for(let n=order.length-2;n>=0;n--)if(set.has(order[n])&&!set.has(order[n+1]))[order[n],order[n+1]]=[order[n+1],order[n]];if(order.some((n,i)=>n!==i))await this.commit('Moved selected pages',order.map(page=>({page,source:0})),undefined,order.flatMap((p,i)=>set.has(p)?[i]:[]))}
  else if(action==='extract'){await this.api.ensureSplitSourcesSafe([{bytes:this.state.bytes,name:this.state.name,marks:this.state.marks}]);const doc=await buildPageArrangement({...this.api,items:items.filter(i=>set.has(i.page)),sources:[{bytes:this.state.bytes}]});this.api.download(await doc.save({useObjectStreams:false}),this.api.outname('-selected-pages'))}
  else if(action==='insert'||action==='replace')await this.importPages(action,items,selected);
 }
 async importPages(action,items,selected){
  const revision=this.state.bytes,id=this.api.activeId(),tabs=this.api.tabs.filter(t=>t.id!==id),$=id=>document.getElementById(id);
  const result=await this.api.modal(action==='replace'?'Replace selected pages':'Insert pages from PDF','<label for="stripSource">Source PDF</label><select id="stripSource"><option value="upload">Upload PDF…</option>'+tabs.map(t=>`<option value="${esc(t.id)}">${esc(t.snapshot.name)}</option>`).join('')+'</select><label for="stripSourceFile">PDF file (for Upload PDF)</label><input id="stripSourceFile" type="file" accept="application/pdf"><label for="stripRange">Source pages</label><input id="stripRange" placeholder="All pages, or e.g. 1-3,5"><p class="help">'+(action==='replace'?'Replaces all selected pages at the first selected position.':'Inserts after the last selected page.')+'</p>',{read:async()=>{const source=$('stripSource').value;let bytes,name,marks=[];if(source==='upload'){const file=$('stripSourceFile').files[0];if(!file)throw Error('Choose a PDF file.');bytes=new Uint8Array(await file.arrayBuffer());name=file.name}else{const tab=tabs.find(t=>t.id===source);if(!tab)throw Error('Source tab is unavailable.');bytes=tab.snapshot.bytes;name=tab.snapshot.name;marks=tab.snapshot.marks||[]}if(marks.length)throw Error('Apply or clear pending redactions in the source PDF.');if((await window.PdfProSigning.inspectSignatures(bytes)).length)throw Error('Use an unsigned source PDF.');const doc=this.api.Engine.openPDF(bytes);try{return{bytes,name,pages:$('stripRange').value.trim()?this.api.parsePages($('stripRange').value,doc.countPages()):Array.from({length:doc.countPages()},(_,i)=>i)}}finally{doc.destroy()}},setup:()=>{$('stripSource').onchange=()=>{$('stripSourceFile').disabled=$('stripSource').value!=='upload'}}});
  if(!result)return;if(revision!==this.state.bytes||id!==this.api.activeId())throw Error('The document changed. Select its pages again.');
  const set=new Set(selected),at=action==='replace'?selected[0]:selected.at(-1)+1,rest=action==='replace'?items.filter(i=>!set.has(i.page)):items,newItems=result.pages.map(page=>({page,source:1}));rest.splice(at,0,...newItems);await this.commit(action==='replace'?'Replaced selected pages':'Inserted PDF pages',rest,[{bytes:revision},result],newItems.map((_,i)=>at+i));
 }
 destroy(){this.closeMenu();this.endDrag();document.removeEventListener('pointerdown',this.outside);document.removeEventListener('keydown',this.escape,true);document.removeEventListener('scroll',this.scroll,true);window.removeEventListener('resize',this.scroll)}
}
