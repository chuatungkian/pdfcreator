/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {installTestWorkers} from './test-worker-runtime.mjs';
import {gunzipSync} from 'node:zlib';
let context;
const runtime=installTestWorkers();
try{
 context=await boot();const {app,$,window,downloads}=context;
 const html=fs.readFileSync('../../outputs/pdfcreator.html','utf8');window.PDFPRO_ASSETS=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64')));
 const PDF=app.PDFLib,pic=canvas.createCanvas(1000,800),ctx=pic.getContext('2d'),pixels=ctx.createImageData(1000,800);let seed=73;for(let i=0;i<pixels.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;pixels.data[i]=seed&255;pixels.data[i+1]=(seed>>>8)&255;pixels.data[i+2]=(seed>>>16)&255;pixels.data[i+3]=255}ctx.putImageData(pixels,0,0);
 const pdf=await PDF.PDFDocument.create(),image=await pdf.embedPng(pic.toBuffer('image/png'));for(let n=0;n<2;n++){const p=pdf.addPage([595,842]);p.drawText('KEEP EDITABLE TEXT '+n,{x:40,y:750,size:15});p.drawImage(image,{x:40,y:100,width:500,height:400})}await app.openFiles([file('Size choice.pdf',new Uint8Array(await pdf.save({useObjectStreams:false})))]);await app.editPDF('Initial edit',doc=>doc.getPage(0).drawText('EDIT TO SAVE',{x:40,y:700,size:14}));await $('next').onclick();const original=app.state.bytes,history=app.state.undo.length,owner=app.activeTabId;
 const submit=()=> $('modalform').onsubmit({preventDefault(){}}),mode=value=>{$('saveCompression').value=value;$('saveCompression').onchange()};
 let reviewTask;const readyTask=async()=>{await pending;await until(()=>['ready','error'].includes(app.documentJobs.forTab(owner)?.status),'background compression ready');const j=app.documentJobs.forTab(owner);if(j.status==='error')throw Error(j.message);return j};const openReview=async()=>{const j=await readyTask();reviewTask=j.actions[0].run(j)};
 let pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'save settings');equal($('saveCompression').value,'original','unchanged is default');check($('modalform').textContent.includes('Current file size'),'current size shown');equal([...$('saveCompression').options].map(o=>o.value),['original','lossless','high','balanced','small','target'],'all compression choices');$('modalcancel').click();await pending;equal(downloads.length,0,'cancelling settings does not download');check(app.state.dirty,'cancel retains unsaved status');
 pending=$('saveBtn').onclick();await until(()=>$('saveName'),'filename field');$('saveName').value='Original export';await submit();await until(()=>$('modaltitle')?.textContent==='Export review','unchanged export review');await submit();await pending;equal(downloads.at(-1).name,'Original export.pdf','filename extension added');equal(new Uint8Array(await runtime.blob(downloads.at(-1).href).arrayBuffer()),original,'unchanged mode exports exact active bytes');check(!app.state.dirty,'completed save clears dirty indicator');
 pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'balanced settings');mode('balanced');check(!$('saveImageHelp').hidden&&$('saveTargetOptions').hidden,'mode describes quality tradeoff');await submit();await openReview();await until(()=>$('modaltitle')?.textContent==='Export review','balanced result');check($('modalform').textContent.includes('Reduction'),'actual resulting size shown before download');const beforeDownload=downloads.length;equal(downloads.length,beforeDownload,'preparation does not auto-download');await submit();await reviewTask;await pending;const balanced=new Uint8Array(await runtime.blob(downloads.at(-1).href).arrayBuffer());check(balanced.length<original.length*.7,'worker image compression reduces PDF');check(app.Engine.extractTextPDF(balanced).every(p=>p.text.includes('KEEP EDITABLE TEXT')),'saved compressed PDF retains searchable text');equal(app.state.bytes,original,'compressed export preserves open PDF quality');equal(app.state.undo.length,history,'export preserves undo history');equal(app.state.page,1,'compressed save retains current page');equal(app.activeTabId,owner,'compressed save retains active tab');
 pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'target size settings');mode('target');check(!$('saveTargetOptions').hidden,'target size input appears');document.querySelector('[data-target-mb="2"]').click();equal($('saveTargetSize').value,'2','target preset fills size');equal($('saveTargetUnit').value,'MB','preset uses decimal MB');$('saveTargetSize').value='0';await submit();check($('modalerror').textContent.includes('target'),'invalid size rejected in dialogue');$('saveTargetSize').value='1';$('saveTargetUnit').value='kB';await submit();await openReview();await until(()=>$('saveTargetResult'),'unattainable target result');check($('saveTargetResult').textContent.includes('not reached'),'target failure stated honestly');check($('modalform').querySelector('[type=submit]').textContent.includes('available'),'best available download requires explicit choice');$('modalcancel').click();await reviewTask;await pending;equal(downloads.length,beforeDownload+1,'cancelling result keeps downloads unchanged');equal(app.state.bytes,original,'failed target does not change open PDF');
 pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'attainable target');mode('target');$('saveTargetSize').value='1';$('saveTargetUnit').value='MB';await submit();await openReview();await until(()=>$('saveTargetResult'),'target reached result');check($('saveTargetResult').textContent.includes('Target reached'),'attainable target confirmed');await submit();await reviewTask;await pending;check(runtime.blob(downloads.at(-1).href).size<=1000000,'download is at or below chosen maximum');
 pending=app.activate('optimize');await until(()=>$('saveCompression'),'Compress tool settings');check(![...$('saveCompression').options].some(o=>o.value==='original'),'working-copy compression offers compression modes');mode('small');await submit();await (await readyTask()).actions[0].run(app.documentJobs.forTab(owner));await pending;check(app.state.bytes.length<original.length,'Compress tool applies smaller PDF');equal(app.state.undo.length,history+1,'applied compression is one undo step');equal(app.state.page,1,'applied compression retains page');check(text(app).includes('EDIT TO SAVE'),'compression retains edits');await $('undo').onclick();equal(app.state.bytes,original,'undo restores exact original quality');await $('redo').onclick();check(app.state.bytes.length<original.length,'redo restores compression');
 const beforeCancel=app.state.bytes;pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'cancel compression');mode('target');$('saveTargetSize').value='.001';await submit();await pending;const cancelling=app.documentJobs.forTab(owner);app.documentJobs.cancel(cancelling.id);await until(()=>cancelling.status==='cancelled','worker cancelled');equal(app.state.bytes,beforeCancel,'worker cancellation preserves PDF');check(cancelling.message.includes('Cancelled'),'cancel feedback displayed');check(!app.state.abort,'cancellation releases task state');
 pending=$('saveBtn').onclick();await until(()=>$('saveName'),'invalid filename');$('saveName').value='../bad.pdf';await submit();check($('modalerror').textContent.includes('file name'),'path-like filename rejected');$('modalcancel').click();await pending;
 app.state.marks=[{page:0,rect:[10,10,20,20]}];pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'redaction save options');await submit();await until(()=>$('modaltitle')?.textContent==='Pending redactions','redaction warning');$('modalcancel').click();await pending;check(app.state.marks.length===1,'cancelled redaction save keeps pending marks');app.state.marks=[];
 const signing=window.PdfProSigning;window.PdfProSigning={...signing,inspectSignatures:async()=>[{}]};const beforeSigned=downloads.length;pending=$('saveBtn').onclick();await until(()=>$('saveCompression'),'signed save options');mode('balanced');await submit();await until(()=>$('modaltitle')?.textContent==='This PDF contains signatures','signature rewrite confirmation');$('modalcancel').click();await pending;equal(downloads.length,beforeSigned,'declining signature rewrite does not export');equal(app.state.bytes,beforeCancel,'declining signature rewrite preserves source');window.PdfProSigning=signing;
 equal(runtime.networkAttempts,0,'real embedded compression worker makes no network requests');await app.local.flush();const saved=app.state.bytes;await context.close();context=null;console.log('PDFCreator compression interactions: '+assertions+' assertions passed with actual embedded workers and controlled save UI.');
}finally{if(context)await context.close();runtime.close()}
