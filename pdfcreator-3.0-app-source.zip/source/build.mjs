// Current portable release build. The full engine rebuild is retained in build-full.mjs.
import './build-portable.mjs';
