// pdfpro reproducible single-file packager. AGPL-3.0-or-later.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {build} from 'esbuild';
import {sourceCRC} from './source-package.js';
const root=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const out=path.resolve(root,'../../outputs');fs.mkdirSync(out,{recursive:true});
const read=f=>fs.readFileSync(f),text=f=>fs.readFileSync(f,'utf8');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const config={absWorkingDir:root,tsconfigRaw:{},bundle:true,write:false,format:'esm',platform:'browser',target:['chrome110','firefox115','safari17'],minify:true,legalComments:'inline',external:['node:fs','module']};
const app=(await build({...config,entryPoints:[path.join(root,'app.mjs')]})).outputFiles[0].text;
const engineWorker=(await build({...config,define:{'import.meta.url':'"https://pdfpro.invalid/embedded.mjs"'},entryPoints:[path.join(root,'engine-worker.mjs')]})).outputFiles[0].text;
const licenses=[
 ['PDFCreator 3.0 (AGPL-3.0-or-later)','node_modules/mupdf/LICENSE'],
 ['MuPDF 1.28.1 — Artifex Software, Inc. (AGPL-3.0-or-later)','node_modules/mupdf/LICENSE'],
 ['pdf-lib 1.17.1 (MIT)','node_modules/pdf-lib/LICENSE.md'],
 ['node-forge 1.4.0 (BSD option)','node_modules/node-forge/LICENSE'],
 ['Tesseract.js 7.0.0 (Apache-2.0)','node_modules/tesseract.js/LICENSE.md'],
 ['Tesseract.js-core 6.1.2 (Apache-2.0)','node_modules/tesseract.js-core/LICENSE'],
 ['Inter 4.1 — The Inter Project Authors (SIL Open Font License 1.1)','fonts/Inter-LICENSE.txt']
];
let notices='PDFCreator 3.0 THIRD-PARTY NOTICES\n\nEnglish model: tesseract-ocr/tessdata_fast eng.traineddata (Apache-2.0).\nSource: https://github.com/tesseract-ocr/tessdata_fast\nSHA256 '+sha(read('eng-fast.traineddata'))+'\n\nMuPDF full corresponding source accompanies the release ZIP under upstream/.\nDo not omit source access or licensing when redistributing.\n\n';
for(const[label,file]of licenses){if(!fs.existsSync(file))throw Error('Missing license '+file);notices+='\n\n======== '+label+' ========\n\n'+text(file)}
// Retain preferred JS/TS sources and notices for the exact bundled npm packages.
// Symlinks are skipped: every pnpm package has one real directory in this store.
const dependencySources=[];
function collectSources(dir,relative=''){
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  if(entry.isSymbolicLink())continue;
  const full=path.join(dir,entry.name),rel=relative?relative+'/'+entry.name:entry.name;
  if(entry.isDirectory()){collectSources(full,rel);continue}
  if(/\.(?:[cm]?js|tsx?|json|md|txt|ya?ml|c|h)$/.test(entry.name)||/^(LICENSE|LICENCE|COPYING|NOTICE)(?:\.|$)/i.test(entry.name)){
   // Large generated WASM loaders are already retained once under vendor/.
   if(rel.includes('tesseract.js-core@')&&/^tesseract-core.*\.(?:wasm\.)?js$/.test(entry.name))continue;
   dependencySources.push(['source/dependencies/'+rel,read(full)]);
   if(/^(LICENSE|LICENCE|COPYING|NOTICE)(?:\.|$)/i.test(entry.name))notices+='\n\n======== '+rel+' ========\n\n'+text(full);
  }
 }
}
collectSources('node_modules/.pnpm');
fs.writeFileSync('LICENSE.txt',text('node_modules/mupdf/LICENSE'));
fs.writeFileSync('THIRD-PARTY-NOTICES.txt',notices);
const table=Uint32Array.from({length:256},(_,i)=>{let c=i;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0});
function crc(b){let c=0xffffffff;for(const n of b)c=table[(c^n)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function zip(entries){const chunks=[],central=[];let offset=0;for(const[name,bytes0]of entries){const bytes=Buffer.from(bytes0),n=Buffer.from(name),data=zlib.deflateRawSync(bytes,{level:6}),sum=crc(bytes),h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50);h.writeUInt16LE(20,4);h.writeUInt16LE(0x800,6);h.writeUInt16LE(8,8);h.writeUInt32LE(sum,14);h.writeUInt32LE(data.length,18);h.writeUInt32LE(bytes.length,22);h.writeUInt16LE(n.length,26);chunks.push(h,n,data);const c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50);c.writeUInt16LE(20,4);c.writeUInt16LE(20,6);c.writeUInt16LE(0x800,8);c.writeUInt16LE(8,10);c.writeUInt32LE(sum,16);c.writeUInt32LE(data.length,20);c.writeUInt32LE(bytes.length,24);c.writeUInt16LE(n.length,28);c.writeUInt32LE(offset,42);central.push(c,n);offset+=30+n.length+data.length}const end=Buffer.alloc(22),size=central.reduce((n,b)=>n+b.length,0);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(size,12);end.writeUInt32LE(offset,16);return Buffer.concat([...chunks,...central,end])}
const sources=fs.readdirSync(root).filter(f=>/\.(?:m?js|html|css|txt|md|json|yaml)$/.test(f)&&!f.includes('release')&&!f.includes('browser-results')).map(f=>['source/'+f,read(f)]);
sources.push(...dependencySources);
sources.push(['source/eng-fast.traineddata',read('eng-fast.traineddata')]);
sources.push(['source/fonts/InterVariable.woff2',read('fonts/InterVariable.woff2')]);
sources.push(['source/fonts/Inter-LICENSE.txt',read('fonts/Inter-LICENSE.txt')]);
// Retain exact distributed engine artifacts so app reconstruction requires no native toolchain.
for(const dir of ['mupdf/dist','pdf-lib/dist','node-forge/dist','tesseract.js/dist','tesseract.js-core']){
 for(const f of fs.readdirSync('node_modules/'+dir)){
  const full='node_modules/'+dir+'/'+f;
  if(fs.statSync(full).isFile()&&(/^(mupdf\.js|mupdf-wasm\.(js|wasm)|pdf-lib\.min\.js|forge\.min\.js|worker\.min\.js|tesseract-core-lstm\.(js|wasm)|LICENSE)$/.test(f)))sources.push(['source/vendor/'+dir+'/'+f,read(full)]);
 }
}
const sourceZip=zip(sources);
const runtimeSources=[
 ['mupdf',read('node_modules/mupdf/dist/mupdf-wasm.wasm')],
 ['ocr-wasm',read('node_modules/tesseract.js-core/tesseract-core-lstm.wasm')],
 ['ocr-model',read('eng-fast.traineddata')],
 ['ocr-worker',read('node_modules/tesseract.js/dist/worker.min.js')],
 ['ocr-core',read('node_modules/tesseract.js-core/tesseract-core-lstm.js')],
 ['notices',Buffer.from(notices)],['inter',read('fonts/InterVariable.woff2')]
];
const sharedHashes=new Map(runtimeSources.map(([asset,bytes])=>[sha(bytes),{asset,bytes}]));
const uniqueSources=new Map(),sourceChunks=[],sourceEntries=[];let poolSize=0,sharedEntries=0,duplicateEntries=0;
for(const[name,bytes]of sources){
 const hash=sha(bytes),shared=sharedHashes.get(hash);let location;
 if(shared&&shared.bytes.equals(bytes)){location={asset:shared.asset};sharedEntries++}
 else if(uniqueSources.has(hash)){location=uniqueSources.get(hash);duplicateEntries++}
 else{const chunk=zlib.deflateRawSync(bytes,{level:6});location={offset:poolSize,length:chunk.length};sourceChunks.push(chunk);poolSize+=chunk.length;uniqueSources.set(hash,location)}
 sourceEntries.push({name,size:bytes.length,crc:sourceCRC(bytes),...location});
}
const sourceArchive={version:1,entries:sourceEntries,poolBase64:Buffer.concat(sourceChunks).toString('base64')};
const assets={app,engineWorker,notices,sourceArchive,mupdfBase64:runtimeSources[0][1].toString('base64'),ocr:{workerSource:runtimeSources[3][1].toString('utf8'),coreSource:runtimeSources[4][1].toString('utf8'),coreWasmBase64:runtimeSources[1][1].toString('base64'),languageDataBase64:runtimeSources[2][1].toString('base64'),language:'eng'}};
const payload=zlib.gzipSync(Buffer.from(JSON.stringify(assets)),{level:9}).toString('base64');
const boot=`<script id="pdfpro-payload" type="application/octet-stream">${payload}</script><script>
(async()=>{try{const data=document.getElementById('pdfpro-payload').textContent;const raw=Uint8Array.from(atob(data),c=>c.charCodeAt(0));const stream=new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'));const assets=JSON.parse(await new Response(stream).text());window.PDFCREATOR_ASSETS=window.PDFPRO_ASSETS=assets;globalThis['$libmupdf_wasm_Module']={locateFile:()=>"embedded.wasm",wasmBinary:Uint8Array.from(atob(assets.mupdfBase64),c=>c.charCodeAt(0))};const script=document.createElement('script');script.type='module';script.textContent=assets.app;script.onerror=()=>{document.getElementById('bootmsg').textContent='Unable to start the PDF engine. Use a current desktop browser.'};document.body.append(script)}catch(e){document.getElementById('bootmsg').textContent='Startup failed: '+e.message;console.error(e)}})();
</script>`;
const fontCSS='@font-face{font-family:Inter;src:url(data:font/woff2;base64,'+read('fonts/InterVariable.woff2').toString('base64')+') format("woff2");font-style:normal;font-weight:100 900;font-display:swap}';
const html=text('shell.html').replace('/* PDFPRO_FONT */',fontCSS).replace('/* PDFPRO_LAYOUT */',text('layout.css')).replace('/* PDFPRO_REFRESH */',text('refresh.css')).replace('<!-- PDFPRO_BOOT -->',boot);
// A decimal 25 MB cap is stricter than 25 MiB. Fail before replacing deliverables.
if(Buffer.byteLength(html)>=25000000)throw Error('The offline HTML exceeds the 25,000,000-byte release limit.');
fs.writeFileSync(path.join(out,'pdfcreator.html'),html);
fs.writeFileSync(path.join(out,'pdfpro.html'),html);
fs.writeFileSync(path.join(out,'pdfcreator-3.0-app-source.zip'),sourceZip);
const releaseEntries=[['index.html',Buffer.from(html)],['README.txt',read('README.txt')],['LICENSE.txt',read('LICENSE.txt')],['THIRD-PARTY-NOTICES.txt',Buffer.from(notices)],['pdfcreator-3.0-app-source.zip',sourceZip],['.nojekyll',Buffer.alloc(0)],['upstream/mupdf-1.28.1-source.tar.gz',read('mupdf-1.28.1-source.tar.gz')]];
if(fs.existsSync('VALIDATION.template.txt')){
 const validation=text('VALIDATION.template.txt').replaceAll('{{HTML_SHA256}}',sha(Buffer.from(html)));
 fs.writeFileSync(path.join(out,'pdfcreator-VALIDATION.txt'),validation);
 releaseEntries.push(['VALIDATION.txt',Buffer.from(validation)]);
}
if(fs.existsSync('FEATURE-AUDIT.template.txt')){
 const audit=text('FEATURE-AUDIT.template.txt').replaceAll('{{HTML_SHA256}}',sha(Buffer.from(html)));
 fs.writeFileSync(path.join(out,'pdfcreator-FEATURE-AUDIT.txt'),audit);releaseEntries.push(['FEATURE-AUDIT.txt',Buffer.from(audit)]);
}
fs.writeFileSync(path.join(out,'pdfcreator-3.0-github.zip'),zip(releaseEntries));
const hashes=['pdfcreator.html','pdfpro.html','pdfcreator-3.0-app-source.zip','pdfcreator-3.0-github.zip'].map(f=>sha(read(path.join(out,f)))+'  '+f).join('\n');
fs.writeFileSync(path.join(out,'pdfcreator-SHA256SUMS.txt'),hashes+'\n');
console.log(JSON.stringify({htmlBytes:Buffer.byteLength(html),appSourceBytes:sourceZip.length,compactSourceBytes:poolSize,sourceEntries:sourceEntries.length,sharedEntries,duplicateEntries,releaseBytes:fs.statSync(path.join(out,'pdfcreator-3.0-github.zip')).size,htmlSHA256:sha(Buffer.from(html))},null,2));
