/* Standalone bundled worker. Network access is disabled for built-in conversion. */
import {convertOfflineWord} from './offline-word-converter.js';
let networkAttempts=0;
self.fetch=()=>{networkAttempts++;throw Error('The built-in converter cannot request network resources.');};
self.onmessage=async event=>{const {id,bytes,fonts,password}=event.data;try{const result=await convertOfflineWord(bytes,fonts,{password,onProgress:(progress,message)=>self.postMessage({id,progress,message})});if(networkAttempts)throw Error('Conversion requested an external resource and was stopped.');self.postMessage({id,result:{...result,networkAttempts}},[result.bytes.buffer])}catch(error){self.postMessage({id,error:{name:error.name||'Error',message:error.message||String(error)}})}};
self.postMessage({ready:true});
