/* Reflow within one horizontal text column, stopping at artwork and page edges. */
export const intersects=(a,b,p=.5)=>a[0]<b[2]-p&&a[2]>b[0]+p&&a[1]<b[3]-p&&a[3]>b[1]+p;
export function columnFollowers(target,nextRect,candidates,obstacles,bounds){
 if(!nextRect)return[];if(target.layout.u&&Math.abs(target.layout.u[1])>.01)throw Error('Column reflow needs horizontal text. Use Fit text for rotated text.');
 const before=target.rect,left=target.layout.left??before[0],tolerance=Math.max(8,target.size),right=Math.max(left+target.layout.width,...candidates.filter(t=>t.rect[1]>=before[3]-.5&&Math.abs(t.rect[0]-left)<=tolerance).map(t=>t.rect[2])),delta=nextRect[3]-before[3];if(Math.abs(delta)<.1)return[];
 const barriers=obstacles.filter(o=>{const r=o.rect;return r[1]>before[1]+1&&r[2]>left+2&&r[0]<right-2&&!(r[0]<=before[0]&&r[1]<=before[1]&&r[2]>=before[2]&&r[3]>=before[3])});
 const limit=Math.min(bounds[3]-2,...barriers.map(o=>o.rect[1]));
 const parts=new Set(target.parts?.map(p=>p.index));const following=candidates.filter(t=>t!==target&&!(target.id&&t.id===target.id)&&t.rect[1]>=before[3]-.5&&t.rect[1]<limit&&t.rect[0]>=left-tolerance&&t.rect[0]<=left+tolerance&&t.rect[2]<=right+tolerance&&!t.parts?.some(p=>parts.has(p.index))).sort((a,b)=>a.rect[1]-b.rect[1]);
 if(nextRect[3]>limit+.5)throw Error('Column reflow reaches artwork, a table or the page edge. Choose Fit text or a larger text region.');
 for(const t of following){const r=t.rect.map((v,i)=>i%2?v+delta:v);if(r[1]<nextRect[3]-.5||r[3]>limit+.5||r[0]<bounds[0]-1||r[2]>bounds[2]+1||barriers.some(o=>intersects(r,o.rect)))throw Error('Following text would reach a table, image or page edge. Choose Fit text.');if(candidates.some(o=>o!==t&&!following.includes(o)&&o!==target&&!o.parts?.some(p=>parts.has(p.index))&&intersects(r,o.rect)))throw Error('Column reflow would collide with another column. Choose Fit text.');}
 return following.map(t=>({target:t,matrix:[1,0,0,1,0,delta]}));
}
