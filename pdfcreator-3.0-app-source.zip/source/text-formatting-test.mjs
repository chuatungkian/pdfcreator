/* Native formatting, decoration lifecycle, rotations and saved/reopened PDFs. */
import assert from 'node:assert/strict';
import {PDFDocument,StandardFonts,degrees} from 'pdf-lib';
import * as E from './engine.js';
import {directEditTargets,directTextTargets,replaceDirectTextGroup,transformDirectText,saveDirectEdit} from './direct-text.js';
let count=0;const check=(v,label)=>{count++;assert.ok(v,label)};
for(const rotation of [0,90,180,270]){
 const d=await PDFDocument.create(),p=d.addPage([595,842]),font=await d.embedFont(StandardFonts.Helvetica);p.setRotation(degrees(rotation));p.drawText('Format these words',{x:50,y:700,size:14,font});p.drawText('Keep this neighbour',{x:50,y:500,size:14,font});
 const original=await d.save(),doc=E.openPDF(original);
 try{
  const target=directEditTargets(doc,0)[0];
  replaceDirectTextGroup(doc,0,target,target.text,{width:350,formatting:[{start:7,end:12,style:{bold:true,italic:true,font:'Times-Roman',size:18,color:'#0044aa',underline:true,strikethrough:true}}]});
  const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);
  try{
   const runs=directTextTargets(reopened,0),changed=runs.find(r=>r.text.includes('these')),plain=runs.find(r=>r.text.includes('Format'));
   check(changed?.bold&&changed.italic,'bold and italic survive reopen');check(changed.size===18,'size survives reopen');check(changed.color==='#0044aa','colour survives reopen');check(/Times|NimbusRoman/i.test(changed.fontName),'font changed');check(changed.underline&&changed.strikethrough,'decorations survive reopen');check(plain.size===14&&!plain.bold,'unselected text retains appearance');
   const page=reopened.loadPage(0),annotations=page.getAnnotations();check(annotations.length===2,'both decorations exported');for(const a of annotations){check(a.getQuadPoints()[0].every(Number.isFinite),'valid rotated annotation quads');a.destroy()}page.destroy();
   check(E.extractTextPDF(bytes)[0].text.includes('Format these words'),'formatted output stays searchable');check(E.extractTextPDF(bytes)[0].text.includes('Keep this neighbour'),'neighbour retained');
   const next=directEditTargets(reopened,0).find(t=>t.text.startsWith('Format'));
   replaceDirectTextGroup(reopened,0,next,next.text,{width:350,formatting:[{start:0,end:Array.from(next.text).length,style:{underline:false,strikethrough:false,bold:false,italic:false,font:'Courier',size:16,color:'#800020'}}]});
   const cleared=E.openPDF(saveDirectEdit(reopened));try{const page=cleared.loadPage(0),a=page.getAnnotations();check(a.length===0,'turning decorations off removes old marks');a.forEach(x=>x.destroy());page.destroy();check(directTextTargets(cleared,0).filter(t=>t.text.includes('Format')).every(t=>!t.bold&&!t.italic),'bold and italic can be removed')}finally{cleared.destroy()}
  }finally{reopened.destroy()}
 }finally{doc.destroy()}
}
const d=await PDFDocument.create();d.addPage().drawText('Safe original',{x:50,y:700});const doc=E.openPDF(await d.save());try{for(const style of [{size:999},{font:'unexpected'},{color:'red'},{underline:'yes'}]){const target=directEditTargets(doc,0)[0];assert.throws(()=>replaceDirectTextGroup(doc,0,target,target.text,{formatting:[{start:0,end:4,style}]}));check(directEditTargets(doc,0)[0].text==='Safe original','invalid formatting preserves source')}}finally{doc.destroy()}
{
 const d=await PDFDocument.create();d.addPage().drawText('Moving style',{x:50,y:700,size:14});const doc=E.openPDF(await d.save());try{
  let target=directEditTargets(doc,0)[0];replaceDirectTextGroup(doc,0,target,target.text,{formatting:[{start:0,end:target.text.length,style:{underline:true,strikethrough:true}}]});
  target=directEditTargets(doc,0)[0];transformDirectText(doc,0,target,{matrix:[1,0,0,1,30,40]});target=directEditTargets(doc,0)[0];check(target.underline&&target.strikethrough,'decorations move with native text');
  transformDirectText(doc,0,target,{action:'duplicate',matrix:[1,0,0,1,0,60]});let page=doc.loadPage(0),a=page.getAnnotations();check(a.length===4,'duplicating text duplicates decorations');a.forEach(x=>x.destroy());page.destroy();
  target=directEditTargets(doc,0).find(t=>t.rect[1]<200);transformDirectText(doc,0,target,{action:'delete'});page=doc.loadPage(0);a=page.getAnnotations();check(a.length===2,'deleting text removes its decorations only');a.forEach(x=>x.destroy());page.destroy();
 }finally{doc.destroy()}
}
console.log('Text formatting: '+count+' native PDF assertions passed.');
