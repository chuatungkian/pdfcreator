/* Independent page bands in displayed-page coordinates. AGPL-3.0-or-later. */
import {PDFName,PDFArray,PDFDict,PDFHexString,pushGraphicsState,popGraphicsState,concatTransformationMatrix,drawObject,rgb} from 'pdf-lib';
import {mupdf} from './engine.js';
import {renderSystemText,measureSystemText} from './system-fonts.js';
import {drawSystemText} from './pdf-font-text.js';
const KEY=PDFName.of('PDFCreatorDecorations');
export const alignmentOptions=(name,value='left')=>`<select name="${name}"><option value="left" ${value==='left'?'selected':''}>Left</option><option value="centre" ${value==='centre'?'selected':''}>Centre</option><option value="right" ${value==='right'?'selected':''}>Right</option></select>`;
const stampOptions=name=>`<select name="${name}"><option value="none">No timestamp</option><option value="both">Date and time</option><option value="date">Date only</option><option value="time">Time only</option></select>`;
export function headerFooterFields(prefix,label){return`<fieldset class="decoration-section"><legend>${label}</legend><label>${label} text</label><input name="${prefix}" maxlength="500"><div class="create-fields decoration-fields"><div><label>${label} alignment</label>${alignmentOptions(prefix+'Align')}</div><div><label>${label} timestamp</label>${stampOptions(prefix+'Stamp')}</div></div><label><input type="checkbox" name="${prefix}Line">Line ${prefix==='header'?'below header':'above footer'} across the full page</label><label>Line thickness (pt)</label><input name="${prefix}Thickness" type="number" min="0.25" max="12" step="0.25" value="1"></fieldset>`}
export function numberFields(){return`<label>Page number alignment</label>${alignmentOptions('numberAlign','centre')}<label><input type="checkbox" name="withFooter">Add or update footer text alongside page numbers</label>${headerFooterFields('footer','Footer')}`}
export function timestampText(mode,now=new Date()){
  if(!['both','date','time'].includes(mode))return'';
  return new Intl.DateTimeFormat('en-GB',{...(mode!=='time'?{dateStyle:'short'}:{}),...(mode!=='date'?{timeStyle:'short'}:{})}).format(now);
}
function removeSlot(doc,page,slot){
  const records=page.node.lookupMaybe(KEY,PDFArray);if(!records)return;
  const remaining=[],names=[];for(const entry of records.asArray()){const record=doc.context.lookup(entry,PDFDict);if(record.lookup(PDFName.of('Slot')).decodeText()===slot)names.push(record.lookup(PDFName.of('Resource'),PDFName).decodeText());else remaining.push(entry)}
  if(!names.length)return;
  const resources=page.node.Resources().clone(doc.context),objects=resources.lookup(PDFName.of('XObject'),PDFDict).clone(doc.context),empty=doc.context.register(doc.context.flateStream(new Uint8Array(),{Type:'XObject',Subtype:'Form',BBox:[0,0,1,1],Resources:{}}));
  for(const [name]of objects.entries())if(names.includes(name.decodeText()))objects.set(name,empty);
  resources.set(PDFName.of('XObject'),objects);page.node.set(PDFName.of('Resources'),resources);page.node.set(KEY,doc.context.obj(remaining));
}
export async function putPageBand(doc,index,slot,{text='',align='left',stamp='none',line=false,thickness=1,font='Arial',color='#800020',now=new Date()}={},geometry){
  if(!['header','footer','pageNumber'].includes(slot))throw Error('Unknown page decoration.');if(!['left','centre','right'].includes(align))throw Error('Choose Left, Centre or Right alignment.');
  text=String(text);if(text.length>500||/[\r\n\x00-\x1f]/.test(text))throw Error('Use one line of header or footer text, up to 500 characters.');
  thickness=Number(thickness);if(line&&(!Number.isFinite(thickness)||thickness<.25||thickness>12))throw Error('Choose a line thickness from 0.25 to 12 pt.');
  const stampText=timestampText(stamp,now);text=[text.trim(),stampText].filter(Boolean).join(' · ');
  const page=doc.getPage(index),{bounds,transform}=geometry,w=bounds[2]-bounds[0],h=bounds[3]-bounds[1];if(w<100||h<130)throw Error('This page is too small for separate header/footer/number bands.');
  let appearance;if(text){const natural=measureSystemText(text,{font,size:10});appearance=await renderSystemText(text,{font,size:10,width:Math.max(16,Math.min(w-48,natural+14)),height:20,color,shrink:true})}
  removeSlot(doc,page,slot);if(!text&&!line)return null;
  const layer=doc.addPage([w,h]);let form,rect=null;
  try{
    if(appearance){const ink=appearance.inkRect,iw=ink[2]-ink[0],left=align==='left'?24:align==='right'?w-24-iw:(w-iw)/2,top=slot==='header'?20:slot==='footer'?h-48:h-22;
      await drawSystemText(doc,layer,appearance,{x:left-ink[0],y:h-top-appearance.height+ink[1],track:false});rect=[left,top,left+iw,top+ink[3]-ink[1]];
    }
    if(line){const y=slot==='header'?h-47:56,c=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)/255);layer.drawLine({start:{x:0,y},end:{x:w,y},thickness,color:rgb(...c)})}
    form=await doc.embedPage(layer);
  }finally{doc.removePage(doc.getPageCount()-1)}
  const matrix=mupdf.Matrix.concat([1,0,0,-1,bounds[0],bounds[1]+h],mupdf.Matrix.invert(transform)),resource=page.node.newXObject('PDFCreatorBand',form.ref);page.pushOperators(pushGraphicsState(),concatTransformationMatrix(...matrix),drawObject(resource),popGraphicsState());
  let records=page.node.lookupMaybe(KEY,PDFArray);if(!records){records=doc.context.obj([]);page.node.set(KEY,records)}records.push(doc.context.obj({Slot:PDFHexString.fromText(slot),Resource:resource,Settings:PDFHexString.fromText(JSON.stringify({text,align,stamp,line,thickness,font,color}))}));
  return{slot,text,rect,lineY:line?(slot==='header'?47:h-56):null,thickness};
}
export async function applyPageDecorations(doc,indices,kind,value,geometryForPage,{now=new Date()}={}){
  const reports=[];for(const [offset,index]of indices.entries()){
    const geometry=geometryForPage(index),common={font:value.font||'Arial',color:value.textColour||'#800020',now};
    if(kind==='header'){
      for(const slot of ['header','footer'])if(value[slot]?.trim()||value[slot+'Line']||value[slot+'Stamp']&&value[slot+'Stamp']!=='none')reports.push(await putPageBand(doc,index,slot,{...common,text:value[slot]||'',align:value[slot+'Align']||'left',stamp:value[slot+'Stamp']||'none',line:!!value[slot+'Line'],thickness:value[slot+'Thickness']??1},geometry));
    }
    if(kind==='number'||kind==='bates'||kind==='header'&&value.withNumbers){
      const start=Number(value.start??1);if(!Number.isInteger(start)||start<0)throw Error('Choose a non-negative starting page number.');const digits=kind==='bates'?Number(value.digits||6):1;if(!Number.isInteger(digits)||digits<1||digits>12)throw Error('Choose from 1 to 12 number digits.');
      const text=String(value.prefix??'Page ')+String(start+offset).padStart(digits,'0');reports.push(await putPageBand(doc,index,'pageNumber',{...common,text,align:value.numberAlign||'centre'},geometry));
    }
    if((kind==='number'||kind==='bates')&&value.withFooter)reports.push(await putPageBand(doc,index,'footer',{...common,text:value.footer||'',align:value.footerAlign||'left',stamp:value.footerStamp||'none',line:!!value.footerLine,thickness:value.footerThickness??1},geometry));
  }return reports;
}
