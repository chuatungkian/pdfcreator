/* Unapplied editor data stays in memory with its owning tab, never in PDF bytes. */
export function captureControls(root){return [...root.querySelectorAll('input:not([type=file]),textarea,select')].map(n=>({value:n.value,checked:n.checked}))}
export function restoreControls(root,saved){const fields=[...root.querySelectorAll('input:not([type=file]),textarea,select')],assign=(n,i)=>{const s=saved[i];if(!s)return;n.value=s.value;if('checked'in n)n.checked=s.checked},notify=n=>n.dispatchEvent(new root.ownerDocument.defaultView.Event('input',{bubbles:true}));fields.forEach((n,i)=>{assign(n,i);notify(n)});fields.forEach(assign);fields.filter(n=>n.matches('[data-image-position],[data-object]')).forEach(notify)}
export class EditorDrafts{
 constructor(){this.entries=new Map()}
 park(owner,revision,editor){if(!owner||!editor?.hasChanges?.()||!editor.reopen)return false;this.entries.set(owner,{revision,page:editor.page,saved:editor.snapshot?editor.snapshot():captureControls(editor.form),reopen:editor.reopen});editor.close();return true}
 async resume(owner,revision){const draft=this.entries.get(owner);if(!draft)return null;if(draft.revision!==revision)return false;this.entries.delete(owner);try{const editor=await draft.reopen();if(!editor)throw Error('Unable to reopen the draft editor.');if(editor.restore)editor.restore(draft.saved);else restoreControls(editor.form,draft.saved);return editor}catch(error){this.entries.set(owner,draft);throw error}}
 has(owner){return this.entries.has(owner)}
 remove(owner){this.entries.delete(owner)}
 clear(){this.entries.clear()}
}
