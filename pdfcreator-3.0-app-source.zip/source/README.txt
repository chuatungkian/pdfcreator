Move attachment icons - 2 November 2026

In Read & select, drag a placed paperclip icon to move it within its PDF page. A destination preview follows the pointer; release to save its new position. A short click still opens the attachment preview/download menu. Movement preserves icon size and the original embedded file, stays inside the page bounds, and is one Undo step. Escape, scrolling, zoom changes or a cancelled pointer discard the drag. Unlock icons in Objects & layers before moving them.

Page attachment icons - 2 November 2026

Attachments are embedded inside the PDF. Use View > Attachments, choose a file (up to 50 MB), choose location, then click a PDF page to place its standard Paperclip icon. Nothing is embedded until the icon is placed. Done or Escape cancels placement. Existing embedded files without a page icon have a Place icon action. Filenames are kept unique so adding another file does not replace an earlier attachment.

In Read & select, click an icon for a local text or raster-image preview, Open PDF in a separate document tab, or Download. HTML, SVG and scripts are displayed as plain text. Other formats can be downloaded to open in an application on the device. Text previews show up to 1 MB; downloads retain the complete original file. No attachment is opened automatically. Icons remain in saved PDFs; external PDF viewer support for opening attachments varies. Move or delete an icon using Edit > Select objects or Objects & layers. Deleting an icon retains the file in the PDF attachment list. Adding a file and icon is one Undo step.

Website update notifications — 1 November 2026

Hosted HTTP/HTTPS copies check a small same-origin version.json after startup and every five minutes when online, including inactive tabs. Downloaded file:// copies check the official repository manifest. No PDF/document data or credentials are sent. Browsers can throttle or suspend background pages; an overdue check runs when the page resumes, is restored, regains focus or reconnects. Heavy PDF jobs defer checking until idle; failed requests time out after eight seconds and retry with backoff. Checks do not open modal dialogues, steal focus, or reload automatically.

A new build shows Update now / Later. Later leaves an update badge and suppresses repeated banners for that build during this session. About & source (?) includes the embedded build ID and Check for updates. Only explicit Update now can reload. Apply your draft first through Keep editing, or confirm Discard draft and update. Running tasks and open merge/split workspaces must finish first. Applied PDFs, originals, retained history, open tabs and reading positions are saved locally before navigating to the same app path with a fresh build query. A failed local save keeps the app and draft open and offers a workspace ZIP backup; unapplied drafts are not included in that backup.

Deployment: use node build.mjs with the output directory. Every build embeds a unique release ID and emits a matching version.json. Deploy that manifest beside index.html, pdfcreator.html and pdfpro.html in one atomic release. Where hosting supports it, use Cache-Control: no-store for version.json and no-cache for HTML. The checker also bypasses browser caching and adds a fresh query to manifest requests and release reloads. Existing tabs that predate this checker need one initial refresh to install it. Downloaded offline copies require replacing their HTML file.

Changes review now follows the visible PDF page automatically while scrolling or using page navigation. Its page number, changed-page selection and Original/Current preview update together. Unchanged pages show Unchanged; Original mode follows each page without changing the working PDF. Opening review keeps the current reading position. Previous/Next still jumps between changed pages.

Changes review — 1 November 2026

Open View > Changes review to compare the working PDF with its originally opened copy. Changed pages are marked in the page strip and page headings. Previous/Next and the page list navigate modified, added, removed and moved pages. Toggle Original/Current for read-only page previews or open the larger comparison. Retained edits have individual before/after views without restoring earlier versions. Save PDF > Export review also offers Review page changes before downloading; this returns to the panel without downloading until Save is chosen again.

Text-fit/reflow choices (feature 4) remain in Edit > Direct edit: Keep layout, Fit text into box, and Move following text in this column. Recognition buttons now use a pastel red background with visible hover/focus states.

Review is local and does not change document bytes or history. It checks rendered pages, text geometry, form values, comments and links; tiny visual differences and hidden PDF structures may need separate inspection. Page matching uses contents; repeated identical pages are paired by position. Undo history is bounded to 20 steps, and undone edits are excluded from retained edits. The original baseline survives local recovery.

PDFCreator 3.0.0 — offline PDF workspace

Text boxes: in Edit > Select objects, resizing native text, added text and FreeText comments changes the container and wrapping without scaling font sizes. Boxes grow downward when needed, and Direct edit keeps the chosen width as words are added. Added text defaults to automatic growth; Fit text remains an explicit sizing choice. Mixed groups scale artwork while retaining text sizes. Growth that affects nearby content requires confirmation, and page-edge overflow requires moving or widening the box.

Text-box sizing checks: text-box-sizing-ui-test.mjs, 68 assertions in source and compiled app: fixed run sizes, native/rich/comment wrapping, four page rotations, logical words, draft pixels, height growth, metadata/reopen, mixed groups, confirmation, page boundaries and exact Undo.
==================================

SPREADSHEET-DRIVEN FORM GENERATION — 31 OCTOBER 2026
Open a PDF with editable form fields. Choose Forms > Generate from XLSX / CSV,
select a file, worksheet and header row, then map each field to a column, a fixed
value or its existing template value. Review records and actual PDF previews.
Use a record range such as 1-10,12 and filename tokens such as Letter_{B}_{row}.
Keep fields editable or flatten them. Generate ZIP produces separate PDFs and a
UTF-8 generation-report.csv. Duplicate filenames get _2, _3 and so on.

Formatted XLSX values preserve displayed dates and leading zeroes; Raw values is
an explicit alternative. CSV values stay literal, including leading zeroes.
XLSX formulas use saved results; recalculate and save in Excel first. Missing
results and spreadsheet errors are reported for affected mapped columns.
Checkboxes accept yes/no, true/false or 1/0. Multi-select lists use semicolons.
Required values, field character limits and choice values are checked. Invalid
records block generation unless Skip invalid records is explicitly selected.
Read-only fields retain template values. Resolve pending redactions and remove
digital signatures on a working copy before generation. Flat/scanned forms need
form fields added first. Review text fit in generated PDFs.

The embedded spreadsheet worker performs no network requests and can be cancelled.
Cancel generation stops before download; the original PDF and undo history remain
unchanged. Imported source data and mappings are transient, not saved in projects.
Limits: 20 MB input, 10,000 records, 256 columns, 500,000 workbook cells and 250 MB
of generated PDFs. Split larger jobs into record ranges/files.


WORKSPACE UPDATE — 31 OCTOBER 2026
- The active-tool guide above the document explains the next gesture. Done returns
  to reading/selection. Tools opens function search; the star pins the current tool.
- Function search has separate favourite stars. Favourites rank before recent tools
  in the empty query. Home shows quick tools. Preferences recover on this device.
- Select native PDF text on one page for Copy, Highlight, Underline, Edit paragraph
  or Add link. Cross-page selections do not offer ambiguous editing actions.
- Image properties offer Crop, Adjust, Replace image and Add link. Replacement fits
  the chosen picture within the old bounds while retaining its proportions. Other
  occurrences of a shared image are retained. Undo restores exact prior PDF bytes.
- Dialogues use visible sticky actions, keyboard focus containment and an inert
  background. Page ranges provide All pages, Current page and a selection count.
- index.html, pdfcreator.html and pdfpro.html now contain the same current build.
  Embedded and separate source exports have identical file contents.
- This revision is verified with synthetic PDFs and a controlled DOM. Actual live
  browser layout, clipboard, file-origin recovery and native download/print UI
  remain unverified in this environment. Earlier browser results describe earlier builds.


OPEN
Open pdfcreator.html (or index.html from the GitHub package) in current desktop
Chrome, Edge, Firefox, or Safari. No installation, accounts, or network access
are needed for standalone PDF tools. Built-in Word import is also offline. The optional Word companion requires
Windows and installed Microsoft Word desktop. Chrome and Edge were tested earlier.
The app may take a few seconds to unpack its embedded engines on first launch.
An earlier Word-import build was checked in Chromium 138 using the HTML directly
from disk, with normal file-origin security and all HTTP/HTTPS requests blocked.
The converter uses a fully bundled classic Blob worker; no server is needed.

NAME AND COMPATIBILITY
PDFCreator was previously named pdfpro. The legacy pdfpro.html path is supplied
as an identical compatibility copy, so existing local-file bookmarks and document
storage can continue using that path. New workspaces use .pdfcreator; older
.pdfpro workspaces remain importable. The existing local database is retained.

COMPACT SINGLE-FILE PACKAGE
The build enforces a strict limit of 25,000,000 bytes for the HTML. PDF/OCR
engines, English recognition data, Inter and source files are retained locally.
Identical files share their stored bytes; source copies of runtime assets refer
to the existing embedded assets. No CDN or first-run download is required.
The source/build ZIPs accompany the release. The embedded source is
also available through window.PDFCreator.downloadSource(), which assembles it
locally. Its paths and file contents match the separate app-source ZIP. When
browser compression is unavailable, a valid larger ZIP preserves the same files.
This changes packaging only; PDF operations, OCR and local recovery are retained.

INTERFACE
White, maroon, navy and black palette. Inter4.1 is embedded in the HTML and
licensed under SIL Open Font License1.1. Interface copy uses British English.
Create is the first entry in the left toolbar; Save PDF has a diskette icon in
the header. Tool popups are 260 px wide with compact 36 px minimum-height tiles,
15 px icons and content-sized height, scrolling within the available workspace.
Create offers New PDF,
Import from Word and Open PDF; the old top Open files button has been removed.
The three-dot menu contains Create, Local library and Print document. Page controls
float above a soft navy-tinted canvas. Tool panes use white surfaces and subtle
shadows; maroon highlights primary actions and selections. Dark theme remains
available at the top right. Reduced-motion preferences are respected.
The page/zoom toolbar can float, minimise, or lock across the full width of the
PDF working area at its top or bottom. Drag the dotted handle in Floating mode;
the position button offers Floating, Lock to top, Lock to bottom and a reset.
Use the minus button to minimise; restore with the plus button or page summary.
On the move handle, arrow keys move the floating toolbar and Shift moves further.
Floating positions remain inside the working area as its size changes. Layout,
position and minimisation are remembered locally when local storage is available.
Fullscreen includes both the document and its page controls.
Processing uses a circular outline in place of the horizontal bar. Unknown progress
traces around the circumference; reported progress fills the ring and shows its
percentage. Task details and Cancel remain available. Reduced-motion preferences
disable the tracing animation, and native progress semantics remain accessible.


CREATE A NEW DOCUMENT OR IMPORT WORD
Choose Create in the left toolbar, on Home, or beside the document tabs.
New PDF opens page settings. Open PDF goes to the file picker. Import from
Word offers a built-in offline converter and the optional Word companion.

BUILT-IN WORD CONVERTER
- Built-in converter is selected by default. Choose a .docx or Word 97–2003
  .doc document (up to 64 MB), then Convert and review.
- Ream 1.33.1 runs in a separate, disposable local worker. Four complete
  Arimo faces (regular/bold/italic/bold italic) are embedded in the HTML.
  No Word installation, companion, server, account, font download or first-run
  asset download is required. Network access is disabled in the worker.
- The compact font set substitutes an Arial-like family for document fonts.
  Source typefaces, line wrapping and pagination can therefore differ.
  Characters absent from these fonts, including Chinese, are refused with
  an explanation. No extra language fonts are downloaded automatically.
- The review shows page count, actual PDF size, a first-page rendering and
  conversion notes. Open PDF adds a new tab; Cancel discards the result.
  The source Word file and other PDF tabs are retained.
- Converted text stays searchable. Ordinary PDF editing, saving, undo/redo
  and local recovery work on the new PDF. Review all pages before sharing.
- An optional password is used only for this conversion and is not stored
  in projects. Protected legacy .doc files need Word. Layout elements that
  cannot be reproduced are reported where the engine supplies a loss note.
  Legacy drawings/text boxes and comments have limited support.
- Cancel terminates the conversion worker. A 180-second timeout stops a
  stalled conversion. The built-in importer rejects expanded ZIP content
  above 256 MB and documents above its text/container limits.

OPTIONAL MICROSOFT WORD COMPANION
Choose Microsoft Word companion in the Converter menu for Word's own PDF
export. It requires Windows and installed Microsoft Word desktop.
Download/extract PDFCreator-Word-Companion.zip, run start-word-companion.cmd,
paste its pairing code, choose the document and Convert and review. The
Word export opens as a new PDF tab. Native Word fidelity still depends on
installed fonts, linked content and document restrictions.
The companion binds to 127.0.0.1 and requires a fresh pairing code; the
browser may ask for local-network access. No cloud conversion is used.
See WORD-COMPANION-README.txt for temporary-file and process details.

SOURCE PACKAGING
The app's source and existing PDF/OCR dependency sources remain embedded
and downloadable through window.PDFCreator.downloadSource(). Their paths
match pdfcreator-3.0-app-source.zip. The additional Ream dependency sources,
font files, licences and legacy fixture builders are supplied separately
in PDFCreator-Ream-Source.zip. Extract both source ZIPs into the same folder
before rebuilding; their source/ directories merge. See REAM-SOURCE.txt.
The runnable HTML remains strictly below 25,000,000 bytes.

QUICK START
Choose Edit > Direct edit. Paragraph is the default: click an outlined paragraph,
edit its text and choose Apply. Its lines rewrap at the selected width, so removing
words pulls the following text up instead of leaving gaps. Enter inserts a hard
line break; Ctrl+Enter (Cmd+Enter on Mac) applies. Cancel/Escape dismisses the edit.

Choose Edit as in tool settings or the on-page editor:
- Paragraph: edit a detected paragraph as continuous text, with automatic wrapping.
- Line: change a single visual line in place without reflowing its neighbours.
- Text chunk: drag around complete lines or several paragraphs, then edit/reflow
  them together. Removing old line/paragraph breaks closes gaps in that selection.

Width (pt) controls wrapping without reducing the font size. It defaults to the
original text width and is retained after an edit, even when the paragraph becomes
shorter. PDF paragraph boundaries are inferred from text geometry; use Text chunk
when automatic detection does not include the text you intend to change. A chunk
uses one text column and writing direction. Reflow stays on the current page;
unselected paragraphs, artwork and page elements do not move. To pull several
paragraphs together, include them in the same chunk. Growth that would overlap
unselected text or leave the page is refused; adjust width or select a larger chunk.

Without formatting changes, the saved PDF reuses original native font programmes,
colours, opacity and sizes.
Unchanged mixed-style words retain their styles; replacement words inherit the
style of the source text they replace. New inserted words inherit a neighbouring
style. The first baseline stays in place; following lines move as text rewraps.
Compatible embedded TrueType/OpenType fonts load locally for the typing preview;
otherwise it uses a matching installed face or a fallback. A mixed-style paragraph
uses its first style in the typing preview; source styles are retained in the PDF.
The editing scope stays selected and is remembered locally. Applied edits, original
wrapping widths, undo/redo and reading position recover through IndexedDB.

Missing source-font characters and unsupported writing directions/encodings are
refused without changing the working PDF. Scanned images, outlined glyphs, invisible
OCR layers and older image-backed text boxes have no editable visible font data.
OCR makes scans searchable rather than directly editable. New PDFCreator text boxes
retain their font recipe and are edited as a complete box, preserving font settings
and fitting inside the original area. They use system fonts on this device;
unavailable fonts fall back. Annotations continue to use the comment tools.
Direct edit stays selected until another tool, Done or the same button is chosen.
Edits and inserted items keep the current page and scroll offset. Apply or cancel
before changing scope; changing page/tool or scrolling dismisses an unapplied edit.

Open PDFs with Create > Open PDF, or use the + beside the document tabs to open
the Create choices. Each PDF opens in
its own tab. Click a tab to switch; edits, undo/redo, page position, zoom, search
and pending redactions stay with that document. Use the x on a tab to close it.
Unsaved edits or pending redactions prompt before closing. New, sample and
restored workspace documents also open new tabs. Images selected together become
one new PDF tab, separately from any selected PDFs.
PDF pages now form one continuous vertical stack. Scroll with your mouse wheel,
trackpad, scrollbar or touch to move through the document. The page field, compact
toolbar summary and bottom preview selection follow the page you are reading.
Previous/next, page-number entry and bottom previews still jump to a page within
the stack. Nearby pages render on demand with a bounded canvas cache. Selecting
text, viewing a comment or starting an annotation on another visible page uses
that page. Scrolling cancels an unfinished pen/area gesture. Reading page, zoom
and scroll position stay with each tab and recover locally. Earlier saved views
are converted to the matching page in the continuous layout when resumed.
IndexedDB automatically retains working documents and edits in this browser.
Open tabs are restored at startup. Closed tabs remain in Library for reopening.
Home, beside the document tabs, shows up to six recent files with first-page
previews and Resume buttons. Resume switches to an existing tab or reopens the
latest saved working copy without duplicating it. Home retains open tabs,
edits, undo history and each document's page/zoom/scroll position. View library
opens the full list. Previews are generated locally and cached only in memory;
view-only changes reuse them, while PDF edits refresh the relevant preview.
Use the chevron above the left navigation to collapse it to an icon bar; icons
are present in the expanded navigation too, with tooltips in compact mode.
Choose a group in the upper-left navigation to open its tools in a left popup
pane. Click outside or press Escape to dismiss it. Use its pin button to dock
the tools as an icon bar on the right. Hover icons for tool names; the settings
button opens options for the selected tool. Text tools show font, colour and
text size; drawing tools show colour and stroke width; search shows its search
controls. Done exits the selected tool. Clicking outside dismisses those
settings while the pinned bar stays visible. Unpin returns to the left popup;
the close button hides the bar.
Text appearance settings use a shallow horizontal card with a small font sample
and a close button. Closing settings keeps the placement tool active.
Page previews stay along the bottom. Use Compact
beside Document pages to reduce previews to a thin strip of numbered page tiles;
use the arrow at its left to expand them. Every tile remains clickable.
Placement tools use a rectangle dragged on the page.
Draw under Annotate uses a freehand pen gesture instead: press, move along your
desired path and release. A live stroke preview follows the active pointer.
Each completed stroke becomes a native PDF Ink annotation; separate strokes stay
separate. Draw stays selected for the next stroke. Colour and stroke width apply
at the start of each stroke. A tap makes a small dot. Escape, pointer cancellation
or a page rerender cancels an unfinished stroke. Undo/redo handles complete strokes.
Sticky notes, text comments, page text, stamps, drawing tools, images, links,
form fields and visual signatures stay selected after placement so they can be
used repeatedly. Click the same feature again, choose another feature, or use
Done/Escape to finish. Browsing tool categories does not cancel the current tool.
Save PDF downloads a new copy. Undo/redo history is also kept in local recovery.
Save workspace includes the current PDF and pending redaction marks in a
portable .pdfcreator file. Download backups for important work or transfer to another browser.

LINKS
Choose Edit > Add link and drag over the text or area that should become clickable.
The dialogue accepts a website URL, email address or a page in the same PDF. A bare
website address such as example.com becomes an HTTPS URL. Invalid input stays in
the dialogue for correction. Link placement remains selected for repeated use.
Choose Done or click Add link again to follow links. Website/email links use the
browser's normal handler; websites open separately. Page links jump within the
continuous document. The small arrow beside a link opens its edit/remove dialogue.
Undo/redo and local recovery retain native PDF links. Links from existing PDFs also
appear in the viewer. Unsupported destination schemes are not opened.

FEATURE AUDIT
FEATURE-AUDIT.txt in the GitHub package (or pdfcreator-FEATURE-AUDIT.txt beside the
standalone HTML) maps all 82 distinct tool actions to the regression suites used.
The PDF worker, OCR core and English model are executed with real synthetic PDFs
and images in a controlled worker runtime. Tests inspect PDF/text/image/JSON/ZIP
outputs, including complete form and certificate-signing UI workflows. A fresh
live-browser layout/print/download/profile test remains unavailable. No user PDFs
or credentials are used by the tests. Existing limitations below still apply.
OCR output retains line grouping for phrase search and plain-text extraction.

MERGE & SPLIT
Open a PDF, choose Organise > Merge & split. The active edited PDF is the first
source. Add PDFs imports additional documents as inactive tabs; choose an open
tab or locally saved PDF in Sources & settings to add its current working copy.
Drag source files or use their up/down arrows to set merged page order. Removing
a source from the plan keeps its document tab and local copy.

Use Split after page N below a preview to add a split, or Remove split after page N
to remove it. Clicking the preview itself also toggles that split. The Split points
field stays visible above the preview grid even when Sources & settings is collapsed.
Enter 3,7 and choose Apply split points to split after pages 3 and 7. The selected
points, grouped ranges and output count update together. Maroon markers identify the cuts;
the final page always ends the last output. Markers belong to source pages and
follow them if files are reordered. Alternatively enter grouped ranges such as
1-3,4-7,8-10 and choose Apply ranges: these create three PDFs. Groups must cover
all pages exactly once, in order. Split every page and Reset splits are shortcuts.
Output names, page ranges and counts appear before generation. Edit the filename
prefix to name the outputs. Previews load on demand in batches of up to 60 pages;
use the arrow buttons above Page previews to browse subsequent batches.

Download ZIP produces the grouped PDFs and a README with source order/ranges.
Where supported, Save As opens at the start of the click; otherwise a normal
download starts after generation. Save generated ZIP remains available in the
workspace for retrying the download. Changing the plan or leaving the workspace
clears that generated link. Create merged tab opens all ordered pages as one new
working PDF, independently of the split markers. Source PDFs remain unchanged.

Plans save with their owner PDF in IndexedDB when local saving is available.
They are local plans, not part of the PDF or portable .pdfcreator workspace export.
Reopening Merge & split restores its source order, cuts and naming. Source edits
require Refresh sources & reset splits and a new review; missing sources must be
removed or restored. Pending redactions must be applied or cleared before export.
Documents with form widgets require Flatten form first, including certificate
signature widgets. New copied PDFs cannot retain original certificate validity.
Flattening creates a changed working copy and requires reviewing/resetting the plan.
Encrypted uploads ask for the password and add an unlocked working copy; use
Encrypt PDF separately to protect an exported PDF. Back to PDF returns to the
owner's page/zoom/scroll position. Up to 200 sources are supported in a plan.

LOCAL LIBRARY AND RECOVERY
Local autosave uses IndexedDB, with no server or account. PDF bytes, original
working bytes, undo/redo, selected images, pending redactions, search, page/zoom/
scroll positions and font choice are retained. Open tab ordering and active tab,
collapsed navigation, compact previews, right docking and theme are restored.
PDF edits are saved before their action finishes. Small view/preferences changes
are debounced; view-only changes do not rewrite PDF binaries. Each PDF snapshot,
its small view record, library metadata and open-tab manifest commit atomically.

The footer reports Saved on this device, Local save pending, Saving locally,
Not saved locally, or Local saving unavailable. Failure never clears the current
in-memory PDF. A failed save keeps the last complete stored copy. Export work
if storage fails. Closed copies can be removed from Library to free space.
A revision check prevents another PDFCreator window from silently overwriting a newer
workspace; export current work before reloading a window that reports a conflict.

Closing a saved tab retains its current edits in Library without a discard prompt.
To delete it from the browser, close the tab then choose Library > Remove and
confirm the named copy. Downloaded files are unaffected. Recovery copies may be
unlocked even when the uploaded source was encrypted. Originals and undo history
can include content removed from a redacted export. Remove the stored copy to
clear its recovery history; other copies and original files are separate.

Storage belongs to the browser profile and web origin. Clearing site/browser data,
private browsing, quota/eviction or browser restrictions can remove/prevent it.
file:// support is browser-dependent and is reported by the save indicator.
Changing browser, origin or hosting location does not transfer stored documents.
Download PDFs or .pdfcreator workspaces for backup or transfer. No passwords, PFX
credentials or signing keys are included in the saved workspace state.

FONTS
Tool settings offer 30 common system-font choices with a live sample. The chosen
font applies to added/replacement text, text comments, stamps, watermarks, page
and Bates numbers, headers/footers, batch decorations and typed visual signatures.
It stays with its PDF tab and is included when saving a .pdfcreator workspace.
The application interface continues to use embedded Inter. Existing PDF text,
form-field fonts and the invisible OCR font are not restyled by the selector.
Watermark, numbering, header/footer and batch dialogs include their own font and
colour choices. Typed visual signatures also have a font selector. Cancelling a
dialog does not change its appearance settings.

Choices: Arial, Arial Black, Arial Narrow, Aptos, Aptos Display, Calibri, Cambria,
Candara, Century Gothic, Comic Sans MS, Consolas, Constantia, Corbel, Courier New,
Franklin Gothic Medium, Gabriola, Garamond, Georgia, Helvetica, Impact, Lucida
Console, Lucida Sans Unicode, Microsoft Sans Serif, Palatino Linotype, Segoe UI,
Segoe Print, Segoe Script, Tahoma, Times New Roman and Verdana.

Font availability depends on the device/browser. Missing faces fall back to
Arial/sans-serif. System font files are not bundled, downloaded or redistributed.
To preserve the chosen device-font appearance, new visible font text is stored
as a transparent image at up to 288 DPI, with searchable Unicode ActualText for
page text. Text comments retain complete Contents and a native annotation subtype.
These appearances are not vector glyph outlines or editable embedded system fonts.
Select an entire added text box when replacing it; its image and search layer are
removed together. The older Replace text rectangle tool preserves surrounding
graphics and uses the chosen replacement font. Direct edit and Find and replace
reuse native source fonts and support paragraph reflow within the selected flow.


COMPLETION WORKSPACES (28 OCTOBER 2026)

Edit > Edit form fields (also under Forms)
Standard AcroForm fields are clickable in the normal viewer. Click a text field to
edit directly, including multiline paragraphs, or use Edit > Edit form fields to
keep selecting fields. Add text, Direct edit and Replace text also route clicks or
regions inside a text field to this native editor; text is not painted underneath
the widget. Apply/Ctrl+Enter saves one undo step. Cancel/Escape or clicking grey
space cancels a draft. The current page and local recovery are retained.

Text fields offer Original font or standard PDF Helvetica/Times/Courier variants,
size (0 for automatic sizing), colour, left/centre/right alignment and multiline.
The original font is retained unless changed. Text wraps within the original
field; reduce the font size if long content is clipped. Checkboxes, radio options,
dropdowns and list selections have appropriate on-page controls. Read-only/locked
fields stay protected. Field names, maximum lengths, choice export values and
shared widgets are respected. Distinct fields with duplicate names are isolated.
The logical field values and visible appearances update together; fields remain
interactive after Save PDF. Forms > Fill form retains a bulk editor and now uses
multiline textareas instead of single-line boxes where appropriate.
XFA, push-button scripts, signature fields and document JavaScript/calculations
are not executed by this editor. Flat/scanned forms have no native fields: use
Add text or create text fields in the blank areas. Existing form boxes do not grow
or move other page content automatically. Lists use a local native appearance.

Edit > Edit images
Click an image directly in the normal viewer, or choose Edit > Edit images first.
The Image inspector provides a crop preview, edge percentages, position/size in
points, a keep-proportions option, opacity, brightness, contrast, saturation,
colour hue and warm/cool tone. Drag the selected image to move it; drag its corner
to resize it. Preview crop changes by dragging a box in the small image preview.
Apply changes commits the inspector settings as one undo step. Delete image
removes the selected occurrence. Arrow keys move it (Shift moves 10 pt), Delete
removes it, and Escape deselects. The inspector can minimise or close.
Add image opens the same inspector after placement. Select objects retains its
rotation, duplication, alignment and snapping controls, with Image adjustments
opening the new inspector. Edits retain page position, undo/redo and local recovery.
Shared image resources and images inside content groups are isolated so editing
one occurrence does not change its other uses. Original pixels are retained for
readjustment: cropping and deleting are not secure redaction. Use Redact for
permanent removal. Colour preview/adjustment supports images up to 20 million
pixels; larger images retain move, resize, crop and opacity controls. Inline binary
images and stencil masks are unsupported. A picture baked into a larger scan
cannot be selected separately, and original PDF clipping can constrain movement.

Large-image appearance fix: pixel views are acquired after native transparency
mask decoding, which can resize WASM memory. This prevents stale colour/alpha
buffers from turning adjusted images blank or discoloured. If an earlier edit
looks white, open Image properties, Reset appearance and Apply changes to restore
its retained source pixels, then adjust it again in this updated app.

Click the grey space around a PDF page or blank non-working workspace to deactivate
the selected function. Clicking within the page keeps the function ready for
repeated use; tool settings, image properties and navigation remain usable.

Edit > Select objects
Click visible PDF text, an image/signature, a content group, or an annotation.
Drag its selection outline to move it; drag the bottom-right handle to resize.
Shift keeps proportions. X/Y/W/H and rotation are in points/degrees. Apply commits
numeric changes; Duplicate offsets a copy; Delete removes the selected item.
Align positions against the page; Snap aligns edges/centres against the page and
other selectable items. Hold Alt while dragging to bypass snapping. Arrow keys
nudge the focused selection; Shift moves 10 pt. Escape closes the inspector.
Native text keeps its vector glyphs/source fonts. Images and Form XObjects stay
native; annotation geometry and appearance move together. Added text retains its
independent editing recipe through movement, resize, rotation and duplication.
Inline binary images, arbitrary painted vector paths and locked annotations are
not independently editable. A nested PDF Form is selected as a content group;
its text can also be selected as individual editable text lines. Source clipping
paths still constrain transformed objects. Unsupported text encodings are refused.
Annotate > Erase drawing removes complete ink strokes touched by the gesture;
other strokes in the same Ink annotation remain. It does not erase image pixels.

Rich text and live page preview
Add text, Text comment and Stamp open a compact horizontal editor on the page.
Enter or paste plain text, then select text to change its font, size, colour,
bold or italic style. With no text selection, formatting applies to all text.
Alignment and bullets apply to selected paragraphs; Line and Gap set line and
paragraph spacing. The selected PDF area shows a live appearance preview.
Fit to area scales styles together if needed, down to 4 pt. Uncheck it to require
the requested sizes exactly. Apply commits; Cancel/Escape leaves the PDF unchanged.
Ctrl/Cmd+Enter applies. Placement stays selected for the next item.
Direct edit reopens the rich editor for tracked rich text boxes. In Comments,
Format text opens it for a FreeText comment or stamp, preserving its reply thread.
Mixed formatting is retained in a run model, never executable HTML. As before,
device-font appearance is a transparent image with searchable Unicode page text;
fonts come from the device and can differ on other devices when re-editing.

Text-aware markup
Highlight, Underline and Strikeout follow the text between pointer endpoints,
including partial lines and multiple lines. The drag preview shows the selected
text bounds. The native PDF annotation stores the selection quads and selected
words. Scans require OCR; unrecognised page images have no selectable text.

All-page comments
Annotate > Comments lists annotations across the whole document. Search contents,
replies and authors; filter by type, open/resolved status or the current page.
Select a comment to edit its text/author, add a reply, resolve/reopen it, or delete
its thread. Delete requires a second click. Go to page closes the workspace and
navigates to the comment. Format text handles the appearance of FreeText/stamps.
Replies use native PDF IRT relationships; resolved status is saved in PDF metadata.
Other viewers can interpret review status differently. Export summary downloads
an escaped offline HTML summary with a Print button. It contains all annotations.
No online collaboration or external messaging is involved.

Visual page organiser
Organise > Page organiser replaces the old numeric reorder prompt. Tiles have
lazy native previews. Click selects, Ctrl/Cmd-click toggles, Shift-click selects a
range. Drag selected tiles before another tile or into empty grid space to move
them to the end. Earlier/Later provides a keyboard-accessible alternative.
The Document dropdown lists every open PDF, defaults to the active tab and switches
the active PDF and organiser together. If changes are staged, choose Apply and
switch, Discard and switch, or Stay here. Cancel also cancels a pending switch.
Stage bulk rotation, duplication, deletion and blank pages. Use the separate
Insert from selector to choose another tab or Upload PDF, enter source page
ranges, then Insert pages or Replace selected.
Insertions follow the last selected tile; replacement uses the first selected
position and removes all selected tiles. Extract downloads selected staged pages.
Apply saves the staged arrangement in one undo step; Cancel discards the preview.
The current original page is followed to its new position when it is retained.
Flatten live forms before copying/extracting/duplicating pages containing fields.
Existing page objects/internal destinations are retained when rearranging originals;
advanced outlines, destinations to deleted pages and imported cross-document links
may need review after restructuring. Imported certificate-signed sources are refused.

Document-wide Find and replace
Available in View and Edit, from the Find tool, or Ctrl/Cmd+H. Choose literal search
text, replacement text, case matching, whole words and page ranges. Preview lists
before/after paragraphs and occurrence counts. Select individual results or all
supported results, then Replace selected. Replacements are one atomic undo step.
Native paragraphs reuse their source styles/fonts and wrap at the original width;
tracked device-font/rich text boxes update both appearance and searchable content.
Missing glyphs, overflows and collisions with unrelated native text are refused;
a failure preserves the entire working PDF. Search is for editable page text,
not comment bodies, image pixels, field values or every possible legacy encoding.
OCR can add search text to scans, but invisible OCR text cannot be directly edited.
Only the selected paragraph/box reflows; unrelated content is not moved.

INCLUDED
Viewing, selection/copy/search, page organisation, PDF/image merging, blank
pages, extraction/splitting, annotation/comments/drawing/stamps, added text and
images, links, bookmarks, watermarks, numbering/Bates/header/footer, metadata,
attachments, AcroForm fill/create/import/export/flatten, visual signatures,
English OCR with invisible searchable text, visual/text comparison and heatmaps,
lossless and image-aware compression, page image/text exports, batch processing, AES-256
password encryption, permanent region removal, full raster sanitation,
bounded existing-text replacement, and RSA PKCS12 certificate signing/verification.

REDACTION
Marking a region is only a pending selection. Apply redactions must be run.
Secure rebuild (default) creates every page from rendered pixels, then masks
selected rectangles again after all overlays render. The new PDF contains no
original text, forms, comments, links, attachments, metadata, or earlier revisions.
It also loses searchable text, vector quality and accessibility tags.
Native removal preserves remaining text/vector content but is not an exhaustive
hidden-data scrubber. Review all exported pages and all potentially sensitive
occurrences before sharing. Undo and local recovery retain prior copies and original working bytes across
sessions. Close the tab and remove its stored copy from Library after sensitive
work. Only the rebuilt export is sanitised; original files and other copies remain.

SIGNATURES
Visual signatures are images, separate from certificate signatures.
Type your name, draw a signature, or combine both. A combined visual signature
keeps the drawing and places the typed name below it in the chosen font. Clear
drawing leaves the typed name intact. Importing PNG/JPEG uses that image by itself.
The combined image stays available for repeated placement and local recovery.
Certificate signing supports RSA >=2048-bit PKCS12/P12/PFX, detached CMS SHA-256,
and incremental approval signatures. Certificate signature widgets are invisible;
add a visual signature separately if desired. Current RSA detached signatures
are verified for byte integrity and coverage. CA trust, revocation, hardware
tokens, ECDSA, RSA-PSS, trusted timestamps and PAdES/LTV are unsupported.
An intact signature does not establish a trusted identity. Claimed local signing
time is not a trusted timestamp. Certification/DocMDP/XFA/encrypted signing
inputs are rejected. Existing signatures may be invalidated by PDF edits.
Signing has a 150 MB input limit and uses main-thread cryptography.

ENCRYPTION
AES-256 export creates a separate password-protected download. Open working
copies remain unlocked. Passwords with commas, NUL/newlines, or over127 UTF-8
bytes are rejected by the native save grammar. If no owner password is given,
the open password is used. Permission restrictions depend on PDF reader support.

LIMITS
This is an implemented offline toolkit, not complete Adobe Acrobat equivalence.
No Office round-trip conversion, live shared reviews/signature collection,
scanner/OS printer drivers, AI assistant, dynamic XFA, rich media/3D/CAD,
professional colour preflight or PDF/A, PDF/X, PDF/UA conformance certification.
The older Replace text tool is bounded by a selected rectangle. Direct edit and
Find and replace reuse compatible native fonts and reflow within paragraph bounds;
they do not move unrelated paragraphs or flow onto another page. OCR includes English
only; confidence is approximate and recognition can be wrong. OCR search text
uses a Latin character set. Comparison aligns pages at the top-left and is
not semantic equivalence. Browser print creates a local raster print view.
Advanced PDF structures may not survive rewriting; always work from a copy.
Very large PDFs may exceed browser memory. Render size is capped; heavy native
engine work and OCR can be cancelled by terminating their background workers.
Smaller page edits and certificate signing can briefly block the interface.

GITHUB PAGES
Extract the GitHub ZIP into your repository. index.html is the single runtime file.
Publish the repository root using GitHub Pages. No backend or secret is required.
Keep LICENSE.txt, THIRD-PARTY-NOTICES.txt, app source ZIP, and upstream source
available with the release. Large source archives can be GitHub Release assets.
The application runs at the hosted URL while connected; for dependable offline
reopening download index.html and open it locally. There is no service worker.
User documents are processed locally and are not committed or uploaded.

SOURCE AND BUILD
About & source shows authorship/contact and links to source/build instructions
and component licences. The app source/build kit remains embedded and can
be exported with window.PDFCreator.downloadSource().
The GitHub ZIP additionally includes the complete official MuPDF1.28.1 source
tarball, including third-party sources. Its platform/wasm/BUILDING.md describes
the upstream engine build (Emscripten4.0.8 and Node22).
For app rebuilds: extract app source ZIP, cd source, install pinned dependencies
with pnpm install --frozen-lockfile, place mupdf-1.28.1-source.tar.gz beside
build.mjs, then run node build.mjs. The output directory is ../../outputs relative
to the source folder. The build downloads nothing after dependencies/model are
present. The included vendor artefacts retain exact distributed runtime bytes.

VERSIONS
MuPDF1.28.1 (AGPL-3.0-or-later), pdf-lib1.17.1 (MIT), node-forge1.4.0 (BSD),
Tesseract.js7.0.0 and core6.1.2 (Apache-2.0). English model: tessdata_fast/eng.
The application is AGPL-3.0-or-later. See included notices and licences.

TESTS
Source tests: node engine-test.mjs; node signing-test.mjs; node annotations-test.mjs;
node annotation-interactions-test.mjs; node tabs-interactions-test.mjs.
node fonts-previews-test.mjs checks compact preview controls and saved system-font text.
node local-store-test.mjs checks IndexedDB transactions, rollback, revision conflicts
and queued writes. node persistence-interactions-test.mjs checks fresh-app recovery
and navigation/library controls. node ui-refresh-test.mjs checks Home/Resume,
bounded native thumbnails, contextual settings and the action menu. These storage
tests use fake-indexeddb as a test-only dependency;
this does not establish browser-specific file:// storage compatibility. Optional
test dependencies can be installed alongside the source with pnpm add -D
jsdom@30.1.3 fake-indexeddb@6.0.1 @napi-rs/canvas, or provided through the
PDFPRO_DOM_MODULES/PDFPRO_IDB_MODULES environment variables.
The interaction tests use jsdom and @napi-rs/canvas as test-only dependencies.
They exercise real PDF processing in a controlled DOM, not a browser layout engine.
Historical browser scripts are included; browser verification status is in VALIDATION.txt.
node source-package-test.mjs verifies deduplicated ZIP reconstruction, integrity
checks, safe paths and the compression fallback. After building, node
packaging-release-test.mjs verifies the strict size cap, all source-file bytes,
runtime assets, both ZIP export paths, release archives and checksums.
node source-export-ui-test.mjs uses the actual release assets in a controlled DOM
to check the embedded source API, retained notices, concurrent requests and
error/retry behaviour without changing the working PDF.
node placement-tools-test.mjs checks repeated placements, toggle-off controls,
compact text settings, preserved placement coordinates and per-document selection.
node freehand-test.mjs checks live pen samples, native Ink paths and rendered pixels,
coalesced events, pointer ownership/cancellation, taps, rotations/zoom, undo/redo
and fresh-instance recovery using synthetic PDFs in a controlled DOM.
node page-toolbar-test.mjs checks dragging, minimisation/restoration, top/bottom
docking, keyboard controls, resizing, fullscreen targeting and local preference
recovery with simulated geometry. It does not establish browser layout accuracy.
The browser harness uses Playwright and a local installed Chrome/Edge and blocks
HTTP/HTTPS requests during file:// runtime tests. See VALIDATION.txt in release
outputs for the actually completed checks and remaining coverage gaps.

ANNOTATIONS
Text comments have a transparent background. Stamps have a transparent text-and-border
appearance. Text wraps/shrinks to fit the selected area or reports an error; it is not
silently clipped. Click an annotation while no placement tool is active, or use its
small comment button, to open its full contents. Dragging text still selects it.

ANNOTATION REGRESSION CHECKS
node annotations-test.mjs checks saved annotation rendering with real PDF bytes.
node annotation-interactions-test.mjs checks comment popups and navigation in
a test DOM using jsdom and @napi-rs/canvas. These are test-only dependencies;
PDFPRO_DOM_MODULES can point at a jsdom installation. This DOM check is not
a browser layout or accessibility certification.

WATERMARK CENTRING AND EDITING (28 OCTOBER 2026)
Edit > Watermark centres the visible rotated text on each displayed page, using
its actual painted bounds. Crop origins, page rotation and scale are accounted
for. Size, angle, opacity, font, colour and page ranges can be chosen. Batch text
watermarks use the same positioning and retain identification metadata.

Edit > Edit watermarks identifies layers across the document. It supports newly
tracked PDFCreator layers, older diagonal/translucent PDFCreator image/search
Forms, explicitly tagged watermark Forms/annotations, and inferred transparent
or diagonal native text objects. Inferred candidates are labelled for review;
ordinary body text is never automatically selected or changed.
Select a listed layer to inspect the outlined page preview and original settings.
Select matching chooses layers with the same text/source on other pages. Update
selected replaces each selected layer with the chosen text/font/colour/size/angle
and centres the result. Imported image/vector layers can be replaced with text;
Remove selected deletes the chosen layers after a second confirmation click.
Other page content is retained, including body text that overlaps a native text
watermark. Updates/removals use one undo step and the normal local recovery path.
Watermarks baked into scanned/page images, clipping text or complex nested content
without an identifiable separate layer may not be recognised. Use Select objects
for other independently selectable artwork. This is not automatic image inpainting.
The Open PDF tile description also includes the requested wording, “Classify
documents before loading”; this change adds descriptive text only.

PAGE DECORATIONS AND LINK PLACEMENT (29 October 2026)
Watermark rotation accepts -360 to 360 degrees in 0.1 degree steps; placement
remains centred on the displayed page, including rotation and crop offsets.
Headers and footers have independent Left/Centre/Right alignment and timestamp
choices: date, time, both or none. Optional full-width rules sit below the header
and above the footer, with independent 0.25–12 pt thickness. Timestamps capture
the device's local date/time once per operation, using British date formatting.
Page numbers and Bates numbers have their own alignment. Add them alongside
header/footer text, or add/update a footer from the numbering dialogue. Footer
and number rows are separate. Later updates replace the same tracked slot while
retaining the other slots. Text shrinks to fit its page band. These slots apply
to PDFCreator's new decorations; untracked imported headers/footers are unchanged.

Edit > Add link offers three placement modes: click existing text, image or shape;
draw a link area; or place new linked text. The dialogue can add visible display
text with a chosen installed font, size and colour, plus a website/email or
internal-page destination. New text and its link form one undo action. Choose
Done to follow links, or use the existing arrow badge to edit/remove a destination.
Click targets follow text lines and identifiable image/vector/annotation bounds;
flattened scans require an area selection because their text/shapes are pixels.

BOTTOM PAGE PREVIEW ORGANISATION
Click a preview to navigate and select. Ctrl/Cmd-click toggles individual pages;
Shift-click selects a range. Ctrl/Cmd+Shift extends an existing selection. Drag
selected tiles together before or after another tile; the insertion mark shows
the position. Dragging near the strip's edges scrolls it. Drop in empty space
to append. The viewed original page follows its new position; undo restores it.
Right-click a tile or the strip for Select all, Rotate, Duplicate, Delete, Extract,
Move earlier/later, Insert blank before/after, Insert pages from PDF, Replace
selected from PDF and Open Page organiser. Right-clicking a selected tile retains
the selection; an unselected tile becomes the selection. New blank pages match
the clicked page's displayed dimensions. Imports accept another open tab or a
local file, with source page ranges. Signed sources and pending redactions need
resolving before import. Live form pages must be flattened before copying.
Changes apply immediately as one undo action and use normal local autosave.
The full organiser continues to offer a staged preview before Apply.
These controls work with both compact and expanded bottom previews. With a tile
focused, Ctrl/Cmd+A selects all, Alt+Left/Right moves earlier/later, Delete asks
before deletion, and Shift+F10 opens the context menu. Escape/outside click closes
the menu. Page selection resets after unrelated PDF changes or tab switches.

node page-features-test.mjs checks page-band pixels on cropped/rotated pages,
tracked-slot replacement, timestamps, existing-object/new-text links, the About
changes, watermark controls, compact tool CSS and organiser document switching.
node page-strip-test.mjs checks multi-selection, drag/drop, context menu actions,
blank/imported pages, native destination retention, form-copy safeguards, undo and
local recovery. Both use synthetic PDFs and a controlled DOM, not live browser
layout or actual browser drag/download behaviour.

SIZE-AWARE SAVE AND BETTER PDF COMPRESSION (29 October 2026)
Save PDF now opens export settings. Current quality downloads the exact current
bytes; choose Lossless, High quality (220 dpi / 90% JPEG), Balanced (150 dpi /
78% JPEG), Small file (96 dpi / 58% JPEG), or Choose a target file size. Enter a
maximum in decimal MB or kB, or use 1/2/5/10 MB presets. You can change the filename.
Compressed exports show current/prepared byte counts and percentage reduction
before download. Target results explicitly state whether the maximum was reached.
Cancelling either dialogue or the processing task keeps the working PDF intact.
The current-quality option preserves existing certificate signatures byte for
byte. Rewriting a signed PDF requires confirmation because signatures are invalidated.

Target mode first tries lossless cleanup. It then tries image settings from
300 dpi / 92% JPEG down to the chosen floors (default 72 dpi / 45% JPEG). It stops
at the first result at or below the maximum, or offers the smallest available
result. Higher resolution floors still permit quality adjustment. No padding is
added to force an exact size, and no result larger than the input is chosen.
Text-heavy, already compressed or unsupported-image PDFs may not reach the target.
Quality choices can soften photographic detail or scanned text; inspect the result.

Eligible opaque 8-bit RGB/grey image streams are JPEG-recompressed and downsampled
using their largest actual display size across pages and nested Forms. Shared
images are processed once, never upsampled, and replaced only when smaller.
Transparent/soft-mask/colour-key images, monochrome images, small images, special
colour spaces, images over 20 million pixels, inline images and unknown uses are
retained. Page content is not rasterised. Native text, vector graphics, links,
annotations, forms, page geometry, metadata and attachments are retained.
Lossless cleanup keeps image pixels and font programmes, removes unused/duplicate
objects and compresses streams/object streams. Target trials start from the
original bytes so JPEG quality loss does not accumulate between attempts.

The Compress tool offers the same settings and an actual-size preview, then
applies the result to the working PDF in one undo step. Saving a compressed copy
keeps the open PDF bytes, view and undo history at their existing quality.
Pending redactions require the usual acknowledgement before an unredacted save;
apply or clear them before changing the working PDF with Compress.

node compression-test.mjs checks real image/target compression, lossless pixel
equality, form/link/attachment/text/geometry retention, protected masks, size
floors and cancellation. node compression-interactions-test.mjs uses the actual
embedded offline worker to check Save/Compress settings, result confirmation,
attainable/unattainable targets, filenames, undo, cancellation and signature/
redaction decisions. These use synthetic documents and a controlled DOM; native
browser save pickers and layout have not been checked in this revision.

FUNCTION NAVIGATION TOGGLES
Click a left navigation function to open its popup. Click the same function again
to close it; another function replaces the popup content. Create follows the same
behaviour, including on Home and with collapsed navigation. When tools are pinned
as a right-side icon bar, clicking the active group closes its floating settings
while keeping the pinned bar. Home/tab-bar Create entries open the Create pane.
node navigation-toggle-test.mjs checks group/Create toggles, accessible state,
collapsed/pinned modes and retention of PDF bytes, page, tab and undo history.

SEARCH APP FUNCTIONS
The magnifying glass beside the dark-mode switch opens an offline function
search. Ctrl/Cmd+K opens it from the keyboard. Search tool names or common terms
such as compress, hyperlink, circle, reorder and scan. Results show their tool
group; shared tools appear once. The catalogue contains all 82 distinct tools
plus Create, Home, Local library, theme and About actions.
Click a result to open the matching tool or its normal settings/confirmation.
Existing safety confirmations and undo behaviour remain. Document tools are
disabled until a PDF is open; Create and app actions work on Home. A result
requiring a PDF resumes the active document if Home is showing. Opening an
already-selected placement tool retains its selection.
Arrow keys navigate, Enter opens, and Escape closes and restores focus to the
magnifier. Clicking outside or focusing another control dismisses the popup.
The header question-mark button opens About & source, retaining its accessible
name, source/licence links and authorship/contact information.
node function-search-test.mjs checks catalogue coverage, aliases, disabled states,
keyboard/dismissal behaviour, actual PDF actions, confirmations and About/theme.
These are controlled DOM/native PDF checks; live browser layout is unverified.

DELETE A PROJECT FROM HOME
Each recent project card has a dustbin beside Resume. Click it to see a warning
and choose Delete project or Cancel. Escape also cancels. Confirmed deletion
removes the project's locally saved PDF, original copy, edits, undo/redo history
and catalogue/view data. An open project is closed only after storage deletion
succeeds. Other projects and downloaded files are kept. Deletion cannot be undone.
Deleting the last project returns Home to its empty state. Invalid archived PDFs
can also be deleted without opening them. Storage errors leave an open project
and its edits intact; existing conflicting-window protection remains in effect.
Autosave serialises deletion with pending saves and excludes deleted IDs from
later captures, so stale queued state cannot recreate an explicitly deleted copy.
node home-deletion-test.mjs uses synthetic PDFs and simulated IndexedDB to check
confirmation/cancellation, failure retention, open/closed/last-project deletion,
in-flight saves, stale captures, local recovery and invalid archived copies.

CENTIMETRE POSITIONING FOR PAGE DECORATIONS
Headers, footers, page numbers and Bates numbers each have independent position
controls. Choose Top edge or Bottom edge and enter the distance in centimetres.
The distance is measured to the nearest visible text edge. Left and Right margin
(cm) position left/right-aligned text; Centre uses the space between those margins.
Distances follow the visible cropped/rotated page, using 72 / 2.54 points per cm.
Header/footer rules follow the text while continuing across the full visible width.
Keep footer and page-number distances different to avoid placing them on the same
row. Negative distances, margins that leave no text area and off-page placements
are refused. Current documents keep their existing decorations until updated.

FIELD EDITOR BOUNDS
Form-field popups stay inside the intersection of the current PDF page and the
visible working area, with an inset from its edges. They move inward near the
bottom or right edge and shrink for narrow/short views. The middle section scrolls
internally while Close and Apply stay outside that scrolling region. Resizing the
textarea, window or workspace recalculates the bounds; draft text is retained.

REMOVE DIGITAL SIGNATURES
Protect & sign > Remove digital signatures asks for confirmation before creating
an unsigned working copy. It removes populated certificate-signature fields and
widgets, their appearances and signing dictionaries, certification/usage-rights
signature policies and obsolete validation data. Full rewriting discards the old
incremental signature revisions. Ordinary fields, other page content and separate
visual signatures remain. Empty signature fields are retained. Save PDF downloads
the unsigned result; undo restores the exact signed bytes, and local recovery
retains the edited copy. The source file is not overwritten. A signature flattened
into page text or a picture has no certificate field to clear; remove it using
Select objects or Edit images. This tool does not make a signed original editable
while preserving its digital signature or establish certificate identity/trust.

REMOVE PASSWORD SECURITY
Protect & sign > Remove security downloads a copy without an open password or
password-based permission restrictions. Choose Current document (which may already
be unlocked for editing), or Choose a protected PDF and select another local file.
Enter its valid password if required, choose a download name and click Remove
security & download. Wrong passwords and invalid names are shown in the dialogue
without producing a file. The original file, working tabs, page, edits and undo
history are unchanged. Passwords stay transient and are not stored in projects.

The exported PDF is verified to have no encryption and to open without a password.
Already-unprotected files are copied byte-for-byte. Encrypted files are rewritten
with text, images, vectors, live forms, attachments and page layout retained; pages
are not flattened. Encrypted PDFs with certificate signatures require a decision
because rewriting invalidates those signatures in the export. Use Remove digital
signatures separately if you need an unsigned file. Pending redaction marks must
be applied or cleared before exporting the current document. Processing runs in a
local worker with cancellation. No password guessing or remote service is used.

EXPERIENCE UPDATE — 30 OCTOBER 2026
- One properties inspector now hosts Direct edit, rich text/stamps/comments, image,
  object and native form editors. Dock it to reserve working-area width or float it.
  An explicit discard choice protects unapplied drafts; changing tools/pages/tabs
  keeps them. Apply/Cancel finishes the draft. Narrow screens use a bounded drawer.
- Watermark, headers/footers, page/Bates number dialogues render a debounced preview
  through their actual PDF operations, with page selection and Show original.
  Image adjustments have an original-pixels comparison; rich text keeps its live
  on-page preview. Previews do not modify document bytes or history.
- View > History & checkpoints names edits, dates and past/future versions. Open
  any available version as a separate tab. Checkpoints also retain pending marks.
  Up to 20 undo versions/150 MiB and 10 checkpoints/100 MiB are retained locally.
- Forms > Form assistant lists fields, previous/next navigation, empty required
  fields and estimated text overflow. Detection reviews vector boxes/underlines
  on the current page before making selected areas interactive text/checkbox fields.
  Scanned boxes are not automatically detected; use manual field placement.
- Edit > Objects & layers: use the small circular-arrow Refresh icon beside Float and Close in
  the pane header after scrolling to another page or editing
  the PDF. The pane reloads the current page and clears temporary hidden previews.
- Edit > Objects & layers lists native text, XObjects, straight vector shapes and
  annotations. Selection opens properties. Hide/Show is a temporary isolated PDF
  preview only; show objects again to edit. Workspace locks prevent selecting that
  object; they are not PDF access controls. Annotation stacking supports Bring to
  front. Complex clipped/curved paths and inline images remain content groups or
  require their existing specialist tools. This is not a PDF optional-content editor.
- Save PDF ends with Export review: actual prepared size/name/page count, mode,
  live fields/signatures, empty required fields, possible overflow and pending marks.
  Cancel prevents download. Existing redaction/signature decisions still apply.
- Local library searches names/tags and filters by tag. Project deletion moves the
  exact stored project to Bin, closing its tab after the atomic transaction. Restore
  recovers originals/history/checkpoints; Delete permanently requires confirmation.
  The bin is retained until emptied individually and uses browser storage too.
  PDF-data totals exclude history/overhead; browser-origin usage is shown when
  available. Select projects for ZIP backup. Extract its .pdfcreator-backup files
  and Import backup to recover independent projects with history/checkpoints/tags.
  Bin copies/templates must be backed up separately. No documents are uploaded.
- Create > Templates offers Blank A4, Ruled A4 and Letterhead, plus saved masters.
  Save the current prepared master, export/import .pdfcreator-template, or create an
  independent tab. PDF content, form values and layout are retained exactly, with
  preferred text font/colour/size. Prepare blank masters before saving. Templates
  are separate from projects; limit 50/100 MiB. IndexedDB v1 migrates in place to v2.
Native PDF and controlled-DOM tests validate these flows. Browser layout, actual
file-origin storage and native browser download/print UI still need live review.

Objects & layers uses a compact 260 px pane in docked and floating modes.
The pane header retains Refresh, Float/Dock and Close.

TEXT FORMATTING — 30 OCTOBER 2026
Direct edit and Add text offer Bold, Italic, Underline, Strikethrough, font,
font size and colour controls. Select words to format a range; when there is
no selection the formatting applies to the whole block. Changes remain drafts
until Apply. Cancel leaves the PDF unchanged. Each Apply is one undo step.

Native Direct edit keeps unformatted source styles and native searchable
glyphs. The font menu offers Original font, Helvetica / Arial, Times New Roman
and Courier New, using embedded PDF fonts for changes. Bold/italic changes
use the matching embedded serif, sans-serif or monospaced family; a custom
source typeface may therefore change when emphasis is requested. Original
font without emphasis changes retains the source typeface. Size changes use
4–144 pt. Reflow and page/overlap checks still apply. Unsupported characters
or invalid settings leave the current PDF unchanged. Underline and strike
are native PDF text-markup appearances that can be toggled independently;
they follow supported text moves/duplicates/deletions and persist on reopen.
The formatting preview shows selected styles before Apply.

Add text uses the existing device-font menu, now with underline and
strikethrough as independent run properties. Selected ranges retain mixed
fonts, sizes, colours and emphasis in the preview and exported appearance.
Fit to area may reduce sizes; disable it to require the requested sizes.
The searchable text layer and editable recipe remain with each text box.
Direct edit reopens both newer rich text and older tracked plain text boxes
with these controls. Undo, redo and local project recovery retain formatting.
Device fonts use this computer's installed fonts and fallbacks; no font
service or network connection is required. Scans still need OCR and are not
automatically converted into editable native text.

Verification: text-formatting-test.mjs and
text-formatting-interactions-test.mjs use synthetic native PDFs and a
controlled DOM. No fresh live-browser layout check is claimed.

STANDALONE WORD STARTUP FIX — 30 October 2026
The previous module Blob worker failed before executing when the standalone
HTML was opened via file:// in Chromium. Replaced it with a self-contained
IIFE bundle in an explicit classic Blob worker. No companion, extra file,
local server, network access or browser security override is required.
The original startup error was reproduced in Chromium 138.0.7204.0.
offline-word-browser-test.mjs passed 15 assertions with the corrected HTML
opened directly from disk: DOCX and binary DOC conversion, actual first-page
preview, cancel preserving the original tab, searchable PDF and PDF download;
zero HTTP/HTTPS requests and no page runtime errors.
Native/VM Word suites also pass (24 + 27 assertions), including worker
cancellation, timeout and cleanup. Other historical browser limitations in
this document apply to their earlier revisions and unrelated features.

CURRENT PORTABLE BUILD
Run pnpm install --frozen-lockfile in the extracted source folder, then
node build.mjs C:\path\to\release-folder. This rebuilds the current app from
preferred JS sources and the exact distributed engine bytes under vendor/.
The older full packaging workflow is retained in build-full.mjs.
See README.md for current commands and RELEASE-NOTES.md for the workspace changes.


# Direct edit character mapping fix — 31 October 2026

Fixed edited text reopening as glyph codes or gibberish with embedded subset fonts. The PDF writer previously tried to reconstruct Unicode from the font program's cmap, which can be absent or differ from the source PDF's text encoding. Edited overlays now carry an explicit glyph-to-Unicode map derived from the actual text being written. The prepared overlay is saved, reopened and checked before removing any source text. Existing glyph mappings take priority over a font's fallback cmap.

The shared fix covers line, paragraph and chunk Direct edit, Find and replace, and native text move/duplicate. Original fonts, appearance, layout, colours and formatting are retained. Ambiguous glyph aliases or unsupported encodings fail before the source text is removed. Full Unicode destinations use UTF-16, including supplementary characters where the source font supports them.

Added exact-content regression checks for repeated edits, reopening the same editor, save/reopen, undo/redo and recovery. Original tests also exercise Add text/rich formatting, Replace text, selected-text editing, page decorations, annotations, search/extraction and OCR. The package retains the spreadsheet form generator and workspace improvements from repository commit db29be1.

This prevents new corruption. For a PDF already saved with broken character mappings, use Undo/History or reopen an unmodified original and reapply the edit. The app does not guess at lost characters or silently rewrite an already-corrupted PDF.


INLINE DIRECT EDIT AND HELPER VISIBILITY — 1 NOVEMBER 2026
Formatting controls are at the top. Fonts, colours, sizes and emphasis appear
in the same editable text box; there is no second formatting preview. Select
words to format, or use an empty selection to format the block. Ctrl/Cmd+Z and
Ctrl/Cmd+Shift+Z undo/redo draft changes; Apply creates one PDF undo step.
Hide the helper with its x button; use the three-dot menu > Show helper bar
to restore it. The preference is saved locally and frees the reserved space.

MULTIPLE OBJECTS AND PANE WIDTH
Use Edit > Select objects, then Ctrl/Cmd-click or Shift-click to add/remove
objects on one page. The pane also offers click-to-add mode. Move, resize,
rotate, align, duplicate or delete the group with one undo step.
Object properties has compact horizontal actions and a Back arrow when opened
from Objects & layers. Drag a right-hand pane's left edge to resize it.
Arrow keys adjust a focused divider; double-click resets its default width.

OVERLAPPING TEXT EDITS
Direct edit now asks before saving formatting that overlaps nearby text.
Choose Apply anyway to proceed, or Cancel to keep your formatted draft open.
Nearby text stays in place. Undo restores the original PDF in one step.

EDIT OUTLINED OR SCANNED LETTERING
Edit > Direct edit recognises pages that have no editable PDF text.
Use Recognise text for editing on the page for mixed or additional pages.
Click a recognised region, review the words and estimated formatting, then
Apply. This replaces visible lettering with editable/searchable PDF text.
Recognition is English and works offline. Undo restores the previous PDF.
Fonts, spacing and solid backgrounds are estimated; review complex artwork.

LIVE PREVIEW, OCR REVIEW, GROUPS AND REFLOW
Direct edit previews typing and formatting on the PDF page. Amber marks show
nearby affected content; purple marks show following text moving.
Text layout offers Keep layout, Fit text into box (minimum 4 pt), and Move
following text in this column. Reflow stays on one horizontal page column and
stops at artwork/table rules and page edges. OCR reflow asks for confirmation.
Review recognised words and source boxes provides word correction, uncertain
word review, local font matching, and draggable/resizable lettering masks.
Select objects supports rectangle selection, persistent Group/Ungroup,
individual alignment, equal spacing and matching widths/heights/sizes.
These operations retain Undo; draft page previews add no history entries.

Typography consistency — 2 November 2026
Shared interface sizes: 12 px controls and body text, 11 px help/labels, 10 px metadata. Equivalent tool tiles, dialogue controls and inspector actions share these roles. Home help/recent metadata no longer inherit an oversized paragraph style. Heading/icon hierarchy and PDF text/field preview formatting remain independent. typography-test.mjs verifies 109 cascade assertions in a controlled DOM; live browser layout is not certified.

Home shortcuts — 2 November 2026
Each Your tools shortcut has a separate, labelled remove button. Removing clears its favourite and recent entries, works without a PDF and retains keyboard focus. Removal persists locally; function search can pin it again. home-tools-test.mjs verifies 30 preference/DOM/recovery assertions.

Automatic tools dock — 2 November 2026
Choosing a feature docks its category tools on the right. Closing the dock retains the selected feature; the left category remains highlighted and names the active feature. Browsing another category is distinguished from the active category. Selecting another feature, Done or same-feature deselection updates this state. Shared tools retain the category from which they were selected, including tab switches and local recovery. auto-dock-test.mjs checks 97 selection, navigation, dismissal and recovery assertions in source and compiled app.

On-page text editing — 2 November 2026
Direct edit and added text boxes are typed directly on the PDF page, with formatting/layout/Apply/Cancel controls in a workspace bar above it. Text comments and stamps use the same on-page rich editor. Source font/colour/size and selected-word formatting continue through the existing native writers. The editable surface follows PDF coordinates and zoom; the toolbar remains accessible while scrolling. Apply is one undo step; Cancel removes the editing surface without changing PDF bytes. on-page-text-test.mjs checks 52 geometry, keyboard, formatting, saved-PDF, rich-text and recovery assertions in source and compiled app. Native AcroForm field property editing keeps its existing dedicated controls. Tests use native engines and controlled DOM, not a live-browser layout certification.

PDFCreator 3.0.1 — 2 November 2026
The on-page text editing release is designated 3.0.1. Its standalone HTML, embedded release metadata and version.json share the same new build ID and version. The original 3.0.1 checker used a visible-tab interval. The current checker runs in active and inactive tabs every five minutes when online, and ? > Check for updates remains available. Detection does not reload or discard work automatically. Downloaded file:// copies retain offline behaviour and must be replaced manually.

OCR action and popup placement — 2 November 2026

The pastel red Recognise text for editing button stays below workspace popup layers. When a function/settings popup covers its usual page position, the action moves into clear space within the page and visible viewport. Closing or resizing the popup restores the usual position where possible. A completely covered control is temporarily hidden until room returns. Placement reacts to scrolling, resizing and popup changes without polling or changing PDF bytes.

Form control deletion, signature styling and privacy — 2 November 2026

Radio buttons and other supported form fields are now selectable in Edit > Select objects and Objects & layers. Delete selected (or keyboard Delete) removes selected widget instances, retaining unselected radio options and shared fields. A radio selection also offers Delete radio group, with confirmation covering options on other pages. Edit form fields has the same individual/group deletion controls. Empty field branches and calculation references are cleaned up, retained radio values/export labels stay aligned, and each operation is one Undo step. Printed option labels are separate PDF text and can be selected/deleted separately. Read-only/locked fields are protected.

Protect & sign > Visual signature now offers Colour and Line thickness (0.5–16), which redraw existing strokes and the live preview. Bold typed name changes typed lettering weight. Typed and drawn signatures use the chosen colour, retain transparent PNG backgrounds and preserve normal placement/Undo. Imported PNG/JPEG signatures retain their original pixels and bypass styling.

The ? > About popup includes: All information is processed locally on your device. No files are stored or uploaded to any cloud server or database. Your information remains yours.

Workspace interface improvements — 3 November 2026
Selected images, shapes/objects, annotations and native form controls now have quick contextual properties in the same top-of-workspace location as text formatting. Controls delegate to the existing image/object/field editors and keep their Apply, Cancel, validation and Undo behaviour. More properties opens the complete inspector; Crop and Adjust reach the existing image controls.

Tool popups reserve canvas space beside the PDF on wider screens and below it on narrower screens. Duplicate tool settings hide while a contextual editor is active. Text/selection bars, the active-tool guide, page toolbar and inspector reserve their own space. Page content remains scrollable, and popup menus are bounded to the viewport.

Focus mode is the corner icon beside the header help/search controls. Ctrl+Alt+F toggles it; Escape restores the workspace after open menus/dialogues are dismissed. It temporarily hides navigation, tool docks and page previews while keeping document/page/context controls available. It does not alter saved navigation settings or PDF bytes. More properties restores the normal workspace. Focus mode is intentionally not restored after reopening the app.

More document actions (the ellipsis) includes Interface density: Compact (existing 12/11/10 px interface roles), Standard (13/12/11) and Comfortable (14/13/12). Density persists with workspace preferences and never changes PDF zoom or PDF text sizes.

Direct edit uses browser caret hit testing near the clicked word when available, and shows an original-box/page-edge overflow indicator on the document and in the formatting bar. Existing layout/fit choices and native writer validation remain authoritative. IME composition Enter does not apply a draft.

Document tabs can be dragged into order or moved with Alt+Shift+Left/Right. Right-click or Shift+F10 opens Rename, Close tab, Close other tabs and Close tabs to the right. Names and tab order persist locally. Closing retains locally saved projects in the library, with the existing failed-save confirmation. These actions do not rewrite PDF content.

Shared SVG header/tab controls, consistent radii/borders/shadows, maroon selection states, labelled keyboard hints and visible focus rings refine the interface. Buttons retain at least 24 px pointer targets in the affected control areas; resize handles use a 24 px target around a small mark. Reduced-motion preferences suppress decorative transitions.

Validation: workspace-polish-test.mjs passes 80 source and compiled assertions for contextual image/object/field edits, native annotation selection, Apply/Cancel/Undo, side/bottom reservations, Focus, density/PDF independence, caret/overflow/IME, drag and keyboard tab order, menus/renaming/closing, accessible hints and IndexedDB recovery. Affected image (58), field (52), object workspace (61), page toolbar (62), navigation (63), automatic dock (97), typography (109), text formatting (21), on-page text (52), workspace UX (49), update UI (48) and OCR Direct edit (51) checks pass. Controlled DOM/native-engine checks do not certify live-browser layout or screen-reader conformance. The historic tabs-interactions test predates automatic docking; current navigation is covered by auto-dock and workspace-polish tests.

OCR control placement also recognises the new selection bar and tab menus as obstacles. The source and compiled ocr-control-placement-test.mjs regression passes 28 checks, including clear-space restoration and unchanged PDF/history.

Automatic content selection — 4 November 2026
Automatic tool selection is enabled by default. A stationary click on supported native text, an added text box, a shape or an annotation selects its object and highlights Select objects. Clicking an image selects Edit images and opens its existing adjustment controls. Clicking a supported interactive field selects Edit form fields. Double-clicking supported native text, an added text box, a text comment or a stamp opens its corresponding on-page text editor and highlights Direct edit.

The double-click remembers the first clicked item and PDF position so opening/docking properties cannot move the intended target away from the second click. It also handles native click/dblclick sequences and the changed selection overlay without opening two editors. Fast object dragging still uses the normal move/resize workflow. Ctrl/Cmd-click and Shift-click retain object multi-selection; dragging words in Read & select retains text selection/copying. Existing link and attachment actions keep their normal controls.

Explicit drawing, markup, placement, redaction and manually chosen Direct edit modes retain their gestures. Locked/read-only objects and unapplied drafts are protected. Detection is local and cached per PDF revision/page; selecting changes no PDF bytes or Undo history. Applied edits keep the existing writers, signature consent, validation, Undo and autosave. Scanned/unsupported lettering still needs the existing OCR or replacement tools.

More document actions includes Automatic tool selection. Switch it off to restore manual tool routing; the preference persists locally. The Read & select helper describes the active click behaviour. No browser project database or user PDF was accessed while building this update.

Validation: context-selection-test.mjs passes 84 source/compiled assertions with actual PDFs and pointer sequences, covering text/image/shape/field selection, native and rich direct edits, a page moving after the first click, quick object dragging, normal word dragging, manual tools, multi-selection, drafts/locks, zoom/later pages, Undo, preference recovery and unchanged bytes/history. Existing affected image (58), object (61), form-field (52), on-page text (52), workspace (80 and 49), attachment (45) and attachment-drag (65) checks pass. The image regression now expects the requested automatic Edit images highlight. Controlled DOM/native-engine checks are not a live-browser visual certification.

Text width resizing and alignment — 4 November 2026
Selected text containers now have side handles for changing the writing width (left/right for horizontal text; top/bottom for quarter-turn text). Drag the side, not the body, to resize; dragging the body still moves the object. Widening brings wrapped words back onto earlier lines and contracts unused text height. Narrowing rewraps and grows the frame so all content remains present. Corner resizing retains its separate minimum-height behaviour. Text sizes, colours and native font programmes are retained.

Text alignment is a separate control in object properties and the contextual top bar: Keep original, Left, Centre and Right. It changes line alignment inside the box; Align to page still moves the whole selection. Native multiline alignment is inferred from shared line edges/centres and is retained in saved reflow metadata; added rich paragraphs retain their stored alignment. Imported FreeText annotations retain native Q alignment. The on-page Direct editor follows the resized paragraph's alignment.

The page preview now updates periodically while a resize is held. It uses the same preparation path as the committed edit, with the latest drag geometry retained independently of the auto-fitted preview frame. Native/rich rotated text keeps the intended writing edge, and the saved frame matches the preview. Pointer cancellation restores the prior geometry. Each completed drag is one normal Undo step; local recovery retains the edited PDF. Existing overlap confirmation and page-boundary checks remain in place.

Validation: resize-reflow-test.mjs passes 98 source/compiled assertions for live drag previews, wider/narrower native and rich text, Left/Centre/Right transitions, fixed font sizes/colour, native and rich rotations, imported comments, cancellation, saved alignment, on-page typing, recovery and exact Undo. Affected text-box sizing (68), native reflow/pixels (145), reflow interactions (43), selected text formatting (21), object workspace (61), contextual selection (84), workspace polish (80) and on-page text (52) checks pass. These are controlled DOM/native-engine checks, not live-browser visual certification. Existing unsupported/scanned text still needs the corresponding OCR or replacement workflow.


Versioned background updates and compact top toolbars — 4 November 2026
PDFCreator is now 3.0.2. The ? heading, version details, app API, embedded metadata and version.json use package.json as their single version source. Each published app commit reserves exactly one patch above the latest repository version through release-version.mjs; rebuilding that same release keeps the reserved version. See RELEASING.md in the source kit. Older manifests cannot offer a downgrade.

A small manifest is checked after startup and every five minutes online, without requiring the ? panel or an active/visible tab. Focus, resume, page restoration and reconnection schedule overdue checks without bypassing the cooldown. Browsers can throttle/suspend background pages; the checker catches up on waking instead of trying to prevent suspension. Failed checks remain non-blocking and retry with backoff. No PDF data or credentials are transmitted.

Hosted copies check their deployment's version.json. Downloaded file copies check only the official public repository manifest; Download update opens the official updated HTML download on explicit user action and never navigates the existing local workspace. Apply unfinished edits, replace the HTML at its existing location, then reload to retain access to the same browser projects. Hosted Update now retains verified local saving, draft consent and failure backups; neither form of detection forces a reload.

Top object/image/form and on-page text toolbars use smaller desktop controls and tighter padding/gaps. Action names and field labels remain visible with tooltips, accessible names, focus outlines and larger touch targets. Density preferences still offer larger controls; the PDF font size and zoom are unchanged.

Validation: update-checker-test.mjs passes 61 deterministic assertions, website-updates-ui-test.mjs passes 63 source/compiled assertions, and release-version-test.mjs passes 20 assertions. Existing workspace polish (80) and on-page editing (52) checks pass. These use bounded mocked update responses, controlled DOM and native PDF processing; they do not certify browser-specific background timer policies or live layout.


PDFCreator 3.0.4 — 4 November 2026
Images, object/annotation selections and interactive form fields now have one canonical properties editor above the PDF. The former quick-toolbar clones and duplicate right-side properties view have been replaced with the original editor controls, organised into labelled groups. Common size, text and actions stay visible. More expands position, rotation, arrangement/grouping, selection settings, image crop/preview/appearance, replacement/link actions and help within the same top surface. Nothing opens a second right properties pane.

Image Crop and Adjust reveal and focus their existing controls. Form values, checkboxes/choices, typography, deletion and next/previous navigation remain available. Form editors detach from their old on-page popup positioning so scrolling the original field offscreen does not hide the top editor. Direct/native/rich text formatting is grouped into Text, Style and Paragraph controls, while editing stays on the PDF. No controls are cloned and no new PDF mutation path is introduced.

The top surface reserves document height rather than width, wraps its groups and limits expanded content height with scrolling. More retains drafts, remains usable in Focus mode, and never restores a side duplicate. Apply, Cancel, discard protection, Back to Objects & layers, atomic edits and Undo/recovery are retained. Nonduplicated panels such as History, Changes review, Forms assistant and Objects & layers keep their existing single side panel.

Validation: top-properties-test.mjs passes 118 source/compiled assertions for canonical control identity/counts, width recovery, More, image crop/adjustments, object transforms, field values and next navigation, scrolling, Focus, Back, native/rich grouping, draft guards and exact Undo. Affected source checks pass: image interactions 58; object workspace 61; form fields 52; field deletion 28; experience panels 59; Changes review 54; on-page text 52; selected formatting 21; contextual selection 84; text resize/reflow 98; workspace polish 86; safe update UI 63. Tests use synthetic PDFs, native processing and controlled DOM. No user browser storage was accessed; live-browser visual layout is not certified.


PDFCreator 3.0.5 — 4 November 2026
Corrected top toolbar alignment and horizontal use. Properties containers stretch across their available workspace instead of centring at intrinsic width. Each primary row separates a flexible controls area from a right-aligned action rail. Groups use shared caption, label and control tracks, so input borders, style controls and layout toggles align horizontally. Independent control groups use the available row width before wrapping; narrow spaces retain horizontal access rather than stacking action buttons.

Action order is consistent across original object, image, field, native text and rich text controls: Apply first, Duplicate when available, deletion actions, then Clear/Cancel. The original controls and form ownership are retained. Native and rich text footers now contain only action buttons; fit options remain with layout controls, and source-font details appear inside Layout options. Initial/ready boilerplate no longer occupies a permanent status row. Meaningful preview progress, affected-layout notices, errors and overflow guidance remain visible.

Validation: top-properties-test.mjs passes 162 source/compiled assertions, covering canonical control identity, action ownership/order/placement, stretched properties, inline options, native edits, crop/adjustments, navigation, drafts and exact Undo. Affected source checks pass for workspace polish 86, on-page editing 52, selected text formatting 21, contextual selection 84 and field deletion 28. Tests use synthetic PDFs, native engines and controlled DOM, not live-browser visual certification.


PDFCreator 3.0.6 — 5 November 2026
Implemented all twelve UI/workflow refinements: comment/reply draft ownership and safe close; staged organiser close protection and selection-aware commands; separate local-save/PDF-download indicators and full project backup; prepared-export continuity through Changes review and settings; shared Current/Selected/All/Custom scope; explicit signature sources with image preview; complete page-grouped OCR issue navigation; searchable/filterable form-data mapping; explicit Home actions and persistent library context; common placement diagrams, unit conversion and appearance-only presets; selected-page/resolution print and image export; compact consistent dialogs/tiles. Canvas priority defaults to compact navigation/previews and can be disabled.
Original controls, native PDF writers, Undo, local recovery and password safeguards remain. Presets exclude text, page ranges, passwords and document content. Pending redaction content is identified before print/image output. Export settings/results remain in memory only for the same document revision.
Checks: dialog drafts 85; scope/placement 44; library state 36; signature/OCR/form workflow helpers 55; integrated Home/canvas/export/selected-print/backup 19; signature pixel/style 28; form generation 42; top properties 162; on-page editing 52. Synthetic PDFs, native rendering and controlled DOM are used; no user browser projects accessed, no live-browser visual certification claimed.


PDFCreator 3.0.7 — 6 November 2026
Fixed Home → Open files incorrectly treating its own click as an operation in progress. The synchronous file-picker launcher is separate from the guarded asynchronous import. Existing PDFs do not need to be saved, closed or deselected before opening additional PDFs in independent tabs. Retains edited bytes, per-tab Undo, page position, selected tool and pending redactions. Actual in-flight writes and unapplied drafts retain their existing ownership safeguards.
Validation: open-files-ui-test.mjs passes 18 source/compiled assertions through the actual picker entry, multiple uploads, edited-tab preservation, independent editing, picker cancellation/retry, Create → Open PDF and in-flight write protection. ui-completion-test.mjs passes 19 source/compiled assertions. Controlled DOM and synthetic PDFs; no user documents or browser projects accessed.


PDFCreator 3.0.8 — 6 November 2026
Implemented UI refinements 1–7.
1. Native/rich text, image, object and form-field drafts remain with their owning document tabs. Switch tabs, open another PDF or return Home without applying/cancelling first; return to resume the draft. Draft badges distinguish unapplied work. Closing a Draft tab asks before discarding it. Drafts are session memory: apply them before browser reload/close to retain them in local recovery.
2. Bulk OCR and compressed PDF preparation run as document-owned background tasks. One heavy task runs at a time while other PDFs remain editable. Source tabs show progress/ready badges; click a badge or More → Tasks (also in function search) for cancellation and results. Review/apply results explicitly, or open result copies. New edits, drafts and pending redactions are never silently overwritten. Tasks/results stay in memory until used/dismissed; browser exit/update protection covers them. OCR has a separate local recogniser; no PDF content is uploaded.
3. The canonical top toolbar uses a steady horizontal controls row and a consistent right-hand action rail. Overflow controls scroll horizontally; advanced options open under More without increasing reserved canvas height. Original controls and form ownership are retained.
4. Automatic selection outlines/names the hovered Text, Image, Shape or Field. Alt-click cycles overlapping items; right-click overlapping content for the keyboard-accessible Select item menu. Locks, explicit drawing tools and text-selection gestures remain respected.
5. Image/object movement shows temporary page-centre, page-edge, 20 mm reference-margin and object-alignment guides. Snapping uses screen-scaled tolerance; Alt bypasses it. Arrow keys nudge 1 pt, Shift+Arrow 10 pt. Guides disappear on completion/cancellation.
6. Undo/Redo tooltips and accessible labels name their actual history operations.
7. Save named text, comment, shape and stamp appearance presets in tool settings or text toolbars. Recent colour swatches, named selection, replacement and deletion are compact. Up to 30 device-local presets contain appearance only, never document text/passwords. Native Direct edit maps shared fonts to its supported Helvetica/Times/Courier families.
Validation uses synthetic PDFs, native engines, embedded offline workers and controlled DOM. Checks: integrated seven refinements 48; real background OCR 14; queue/styles 16; top properties 162; contextual selection 84; on-page text 52; completion UI 19; open files 18; image interactions 58; object workspace 61; compression UI 42; OCR layer 5; safe updates 63. No user documents or browser project storage accessed; no live-browser visual certification claimed.


PDFCreator 3.0.9 — 7 November 2026
Implements requested refinements 1, 2, 5, 7 and 8.
1. Native/rich text, image, object and form-field drafts are saved locally with their owning PDF revision, including parked tabs. After restart, Resume edit / Discard draft / Later lets the user decide. Draft persistence never applies changes to PDF bytes. Storage failures stay visible and keep the editor open. Explicit discard on close/update clears stored recovery. Password inputs and file pickers are excluded; recovery requires working browser storage and does not retain background task results.
2. Canonical top toolbars prioritise text/font/size/colour and Apply. Secondary style, paragraph, image, navigation and named-style controls move to More below 820 px; duplicate/delete actions move there below 600 px. Controls are moved, never cloned, and return to their original positions when space grows.
5. The current-page footer reports Editable text, Recognised text, Image-only page, Limited text editing or No editable text, with an explanation and relevant edit/recognise/add action. Classification is cached by PDF revision/page and never starts OCR automatically. Font changes and OCR estimates explain possible layout differences.
7. Attachment menus support Open/preview, Download, Move icon, Remove this icon and Remove embedded file, with all page locations listed. Icon-only deletion retains the file. Full deletion removes its page icons, all matching name-tree aliases and ordinary PDF/page AF associations. Locked icons protect full removal. Each change supports Undo and preserves unrelated attachments. Right-click opens the same menu; arrow keys move icons, Shift uses 10 pt.
8. Escape closes an editor More panel before dismissing the editor and returns focus to its toggle. Attachment keyboard movement preserves focus. Image/object resize corners support arrow keys and Shift increments; pane-drag cancellation restores the initial width. Coarse-pointer controls and invisible handle/field hit areas are larger, with visible keyboard outlines in light/dark themes.
Validation: five-refinements-test.mjs, 65 assertions in source and compiled app for real local recovery/restart, active/parked draft ownership, local-save failure, apply/Undo, discard/close/update, canonical responsive controls, Escape/focus, page capability and attachment actions; attachment-removal-test.mjs, 17 real-engine checks for shared/hidden/locked icons, aliases, AF cleanup, stale targets, orphan retention and unchanged page text. Existing storage 52, persistence/navigation 64, prior seven refinements 48, top properties 162, on-page text 52, image interactions 58, object workspace 61, safe updates 63 and attachment movement 65 pass. Tests use synthetic PDFs, native engines and controlled DOM. No user PDF contents or browser project storage accessed; live browser visual layout is not certified.
