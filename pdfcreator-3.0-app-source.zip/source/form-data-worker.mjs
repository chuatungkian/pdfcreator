import {parseFormData} from './form-data-parser.js';
self.onmessage=event=>{try{const {bytes,options}=event.data;self.postMessage({result:parseFormData(bytes,options)})}catch(error){self.postMessage({error:error.message||String(error)})}};
