/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {WorkspaceAutosave} from './workspace-autosave.js';
let context;
try{
 context=await boot();let {app,$,window,downloads}=context;
 await app.openFiles([file('Same.pdf',await fixture(app,'ALPHA')),file('<img src=x onerror=bad()> Same.pdf',await fixture(app,'BETA'))]);const aid=app.tabs[0].id,bid=app.activeTabId;
 await app.editPDF('Beta edit',doc=>doc.getPage(0).drawText('SAVED PROJECT EDIT',{x:40,y:700,size:13}));await $('next').onclick();const bBytes=app.state.bytes,bUndo=app.state.undo.length,bOriginal=app.state.original;await $('homeBtn').onclick();await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 const card=id=>[...$('recentDocuments').children].find(n=>n.dataset.recentId===id),bin=id=>card(id)?.querySelector('[data-recent-remove]'),start=id=>bin(id).onclick(),submit=()=>$('modalform').onsubmit({preventDefault(){}});
 equal($('recentDocuments').querySelectorAll('[data-recent-remove]').length,2,'every recent project has a delete button');check([...$('recentDocuments').querySelectorAll('[data-recent-remove]')].every(b=>b.querySelector('svg')&&b.getAttribute('aria-label').startsWith('Delete ')),'dustbins have SVGs and project-specific accessible names');check(!card(bid).querySelector('img[onerror]'),'untrusted project name cannot inject HTML');
 let pending=start(bid);await until(()=>$('modaltitle')?.textContent.startsWith('Delete '),'confirmation opens');check($('modaltitle').textContent.includes('<img src=x onerror=bad()> Same.pdf'),'confirmation displays literal filename');check($('modalform').textContent.includes('undo history')&&$('modalform').textContent.includes('open tab will also close'),'warning explains stored history and open tab deletion');check($('modalform').textContent.includes('Downloaded files are kept'),'warning distinguishes downloaded files');check(await app.local.store.getDocument(bid),'no deletion before confirmation');$('modalcancel').click();await pending;equal(app.state.bytes,bBytes,'Cancel keeps active PDF bytes');equal(app.state.undo.length,bUndo,'Cancel keeps undo history');equal(app.state.original,bOriginal,'Cancel keeps original PDF');check(!!card(bid)&&app.tabs.some(t=>t.id===bid),'Cancel keeps card and open tab');
 pending=start(bid);await until(()=>$('modaltitle'),'Escape confirmation');$('modalcancel').dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));await pending;check(await app.local.store.getDocument(bid),'Escape keeps project stored');
 await app.closeTab(aid);pending=start(aid);await until(()=>$('modaltitle'),'closed-project confirmation');check(!$('modalform').textContent.includes('open tab will also close'),'closed project has accurate warning');await submit();await pending;equal(await app.local.store.getDocument(aid),null,'closed project PDF removed');check(!(await app.local.store.listDocuments()).some(r=>r.id===aid),'closed project catalogue removed');check(!card(aid),'closed project card disappears');equal(app.activeTabId,bid,'deleting closed project preserves active tab');equal(app.state.bytes,bBytes,'deleting closed project preserves other PDF');equal(downloads.length,0,'deleting local copy does not create or alter downloads');
 await app.openFiles([file('Remaining.pdf',await fixture(app,'REMAINING'))]);const cid=app.activeTabId;await app.editPDF('Keep neighbour edit',doc=>doc.getPage(0).drawText('NEIGHBOUR EDIT',{x:40,y:700,size:13}));const cBytes=app.state.bytes,cUndo=app.state.undo.length,cRecord=await app.local.store.getDocument(cid);await app.switchTab(bid);await $('homeBtn').onclick();await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','two open projects');
 const commit=app.local.store.commit.bind(app.local.store),errors=[],oldError=console.error;app.local.store.commit=async change=>{if(change.removeIds?.includes(bid))throw Error('Simulated deletion failure');return commit(change)};console.error=error=>errors.push(error);
 const nativeBefore=app.state.doc;pending=start(bid);await until(()=>$('modaltitle'),'failed delete confirmation');await submit();await pending;console.error=oldError;app.local.store.commit=commit;check(errors.length===1,'storage deletion failure reported');check(app.tabs.some(t=>t.id===bid)&&app.state.doc===nativeBefore,'failed delete leaves open tab and native document intact');equal(app.state.bytes,bBytes,'failed delete preserves edits');check(await app.local.store.getDocument(bid),'failed delete preserves stored PDF');check(!app.local.autosave.removedIds.has(bid),'failed delete does not blacklist project');await app.local.flush();
 // A save already in flight must finish before deletion, and never recreate it.
 let release,held=false;app.local.store.commit=async change=>{if(!held&&!change.removeIds?.length){held=true;await new Promise(resolve=>release=resolve)}return commit(change)};app.state.page=0;const older=app.local.flush();await until(()=>!!release,'older autosave held');pending=start(bid);await until(()=>$('modaltitle'),'queued deletion');await submit();await pause();check(app.tabs.some(t=>t.id===bid),'tab stays open until storage deletion commits');release();await older;await pending;app.local.store.commit=commit;
 equal(await app.local.store.getDocument(bid),null,'confirmed open project removed after queued save');check(!app.tabs.some(t=>t.id===bid),'confirmed deletion closes its tab');equal(app.activeTabId,cid,'deleting active project selects remaining tab');equal(app.state.bytes,cBytes,'remaining PDF retains exact edits');equal(app.state.undo.length,cUndo,'remaining PDF retains undo history');equal((await app.local.store.readSession()).openIds,[cid],'reopen list excludes deleted projects');check(document.body.classList.contains('home-visible')&&!card(bid),'successful deletion stays on Home and removes card');
 await app.local.flush();await app.local.flush();equal(await app.local.store.getDocument(bid),null,'subsequent autosaves do not resurrect deleted project');equal($('libraryCount').textContent,'1','library count updates');
 pending=start(cid);await until(()=>$('modaltitle'),'last project confirmation');await submit();await pending;equal(app.tabs.length,0,'last project tab closes');equal(app.state.doc,null,'last native document released');equal(app.activeTabId,null,'no active deleted project');equal(app.state.bytes,null,'deleted PDF bytes removed from active state');equal((await app.local.store.listDocuments()).length,0,'all projects removed from library');check(!$('recentEmpty').hidden&&!$('recentDocuments').children.length,'empty Home state appears');check($('saveBtn').disabled,'Save disabled after last deletion');
 await context.close();context=await boot();({app,$,window}=context);equal(app.tabs.length,0,'restart does not reopen deleted projects');equal((await app.local.store.listDocuments()).length,0,'restart has no deleted project records');
 // A damaged archived PDF can be deleted without first opening it.
 await app.local.store.commit({documents:[{...cRecord,id:'broken-delete',snapshot:{...cRecord.snapshot,name:'Broken.pdf',bytes:new Uint8Array([1,2,3]),original:new Uint8Array([1,2,3])},updatedAt:Date.now()}]});await $('homeBtn').onclick();await until(()=>card('broken-delete')&&$('recentDocuments').getAttribute('aria-busy')==='false','broken project on Home');pending=start('broken-delete');await until(()=>$('modaltitle'),'broken project deletion');await submit();await pending;equal(await app.local.store.getDocument('broken-delete'),null,'damaged archived project deletable');
 await context.close();context=null;
 // Autosave itself rejects unsafe open-copy deletion and filters stale captures.
 const db=new IDBFactory(),store=new LocalWorkspaceStore({indexedDB:db,name:'deletion-races'});await store.readSession();const record={id:'race',pageCount:1,snapshot:cRecord.snapshot},session={openIds:['race'],activeId:'race'},auto=new WorkspaceAutosave({store,capture:()=>({documents:[record],session})});auto.start({documents:[],session:{openIds:[],activeId:null}});await auto.flush();await assert.rejects(()=>auto.remove('race'),/Close this project/);assertions++;check(await store.getDocument('race'),'unsafe direct remove keeps record');let removed=0;await auto.remove('race',{onRemoved:()=>removed++});equal(removed,1,'post-commit memory callback runs once');await auto.flush();equal(await store.getDocument('race'),null,'stale in-memory capture cannot recreate deleted project');equal((await store.readSession()).openIds,[],'stale session cannot restore deleted id');check(auto.isCurrent(),'filtered deleted capture has consistent save state');await auto.close();
 console.log('PDFCreator Home deletion: '+assertions+' assertions passed with native PDFs and simulated IndexedDB transactions.');
}finally{if(context)await context.close()}
