import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
const {createCanvas}=createRequire(import.meta.url)('@napi-rs/canvas');
import {convertOfflineWord} from './offline-word-converter.js';
import {wordFixture} from './offline-word-fixtures.mjs';
import * as Engine from './engine.js';
import {buildDoc} from './legacy-word-fixture.mjs';
import {directTextTargets} from './direct-text.js';
let assertions=0;const check=(v,label)=>{assertions++;assert.ok(v,label)};
const fonts=Object.fromEntries([['regular','Regular'],['bold','Bold'],['italic','Italic'],['boldItalic','BoldItalic']].map(([key,label])=>[key,new Uint8Array(fs.readFileSync('fonts/Arimo-'+label+'.ttf'))]));
let requests=0;const original=globalThis.fetch;globalThis.fetch=()=>{requests++;throw Error('Test blocks all network')};
try{
 const image=createCanvas(30,15);image.getContext('2d').fillStyle='#c02040';image.getContext('2d').fillRect(0,0,30,15);
 const progress=[],input=wordFixture({image:new Uint8Array(image.toBuffer('image/png'))}),result=await convertOfflineWord(input,fonts,{onProgress:value=>progress.push(value)}),info=Engine.inspectPDF(result.bytes),text=Engine.extractTextPDF(result.bytes).map(p=>p.text).join('\n');
 check(info.pageCount===2,'sections become two PDF pages');check(info.pages[0].height>info.pages[0].width&&info.pages[1].width>info.pages[1].height,'portrait and landscape geometry retained');
 for(const phrase of ['OFFLINE WORD IMPORT','Italic and underline retained.','TABLE LEFT','TABLE RIGHT','LANDSCAPE SECOND PAGE','HEADER RETAINED','FOOTER RETAINED','Footnote survives conversion.'])check(text.includes(phrase),phrase+' remains searchable');
 const doc=Engine.openPDF(result.bytes);try{const runs=directTextTargets(doc,0);check(runs.some(r=>r.text.includes('OFFLINE WORD')&&r.bold&&r.color==='#800020'&&Math.abs(r.size-18)<.1),'heading formatting retained');check(runs.some(r=>r.text.includes('Italic')&&r.italic),'italic uses the embedded face');const page=doc.loadPage(0),structured=page.toStructuredText('preserve-images');try{check(JSON.parse(structured.asJSON()).blocks.some(b=>b.type==='image'),'embedded picture retained')}finally{structured.destroy();page.destroy()}}finally{doc.destroy()}
 check(requests===0,'conversion makes no network requests');check(progress.at(-1)===.95,'conversion progress reported');check(Array.isArray(result.losses),'conversion notes available');
 await assert.rejects(()=>convertOfflineWord(wordFixture({chinese:true}),fonts),/embedded font does not contain/);assertions++;
 await assert.rejects(()=>convertOfflineWord(new TextEncoder().encode('not a Word document'),fonts),/Cannot read/);assertions++;
 await assert.rejects(()=>convertOfflineWord(wordFixture(),{}),/fonts/);assertions++;
 const legacy=await convertOfflineWord(buildDoc([{text:'LEGACY WORD IMPORT\rSecond paragraph\r',compressed:false}]),fonts);check(legacy.format==='doc','real CFB/Word 97-2003 input accepted');check(Engine.extractTextPDF(legacy.bytes).map(p=>p.text).join(' ').includes('LEGACY WORD IMPORT'),'legacy Word text becomes searchable PDF');check(legacy.losses.length>0,'legacy conversion limitations are reported');
 await assert.rejects(()=>convertOfflineWord(buildDoc([{text:'secret\r',compressed:false}],{encrypted:true}),fonts),/protected legacy/);assertions++;
 const pdf=await Engine.renderPagePNG(result.bytes,0,{scale:.7});check(pdf.bytes.length>1000,'converted PDF renders to pixels');fs.writeFileSync('offline-word-proof.png',pdf.bytes);
 console.log('Offline Word converter: '+assertions+' assertions passed; native PDF output, fonts, sections, headers/footers, table, footnote and zero network.');
}finally{globalThis.fetch=original}
