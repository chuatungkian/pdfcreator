/* Explicit visual-signature sources. Neither preview nor selection changes a PDF. */
import {SYSTEM_FONTS} from './system-fonts.js';
import {signatureStyle,drawSignatureStrokes,visualSignatureCanvas,composeVisualSignature} from './visual-signature.js';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function signatureImageType(bytes){
 if(bytes?.length>=8&&[137,80,78,71,13,10,26,10].every((value,index)=>bytes[index]===value))return'image/png';
 if(bytes?.length>=3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return'image/jpeg';
 throw Error('Import a PNG or JPEG signature image.');
}
function dataURL(bytes,type){let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return'data:'+type+';base64,'+btoa(binary)}
export async function chooseSignatureInput({modal,font='Arial',document:doc=globalThis.document}={}){
 let dispose=()=>{},readInput;
 try{return await modal('Add a visual signature',`<p>This places a signature image. Use Certificate sign for a cryptographic signature.</p><label for="sigMode">Signature source</label><select id="sigMode" aria-controls="sigComposeFields sigImportFields"><option value="compose">Type &amp; draw</option><option value="image">Import image</option></select><div id="sigComposeFields" class="signature-compose"><label for="dialogFont">Font</label><select id="dialogFont" name="font">${SYSTEM_FONTS.map(name=>'<option value="'+esc(name)+'" '+(name===font?'selected':'')+'>'+esc(name)+'</option>').join('')}</select><div class="signature-style-controls"><label>Colour<input id="sigColour" type="color" value="#101d3a"></label><label>Line thickness<input id="sigLineWidth" type="number" min="0.5" max="16" step="0.5" value="4"></label><label class="signature-bold"><input id="sigBold" type="checkbox">Bold typed name</label></div><label for="sigtext">Type your name (optional)</label><input id="sigtext" placeholder="Your name" maxlength="200"><label for="drawcanvas">Draw your signature (optional)</label><canvas id="drawcanvas" width="900" height="300" aria-label="Draw your signature"></canvas><button type="button" id="clearsig" class="small">Clear drawing</button><p class="help">Type, draw, or use both. When both are provided, your name appears below the drawing.</p><label for="sigpreview">Signature preview</label><canvas id="sigpreview" width="900" height="300" aria-label="Signature preview"></canvas></div><div id="sigImportFields" class="signature-import" hidden><label for="sigfile">Signature image</label><input type="file" id="sigfile" accept="image/png,image/jpeg" disabled><p id="sigImageStatus" class="help" role="status">Choose a PNG or JPEG image to preview.</p><img id="sigImagePreview" class="signature-import-preview" alt="Imported signature preview" style="max-width:100%;max-height:180px" hidden><p class="help">The imported image is used by itself, with its original colours and pixels.</p></div>`,{
  ok:'Use signature',setup:()=>{
   const $=id=>doc.getElementById(id),canvas=$('drawcanvas'),preview=$('sigpreview'),strokes=[],view=doc.defaultView;
   let pointer=null,current=null,imported=null,pending=null,serial=0,closed=false;
   const error=message=>{const target=$('modalerror');if(target)target.textContent=message};
   const style=()=>signatureStyle({color:$('sigColour').value,lineWidth:+$('sigLineWidth').value,bold:$('sigBold').checked});
   function release(){const id=pointer;pointer=null;current=null;if(id!==null)try{canvas.releasePointerCapture?.(id)}catch{}}
   function update(){if(closed||$('sigMode').value!=='compose')return;try{const options=style();drawSignatureStrokes(canvas,strokes,options);if(strokes.length)canvas.dataset.drawn='1';else delete canvas.dataset.drawn;visualSignatureCanvas(canvas,{text:$('sigtext').value,font:$('dialogFont').value,hasDrawing:strokes.length>0,...options},preview);error('')}catch(problem){error(problem.message)}}
   function mode(){release();const image=$('sigMode').value==='image';for(const [id,active]of [['sigComposeFields',!image],['sigImportFields',image]]){const panel=$(id);panel.hidden=!active;for(const control of panel.querySelectorAll('input,select,button'))control.disabled=!active}$('sigfile').required=image;error('');if(!image)update()}
   const point=event=>{const r=canvas.getBoundingClientRect();return r.width>0&&r.height>0?[(event.clientX-r.left)*canvas.width/r.width,(event.clientY-r.top)*canvas.height/r.height]:null};
   canvas.onpointerdown=event=>{if($('sigMode').value!=='compose'||pointer!==null||event.button!==0||event.isPrimary===false)return;const p=point(event);if(!p)return;event.preventDefault();pointer=event.pointerId;canvas.setPointerCapture?.(pointer);current=[p];strokes.push(current);update()};
   canvas.onpointermove=event=>{if(event.pointerId!==pointer||pointer===null)return;const p=point(event);if(!p)return;event.preventDefault();current.push(p);update()};
   canvas.onpointerup=event=>{if(event.pointerId!==pointer||pointer===null)return;const p=point(event);if(p)current.push(p);release();update()};
   for(const type of ['pointercancel','lostpointercapture'])canvas.addEventListener(type,event=>{if(event.pointerId===pointer)release()});
   $('clearsig').onclick=()=>{release();strokes.length=0;update()};for(const id of ['sigColour','sigLineWidth','sigtext'])$(id).oninput=update;$('sigBold').onchange=update;$('dialogFont').addEventListener('change',update);$('sigMode').onchange=mode;
   function loadImport(){
    const token=++serial,file=$('sigfile').files[0];imported=null;$('sigImagePreview').hidden=true;$('sigImagePreview').removeAttribute('src');error('');
    if(!file){$('sigImageStatus').textContent='Choose a PNG or JPEG image to preview.';pending=null;return Promise.resolve()}
    $('sigImageStatus').textContent='Preparing image preview…';
    pending=(async()=>{
     const bytes=new Uint8Array(await file.arrayBuffer()),type=signatureImageType(bytes),url=dataURL(bytes,type),image=new view.Image();
     await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(Error('The signature image could not be opened. Choose a valid PNG or JPEG.'));image.src=url});
     if(closed||token!==serial)return;imported={file,bytes,type};$('sigImagePreview').src=url;$('sigImagePreview').hidden=false;$('sigImageStatus').textContent=file.name+' · '+image.width+' × '+image.height+' px';
    })().catch(problem=>{if(!closed&&token===serial){$('sigImageStatus').textContent=problem.message;if($('sigMode').value==='image')error(problem.message)}});
    return pending;
   }
   $('sigfile').onchange=loadImport;
   readInput=async()=>{
    if($('sigMode').value==='image'){
     const file=$('sigfile').files[0];if(!file)throw Error('Choose a PNG or JPEG signature image.');if(!pending||imported&&imported.file!==file)await loadImport();else await pending;
     if(!imported||imported.file!==file)throw Error('Choose a valid PNG or JPEG signature image and check its preview.');return{mode:'image',bytes:imported.bytes,type:imported.type};
    }
    const text=$('sigtext').value.trim(),selectedFont=$('dialogFont').value,options=style(),image=await composeVisualSignature(canvas,{text,font:selectedFont,hasDrawing:strokes.length>0,...options});
    return{mode:'compose',...image,font:text?selectedFont:null};
   };
   dispose=()=>{if(closed)return;closed=true;serial++;release();imported=null;pending=null;$('sigImagePreview')?.removeAttribute('src')};mode();return dispose;
  },read:()=>readInput()
 })}finally{dispose()}
}
