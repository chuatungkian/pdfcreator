/* One preparation path for page previews and committed edits; original bytes stay untouched. */
import {openPDF} from './engine.js';
import {directEditTargets,replaceDirectTextGroup,saveDirectEdit} from './direct-text.js';
import {replaceOCRText} from './ocr-direct.js';
import {pageObjects} from './object-tools.js';
import {reconcileTextGroups} from './object-groups.js';
import {columnFollowers,intersects} from './column-reflow.js';
export function prepareDirectEdit(bytes,index,target,text,options={},ocr=[]){
 if(target.kind==='ocr'&&options.sourceRects)target={...target,wordRects:options.sourceRects};const mode=options.layoutMode||'keep';if(!['keep','fit','column'].includes(mode))throw Error('Choose a valid text layout mode.');
 function attempt(scale=1,following=[],serialize=true){const doc=openPDF(bytes);try{let result;if(target.kind==='ocr')result=replaceOCRText(doc,index,target,text,{...options,fontScale:scale,reflowFollowing:following,allowTextOverlap:true},ocr);else result=replaceDirectTextGroup(doc,index,target,text,{...options,fontScale:scale,reflowFollowing:following,allowTextOverlap:true});reconcileTextGroups(doc,index,target,following);return{bytes:serialize?saveDirectEdit(doc):null,...result,fontScale:scale}}finally{doc.destroy()}}
 let plan;
 if(mode==='fit'){
  const widthDelta=(options.width??target.layout.width)-target.layout.width,u=target.layout.u||[1,0],fitRight=target.rect[2]+widthDelta*Math.abs(u[0]),fitBottom=target.rect[3]+widthDelta*Math.abs(u[1]);
  const fits=p=>!p.rect||p.rect[0]>=target.rect[0]-2&&p.rect[1]>=target.rect[1]-2&&p.rect[2]<=fitRight+2&&p.rect[3]<=fitBottom+2;
  let low=.02,high=1;for(let i=0;i<13;i++){const scale=i===0?1:(low+high)/2;let p;try{p=attempt(scale,[],false)}catch(e){if(!/beyond the page/.test(e.message))throw e;high=scale;continue}const readable=!p.fontSizes?.length||Math.min(...p.fontSizes)>=4;if(fits(p)&&readable){plan=p;low=scale;if(scale===1)break}else if(!readable)low=scale;else high=scale;}
  if(!plan)throw Error('This text cannot fit at 4 pt or larger. Increase the width or select a larger text region.');plan=attempt(plan.fontScale);
 }else plan=attempt();
 const doc=openPDF(bytes);try{
  const native=directEditTargets(doc,index,'paragraph'),all=[...native,...ocr],selected=new Set(target.parts?.map(p=>p.index)),neighbours=all.filter(t=>t!==target&&!(target.kind==='ocr'&&t.kind==='ocr'&&t.id===target.id)&&!t.parts?.some(p=>selected.has(p.index)));
  if(mode==='column'){const page=doc.loadPage(index);let bounds;try{bounds=page.getBounds()}finally{page.destroy()}const sourceWords=ocr.flatMap(t=>t.wordRects),obstacles=pageObjects(doc,index).filter(o=>o.kind!=='annotation'&&o.type!=='Text box'&&!(target.kind==='ocr'&&sourceWords.some(r=>o.rect[0]>=r[0]-1&&o.rect[1]>=r[1]-1&&o.rect[2]<=r[2]+1&&o.rect[3]<=r[3]+1)));obstacles.push(...(target.columnBarriers||[]),...native.filter(t=>!t.editable));if(target.kind==='ocr')obstacles.push(...native);else obstacles.push(...ocr);
   const following=columnFollowers(target,plan.rect||[target.rect[0],target.rect[1],target.rect[2],target.rect[1]],(target.kind==='ocr'?ocr:native).filter(t=>t.editable!==false),obstacles,bounds);if(following.length){plan=attempt(1,following);plan.following=following;plan.movedOCRIds=target.kind==='ocr'?following.map(i=>i.target.id):[];}
  }
  const moved=new Set(plan.following?.map(i=>i.target));plan.affected=neighbours.filter(n=>!moved.has(n)&&[...plan.rects,...(target.kind==='ocr'?target.wordRects:[])].some(r=>intersects(r,n.rect))).map(n=>n.rect);plan.moved=(plan.following||[]).flatMap(i=>[i.target.rect,i.target.rect.map((v,j)=>j%2?v+i.matrix[5]:v)]);
  const draftRects=[...plan.rects,...(target.kind==='ocr'?target.wordRects:[])];plan.artwork=pageObjects(doc,index).filter(o=>!intersects(o.rect,target.rect)&&!all.some(t=>o.rect[0]>=t.rect[0]-1&&o.rect[1]>=t.rect[1]-1&&o.rect[2]<=t.rect[2]+1&&o.rect[3]<=t.rect[3]+1)&&draftRects.some(r=>intersects(r,o.rect))).map(o=>o.rect);plan.affected.push(...plan.artwork);
  if(plan.affected.length&&options.allowTextOverlap!==true)throw Object.assign(new Error('The edit overlaps nearby content.'),{code:'DIRECT_TEXT_OVERLAP',hasArtwork:plan.artwork.length>0});
  return plan;
 }finally{doc.destroy()}
}
