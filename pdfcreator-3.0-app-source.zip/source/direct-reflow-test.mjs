/* Reflow regressions use real native fonts, PDF glyph positions and page pixels. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PDFDocument,StandardFonts,rgb,degrees} from 'pdf-lib';
import * as E from './engine.js';
import {directTextTargets,directEditTargets,directChunkTarget,replaceDirectTextGroup,saveDirectEdit} from './direct-text.js';
let assertions=0;const ok=(v,m)=>{assertions++;assert.ok(v,m)},equal=(a,b,m)=>{assertions++;assert.deepEqual(a,b,m)};
const text=bytes=>E.extractTextPDF(bytes).map(p=>p.text).join('\n').replace(/\s+/gu,' ').trim();
async function fixture(rotation=0,fontName=StandardFonts.Helvetica){
 const d=await PDFDocument.create(),p=d.addPage([595,842]),font=await d.embedFont(fontName);p.setCropBox(10,15,575,812);p.setRotation(degrees(rotation));
 p.drawText('This paragraph has three separate lines.\nThe next line should close up after edits.\nThe final sentence finishes here.',{x:50,y:740,size:14,lineHeight:18,font,color:rgb(.5,0,.125)});
 p.drawText('Another paragraph stays independent.\nThis line must stay in place.',{x:50,y:590,size:14,lineHeight:18,font});p.drawRectangle({x:45,y:460,width:200,height:40,color:rgb(.05,.1,.25)});
 return d.save();
}
for(const font of [StandardFonts.Helvetica,StandardFonts.TimesRoman])for(const rotation of [0,90,180,270]){
 const original=await fixture(rotation,font),doc=E.openPDF(original);
 try{
  const paragraphs=directEditTargets(doc,0),first=paragraphs.find(p=>p.text.startsWith('This paragraph')),next=paragraphs.find(p=>p.text.startsWith('Another paragraph'));
  equal(paragraphs.length,2,'paragraph boundaries detected independently');equal(first.parts.length,3,'three lines form one paragraph');ok(first.text.includes('lines. The next'),'soft line endings join as text');equal(first.layout.leading,18,'original line spacing retained');equal(directEditTargets(doc,0,'line').length,5,'line mode stays available');
  const result=replaceDirectTextGroup(doc,0,first,'A short paragraph.');equal(result.lineCount,1,'shortening closes all internal line gaps');const bytes=saveDirectEdit(doc),reopened=E.openPDF(bytes);
  try{
   const edited=directEditTargets(reopened,0).find(p=>p.text==='A short paragraph.'),unchanged=directEditTargets(reopened,0).find(p=>p.text.startsWith('Another paragraph'));
   ok(edited,'replacement is editable as a paragraph');equal(edited.layout.width,first.layout.width,'original wrapping width survives a shorter edit');equal(edited.size,first.size,'font size retained');equal(edited.color,first.color,'text colour retained');equal(edited.parts[0].matrix.slice(0,4).map(n=>n||0),first.parts[0].matrix.slice(0,4).map(n=>n||0),'font transform retained');equal(unchanged.rect,next.rect,'unselected paragraph stays in place');ok(!text(bytes).includes('three separate lines'),'old paragraph content removed');
   const before=E.renderPagePixels(original,0,{scale:.7}),after=E.renderPagePixels(bytes,0,{scale:.7}),r=[Math.min(first.rect[0],edited.rect[0])*.7-3,Math.min(first.rect[1],edited.rect[1])*.7-3,Math.max(first.rect[2],edited.rect[2])*.7+3,Math.max(first.rect[3],edited.rect[3])*.7+3];let difference=0;
   for(let y=0;y<before.height;y++)for(let x=0;x<before.width;x++)if(x<r[0]||x>r[2]||y<r[1]||y>r[3])for(let c=0;c<before.components;c++){const i=y*before.stride+x*before.components+c;if(before.pixels[i]!==after.pixels[i])difference++}equal(difference,0,'unselected text and artwork stay pixel-identical');
   const expanded=replaceDirectTextGroup(reopened,0,edited,'This replacement paragraph is longer and will wrap over several lines without changing the original font size.',{width:180});ok(expanded.lineCount>=3,'longer paragraph wraps rather than shrinking');const output=saveDirectEdit(reopened);ok(text(output).includes('without changing the original font size.'),'complete longer replacement remains searchable');
   if(rotation===0&&font===StandardFonts.Helvetica)fs.writeFileSync('direct-reflow-proof.png',E.renderPagePNG(output,0,{scale:1.3}).bytes);
  }finally{reopened.destroy()}
 }finally{doc.destroy()}
}
// A manually selected chunk may include several paragraphs. Removing their old
// hard layout and reflowing the selection closes the gap between selected paragraphs.
{
 const bytes=await fixture(),doc=E.openPDF(bytes);try{const chunk=directChunkTarget(doc,0,[35,65,400,280]);equal(chunk.parts.length,5,'dragged chunk contains complete selected lines');ok(chunk.text.includes('\n\n'),'paragraph breaks remain explicit in a chunk');
 const result=replaceDirectTextGroup(doc,0,chunk,'First paragraph.\n\nSecond paragraph.',{width:260});equal(result.lineCount,3,'chunk uses the requested blank paragraph separator');const output=saveDirectEdit(doc),reopened=E.openPDF(output);try{const a=directTextTargets(reopened,0).find(p=>p.text.startsWith('First')),b=directTextTargets(reopened,0).find(p=>p.text.startsWith('Second'));equal(b.matrix[5]-a.matrix[5],36,'selected paragraphs pull up to the new flow');equal(directEditTargets(reopened,0).length,2,'paragraph mode still selects each paragraph independently after chunk reflow')}finally{reopened.destroy()}
 }finally{doc.destroy()}
}
// Mixed fonts and colours are retained for unchanged words, and replacements
// inherit the source word's style instead of flattening the paragraph to one font.
{
 const d=await PDFDocument.create(),p=d.addPage([595,842]),normal=await d.embedFont(StandardFonts.TimesRoman),bold=await d.embedFont(StandardFonts.TimesRomanBold);let x=50;
 const segment=(value,font,color)=>{p.drawText(value,{x,y:740,size:16,font,color});x+=font.widthOfTextAtSize(value,16)};
 segment('Plain ',normal,rgb(0,0,0));segment('bold',bold,rgb(.5,0,.125));segment(' and blue.',normal,rgb(.05,.1,.3));
 p.drawText('The next line belongs to the paragraph.',{x:50,y:720,size:16,font:normal});const doc=E.openPDF(await d.save());try{
 const target=directEditTargets(doc,0)[0];ok(target.mixed,'mixed style paragraph identified');replaceDirectTextGroup(doc,0,target,'Plain stronger and blue. The next line belongs to the paragraph.',{width:300});const output=saveDirectEdit(doc),reopened=E.openPDF(output);try{
 const runs=directTextTargets(reopened,0),replacement=runs.find(r=>r.text.includes('stronger')),blue=runs.find(r=>r.text.includes('blue.'));ok(replacement.bold,'changed word inherits bold');equal(replacement.color,'#800020','changed word inherits colour');equal(replacement.size,16,'mixed source size retained');equal(blue.color,'#0d1a4d','unchanged coloured phrase retains colour');ok(text(output).includes('Plain stronger and blue.'),'mixed style output remains searchable');
 }finally{reopened.destroy()}
 }finally{doc.destroy()}
}
for(const [replacement,options,pattern]of [['Missing 😀',{},/does not contain/],['Word '.repeat(500),{width:100},/beyond|overlap/],['Text',{width:0},/text width/]]){
 const doc=E.openPDF(await fixture());try{const target=directEditTargets(doc,0)[0];assertions++;assert.throws(()=>replaceDirectTextGroup(doc,0,target,replacement,options),pattern);ok(directEditTargets(doc,0).some(p=>p.text===target.text),'invalid reflow does not remove the selected text')}finally{doc.destroy()}
}
console.log('pdfpro paragraph/chunk reflow: '+assertions+' assertions passed with original fonts, mixed styles, rotations, crop origins, gap closing and native PDF pixels.');
