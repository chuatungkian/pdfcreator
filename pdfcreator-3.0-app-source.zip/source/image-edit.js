/* Instance-local PDF image editing with reversible source pixels. AGPL-3.0-or-later. */
import {mupdf} from './engine.js';
import {contentTokens,readPageContent,objectMatrix} from './object-tools.js';
const I=[1,0,0,1,0,0],concat=mupdf.Matrix.concat,inv=mupdf.Matrix.invert;
const KEY='PDFCreatorImage',encoder=new TextEncoder();
const number=(value,fallback,min,max)=>{const n=value===undefined?fallback:Number(value);if(!Number.isFinite(n)||n<min||n>max)throw Error('Image setting is outside its allowed range.');return n};
export function imageSettings(input={}){
 const crop={};for(const key of ['left','top','right','bottom'])crop[key]=number(input.crop?.[key],0,0,.99);
 if(crop.left+crop.right>=.99||crop.top+crop.bottom>=.99)throw Error('Keep at least 1% of the image when cropping.');
 return{crop,opacity:number(input.opacity,1,0,1),brightness:number(input.brightness,0,-100,100),contrast:number(input.contrast,0,-100,100),saturation:number(input.saturation,0,-100,100),hue:number(input.hue,0,-180,180),warmth:number(input.warmth,0,-100,100)};
}
const read=(obj,key,fn)=>{if(obj.isNull())return fn(obj);const value=obj.get(key);try{return fn(value)}finally{value.destroy()}};
const name=(obj,key)=>obj.isNull()?'':read(obj,key,v=>v.isName()?v.asName():'');
function streamText(obj){const buffer=obj.readStream();try{const bytes=buffer.asUint8Array(),parts=[];for(let i=0;i<bytes.length;i+=16000)parts.push(String.fromCharCode(...bytes.subarray(i,i+16000)));return parts.join('')}finally{buffer.destroy()}}
function cloneDict(doc,obj){const result=doc.newDictionary();obj.forEach((value,key)=>{try{result.put(key,value)}finally{value.destroy()}});return result}
const decodeName=token=>token.text.slice(1).replace(/#([a-f\d]{2})/gi,(_,h)=>String.fromCharCode(parseInt(h,16)));
function calls(source){const tokens=contentTokens(source),result=[];if(tokens.some(t=>t.kind==='operator'&&t.text==='BI'))throw Error('Inline-image streams are not supported by image editing.');let operands=[];for(const token of tokens){if(token.kind!=='operator'){operands.push(token);continue}if(token.text==='Do'&&operands.at(-1)?.kind==='name')result.push({name:decodeName(operands.at(-1)),start:operands.at(-1).start,end:token.end});operands=[]}return result}
export function imageTargets(doc,index){
 const page=doc.loadPage(index),out=[];let object,resources;
 try{
  object=page.getObject();resources=object.getInheritable('Resources');const textResources=new Set();
  for(const key of ['PdfProFontBoxes','PDFCreatorWatermarks']){const records=object.get(key);try{if(records.isArray())records.forEach(record=>{try{const resource=record.get('Resource');try{if(resource.isName())textResources.add(resource.asName())}finally{resource.destroy()}}finally{record.destroy()}})}finally{records.destroy()}}
  function walk(source,res,matrix,opacity,path,ancestors,depth){
   if(depth>24)return;let tokens;try{tokens=contentTokens(source);if(tokens.some(t=>t.kind==='operator'&&t.text==='BI'))return}catch{return}
   let ctm=matrix,alpha=opacity,operands=[],stack=[],ordinal=0;
   for(const token of tokens){
    if(token.kind!=='operator'){operands.push(token);continue}
    if(token.text==='q')stack.push({ctm:[...ctm],alpha});
    else if(token.text==='Q'){const previous=stack.pop();if(!previous)return;({ctm,alpha}=previous)}
    else if(token.text==='cm'&&operands.length>=6&&operands.slice(-6).every(t=>t.kind==='number'))ctm=concat(operands.slice(-6).map(t=>+t.text),ctm);
    else if(token.text==='gs'&&operands.at(-1)?.kind==='name'){const gs=res.get('ExtGState',decodeName(operands.at(-1)));try{alpha=read(gs,'ca',v=>v.isNumber()?v.asNumber():alpha)}finally{gs.destroy()}}
    else if(token.text==='Do'&&operands.at(-1)?.kind==='name'){
     const resourceName=decodeName(operands.at(-1)),ref=res.get('XObject',resourceName),subtype=name(ref,'Subtype'),key=ref.isIndirect()?ref.asIndirect():null,nextPath=[...path,ordinal++];
     try{
      if(!path.length&&textResources.has(resourceName)){operands=[];continue}
      const recipe=read(ref,KEY,v=>{try{return v.isString()?JSON.parse(v.asString()):null}catch{return null}});
      if(subtype==='Image'||recipe?.version===1){
       if(subtype==='Image'&&read(ref,'ImageMask',v=>v.isBoolean()&&v.asBoolean())){operands=[];continue}
       const sourceRef=recipe?read(ref,'Resources',r=>read(r,'XObject',xo=>read(xo,'Source',s=>s.isIndirect()?s.asIndirect():null))):key;
       const local=read(ref,'Matrix',m=>m.isArray()?m.asJS():I),paint=concat(local,ctm),rect=mupdf.Rect.transform([0,0,1,1],paint);
       if(sourceRef&&rect.every(Number.isFinite)&&Math.abs(paint[0]*paint[3]-paint[1]*paint[2])>.000001)out.push({kind:'image',type:'Image',path:nextPath,matrix:paint,rect,sourceRef,settings:recipe?imageSettings(recipe.settings):imageSettings({opacity:alpha}),originalOpacity:recipe?.originalOpacity??alpha});
      }else if(subtype==='Form'&&!ancestors.has(key)){
       const local=read(ref,'Matrix',m=>m.isArray()?m.asJS():I),own=ref.get('Resources'),group=ref.get('Group');
       try{walk(streamText(ref),own.isNull()?res:own,concat(local,ctm),name(group,'S')==='Transparency'?1:alpha,nextPath,new Set([...ancestors,key]),depth+1)}finally{group.destroy();own.destroy()}
      }
     }finally{ref.destroy()}
    }
    operands=[];
   }
  }
  walk(readPageContent(page),resources,page.getTransform(),1,[],new Set(),0);return out;
 }finally{resources?.destroy();object?.destroy();page.destroy()}
}
const cropMatrix=crop=>[1-crop.left-crop.right,0,0,1-crop.top-crop.bottom,crop.left,crop.bottom];
export function croppedImageFrame(target,crop){const settings=imageSettings({...target.settings,crop}),matrix=concat(concat(cropMatrix(settings.crop),inv(cropMatrix(target.settings.crop))),target.matrix);return{matrix,rect:mupdf.Rect.transform([0,0,1,1],matrix)}}
export function imageAtPoint(targets,point){return[...targets].reverse().find(target=>{const m=inv(target.matrix),x=m[0]*point[0]+m[2]*point[1]+m[4],y=m[1]*point[0]+m[3]*point[1]+m[5];return x>=0&&x<=1&&y>=0&&y<=1})}
export function readImageRGBA(doc,target){
 const ref=doc.newIndirect(target.sourceRef);let image,pix,rgb,mask,maskPix,maskScaled;
 try{
  image=doc.loadImage(ref);const width=image.getWidth(),height=image.getHeight();if(width*height>20000000)throw Error('Colour adjustments support images up to 20 million pixels. Move, resize, crop and opacity remain available.');
  pix=image.toPixmap();rgb=pix.convertToColorSpace(mupdf.ColorSpace.DeviceRGB,true);const values=rgb.getPixels(),n=rgb.getNumberOfComponents(),alpha=rgb.getAlpha(),rgba=new Uint8ClampedArray(width*height*4);
  mask=image.getMask();if(mask&&!alpha){maskPix=mask.toPixmap();if(maskPix.getWidth()!==width||maskPix.getHeight()!==height)maskScaled=maskPix.warp([[0,0],[maskPix.getWidth(),0],[0,maskPix.getHeight()],[maskPix.getWidth(),maskPix.getHeight()]],width,height)}
  const maskData=(maskScaled||maskPix)?.getPixels(),maskComponents=(maskScaled||maskPix)?.getNumberOfComponents();
  for(let p=0;p<width*height;p++){const a=alpha?values[p*n+n-1]:maskData?maskData[p*maskComponents]:255;for(let c=0;c<3;c++)rgba[p*4+c]=alpha&&a?Math.min(255,values[p*n+c]*255/a):values[p*n+c];rgba[p*4+3]=a}
  return{width,height,rgba};
 }finally{maskScaled?.destroy();maskPix?.destroy();mask?.destroy();rgb?.destroy();pix?.destroy();image?.destroy();ref.destroy()}
}
const clamp=n=>Math.max(0,Math.min(255,n));
export function adjustImagePixels(rgba,input){
 const s=imageSettings(input),out=new Uint8ClampedArray(rgba),brightness=s.brightness*2.55,contrast=(259*(s.contrast+255))/(255*(259-s.contrast)),sat=1+s.saturation/100,angle=s.hue*Math.PI/180,c=Math.cos(angle),sn=Math.sin(angle);
 for(let i=0;i<out.length;i+=4){
  let r=rgba[i],g=rgba[i+1],b=rgba[i+2];
  if(s.hue){const y=.299*r+.587*g+.114*b,u=.596*r-.274*g-.322*b,v=.211*r-.523*g+.312*b,uu=u*c-v*sn,vv=u*sn+v*c;r=y+.956*uu+.621*vv;g=y-.272*uu-.647*vv;b=y-1.106*uu+1.703*vv}
  const lum=.2126*r+.7152*g+.0722*b;r=lum+(r-lum)*sat;g=lum+(g-lum)*sat;b=lum+(b-lum)*sat;
  out[i]=clamp(contrast*(r-128)+128+brightness+s.warmth*.4);out[i+1]=clamp(contrast*(g-128)+128+brightness+s.warmth*.08);out[i+2]=clamp(contrast*(b-128)+128+brightness-s.warmth*.4);
 }return out;
}
function uniqueResource(doc,resources,value,prefix){const original=resources.get('XObject'),objects=original.isDictionary()?cloneDict(doc,original):doc.newDictionary();try{let n=doc.countObjects(),key;do{key=prefix+n++;const existing=objects.get(key);const free=existing.isNull();existing.destroy();if(free)break}while(true);objects.put(key,value);resources.put('XObject',objects);return key}finally{objects.destroy();original.destroy()}}
function dictionary(doc,object){const result=doc.newDictionary();object.forEach((value,key)=>{try{if(!['Length','Filter','DecodeParms'].includes(key))result.put(key,value)}finally{value.destroy()}});return result}
function replaceInvocation(doc,page,target,replacement){
 const object=page.getObject(),inherited=object.getInheritable('Resources'),resources=cloneDict(doc,inherited);
 try{
  function descend(source,res,path){const call=calls(source)[path[0]];if(!call)throw Error('This image changed. Select it again.');let command;
   if(path.length===1)command=replacement(res);
   else{const form=res.get('XObject',call.name),own=form.get('Resources'),child=cloneDict(doc,own.isNull()?res:own),dict=dictionary(doc,form);let copy;try{const updated=descend(streamText(form),child,path.slice(1));dict.put('Resources',child);dict.put('PDFCreatorImageBranch',true);copy=doc.addStream(Uint8Array.from(updated,c=>c.charCodeAt(0)),dict);command='/'+uniqueResource(doc,res,copy,'ImageBranch')+' Do'}finally{copy?.destroy();dict.destroy();child.destroy();own.destroy();form.destroy()}}
   const updated=source.slice(0,call.start)+command+source.slice(call.end);
   if(!calls(updated).some(item=>item.name===call.name)){
    const previous=res.get('XObject',call.name);const owned=read(previous,KEY,v=>v.isString())||read(previous,'PDFCreatorImageBranch',v=>v.isBoolean()&&v.asBoolean());previous.destroy();
    if(owned){const oldObjects=res.get('XObject'),objects=cloneDict(doc,oldObjects);try{objects.delete(call.name);res.put('XObject',objects)}finally{objects.destroy();oldObjects.destroy()}}
   }
   return updated;
  }
  const updated=descend(readPageContent(page),resources,target.path),stream=doc.addStream(Uint8Array.from(updated,c=>c.charCodeAt(0)),{});try{object.put('Resources',resources);object.put('Contents',stream)}finally{stream.destroy()}
 }finally{resources.destroy();inherited.destroy();object.destroy()}
}
export async function editImage(doc,index,target,input,{geometry=null,remove=false,progress=()=>{},signal}={}){
 const current=imageTargets(doc,index).find(t=>t.path.join('.')===target.path.join('.'));
 if(!current||current.sourceRef!==target.sourceRef||current.matrix.some((n,i)=>Math.abs(n-target.matrix[i])>.01))throw Error('This image changed. Select it again.');
 const page=doc.loadPage(index);let source,pixelRef,form;
 try{
  if(remove){replaceInvocation(doc,page,current,()=> '');return}
  const settings=imageSettings(input),natural=croppedImageFrame(current,settings.crop),rect=natural.rect,transform=geometry?objectMatrix(rect,geometry):I,desired=concat(natural.matrix,transform),local=concat(desired,inv(current.matrix));
  source=doc.newIndirect(current.sourceRef);pixelRef=source;
  if(['brightness','contrast','saturation','hue','warmth'].some(key=>settings[key]!==0)){
   const data=readImageRGBA(doc,current),rgba=new Uint8ClampedArray(data.rgba.length),rows=64;
   for(let y=0;y<data.height;y+=rows){if(signal?.aborted)throw new DOMException('Cancelled','AbortError');const start=y*data.width*4,end=Math.min(data.rgba.length,(y+rows)*data.width*4);rgba.set(adjustImagePixels(data.rgba.subarray(start,end),settings),start);progress(y/data.height,'Adjusting image colours');await new Promise(r=>setTimeout(r,0))}
   const pix=new mupdf.Pixmap(mupdf.ColorSpace.DeviceRGB,[0,0,data.width,data.height],true);let adjusted;try{const pixels=pix.getPixels();for(let i=0;i<rgba.length;i+=4){const a=rgba[i+3];pixels[i]=Math.round(rgba[i]*a/255);pixels[i+1]=Math.round(rgba[i+1]*a/255);pixels[i+2]=Math.round(rgba[i+2]*a/255);pixels[i+3]=a}adjusted=new mupdf.Image(pix);pixelRef=doc.addImage(adjusted)}finally{adjusted?.destroy();pix.destroy()}
  }
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  const crop=inv(cropMatrix(settings.crop)),content='q /Appearance gs '+crop.join(' ')+' cm /Pixels Do Q',metadata={version:1,originalOpacity:current.originalOpacity,settings};
  form=doc.addStream(encoder.encode(content),{Type:'XObject',Subtype:'Form',BBox:[0,0,1,1],Resources:{XObject:{Source:source,Pixels:pixelRef},ExtGState:{Appearance:{Type:'ExtGState',ca:settings.opacity,CA:settings.opacity}}}});const record=doc.newString(JSON.stringify(metadata));try{form.put(KEY,record)}finally{record.destroy()}
  replaceInvocation(doc,page,current,resources=>'q '+local.map(n=>Number(n.toFixed(9))).join(' ')+' cm /'+uniqueResource(doc,resources,form,'EditedImage')+' Do Q');progress(1,'Image updated');
 }finally{form?.destroy();if(pixelRef&&pixelRef!==source)pixelRef.destroy();source?.destroy();page.destroy()}
}
