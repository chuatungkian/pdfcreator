/* Verify actual release aliases, source export, runtime assets and all declared checksums. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {readTestZip} from './source-zip-test-utils.mjs';
import {rebuildSourceZip} from './source-package.js';
const out=path.resolve(process.env.PDFCREATOR_RELEASE_DIR||'../../outputs'),html=fs.readFileSync(path.join(out,'index.html')),text=html.toString('utf8'),assets=JSON.parse(gunzipSync(Buffer.from(text.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64'))),fontBase64=text.match(/data:font\/woff2;base64,([A-Za-z0-9+/=]+)/)[1];
let count=0;const equal=(a,b,label)=>{count++;assert.deepEqual(a,b,label)},check=(v,label)=>{count++;assert.ok(v,label)},sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
for(const name of ['pdfcreator.html','pdfpro.html'])equal(fs.readFileSync(path.join(out,name)),html,'same current HTML '+name);
check(html.length<25000000,'single-file size cap');check(assets.app.includes('In-browser docx and doc converter'),'requested converter label retained');check(assets.app.includes('activeToolGuide')&&assets.app.includes('selectionActions')&&assets.app.includes('data-pin-function'),'new controls are in actual bundled app');
check(assets.app.includes('data-object-add')&&assets.app.includes('data-inspector-back'),'object group selection and Back are in the shipped app');check(assets.app.includes('pane-resize-handle'),'right-hand pane resizing is in the shipped app');
const separate=readTestZip(fs.readFileSync(path.join(out,'pdfcreator-3.0-app-source.zip'))),embedded=readTestZip(Buffer.from(await(await rebuildSourceZip(assets,{fontBase64})).arrayBuffer()));equal(separate.size,embedded.size,'same embedded/separate source file count');
for(const [name,entry]of separate){equal(embedded.get(name)?.bytes,entry.bytes,'matching source '+name);if(!name.includes('/dependencies/'))equal(entry.bytes,fs.readFileSync(name.replace(/^source\//,'')),'preferred source matches download '+name)}
for(const [file,content]of [['vendor/form-data-worker.js',Buffer.from(assets.formDataWorker)],['vendor/engine-worker.js',Buffer.from(assets.engineWorker)],['vendor/word-worker.js',Buffer.from(assets.word.workerSource)],['vendor/mupdf/dist/mupdf-wasm.wasm',Buffer.from(assets.mupdfBase64,'base64')],['eng-fast.traineddata',Buffer.from(assets.ocr.languageDataBase64,'base64')]])equal(fs.readFileSync(file),content,'runtime vendor identity '+file);
for(const line of fs.readFileSync(path.join(out,'SHA256SUMS.txt'),'utf8').trim().split(/\r?\n/)){const match=line.match(/^([a-f0-9]{64})  (.+)$/);check(match,'valid checksum line');equal(sha(fs.readFileSync(path.join(out,match[2]))),match[1],'verified checksum '+match[2])}
check(fs.existsSync(path.join(out,'PDFCreator-Ream-Source.zip')),'Word dependency sources accompany runtime');const word=readTestZip(fs.readFileSync(path.join(out,'PDFCreator-Ream-Source.zip')));check(word.has('source/word-dependencies/node_modules/reamkit/package.json'),'Word source archive retains converter package');
console.log('PDFCreator release alignment: '+count+' assertions passed for aliases, all source bytes, engines, Word sources and checksums.');
