/* PDFCreator offline OCR and page comparison.
 * Tesseract worker/core and language bytes are supplied by the single-file build.
 * No resource URLs, storage caches, or network requests are used by this module.
 */

let defaultOCR = null;

function abortError() {
  return new DOMException('Operation cancelled.', 'AbortError');
}

function checkAbort(signal) {
  if (signal?.aborted) throw abortError();
}

function bytesFrom(value) {
  if (!value) return new Uint8Array();
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (typeof value !== 'string') throw new TypeError('Embedded OCR data must be base64 or bytes.');
  const binary = atob(value.replace(/^data:[^,]+,/, ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function workerBootstrap(assets) {
  // Supplying wasmBinary prevents Emscripten from resolving a separate .wasm URL.
  // Defining TesseractCore before the worker prevents its getCore adapter from
  // importing a default CDN resource. Direct traineddata bytes bypass langPath.
  const wasm = assets.coreWasmBase64 || assets.coreWasm || '';
  const wasmBase64 = typeof wasm === 'string' ? wasm : (() => {
    let s = '';
    const bytes = bytesFrom(wasm);
    for (let i = 0; i < bytes.length; i += 32768) s += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(s);
  })();
  return `
"use strict";
self.addEventListener('unhandledrejection',function(e){
  self.postMessage({pdfproFatal:String(e.reason && (e.reason.message || e.reason) || 'OCR worker failed')});
  e.preventDefault();
});
${assets.coreSource}
;(() => {
  const factory = self.TesseractCore || (typeof TesseractCore !== 'undefined' && TesseractCore);
  if (typeof factory !== 'function') throw new Error('Embedded Tesseract core is invalid.');
  const encoded = ${JSON.stringify(wasmBase64)};
  let binary;
  if (encoded) {
    const raw = atob(encoded); binary = new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++) binary[i]=raw.charCodeAt(i);
  }
  self.TesseractCore = options => factory(Object.assign({}, options, binary ? {wasmBinary:binary} : {}));
  self.fetch = () => Promise.reject(new Error('PDFCreator OCR blocks network requests.'));
  self.importScripts = () => { throw new Error('PDFCreator OCR blocks external scripts.'); };
  self.XMLHttpRequest = class { constructor(){ throw new Error('PDFCreator OCR blocks network requests.'); } };
})();
${assets.workerSource}
`;
}

async function imageBytes(image, signal) {
  checkAbort(signal);
  if (image instanceof Blob) {
    const bytes = new Uint8Array(await image.arrayBuffer());
    checkAbort(signal);
    return { bytes, width: 0, height: 0 };
  }
  if (image instanceof Uint8Array || image instanceof ArrayBuffer) {
    return { bytes: bytesFrom(image), width: 0, height: 0 };
  }
  let canvas = image;
  if (typeof ImageData !== 'undefined' && image instanceof ImageData) {
    canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    canvas.getContext('2d').putImageData(image, 0, 0);
  }
  if (!canvas?.width || !canvas?.height) throw new TypeError('OCR needs an image, canvas, or image bytes.');
  let blob;
  if (typeof canvas.convertToBlob === 'function') blob = await canvas.convertToBlob({ type: 'image/png' });
  else if (typeof canvas.toBlob === 'function') blob = await new Promise((resolve, reject) => {
    canvas.toBlob(result => result ? resolve(result) : reject(new Error('Could not encode the OCR image.')), 'image/png');
  });
  else throw new TypeError('OCR needs a canvas, Blob, or ImageData.');
  checkAbort(signal);
  return { bytes: new Uint8Array(await blob.arrayBuffer()), width: canvas.width, height: canvas.height };
}

function bbox(left, top, width, height, pageWidth, pageHeight) {
  return {
    x0: left, y0: top, x1: left + width, y1: top + height,
    x: left, y: top, width, height,
    normalized: pageWidth && pageHeight ? {
      x: left / pageWidth, y: top / pageHeight,
      width: width / pageWidth, height: height / pageHeight,
    } : null,
  };
}

/** Parse Tesseract TSV without inserting OCR text into HTML. Coordinates are pixels. */
export function parseOCRTSV(tsv, imageWidth = 0, imageHeight = 0) {
  // Some Tesseract builds return a header, while GetTSVText in others starts
  // directly with the level-1 page record. Numeric validation handles both.
  const records = String(tsv || '').split(/\r?\n/).filter(Boolean).map(line => {
    const cols = line.split('\t');
    if (cols.length < 11) return null;
    const n = cols.slice(0, 11).map(Number);
    if (!n.every(Number.isFinite)) return null;
    return { level: n[0], page: n[1], block: n[2], paragraph: n[3], line: n[4], word: n[5], left: n[6], top: n[7], width: n[8], height: n[9], confidence: n[10], text: cols.slice(11).join('\t') };
  }).filter(Boolean);
  const pageRecord = records.find(row => row.level === 1);
  const width = imageWidth || pageRecord?.width || 0;
  const height = imageHeight || pageRecord?.height || 0;
  const words = records.filter(row => row.level === 5 && row.text.trim()).map(row => ({
    text: row.text, confidence: row.confidence,
    page: row.page, block: row.block, paragraph: row.paragraph, line: row.line,
    bbox: bbox(row.left, row.top, row.width, row.height, width, height),
  }));
  const groups = new Map();
  for (const word of words) {
    const key = [word.page, word.block, word.paragraph, word.line].join(':');
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(word);
  }
  const lines = [...groups.values()].map(lineWords => {
    const left = Math.min(...lineWords.map(w => w.bbox.x0));
    const top = Math.min(...lineWords.map(w => w.bbox.y0));
    const right = Math.max(...lineWords.map(w => w.bbox.x1));
    const bottom = Math.max(...lineWords.map(w => w.bbox.y1));
    return {
      text: lineWords.map(w => w.text).join(' '),
      confidence: lineWords.reduce((sum, w) => sum + w.confidence, 0) / lineWords.length,
      bbox: bbox(left, top, right - left, bottom - top, width, height),
      words: lineWords,
    };
  });
  return { width, height, words, lines };
}

/**
 * Create a private, reusable OCR worker. Required assets:
 * workerSource: tesseract.js/dist/worker.min.js text;
 * coreSource: tesseract.js-core/tesseract-core-lstm.wasm.js text;
 * coreWasmBase64: matching .wasm bytes (optional only for self-contained core glue);
 * languageDataBase64: eng.traineddata(.gz) bytes; language defaults to eng.
 */
export function createOfflineOCR(assets) {
  if (!assets?.workerSource || !assets?.coreSource || !assets?.languageDataBase64 && !assets?.languageData) {
    throw new Error('The offline OCR engine is not embedded in this build.');
  }
  let worker = null;
  let workerURL = null;
  let ready = null;
  let nextId = 0;
  let jobProgress = null;
  let busy = false;
  const pending = new Map();
  const language = assets.language || 'eng';

  function dispose(reason = abortError()) {
    worker?.terminate();
    worker = null;
    ready = null;
    if (workerURL) URL.revokeObjectURL(workerURL);
    workerURL = null;
    for (const { reject } of pending.values()) reject(reason);
    pending.clear();
  }

  function rpc(action, payload) {
    return new Promise((resolve, reject) => {
      if (!worker) return reject(new Error('OCR worker is unavailable.'));
      const jobId = `pdfpro-${++nextId}`;
      pending.set(jobId, { resolve, reject });
      try { worker.postMessage({ workerId: 'pdfpro-ocr', jobId, action, payload }); }
      catch (error) { pending.delete(jobId); reject(error); }
    });
  }

  function report(data) {
    try { jobProgress?.({ status: String(data.status || 'Recognising text').replace(/recognizing/gi,'recognising').replace(/initializing/gi,'initialising'), progress: Math.max(0, Math.min(1, Number(data.progress) || 0)) }); }
    catch { /* A progress listener must not interrupt worker communication. */ }
  }

  async function initialize() {
    workerURL = URL.createObjectURL(new Blob([workerBootstrap(assets)], { type: 'text/javascript' }));
    worker = new Worker(workerURL, { name: 'pdfpro-offline-ocr' });
    worker.onmessage = ({ data }) => {
      if (data.pdfproFatal) { dispose(new Error(data.pdfproFatal)); return; }
      if (data.status === 'progress') { report(data.data || {}); return; }
      const task = pending.get(data.jobId);
      if (!task) return;
      if (data.status === 'resolve') { pending.delete(data.jobId); task.resolve(data.data); }
      else if (data.status === 'reject') { pending.delete(data.jobId); task.reject(new Error(String(data.data))); }
    };
    worker.onerror = event => {
      event.preventDefault();
      dispose(new Error(event.message || 'The offline OCR worker could not start.'));
    };
    worker.onmessageerror = () => dispose(new Error('The OCR worker returned unreadable data.'));
    await rpc('load', { options: { lstmOnly: true, logging: false } });
    await rpc('loadLanguage', {
      langs: [{ code: language, data: bytesFrom(assets.languageDataBase64 || assets.languageData) }],
      options: { cacheMethod: 'none', lstmOnly: true },
    });
    await rpc('initialize', { langs: language, oem: 1, config: {} });
    return true;
  }

  return {
    language,
    async recognize(image, { onProgress, signal, pageSegmentation = 3, rectangle, dpi = 200, lowConfidence = 75 } = {}) {
      if (busy) throw new Error('OCR is already running. Wait for it to finish or cancel it.');
      checkAbort(signal);
      busy = true;
      jobProgress = onProgress;
      const onAbort = () => dispose(abortError());
      signal?.addEventListener('abort', onAbort, { once: true });
      try {
        const input = await imageBytes(image, signal);
        checkAbort(signal);
        if (!ready) ready = initialize();
        await ready;
        checkAbort(signal);
        const result = await rpc('recognize', {
          image: input.bytes,
          options: {
            tessedit_pageseg_mode: String(pageSegmentation),
            user_defined_dpi: String(dpi),
            preserve_interword_spaces: '1',
            ...(rectangle ? { rectangle } : {}),
          },
          output: { text: true, tsv: true, blocks: false, hocr: false },
        });
        checkAbort(signal);
        const parsed = parseOCRTSV(result.tsv, input.width, input.height);
        report({ status: 'OCR complete', progress: 1 });
        return {
          ...parsed,
          text: result.text || '', confidence: Number(result.confidence) || 0,
          uncertainWords: parsed.words.filter(word => word.confidence < lowConfidence),
          language, engineVersion: result.version || '',
        };
      } catch (error) {
        // A failed initialization must be retryable and must release its worker.
        if (!worker || error.name !== 'AbortError') dispose(error);
        throw error;
      } finally {
        signal?.removeEventListener('abort', onAbort);
        jobProgress = null;
        busy = false;
      }
    },
    cancel() { dispose(abortError()); },
    terminate() { dispose(new Error('OCR engine closed.')); },
  };
}

export function configureOCR(assets) {
  defaultOCR?.terminate();
  defaultOCR = createOfflineOCR(assets);
  return defaultOCR;
}

export function recognizeImage(image, options) {
  if (!defaultOCR) throw new Error('Offline OCR is unavailable in this build.');
  return defaultOCR.recognize(image, options);
}

export function cancelOCR() { defaultOCR?.cancel(); }

function canvasOf(image, width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(image, 0, 0);
  return canvas;
}

/**
 * Compare equally scaled page canvases, aligned at their top-left corners.
 * Outputs a red heatmap over a faded baseline plus counts and changed bounds.
 * Pixel differences indicate visual changes; they do not establish semantic equality.
 */
export async function compareCanvases(before, after, { threshold = 24, onProgress, signal, maxPixels = 18000000 } = {}) {
  checkAbort(signal);
  const width = Math.max(before.width, after.width);
  const height = Math.max(before.height, after.height);
  if (!width || !height) throw new Error('Both pages must be rendered before comparison.');
  if (width * height > maxPixels) throw new Error('Comparison images are too large. Render both pages at a lower resolution.');
  const beforeCanvas = canvasOf(before, width, height);
  const afterCanvas = canvasOf(after, width, height);
  const a = beforeCanvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, width, height);
  const b = afterCanvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, width, height);
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  const output = ctx.createImageData(width, height);
  let changedPixels = 0;
  let minX = width, minY = height, maxX = -1, maxY = -1;
  const cutoff = Math.max(0, Math.min(255, threshold));
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const delta = Math.max(Math.abs(a.data[i] - b.data[i]), Math.abs(a.data[i + 1] - b.data[i + 1]), Math.abs(a.data[i + 2] - b.data[i + 2]));
      if (delta > cutoff) {
        changedPixels++;
        minX = Math.min(minX, x); minY = Math.min(minY, y);
        maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
        output.data[i] = 235; output.data[i + 1] = 52; output.data[i + 2] = 83;
      } else {
        const grey = Math.round(0.299 * a.data[i] + 0.587 * a.data[i + 1] + 0.114 * a.data[i + 2]);
        output.data[i] = output.data[i + 1] = output.data[i + 2] = Math.round(180 + grey * 75 / 255);
      }
      output.data[i + 3] = 255;
    }
    if (y % 128 === 0) {
      onProgress?.({ status: 'Comparing pages', progress: y / height });
      await new Promise(resolve => setTimeout(resolve, 0));
      checkAbort(signal);
    }
  }
  ctx.putImageData(output, 0, 0);
  onProgress?.({ status: 'Comparison complete', progress: 1 });
  return {
    canvas, width, height, changedPixels,
    totalPixels: width * height, changedPercent: changedPixels / (width * height) * 100,
    changedBounds: changedPixels ? { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 } : null,
    sameDimensions: before.width === after.width && before.height === after.height,
    threshold: cutoff,
  };
}

/** Bounded line comparison for extracted text. Large inputs fall back to a summary. */
export function compareText(beforeText, afterText, { maxCells = 1000000 } = {}) {
  const before = String(beforeText || '').replace(/\r\n?/g, '\n').split('\n');
  const after = String(afterText || '').replace(/\r\n?/g, '\n').split('\n');
  if ((before.length + 1) * (after.length + 1) > maxCells) {
    return { truncated: true, equal: beforeText === afterText, beforeLines: before.length, afterLines: after.length, changes: [] };
  }
  const rows = Array.from({ length: before.length + 1 }, () => new Uint32Array(after.length + 1));
  for (let i = before.length - 1; i >= 0; i--) {
    for (let j = after.length - 1; j >= 0; j--) rows[i][j] = before[i] === after[j] ? rows[i + 1][j + 1] + 1 : Math.max(rows[i + 1][j], rows[i][j + 1]);
  }
  const changes = [];
  let i = 0, j = 0;
  while (i < before.length || j < after.length) {
    if (i < before.length && j < after.length && before[i] === after[j]) { changes.push({ type: 'equal', text: before[i], beforeLine: ++i, afterLine: ++j }); }
    else if (j < after.length && (i === before.length || rows[i][j + 1] >= rows[i + 1][j])) changes.push({ type: 'insert', text: after[j], afterLine: ++j });
    else changes.push({ type: 'delete', text: before[i], beforeLine: ++i });
  }
  return { truncated: false, equal: changes.every(change => change.type === 'equal'), beforeLines: before.length, afterLines: after.length, changes };
}
