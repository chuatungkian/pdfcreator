/* Predictable first-Escape behaviour for editor popovers. Existing modal traps retain ownership. */
export class WorkspaceAccessibility{
 constructor(document){this.document=document;this.key=event=>{if(event.key!=='Escape'||event.isComposing||event.defaultPrevented||document.querySelector('#modalroot .modal'))return;for(const panel of document.querySelectorAll('.context-more-panel:not([hidden]),.toolbar-options-panel:not([hidden])')){const root=panel.closest('.top-properties-editor,.page-text-toolbar'),toggle=document.querySelector('[aria-controls="'+panel.id+'"]');if(root?.contains(event.target)||toggle?.contains(event.target)){event.preventDefault();event.stopImmediatePropagation();if(toggle?.getAttribute('aria-expanded')==='true')toggle.click();else panel.hidden=true;toggle?.focus({preventScroll:true});return}}};document.addEventListener('keydown',this.key,true)}
 destroy(){this.document.removeEventListener('keydown',this.key,true)}
}
