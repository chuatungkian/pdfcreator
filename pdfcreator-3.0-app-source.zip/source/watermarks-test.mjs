/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';

import {addWatermark,scanWatermarks,removeWatermarks,watermarkGeometry} from './watermarks.js';
import {renderSystemText,measureSystemText} from './system-fonts.js';
import {drawSystemText} from './pdf-font-text.js';
let context;
try{
 context=await boot();const {app,$,window}=context,{mupdf:m}=app.Engine,PDF=app.PDFLib;
 for(const rotation of [0,90,180,270])for(const angle of [0,28,-35]){
   const doc=await PDF.PDFDocument.create(),page=doc.addPage([620,860]);page.setCropBox(14,22,570,790);page.setRotation(PDF.degrees(rotation));const base=await doc.save({useObjectStreams:false}),native=app.Engine.openPDF(base),g=watermarkGeometry(native,0);native.destroy();
   const result=await addWatermark(doc,0,{text:'CENTRED WATERMARK',font:'Georgia',size:60,color:'#800020',opacity:.15,angle},g),bytes=await doc.save({useObjectStreams:false});
   check(Math.abs((result.rect[0]+result.rect[2])/2-(g.bounds[0]+g.bounds[2])/2)<.001,'geometric horizontal centre '+rotation+'/'+angle);check(Math.abs((result.rect[1]+result.rect[3])/2-(g.bounds[1]+g.bounds[3])/2)<.001,'geometric vertical centre '+rotation+'/'+angle);
   const d=app.Engine.openPDF(bytes),p=d.loadPage(0),pix=p.toPixmap(m.Matrix.identity,m.ColorSpace.DeviceRGB,true,true),pixels=pix.getPixels(),w=pix.getWidth(),h=pix.getHeight(),n=pix.getNumberOfComponents();let x0=w,y0=h,x1=0,y1=0,maxAlpha=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=pixels[(y*w+x)*n+n-1];if(a>3){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);maxAlpha=Math.max(maxAlpha,a)}}
   check(Math.abs((x0+x1+1)/2-w/2)<2,'painted pixels horizontally centred '+rotation+'/'+angle);check(Math.abs((y0+y1+1)/2-h/2)<2,'painted pixels vertically centred '+rotation+'/'+angle);check(maxAlpha>10&&maxAlpha<50,'matrix watermark opacity is applied');const rows=scanWatermarks(d);equal(rows.length,1,'tracked watermark identified once');equal(rows[0].text,'CENTRED WATERMARK','tracked text retained');
   removeWatermarks(d,rows);const cleaned=saveDirectEdit(d);check(!app.Engine.extractTextPDF(cleaned)[0].text.includes('CENTRED WATERMARK'),'removal deletes appearance/search invocation');pix.destroy();p.destroy();d.destroy();if(rotation===0&&angle===28)fs.writeFileSync('watermark-centre-proof.png',app.Engine.renderPagePNG(bytes,0,{scale:1}).bytes);
 }
 const tagged=await PDF.PDFDocument.create(),tp=tagged.addPage([595,842]);tp.drawText('UNTAGGED BODY',{x:60,y:700,size:14});tp.pushOperators(PDF.PDFOperator.of('BDC',[PDF.PDFName.of('Artifact'),tagged.context.obj({Type:'Pagination',Subtype:'Watermark'})]));tp.drawText('TAGGED IMPORT',{x:80,y:400,size:35});tp.pushOperators(PDF.PDFOperator.of('EMC'));let td=app.Engine.openPDF(await tagged.save({useObjectStreams:false}));const taggedRows=scanWatermarks(td);check(taggedRows.some(r=>r.text==='TAGGED IMPORT'&&r.confirmed),'standard tagged native watermarks are identified');removeWatermarks(td,taggedRows);check(app.Engine.extractTextPDF(saveDirectEdit(td))[0].text.includes('UNTAGGED BODY'),'tagged watermark removal preserves untagged body content');td.destroy();
 // Legacy app watermarks have a translucent, diagonal image/search Form without tracking metadata.
 const legacy=await PDF.PDFDocument.create(),lp=legacy.addPage([595,842]);lp.drawText('BODY CONTENT MUST REMAIN',{x:60,y:620,size:14});const appearance=await renderSystemText('LEGACY WATERMARK',{font:'Arial',size:48,width:520,height:110,color:'#800020'});await drawSystemText(legacy,lp,appearance,{x:35,y:380,rotation:28,opacity:.15,track:false});const legacyBytes=await legacy.save({useObjectStreams:false});let d=app.Engine.openPDF(legacyBytes),rows=scanWatermarks(d);check(rows.some(r=>r.text==='LEGACY WATERMARK'),'legacy PDFCreator watermark is identified');removeWatermarks(d,rows);let cleaned=saveDirectEdit(d);d.destroy();check(app.Engine.extractTextPDF(cleaned)[0].text.includes('BODY CONTENT MUST REMAIN'),'legacy removal retains body text');check(!app.Engine.extractTextPDF(cleaned)[0].text.includes('LEGACY WATERMARK'),'legacy removal removes watermark search content');
 // Untagged native text can overlap body text; remove only its text-show operators.
 const imported=await PDF.PDFDocument.create(),ip=imported.addPage([595,842]);ip.drawText('BODY BELOW WATERMARK',{x:70,y:400,size:18});const reference=await PDF.PDFDocument.create();reference.addPage([595,842]).drawText('BODY BELOW WATERMARK',{x:70,y:400,size:18});const cleanReference=await reference.save({useObjectStreams:false});ip.drawText('IMPORTED DRAFT',{x:40,y:340,size:52,rotate:PDF.degrees(28),opacity:.2,color:PDF.rgb(.5,0,.125)});const importedBytes=await imported.save({useObjectStreams:false});d=app.Engine.openPDF(importedBytes);rows=scanWatermarks(d);check(rows.some(r=>r.kind==='text'&&r.text.includes('IMPORTED DRAFT')),'transparent diagonal native text is offered as a candidate');equal(rows.find(r=>r.text.includes('IMPORTED DRAFT')).settings.color,'#800020','imported watermark inherits its original colour');check(!rows.some(r=>r.text.includes('BODY BELOW')),'ordinary body text is not classified as a watermark');removeWatermarks(d,rows);cleaned=saveDirectEdit(d);d.destroy();check(app.Engine.extractTextPDF(cleaned)[0].text.includes('BODY BELOW WATERMARK'),'overlapping body text survives native watermark removal');check(!app.Engine.extractTextPDF(cleaned)[0].text.includes('IMPORTED DRAFT'),'native watermark text is removed');equal(app.Engine.renderPagePNG(cleaned,0,{scale:1}).bytes,app.Engine.renderPagePNG(cleanReference,0,{scale:1}).bytes,'body page pixels are unchanged after native watermark removal');
 await app.openFiles([file('Old watermark.pdf',legacyBytes)]);const before=app.state.bytes;let pending=app.activate('watermarks');await until(()=>$('wmRows'),'watermark manager opens');check($('wmRows').textContent.includes('LEGACY WATERMARK'),'manager lists earlier app watermarks');$('wmRows').querySelector('[data-preview-wm]').click();$('wmText').value='UPDATED WATERMARK';$('wmAngle').value='15';$('wmOpacity').value='.25';await $('modalform').onsubmit({preventDefault(){}});await pending;check(text(app).includes('UPDATED WATERMARK')&&!text(app).includes('LEGACY WATERMARK'),'manager replaces selected watermark');check(text(app).includes('BODY CONTENT MUST REMAIN'),'manager edit preserves body content');equal(app.state.undo.length,1,'watermark replacement is a single undo step');await $('undo').onclick();check(text(app).includes('LEGACY WATERMARK'),'undo restores original watermark');await $('redo').onclick();check(text(app).includes('UPDATED WATERMARK'),'redo restores edited watermark');
 pending=app.activate('watermarks');await until(()=>$('wmRows'),'manager removal');$('wmRows').querySelector('[data-preview-wm]').click();$('wmRemove').click();$('wmRemove').click();await pending;check(!text(app).includes('UPDATED WATERMARK'),'manager removes selected watermark');check(text(app).includes('BODY CONTENT MUST REMAIN'),'removal retains unrelated page content');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator watermarks: '+assertions+' assertions passed with native PDF geometry, pixels and controlled UI.');
}finally{if(context)await context.close()}
