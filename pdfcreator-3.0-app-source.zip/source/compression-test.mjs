/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {compressPDF} from './pdf-compression.js';
import {parseTargetSize} from './save-pdf.js';
import {inspectLinks} from './pdf-links.js';
let context;
try{
 context=await boot();const {app,$,window}=context,PDF=app.PDFLib,m=app.Engine.mupdf;
 const pic=canvas.createCanvas(1400,1000),ctx=pic.getContext('2d'),pixels=ctx.createImageData(1400,1000);let seed=129;
 for(let y=0;y<1000;y++)for(let x=0;x<1400;x++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const i=(y*1400+x)*4;pixels.data[i]=(x/6+(seed&31))%256;pixels.data[i+1]=(y/5+((seed>>>5)&31))%256;pixels.data[i+2]=(x/10+y/8+((seed>>>10)&31))%256;pixels.data[i+3]=255}ctx.putImageData(pixels,0,0);
 const doc=await PDF.PDFDocument.create(),image=await doc.embedPng(pic.toBuffer('image/png'));
 for(let n=0;n<2;n++){const page=doc.addPage([595,842]);page.drawText('Searchable body remains '+n,{x:40,y:790,size:16});page.drawImage(image,{x:40,y:100,width:504,height:360});if(n===1){page.setRotation(PDF.degrees(90));page.setCropBox(10,20,570,790)}}
 const f=doc.getForm().createTextField('RetainedField');f.setText('Value retained');f.addToPage(doc.getPage(0),{x:40,y:600,width:150,height:24});
 const link=doc.context.obj({Type:'Annot',Subtype:'Link',Rect:[40,760,300,785],A:{S:'URI',URI:PDF.PDFString.of('https://example.com')}});doc.getPage(0).node.addAnnot(doc.context.register(link));doc.setTitle('Compression fixture');await doc.attach(new Uint8Array([1,2,3]),'retained.txt');
 const base=new Uint8Array(await doc.save({useObjectStreams:false})),progress=[];const balanced=await compressPDF(base,{mode:'balanced'},(p,msg)=>progress.push([p,msg]));
 check(balanced.after<base.length*.5,'image recompression substantially reduces large RGB image');equal(balanced.imagesRecompressed,1,'shared image is recompressed once');equal(balanced.dpi,150,'balanced resolution');equal(balanced.quality,78,'balanced JPEG quality');check(progress.some(([p])=>p>0&&p<1)&&progress.at(-1)[0]===1,'progress includes intermediate updates and completion');
 let native=app.Engine.openPDF(balanced.bytes);equal(native.countPages(),2,'page count retained');check(app.Engine.extractTextPDF(balanced.bytes).every(p=>p.text.includes('Searchable body remains')),'searchable text retained');equal(inspectLinks(native,0)[0].href,'https://example.com/','native links retained');const p1=native.loadPage(1);equal(p1.getBounds(),[0,0,790,570],'rotated/cropped page geometry retained');p1.destroy();native.destroy();
 let out=await PDF.PDFDocument.load(balanced.bytes);equal(out.getForm().getTextField('RetainedField').getText(),'Value retained','form field/value retained');equal(out.getTitle(),'Compression fixture','metadata retained');check(out.catalog.lookup(PDF.PDFName.of('Names')).has(PDF.PDFName.of('EmbeddedFiles')),'attachments retained');
 fs.writeFileSync('compression-proof.png',app.Engine.renderPagePNG(balanced.bytes,0,{scale:1}).bytes);
 const small=await compressPDF(base,{mode:'small'});check(small.after<balanced.after,'smaller preset reduces size further');
 const high=await compressPDF(base,{mode:'high'});check(high.after>balanced.after&&high.after<base.length,'high quality trades size for detail');
 const targetBytes=Math.floor((balanced.after+small.after)/2),target=await compressPDF(base,{mode:'target',targetBytes});check(target.targetMet&&target.after<=targetBytes,'target search reaches attainable maximum');check(target.passes>2,'target adapts image settings over multiple passes');check(target.dpi>=72&&target.quality>=45,'quality floor honoured');
 const impossible=await compressPDF(base,{mode:'target',targetBytes:1000});equal(impossible.targetMet,false,'unattainable target reported honestly');check(impossible.after<=small.after,'best available result retained');
 const fixedDpi=await compressPDF(base,{mode:'target',targetBytes:1000,minDpi:300,minQuality:40});equal(fixedDpi.dpi,300,'target keeps a higher resolution floor');equal(fixedDpi.quality,40,'target still tries lower quality at a fixed resolution');
 const already=await compressPDF(base,{mode:'target',targetBytes:base.length});equal(already.bytes,base,'already-under-target preserves exact bytes');equal(already.passes,0,'already-under-target avoids quality changes');
 const lossless=await compressPDF(base,{mode:'lossless'});check(lossless.after<=base.length,'lossless never grows exported file');equal(app.Engine.renderPagePNG(lossless.bytes,0,{scale:.5}).bytes,app.Engine.renderPagePNG(base,0,{scale:.5}).bytes,'lossless pixels match original');
 await assert.rejects(()=>compressPDF(base,{mode:'target',targetBytes:0}),/target/);assertions++;await assert.rejects(()=>compressPDF(base,{mode:'target',targetBytes:1000,minQuality:20}),/quality/);assertions++;const aborted=new AbortController();aborted.abort();await assert.rejects(()=>compressPDF(base,{},()=>{},aborted.signal),{name:'AbortError'});assertions++;
 equal(parseTargetSize('2.5','MB'),2500000,'decimal MB conversion');equal(parseTargetSize('500','kB'),500000,'decimal kB conversion');assert.throws(()=>parseTargetSize('0.0001','MB'),/target/);assertions++;
 // Fully transparent masks, app text boxes and small images are never JPEG-rewritten.
 const protectedDoc=await PDF.PDFDocument.create(),transparent=canvas.createCanvas(200,200),tc=transparent.getContext('2d');tc.fillStyle='#800020';tc.fillRect(50,50,100,100);const ti=await protectedDoc.embedPng(transparent.toBuffer('image/png'));protectedDoc.addPage([595,842]).drawImage(ti,{x:100,y:100,width:300,height:300});const protectedBytes=new Uint8Array(await protectedDoc.save({useObjectStreams:false})),protectedResult=await compressPDF(protectedBytes,{mode:'small'});equal(protectedResult.imagesRecompressed,0,'transparency and its soft mask skipped');equal(app.Engine.renderPagePNG(protectedResult.bytes,0,{scale:.5}).bytes,app.Engine.renderPagePNG(protectedBytes,0,{scale:.5}).bytes,'transparent pixels unchanged');
 await app.local.flush();await context.close();context=null;console.log('PDFCreator compression engine: '+assertions+' assertions passed with native images, PDFs and size targets.');
}finally{if(context)await context.close()}
