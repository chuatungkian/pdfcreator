// Only narrow workspaces use the phone layout. Touch does not switch a wide tablet to it.
export const PHONE_LAYOUT = '(max-width: 640px), (max-width: 960px) and (max-height: 540px) and (pointer: coarse)';
const EDITOR = '.on-page-text-surface,.form-field-editor';
const TEXT_INPUT = 'textarea,input:not([type]),input[type=text],input[type=number],input[type=password],input[type=search],[contenteditable=true]';

export class PhoneWorkspace {
 constructor({window, onLayout}){
  this.window=window;
  this.document=window.document;
  this.media=window.matchMedia(PHONE_LAYOUT);
  this.viewport=window.visualViewport;
  this.onLayout=onLayout;
  this.layout=()=>{
   const phone=this.media.matches;
   if(phone!==this.phone){
    this.phone=phone;
    this.document.body.classList.toggle('phone-workspace',phone);
    this.onLayout();
   }
   this.schedule();
  };
  this.schedule=()=>{
   if(this.frame!=null)return;
   this.frame=window.requestAnimationFrame(()=>{
    this.frame=null;
    this.measure();
   });
  };
  this.media.addEventListener?.('change',this.layout);
  window.addEventListener('resize',this.layout);
  for(const event of ['resize','scroll'])this.viewport?.addEventListener(event,this.schedule);
  for(const event of ['focusin','focusout'])this.document.addEventListener(event,this.schedule);
 }
 get editing(){
  return this.phone&&!!this.document.querySelector(EDITOR);
 }
 measure(){
  const {body,activeElement}=this.document;
  const viewport=this.viewport;
  const input=activeElement?.matches(TEXT_INPUT)?activeElement:null;
  const scale=viewport?.scale??1;
  const height=viewport?.height??this.window.innerHeight;
  if((!input&&!this.keyboard)||!this.phone||this.lastWidth!==this.window.innerWidth){
   this.unfocusedHeight=this.window.innerHeight;
   this.lastWidth=this.window.innerWidth;
  }
  const inset=Math.max(0,this.window.innerHeight-height);
  const keyboard=!!(this.phone&&(input||this.keyboard)&&scale<1.1&&Math.max(inset,(this.unfocusedHeight||height)-height)>100);
  this.keyboard=keyboard;
  body.classList.toggle('phone-keyboard',keyboard);
  const editor=keyboard?input?.closest(EDITOR)||this.document.querySelector(EDITOR):null;
  body.classList.toggle('phone-editor-keyboard',!!editor);
  if(keyboard){
   body.style.setProperty('--phone-viewport-top',Math.round(viewport?.offsetTop||0)+'px');
   body.style.setProperty('--phone-visible-height',Math.round(height)+'px');
   body.style.setProperty('--phone-keyboard-inset',Math.round(Math.max(0,inset-(viewport?.offsetTop||0)))+'px');
  }else{
   body.style.removeProperty('--phone-viewport-top');
   body.style.removeProperty('--phone-visible-height');
   body.style.removeProperty('--phone-keyboard-inset');
  }
  if(editor?.matches('.on-page-text-surface')){
   const main=this.document.getElementById('main');
   const area=main.getBoundingClientRect();
   const edit=editor.getBoundingClientRect();
   const toolbar=this.document.querySelector('.page-text-bar-host:not([hidden])')?.getBoundingClientRect();
   const top=Math.max(area.top,toolbar?.bottom||0,viewport?.offsetTop||0)+12;
   const bottom=Math.min(area.bottom,(viewport?.offsetTop||0)+height)-12;
   if(bottom>top&&edit.top<top)main.scrollTop+=edit.top-top;
   else if(bottom>top&&edit.bottom>bottom)main.scrollTop+=Math.min(edit.bottom-bottom,edit.top-top);
  }
 }
 destroy(){
  this.media.removeEventListener?.('change',this.layout);
  this.window.removeEventListener('resize',this.layout);
  for(const event of ['resize','scroll'])this.viewport?.removeEventListener(event,this.schedule);
  for(const event of ['focusin','focusout'])this.document.removeEventListener(event,this.schedule);
  if(this.frame!=null)this.window.cancelAnimationFrame(this.frame);
 }
}
