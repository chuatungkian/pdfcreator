/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;
 const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<7;i++){const page=doc.addPage([595,842]);page.drawText('Original line '+(i+1),{x:50,y:700,size:22,font:await doc.embedFont(app.PDFLib.StandardFonts.TimesRomanBoldItalic),color:app.PDFLib.rgb(.5,0,.15)});page.drawText('Neighbour '+(i+1),{x:50,y:650,size:15})}
 await app.openFiles([file('Direct edit.pdf',await doc.save())]);app.state.fit=false;app.state.zoom=1;await app.render();
 let main=$('main'),viewer=$('viewer'),clamps=0;const pages=app.continuousPages;
 Object.defineProperty(main,'clientHeight',{configurable:true,get:()=>600});
 // Real browser layout clamps scroll when the stack temporarily collapses.
 // JSDOM has no layout, so reproduce that event explicitly during rebuilds.
 const replace=viewer.replaceChildren.bind(viewer);viewer.replaceChildren=(...nodes)=>{replace(...nodes);main.scrollTop=main.scrollLeft=0;clamps++;main.dispatchEvent(new window.Event('scroll'))};
 $('pageinput').value='5';await $('pageinput').onchange({target:$('pageinput')});main.scrollTop=pages.pageTop(4)+71;main.scrollLeft=13;
 const top=main.scrollTop,owner=app.activeTabId,original=directTextTargets(app.state.doc,4)[0];
 app.state.group='Edit';app.state.directMode='line';await app.activate('directedit');check(!!document.querySelector('[data-tool="directedit"]'),'Edit tools contain Direct edit');
 equal(document.querySelector('[data-tool="directedit"]').getAttribute('aria-pressed'),'true','Direct edit selected state');
 equal($('fontSetting').hidden,true,'source-style editing does not offer a replacement font');
 async function editor(label){const row=pages.records[4],button=[...row.overlay.querySelectorAll('.direct-text-target')].find(b=>b.getAttribute('aria-label').includes(label));check(!!button,'existing text has an edit target');await button.onclick(new window.MouseEvent('click',{bubbles:true}));return document.querySelector('.direct-editor,.rich-editor')}
 let form=await editor('Original line 5'),input=form.querySelector('input');equal(input.value,'Original line 5','inline editor shows existing text');equal(input.style.color,'rgb(128, 0, 38)','typing preview matches colour');equal(input.style.fontSize,'22px','typing preview matches size');check(form.textContent.includes('Times-BoldItalic'),'original font is labelled');
 input.value='Edited line 5';await form.onsubmit({preventDefault(){}});await pause(80);
 check(!document.querySelector('.direct-editor'),'successful edit closes editor');check(clamps>0,'rebuild exercised browser scroll clamping');equal(app.state.page,4,'Direct edit retains page 5');equal(main.scrollTop,top,'Direct edit retains precise vertical offset');equal(main.scrollLeft,13,'Direct edit retains horizontal offset');equal(app.state.tool,'directedit','Direct edit persists for repeated edits');
 const changed=directTextTargets(app.state.doc,4).find(t=>t.text==='Edited line 5');equal(changed.size,original.size,'saved font size retained');equal(changed.color,original.color,'saved colour retained');check(changed.bold&&changed.italic,'saved font style retained');check(text(app).includes('Edited line 5')&&!text(app).includes('Original line 5'),'real text replaced');
 form=await editor('Edited line 5');input=form.querySelector('input');const beforeFailure=app.state.bytes;input.value='Unsupported 😀';await form.onsubmit({preventDefault(){}});check(form.isConnected,'missing glyph keeps editor open');check(form.querySelector('[role="alert"]').textContent.includes('does not contain'),'font error appears inline');equal(input.value,'Unsupported 😀','invalid text remains available to revise');equal(app.state.bytes,beforeFailure,'missing glyph preserves working PDF');form.querySelector('[type="button"]').click();
 form=await editor('Edited line 5');form.querySelector('input').value='Cancelled';form.dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));check(!form.isConnected,'Escape cancels inline edit');equal(app.state.tool,'directedit','Escape inside editor leaves Direct edit selected');equal(app.state.bytes,beforeFailure,'cancel leaves PDF unchanged');
 await $('undo').onclick();await pause(70);equal(app.state.page,4,'undo retains page');equal(main.scrollTop,top,'undo retains viewport');check(text(app).includes('Original line 5'),'undo restores original text');await $('redo').onclick();check(text(app).includes('Edited line 5'),'redo restores edit');
 // A signature and different item types must use the same central view restoration.
 function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0});Object.defineProperties(event,{pointerId:{value:1},isPrimary:{value:true}});$('overlay').dispatchEvent(event)}
 async function place(){const previous=app.state.bytes;pointer('pointerdown',50,240);pointer('pointermove',300,300);pointer('pointerup',300,300);await until(()=>app.state.bytes!==previous&&!app.state.abort,'item placement');await pause(80);equal(app.state.page,4,'item retains selected page');equal(main.scrollTop,top,'item retains vertical offset');equal(main.scrollLeft,13,'item retains horizontal offset')}
 let task=app.activate('signature');await until(()=>$('sigtext'),'signature dialogue');$('sigtext').value='Alex Morgan';$('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await task;await place();equal(app.state.tool,'signatureImage','signature stays selected');
 await app.activate('rectangle');await place();check(app.state.doc.loadPage(4).getAnnotations().some(a=>a.getType()==='Square'),'annotation added to page 5');
 await app.activate('text');app.state.font='Georgia';app.state.size=17;app.state.color='#101d3a';
 let previous=app.state.bytes;pointer('pointerdown',50,340);pointer('pointermove',450,420);pointer('pointerup',450,420);await until(()=>document.querySelector('.rich-input'),'Add text editor');document.querySelector('.rich-input').textContent='Device font text';await document.querySelector('.rich-editor [data-apply]').onclick();await until(()=>app.state.bytes!==previous&&!app.state.abort,'added text');await pause(80);equal(main.scrollTop,top,'added text preserves viewport');
 check(addedTextTargets(app.state.doc,4).some(t=>t.text==='Device font text'),'new app text retains its font recipe');
 await app.activate('directedit');form=await editor('Device font text');form=document.querySelector('.rich-editor');equal(form.querySelector('.rich-input').textContent,'Device font text','image-backed app text is editable using its retained recipe');form.querySelector('.rich-input').textContent='Changed device text';await form.querySelector('[data-apply]').onclick();await pause(80);const added=addedTextTargets(app.state.doc,4).find(t=>t.text==='Changed device text');check(!!added,'app text replacement stored');equal(added.fontName,'Georgia','app text font retained');equal(added.size,17,'app text size retained');equal(added.color,'#101d3a','app text colour retained');check(text(app).includes('Changed device text')&&!text(app).includes('Device font text'),'old app search/appearance removed together');equal(main.scrollTop,top,'app text edit retains viewport');
 form=await editor('Changed device text');form=document.querySelector('.rich-editor');form.querySelector('.rich-input').textContent='Will cancel on tool change';await app.activate('note');check(form.isConnected,'changing tools preserves an unapplied draft');form.querySelector('[data-cancel]').click();await app.activate('note');check(!form.isConnected,'explicit Cancel dismisses inline editor');
 await app.local.flush();const saved=await app.local.store.getDocument(owner);equal(saved.snapshot.page,4,'saved page is current');equal(saved.snapshot.scrollTop,top,'saved viewport is restored value');check(app.Engine.extractTextPDF(saved.snapshot.bytes)[4].text.includes('Changed device text'),'local document contains Direct edits');
 main.scrollTop=pages.pageTop(5)+40;main.dispatchEvent(new window.Event('scroll'));await until(()=>app.state.page===5,'user scrolling resumes after restoration');equal(app.state.page,5,'restoration marker does not block real scrolling');
 await app.local.flush();await context.close();context=await boot();({app,$,window}=context);equal(app.activeTabId,owner,'document reopens after recovery');equal(app.state.page,5,'reading page recovers');check(text(app).includes('Changed device text')&&text(app).includes('Edited line 5'),'Direct edits recover after reload');
 await context.close();context=null;console.log('pdfpro Direct edit and viewport: '+assertions+' assertions passed with native PDF edits, simulated browser scroll clamping and IndexedDB recovery.');
}finally{if(context)await context.close()}
