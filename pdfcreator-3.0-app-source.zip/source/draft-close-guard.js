/* Confirm discarding dialog drafts inside the existing modal surface. */
export function protectDialogDraft(root,{isDirty,onDiscard}={}){
 const document=root.ownerDocument;let prompt=null,pending=null,settle=null,previousFocus=null,closed=false;
 function finish(accepted){const resolve=settle;settle=null;pending=null;prompt?.remove();prompt=null;if(!accepted&&previousFocus?.isConnected&&root.contains(previousFocus))previousFocus.focus({preventScroll:true});resolve?.(accepted)}
 async function beforeClose(reason='cancel'){
  if(closed)return false;
  if(pending){if(reason==='escape')finish(false);return pending||false}
  const dirty=await isDirty?.();if(closed)return false;
  if(pending){if(reason==='escape')finish(false);return pending||false}
  if(!dirty)return true;
  previousFocus=document.activeElement;prompt=document.createElement('section');prompt.className='notice warning dialog-draft-confirmation';prompt.dataset.dialogDraftPrompt='';prompt.setAttribute('role','group');prompt.setAttribute('aria-label','Unsaved changes');
  const message=document.createElement('p');message.textContent='Discard your unsaved changes?';const actions=document.createElement('div');actions.className='review-actions';const keep=document.createElement('button');keep.type='button';keep.textContent='Keep editing';keep.dataset.dialogDraftKeep='';const discard=document.createElement('button');discard.type='button';discard.textContent='Discard changes';discard.className='danger';discard.dataset.dialogDraftDiscard='';actions.append(keep,discard);prompt.append(message,actions);const footer=root.querySelector(':scope > .actions');if(footer)footer.before(prompt);else root.append(prompt);
  pending=new Promise(resolve=>{settle=resolve});const result=pending;keep.onclick=()=>finish(false);discard.onclick=async()=>{keep.disabled=discard.disabled=true;try{await onDiscard?.();finish(true)}catch(error){message.textContent=error.message||String(error);message.setAttribute('role','alert');keep.disabled=discard.disabled=false;keep.focus()}};keep.focus({preventScroll:true});prompt.scrollIntoView?.({block:'nearest'});return result;
 }
 return{beforeClose,cleanup(){closed=true;finish(false)}};
}
