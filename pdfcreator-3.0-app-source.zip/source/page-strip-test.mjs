/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
import {pageObjects,transformObject,objectMatrix,contentTokens} from './object-tools.js';
import {textSelection,readComments,changeComment,eraseInk} from './review-tools.js';
import {normaliseRich,renderRichText,richPlain} from './rich-text.js';
import {planReplacements,applyReplacements,literalMatches,replaceRichLiteral} from './find-replace.js';
import {inspectLinks} from './pdf-links.js';
import {movePageSelection} from './page-arrangement.js';
let context;
try{
 context=await boot();const {app,$,window,downloads}=context,PDF=app.PDFLib;
 const doc=await PDF.PDFDocument.create();for(let i=0;i<5;i++){const page=doc.addPage([595,842]);page.drawText('ORIGINAL PAGE '+(i+1),{x:40,y:700,size:16})}
 const link=doc.context.obj({Type:'Annot',Subtype:'Link',Rect:[30,600,200,630],Dest:[doc.getPage(4).ref,'Fit']});doc.getPage(0).node.addAnnot(doc.context.register(link));
 const bytes=new Uint8Array(await doc.save({useObjectStreams:false}));await app.openFiles([file('Main.pdf',bytes)]);const owner=app.activeTabId;
 const tile=i=>$('thumbs').querySelector(`[data-page="${i}"]`),chosen=()=>[...$('thumbs').querySelectorAll('.page-selected')].map(b=>+b.dataset.page),order=()=>app.Engine.extractTextPDF(app.state.bytes).map(p=>p.text.match(/ORIGINAL PAGE (\d)/)?.[1]||'Blank');
 const click=async(i,options={})=>{await tile(i).onclick(new window.MouseEvent('click',{bubbles:true,...options}))};
 const menu=i=>{$('pagesdock').dispatchEvent(new window.MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:500,clientY:750}));if(i!==undefined)tile(i).dispatchEvent(new window.MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:500,clientY:750}));return $('pageContextMenu')};
 const act=async id=>{const button=$('pageContextMenu').querySelector(`[data-page-action=${id}]`);check(!!button,'context action '+id);return button.onclick()};
 equal(chosen(),[0],'first page initially selected');await click(1);equal(app.state.page,1,'plain click navigates');equal(chosen(),[1],'plain click selects one page');await click(3,{ctrlKey:true});equal(chosen(),[1,3],'Ctrl selects disjoint pages');equal(app.state.page,1,'multiselection leaves current page');await click(4,{shiftKey:true,ctrlKey:true});equal(chosen(),[1,3,4],'Ctrl+Shift extends selection');await click(3,{metaKey:true});equal(chosen(),[1,4],'Cmd toggles selection');await click(1);await click(3,{shiftKey:true});equal(chosen(),[1,2,3],'Shift selects contiguous range');check(tile(2).getAttribute('aria-pressed')==='true','selected state accessible');equal($('pageSelectionStatus').textContent,'3 selected','selection count displayed');
 await click(1);await click(3,{ctrlKey:true});menu(1);equal(chosen(),[1,3],'right-click selected page preserves multiselection');check($('pageContextMenu').textContent.includes('2 pages selected'),'menu summarises selection');document.dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));check(!$('pageContextMenu'),'Escape closes menu');menu(4);equal(chosen(),[4],'right-click unselected page selects it');document.body.dispatchEvent(new window.MouseEvent('pointerdown',{bubbles:true}));check(!$('pageContextMenu'),'outside click dismisses menu');
 await click(1);await click(3,{ctrlKey:true});const before=app.state.bytes,history=app.state.undo.length,transfer={setData(){},effectAllowed:''};tile(1).ondragstart({dataTransfer:transfer,preventDefault(){throw Error('Unexpected blocked drag')}});equal(transfer.effectAllowed,'move','drag marks move operation');const dest=tile(4);dest.getBoundingClientRect=()=>({left:100,width:60,right:160});dest.ondragover({clientX:155,dataTransfer:transfer,preventDefault(){}});check(dest.classList.contains('page-drop-after'),'drop cue shows after target');await dest.ondrop({clientX:155,preventDefault(){},stopPropagation(){}});equal(order(),['1','3','5','2','4'],'disjoint pages move together in original order');equal(chosen(),[3,4],'moved pages remain selected');equal(app.state.page,3,'viewer follows same original page');equal(app.state.undo.length,history+1,'drag is one undo step');equal(inspectLinks(app.state.doc,0)[0].target,2,'original internal destination follows moved page object');await $('undo').onclick();equal(app.state.bytes,before,'undo restores exact prior PDF bytes');equal(app.state.page,1,'undo restores prior viewed page');await $('redo').onclick();equal(order(),['1','3','5','2','4'],'redo restores page order');await $('undo').onclick();
 await click(1);menu(1);await act('blankBefore');equal(order(),['1','Blank','2','3','4','5'],'insert blank before selected page');equal(chosen(),[1],'new blank selected');equal(app.state.page,2,'blank insertion retains viewed original page');await $('undo').onclick();menu(1);await act('blankAfter');equal(order(),['1','2','Blank','3','4','5'],'insert blank after selected page');await $('undo').onclick();
 await click(1);await click(3,{ctrlKey:true});menu(1);await act('rotate');let loaded=await PDF.PDFDocument.load(app.state.bytes);equal(loaded.getPages().map(p=>p.getRotation().angle),[0,90,0,90,0],'rotate affects selected pages only');equal(chosen(),[1,3],'rotation retains selection');await $('undo').onclick();await click(1);await click(3,{ctrlKey:true});menu(1);await act('duplicate');equal(order(),['1','2','2','3','4','4','5'],'duplicates each selected page beside original');await $('undo').onclick();
 await click(1);await click(3,{ctrlKey:true});menu(1);await act('earlier');equal(order(),['2','1','4','3','5'],'Move earlier handles disjoint selection');await $('undo').onclick();await click(1);await click(3,{ctrlKey:true});menu(1);await act('later');equal(order(),['1','3','2','5','4'],'Move later handles disjoint selection');await $('undo').onclick();
 await click(1);await click(3,{ctrlKey:true});menu(1);await act('extract');equal(downloads.length,1,'extract downloads once');const extracted=new Uint8Array(await(await fetch(downloads[0].href)).arrayBuffer());equal(app.Engine.extractTextPDF(extracted).map(p=>p.text.match(/ORIGINAL PAGE (\d)/)[1]),['2','4'],'extract follows document order');equal(app.state.doc.countPages(),5,'extract leaves working PDF intact');
 menu(1);const deletion=act('delete');await until(()=>$('modaltitle')?.textContent==='Delete 2 selected pages?','delete confirmation');$('modalcancel').click();await deletion;equal(app.state.doc.countPages(),5,'cancel delete preserves pages');menu(1);const remove=act('delete');await until(()=>$('modaltitle')?.textContent==='Delete 2 selected pages?','confirmed deletion');await $('modalform').onsubmit({preventDefault(){}});await remove;equal(order(),['1','3','5'],'delete selected pages');await $('undo').onclick();
 menu(0);await act('all');equal(chosen(),[0,1,2,3,4],'Select all context action');const errors=[];const oldError=console.error;console.error=e=>errors.push(e);menu(0);await act('delete');console.error=oldError;check($('toast').textContent.includes('retain at least one page'),'deleting all pages refused');equal(app.state.doc.countPages(),5,'all-page deletion is atomic');
 await app.openFiles([file('Insert.pdf',await fixture(app,'INSERTED'))]);const sourceId=app.activeTabId;await app.switchTab(owner);await click(1);menu(1);const insertion=act('insert');await until(()=>$('stripSource'),'insert source dialogue');$('stripSource').value=sourceId;$('stripSource').onchange();$('stripRange').value='2';await $('modalform').onsubmit({preventDefault(){}});await insertion;equal(app.state.doc.countPages(),6,'inserts selected source range');check(app.Engine.extractTextPDF(app.state.bytes)[2].text.includes('INSERTED 2'),'insert source bytes used');equal(app.activeTabId,owner,'insert keeps destination active');await $('undo').onclick();await click(1);await click(3,{ctrlKey:true});menu(1);const replacement=act('replace');await until(()=>$('stripSource'),'replace source dialogue');$('stripSource').value=sourceId;$('stripSource').onchange();$('stripRange').value='1-2';await $('modalform').onsubmit({preventDefault(){}});await replacement;equal(app.state.doc.countPages(),5,'replace disjoint pages with source range');const replaced=app.Engine.extractTextPDF(app.state.bytes).map(p=>p.text);check(replaced[1].includes('INSERTED 1')&&replaced[2].includes('INSERTED 2')&&replaced[3].includes('ORIGINAL PAGE 3'),'replacement starts at first selected position');await $('undo').onclick();
 await click(1);menu(1);const openOrganiser=act('organiser');await until(()=>$('organiseGrid'),'context opens full organiser');equal($('organiseDocument').value,owner,'full organiser uses active PDF');$('modalcancel').click();await openOrganiser;
 $('togglePages').click();check(document.body.classList.contains('pages-compact'),'compact strip enabled');menu(2);await act('rotate');loaded=await PDF.PDFDocument.load(app.state.bytes);equal(loaded.getPage(2).getRotation().angle,90,'context actions work in compact strip');await $('undo').onclick();menu(0);window.dispatchEvent(new window.Event('resize'));check(!$('pageContextMenu'),'resize safely dismisses menu');
 await click(1);await click(3,{ctrlKey:true});await app.switchTab(sourceId);equal(chosen(),[0],'switching tabs clears old page selection');await app.switchTab(owner);check(chosen().length===1,'returning tab selection remains valid');
 // Copying live form pages fails without changing the document or history.
 const form=await PDF.PDFDocument.create();const fp=form.addPage([595,842]);form.getForm().createTextField('Name').addToPage(fp,{x:50,y:700,width:100,height:20});await app.openFiles([file('Form.pdf',new Uint8Array(await form.save({useObjectStreams:false})))]);const formBytes=app.state.bytes;await assert.rejects(()=>app.pageStrip.action('duplicate'),/Flatten form/);assertions++;equal(app.state.bytes,formBytes,'failed form duplication preserves bytes');equal(app.state.undo.length,0,'failed form duplication leaves no history');
 equal(movePageSelection(5,new Set([1,3]),0),[1,3,0,2,4],'shared move helper supports beginning');equal(movePageSelection(5,new Set([1,2]),2),[0,1,2,3,4],'dropping into selected block is a no-op');
 await app.local.flush();const saved=app.state.bytes;await context.close();context=await boot();equal(context.app.state.bytes,saved,'page edits persist in local recovery');await context.close();context=null;
 console.log('PDFCreator thumbnail organiser: '+assertions+' assertions passed with native PDFs and controlled drag/context interactions.');
}finally{if(context)await context.close()}
