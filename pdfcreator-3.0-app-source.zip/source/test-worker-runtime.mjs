/* Test-only Web Worker message adapter. Executes embedded engines in Node VM,
 * never opens a browser, user profile or document, and refuses network access. */
import vm from 'node:vm';
export function installTestWorkers(){
 const blobs=new Map(),workers=new Set(),original={Worker:globalThis.Worker,create:URL.createObjectURL,revoke:URL.revokeObjectURL};let networkAttempts=0;
 URL.createObjectURL=blob=>{const url=original.create(blob);blobs.set(url,blob);return url};URL.revokeObjectURL=url=>{blobs.delete(url);original.revoke(url)};
 class TestWorker{
  constructor(url){this.pending=[];this.dead=false;workers.add(this);void this.start(url)}
  async start(url){try{
   const blob=blobs.get(url);if(!blob)throw Error('Missing embedded worker blob.');const source=await blob.text(),listeners=new Map();
   const blocked=()=>{networkAttempts++;throw Error('Test worker blocks network and external scripts.')};
   const sandbox={console,WebAssembly,TextEncoder,TextDecoder,ArrayBuffer,SharedArrayBuffer,DataView,Uint8Array,Uint8ClampedArray,Uint16Array,Uint32Array,Int8Array,Int16Array,Int32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array,Blob,Response,ReadableStream,URL,atob,btoa,performance,crypto:globalThis.crypto,setTimeout,clearTimeout,setInterval,clearInterval,queueMicrotask,fetch:blocked,importScripts:blocked,XMLHttpRequest:class{constructor(){blocked()}},navigator:{hardwareConcurrency:4,userAgent:'pdfpro-controlled-worker-test'},location:{href:'blob:pdfpro-test-worker'},
    postMessage:data=>queueMicrotask(()=>{if(!this.dead)this.onmessage?.({data})}),addEventListener:(type,fn)=>{if(!listeners.has(type))listeners.set(type,[]);listeners.get(type).push(fn)},removeEventListener:(type,fn)=>listeners.set(type,(listeners.get(type)||[]).filter(x=>x!==fn))};
   sandbox.self=sandbox;this.context=vm.createContext(sandbox);await vm.runInContext(source,this.context,{timeout:30000});if(this.dead)return;
   this.deliver=data=>{const event={data};for(const handler of [sandbox.onmessage,...listeners.get('message')||[]])if(handler)Promise.resolve(handler(event)).catch(error=>this.fail(error))};
   this.pending.splice(0).forEach(data=>this.deliver(data));
  }catch(error){this.fail(error)}}
  fail(error){if(!this.dead)this.onerror?.({message:error.message,preventDefault(){}})}
  postMessage(data){if(this.dead)return;if(this.deliver)this.deliver(data);else this.pending.push(data)}
  terminate(){this.dead=true;this.pending=[];this.context=null;this.deliver=null;workers.delete(this)}
 }
 globalThis.Worker=TestWorker;
 return{blob:url=>blobs.get(url),get networkAttempts(){return networkAttempts},get activeWorkerCount(){return workers.size},close(){for(const worker of workers)worker.terminate();globalThis.Worker=original.Worker;URL.createObjectURL=original.create;URL.revokeObjectURL=original.revoke;for(const url of blobs.keys())original.revoke(url);blobs.clear()}};
}
