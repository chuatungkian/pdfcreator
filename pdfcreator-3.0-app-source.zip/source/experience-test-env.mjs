/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets,transformDirectText,saveDirectEdit} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
export async function boot({moduleURL=null,assets=null,pageURL='https://pdfpro.test/',fetch:fetchUpdates=null}={}){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:pageURL,pretendToBeVisual:true});
const {window}=dom;if(fetchUpdates)window.fetch=fetchUpdates;
window.Image=canvas.Image;globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toDataURL=function(type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));return 'data:'+type+';base64,'+backing.toBuffer(type).toString('base64')};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS=assets||{ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
if(moduleURL&&assets)globalThis['$libmupdf_wasm_Module']={locateFile:()=>"embedded.wasm",wasmBinary:Uint8Array.from(atob(assets.mupdfBase64),c=>c.charCodeAt(0))};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import(moduleURL||'./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

