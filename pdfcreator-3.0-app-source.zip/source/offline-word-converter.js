/* Ream conversion core. The caller supplies all font bytes; no asset downloads. */
import {Ream,parseTtf,docxReader} from 'reamkit';
import {docReader} from './word-dependencies/node_modules/reamkit/dist/esm/word/doc/doc-reader.js';
const limit=256*1024*1024;
function checkZip(bytes){
 if(bytes[0]!==80||bytes[1]!==75)return;
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
 for(let p=bytes.length-22;p>=Math.max(0,bytes.length-65557);p--)if(view.getUint32(p,true)===0x06054b50&&p+22+view.getUint16(p+20,true)===bytes.length){end=p;break}
 if(end<0)throw Error('This Word document has an incomplete ZIP container.');
 const entries=view.getUint16(end+10,true),size=view.getUint32(end+12,true),start=view.getUint32(end+16,true);
 if(entries===65535||entries>10000||start+size>end)throw Error('This Word document is too large or uses an unsupported ZIP container.');
 let p=start,total=0;for(let i=0;i<entries;i++){if(p+46>end||view.getUint32(p,true)!==0x02014b50)throw Error('This Word document has an invalid ZIP directory.');total+=view.getUint32(p+24,true);if(total>limit)throw Error('The expanded Word document exceeds the 256 MB conversion limit.');p+=46+view.getUint16(p+28,true)+view.getUint16(p+30,true)+view.getUint16(p+32,true)}
}
function checkCharacters(flow,font){
 const missing=new Set(),seen=new WeakSet();let length=0;
 function walk(value){if(!value||typeof value!=='object'||ArrayBuffer.isView(value)||value instanceof ArrayBuffer||seen.has(value))return;seen.add(value);
  if(typeof value.text==='string'){length+=value.text.length;if(length>2000000)throw Error('The document contains too much text for this built-in import.');for(const ch of value.text)if(!/[\s\p{Cf}]/u.test(ch)&&!font.glyphForCodepoint(ch.codePointAt(0)))missing.add(ch)}
  if(value instanceof Map){for(const item of value.values())walk(item);return}
  for(const [key,item]of Object.entries(value))if(!['native','resources','styleSheet','source','original'].includes(key))walk(item);
 }
 walk(flow);if(missing.size)throw Error('The embedded font does not contain '+[...missing].slice(0,10).map(c=>'“'+c+'”').join(', ')+'. Chinese and some symbols need additional fonts. Use the Microsoft Word companion or export a PDF from your word processor.');
}
export async function convertOfflineWord(bytes,fonts,{password='',onProgress=()=>{}}={}){
 if(!(bytes instanceof Uint8Array)||bytes.length<8||bytes.length>64*1024*1024)throw Error('Choose a Word document of up to 64 MB.');
 for(const key of ['regular','bold','italic','boldItalic'])if(!(fonts?.[key]instanceof Uint8Array)||fonts[key].length<12)throw Error('The embedded Word fonts are unavailable. Reopen the complete PDFCreator HTML.');
 checkZip(bytes);onProgress(.1,'Reading the Word document');
 let document;try{document=Ream.parse(bytes,{readers:[docxReader,docReader],...(password?{password}:{})});}catch(error){if(error.name==='WrongPasswordError')throw Error('This document needs a valid password. Enter it under Protected document, or use the Word companion.');throw Error('Cannot read this Word document: '+error.message)}
 if(document.losses.some(loss=>/encrypted\/obfuscated/i.test(loss.detail||'')))throw Error('This protected legacy .doc file needs Microsoft Word. Use the companion or export it as a PDF from Word.');
 if(!['docx','doc'].includes(document.format))throw Error('Choose a genuine .docx or .doc Word document.');
 onProgress(.3,'Checking text and embedded fonts');checkCharacters(document.flow,parseTtf(fonts.regular));
 onProgress(.45,'Laying out pages and creating the PDF');
 const result=await document.convertWithReport('pdf',{fonts,layoutProfile:'word',info:{producer:'PDFCreator · Ream 1.33.1'}});
 if(!(result.bytes instanceof Uint8Array)||new TextDecoder().decode(result.bytes.subarray(0,5))!=='%PDF-')throw Error('The converter did not produce a valid PDF.');
 const seen=new Set(),losses=[];for(const loss of result.losses||[]){const row={severity:String(loss.severity||'changed'),feature:String(loss.feature||'Document content').slice(0,100),detail:String(loss.detail||'An element may appear differently.').slice(0,500)},key=JSON.stringify(row);if(!seen.has(key)&&losses.length<50){losses.push(row);seen.add(key)}}
 onProgress(.95,'Conversion ready for review');return{bytes:result.bytes,format:document.format,losses};
}
