@echo off
setlocal
set "PDFCREATOR_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%PDFCREATOR_CSC%" set "PDFCREATOR_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if exist "%~dp0PDFCreator-Word-Companion.exe" goto run
if not exist "%PDFCREATOR_CSC%" (
  echo Windows .NET Framework is required for the Word companion.
  pause
  exit /b 1
)
"%PDFCREATOR_CSC%" /nologo /target:exe /optimize+ /r:Microsoft.CSharp.dll /out:"%~dp0PDFCreator-Word-Companion.exe" "%~dp0word-companion.cs"
if errorlevel 1 (
  pause
  exit /b 1
)
:run
"%~dp0PDFCreator-Word-Companion.exe"
pause
