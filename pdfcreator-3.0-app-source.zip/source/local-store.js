/* Browser-local PDF workspace persistence. AGPL-3.0-or-later.
 * A PDF snapshot and its catalogue/session updates commit atomically.
 * Revision checks stop another app window from silently overwriting this one.
 */
const DATABASE='pdfpro-local-workspace';
const VERSION=2;
const SESSION='workspace';
const error=(name,message)=>Object.assign(new Error(message),{name});
export class LocalWorkspaceStore{
  constructor(options={}){
    try{this.factory=Object.hasOwn(options,'indexedDB')?options.indexedDB:globalThis.indexedDB}catch(e){this.accessError=e;this.factory=null}
    this.name=options.name||DATABASE;this.db=null;this.opening=null;this.revision=0;
  }
  async open(){
    if(this.db)return this.db;
    if(!this.factory)throw this.accessError||error('StorageUnavailableError','This browser does not provide local document storage here.');
    if(this.opening)return this.opening;
    this.opening=new Promise((resolve,reject)=>{
      let request,settled=false;
      try{request=this.factory.open(this.name,VERSION)}catch(e){reject(e);return}
      request.onupgradeneeded=()=>{for(const name of ['documents','views','catalogue','session','trash','templates'])if(!request.result.objectStoreNames.contains(name))request.result.createObjectStore(name,{keyPath:'id'})};
      request.onerror=()=>{settled=true;reject(request.error||error('StorageUnavailableError','Unable to open local document storage.'))};
      request.onblocked=()=>{settled=true;reject(error('StorageBlockedError','Another PDFCreator window is blocking local storage. Close that window and reopen PDFCreator.'))};
      request.onsuccess=()=>{
        if(settled){request.result.close();return}
        this.db=request.result;this.db.onversionchange=()=>{this.db?.close();this.db=null};resolve(this.db);
      };
    });
    try{return await this.opening}finally{this.opening=null}
  }
  async readSession(){
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('session','readonly'),request=tx.objectStore('session').get(SESSION);let value;
      request.onsuccess=()=>value=request.result||null;
      tx.oncomplete=()=>{this.revision=value?.revision||0;resolve(value)};
      tx.onabort=tx.onerror=()=>reject(tx.error||request.error||Error('Unable to read the saved workspace.'));
    });
  }
  async getDocuments(ids){
    if(!ids.length)return [];
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(['documents','views'],'readonly'),out=new Array(ids.length),views=[];
      ids.forEach((id,index)=>{
        const request=tx.objectStore('documents').get(id);request.onsuccess=()=>out[index]=request.result||null;
        const view=tx.objectStore('views').get(id);view.onsuccess=()=>views[index]=view.result;
      });
      tx.oncomplete=()=>resolve(out.map((record,index)=>record?{...record,snapshot:{...record.snapshot,...views[index]?.view}}:null));
      tx.onabort=tx.onerror=()=>reject(tx.error||Error('Unable to read the saved documents.'));
    });
  }
  async getDocument(id){return (await this.getDocuments([id]))[0]}
  async listDocuments(){
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('catalogue','readonly'),request=tx.objectStore('catalogue').getAll();let rows=[];
      request.onsuccess=()=>rows=request.result;
      tx.oncomplete=()=>resolve(rows.sort((a,b)=>b.updatedAt-a.updatedAt));
      tx.onabort=tx.onerror=()=>reject(tx.error||Error('Unable to read the local library.'));
    });
  }
  async commit({documents=[],views=[],session,removeIds=[],archiveIds=[],restoreIds=[],purgeIds=[],templates=[],removeTemplateIds=[],tagUpdates=[]}={}){
    const db=await this.open(),expected=this.revision;
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(['documents','views','catalogue','session','trash','templates'],'readwrite');
      const sessions=tx.objectStore('session'),request=sessions.get(SESSION);let failure,nextRevision;
      request.onsuccess=()=>{
        try{
          const previous=request.result;
          if((previous?.revision||0)!==expected)throw error('WorkspaceConflictError','Another PDFCreator window changed this library. Export your current work before reloading this window.');
          const docs=tx.objectStore('documents'),catalogue=tx.objectStore('catalogue');
          for(const record of documents){
            docs.put(record);
            catalogue.put({id:record.id,name:record.snapshot.name,byteLength:record.snapshot.bytes.byteLength,pageCount:record.pageCount,updatedAt:record.updatedAt,contentUpdatedAt:record.updatedAt,contentRevision:expected+1,dirty:record.snapshot.dirty,marks:record.snapshot.marks.length,tags:record.snapshot.tags||[]});
          }
          for(const view of views){
            tx.objectStore('views').put(view);
            const metadata=catalogue.get(view.id);
            metadata.onsuccess=()=>{if(metadata.result)catalogue.put({...metadata.result,name:view.view.name,dirty:view.view.dirty,marks:view.view.marks?.length||0,tags:view.view.tags||[],updatedAt:Date.now()})};
          }
          const trash=tx.objectStore('trash'),templateStore=tx.objectStore('templates'),viewStore=tx.objectStore('views');
          for(const id of archiveIds){const r=docs.get(id),v=viewStore.get(id);r.onsuccess=()=>{const record=r.result;if(record){v.onsuccess=()=>trash.put({id,record,view:v.result||null,deletedAt:Date.now()})}}}
          for(const id of restoreIds){const r=trash.get(id);r.onsuccess=()=>{const item=r.result;if(!item)return;docs.put(item.record);if(item.view)viewStore.put(item.view);const snap={...item.record.snapshot,...item.view?.view};catalogue.put({id,name:snap.name,byteLength:snap.bytes.length,pageCount:item.record.pageCount,updatedAt:Date.now(),dirty:snap.dirty,marks:snap.marks?.length||0,tags:snap.tags||[]});trash.delete(id)}}
          for(const id of purgeIds)trash.delete(id);
          for(const item of templates)templateStore.put(item);
          for(const id of removeTemplateIds)templateStore.delete(id);
          for(const item of tagUpdates){const r=catalogue.get(item.id);r.onsuccess=()=>{if(r.result)catalogue.put({...r.result,tags:item.tags})};const v=viewStore.get(item.id);v.onsuccess=()=>{if(v.result)viewStore.put({...v.result,view:{...v.result.view,tags:item.tags}});else{const d=docs.get(item.id);d.onsuccess=()=>{if(d.result)viewStore.put({id:item.id,view:Object.fromEntries([...Object.entries(d.result.snapshot).filter(([key])=>!['bytes','original','undo','redo','checkpoints','selectedImage'].includes(key)),['tags',item.tags]])})}}}}
          removeIds=[...new Set([...removeIds,...archiveIds])];
          for(const id of removeIds){docs.delete(id);catalogue.delete(id);viewStore.delete(id)}
          nextRevision=expected+1;
          const next={...previous,...session,id:SESSION,schema:1,revision:nextRevision,updatedAt:Date.now()};
          if(removeIds.length){next.openIds=(next.openIds||[]).filter(id=>!removeIds.includes(id));if(removeIds.includes(next.activeId))next.activeId=next.openIds[0]||null}
          sessions.put(next);
        }catch(e){failure=e;tx.abort()}
      };
      tx.oncomplete=()=>{this.revision=nextRevision;resolve(nextRevision)};
      tx.onabort=()=>reject(failure||tx.error||Error('The local save did not complete.'));
      tx.onerror=()=>{failure||=tx.error||Error('Unable to save the local workspace.')};
    });
  }
  async listExtra(store){
    if(!['trash','templates'].includes(store))throw Error('Invalid library section.');const db=await this.open();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readonly'),request=tx.objectStore(store).getAll();let values=[];request.onsuccess=()=>values=request.result;tx.oncomplete=()=>resolve(values);tx.onabort=tx.onerror=()=>reject(tx.error||Error('Unable to read library section.'))});
  }
  close(){this.db?.close();this.db=null}
}
