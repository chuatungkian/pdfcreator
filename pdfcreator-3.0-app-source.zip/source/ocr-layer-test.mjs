/* Real OCR search-layer and visual-preservation regression. No browser or user files are opened. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {gunzipSync} from 'node:zlib';
import {installTestWorkers} from './test-worker-runtime.mjs';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');

let context;const runtime=installTestWorkers();
try{context=await boot();const {app,$,window}=context;const html=fs.readFileSync('../../outputs/pdfcreator.html','utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64')));window.PDFPRO_ASSETS=assets;app.OCR.configureOCR(assets.ocr);
const scan=canvas.createCanvas(1400,300),ctx=scan.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,1400,300);ctx.fillStyle='black';ctx.font='85px Arial';ctx.fillText('PDFPRO AUDIT TEXT 987',45,165);const pdf=await app.PDFLib.PDFDocument.create(),image=await pdf.embedPng(scan.toBuffer('image/png'));pdf.addPage([504,108]).drawImage(image,{x:0,y:0,width:504,height:108});await app.openFiles([file('Scan.pdf',await pdf.save())]);
const beforePixels=app.Engine.renderPagePixels(app.state.bytes,0,{scale:1}).pixels;const rendered=app.canvasForPage(0,200/72),result=await app.OCR.recognizeImage(rendered,{dpi:200});check(result.lines.length===1&&result.words.length===4,'OCR recognises one line with four words');
const pending=app.activate('ocr');await until(()=>$('modalform'),'settings');$('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await pending;await until(()=>['ready','error'].includes(app.documentJobs.forTab(app.activeTabId)?.status),'OCR task ready');const completed=app.documentJobs.forTab(app.activeTabId);if(completed.status==='error')throw Error(completed.message);await completed.actions[0].run(completed);check(app.Engine.extractTextPDF(app.state.bytes)[0].text.includes('PDFPRO AUDIT TEXT 987'),'searchable OCR text keeps the original line');check(app.Engine.searchPDF(app.state.bytes,'AUDIT TEXT 987').length===1,'OCR phrase search crosses word spans');if($('modalform'))$('modalcancel').click();await pending;equal(app.Engine.renderPagePixels(app.state.bytes,0,{scale:1}).pixels,beforePixels,'OCR leaves rendered source appearance unchanged');const ocrBytes=app.state.bytes,skipped=app.activate('ocr');await until(()=>document.getElementById('modalform'),'skip existing text');document.getElementById('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await skipped;await until(()=>['ready','error'].includes(app.documentJobs.forTab(app.activeTabId)?.status),'skip task ready');equal(app.state.bytes,ocrBytes,'skip-existing-text does not duplicate the OCR layer');app.OCR.cancelOCR();console.log('pdfpro OCR text layer: '+assertions+' assertions passed with real recognition, phrase search and native text extraction.');
}finally{if(context)await context.close();runtime.close()}
