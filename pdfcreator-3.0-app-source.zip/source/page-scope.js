/* Compact page scope for any dialog that submits an existing page-range input. */
export function parsePageScope(value,count){
 const indices=[];
 for(const bit of String(value).split(',')){
  const match=bit.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
  if(!match)throw Error('Use page numbers or ranges, for example 1-3,5');
  const start=+match[1],end=+(match[2]||match[1]);
  if(start<1||end<1||start>count||end>count)throw Error('Pages must be between 1 and '+count);
  for(let page=start;start<=end?page<=end:page>=end;start<=end?page++:page--)indices.push(page-1);
 }
 return indices;
}
export function pageScope(input,{count=0,page=0,parsePages=value=>parsePageScope(value,count),selectedPages=[]}={}){
 const doc=input.ownerDocument,group=doc.createElement('div'),choices=doc.createElement('div'),info=doc.createElement('span');
 group.className='page-range-shortcuts page-scope';group.dataset.pageScope='';choices.className='page-scope-choices';choices.setAttribute('role','group');choices.setAttribute('aria-label','Page scope');info.className='help';info.setAttribute('role','status');info.setAttribute('aria-live','polite');
 const selected=()=>[...new Set((typeof selectedPages==='function'?selectedPages():selectedPages)||[])].filter(index=>Number.isInteger(index)&&index>=0&&index<count).sort((a,b)=>a-b);
 const values={current:()=>String(Math.min(Math.max(0,page),count-1)+1),selected:()=>selected().map(index=>index+1).join(','),all:()=>'1-'+count};
 const buttons=new Map();let mode='custom';
 const same=(a,b)=>a.length===b.length&&a.every((index,i)=>index===b[i]);
 const update=(chosen=null)=>{
  buttons.get('selected').disabled=!selected().length;
  try{
   const indices=[...new Set(parsePages(input.value))].sort((a,b)=>a-b);
   input.removeAttribute('aria-invalid');info.textContent=indices.length+' of '+count+' pages affected';
   mode=chosen||(['all','current','selected'].find(key=>values[key]()&&same(indices,[...new Set(parsePages(values[key]()))].sort((a,b)=>a-b)))||'custom');
  }catch(error){input.setAttribute('aria-invalid','true');info.textContent=error.message;mode=chosen||'custom'}
  for(const [key,button]of buttons)button.setAttribute('aria-pressed',String(key===mode));
 };
 const emit=()=>{const Event=doc.defaultView.Event;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}))};
 for(const [key,label]of [['current','Current'],['selected','Selected'],['all','All'],['custom','Custom']]){
  const button=doc.createElement('button');button.type='button';button.className='small';button.dataset.pageScopeChoice=key;button.textContent=label;button.title={current:'Current page',selected:'Pages selected in the page strip',all:'All pages',custom:'Enter page numbers or ranges'}[key];
  button.onclick=()=>{if(key==='selected'&&!selected().length)return;if(key==='custom'){update('custom');input.focus();return}input.value=values[key]();emit();update(key)};buttons.set(key,button);choices.append(button);
 }
 group.append(choices,info);input.after(group);
 const onInput=()=>update();input.addEventListener('input',onInput);input.addEventListener('change',onInput);update();
 const cleanup=()=>{input.removeEventListener('input',onInput);input.removeEventListener('change',onInput);group.remove()};cleanup.refresh=update;cleanup.element=group;return cleanup;
}
