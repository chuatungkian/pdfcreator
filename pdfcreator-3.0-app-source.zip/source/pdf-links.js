/* Native PDF links and conservative URL handling. AGPL-3.0-or-later. */
export function webLink(value){
  let text=String(value??'').trim();if(!text)throw Error('Enter a website URL or email address.');
  if(/[\x00-\x1f\x7f]/.test(text))throw Error('The link contains invalid control characters.');
  if(!/^[a-z][\w+.-]*:/i.test(text)){
    if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text))text='mailto:'+text;
    else if(/^(?:localhost|[^\s/:]+\.[^\s/:]+)(?::\d+)?(?:[/?#]|$)/i.test(text))text='https://'+text;
  }
  let url;try{url=new URL(text)}catch{throw Error('Enter a complete website URL, such as https://example.com, or an email address.');}
  if(!['http:','https:','mailto:'].includes(url.protocol))throw Error('Only HTTP, HTTPS and email links can be opened.');
  if(url.protocol==='mailto:'&&!url.pathname)throw Error('Enter an email address.');return url.href;
}
export function pageLink(value,total){const page=Number(value);if(!Number.isInteger(page)||page<1||page>total)throw Error('Choose a page from 1 to '+total+'.');return '#page='+page}
export function inspectLinks(doc,pageIndex){
  const page=doc.loadPage(pageIndex),records=[];let links=[];
  try{links=page.getLinks();for(const [index,link]of links.entries()){
    const uri=link.getURI(),rect=link.getBounds();if(!rect.every(Number.isFinite)||rect[2]<=rect[0]||rect[3]<=rect[1])continue;
    let href=null,target=null,error='';try{if(link.isExternal())href=webLink(uri);else{target=doc.resolveLink(uri);if(!Number.isInteger(target)||target<0||target>=doc.countPages())throw Error('This PDF link destination cannot be resolved.')}}catch(e){error=e.message}
    records.push({index,page:pageIndex,uri,rect:[...rect],href,target,error});
  }}finally{links.forEach(link=>link.destroy());page.destroy()}return records;
}
export function writeLink(doc,pageIndex,rect,uri,existing=null){
  if(uri!==null&&(!Array.isArray(rect)||rect.length!==4||!rect.every(Number.isFinite)||rect[2]<=rect[0]||rect[3]<=rect[1]))throw Error('Select a link area inside the page.');
  const page=doc.loadPage(pageIndex);let links=[],link;
  try{
    if(existing){links=page.getLinks();const match=links[existing.index];if(!match||match.getURI()!==existing.uri||match.getBounds().some((v,i)=>Math.abs(v-existing.rect[i])>.05))throw Error('This link changed. Select it again.');page.deleteLink(match)}
    if(uri!==null){link=page.createLink(rect,uri);return{uri:link.getURI(),rect:link.getBounds()}}
  }finally{link?.destroy();links.forEach(link=>link.destroy());page.destroy()}
}
