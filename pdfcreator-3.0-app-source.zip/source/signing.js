/* PDFCreator certificate signing. Dependencies: PDFLib and forge, both bundled locally.
 * Creates an incremental PDF revision and a detached CMS RSA/SHA-256 signature.
 * Verification establishes byte integrity, not identity, CA trust or revocation.
 * Sources: https://github.com/digitalbazaar/forge and RFC 5652 section 5.
 */
(function (root) {
  'use strict';
  const MAX_PDF_BYTES = 150 * 1024 * 1024;
  const SUPPORTED_SUBFILTERS = ['adbe.pkcs7.detached', 'ETSI.CAdES.detached'];
  const TRUST_NOTICE = 'Offline cryptographic integrity only. Certificate identity, CA trust, revocation, trusted timestamps, and document permission policies are not validated.';
  function deps() {
    if (!root.forge || !root.PDFLib) throw new Error('The bundled certificate signing libraries are unavailable.');
    return { f: root.forge, P: root.PDFLib };
  }
  function bytes(value) {
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    throw new Error('Expected PDF or certificate bytes.');
  }
  function binary(value) {
    const b = bytes(value), parts = [];
    for (let i = 0; i < b.length; i += 32768) parts.push(String.fromCharCode.apply(null, b.subarray(i, i + 32768)));
    return parts.join('');
  }
  function fromBinary(s) {
    const b = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 255;
    return b;
  }
  function sameBytes(a, b) {
    if (a.length !== b.length) return false;
    let difference = 0;
    for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return difference === 0;
  }
  function fieldName(dn) {
    const cn = dn.getField('CN');
    if (cn && cn.value) return cn.value;
    return dn.attributes.map(a => (a.shortName || a.name || a.type) + '=' + a.value).join(', ');
  }
  function certificateInfo(cert) {
    const { f } = deps();
    const der = f.asn1.toDer(f.pki.certificateToAsn1(cert)).getBytes();
    const now = new Date();
    return {
      subject: fieldName(cert.subject), issuer: fieldName(cert.issuer), serialNumber: cert.serialNumber,
      validFrom: cert.validity.notBefore.toISOString(), validTo: cert.validity.notAfter.toISOString(),
      currentlyWithinValidity: now >= cert.validity.notBefore && now <= cert.validity.notAfter,
      fingerprintSHA256: f.md.sha256.create().update(der).digest().toHex().match(/../g).join(':'),
      keyType: cert.publicKey && cert.publicKey.n ? 'RSA' : 'Unsupported',
      keyBits: cert.publicKey && cert.publicKey.n ? cert.publicKey.n.bitLength() : null,
      trusted: null, revocationChecked: false,
    };
  }
  async function importP12(input, password) {
    const { f } = deps();
    const data = bytes(input);
    if (data.length > 10 * 1024 * 1024) throw new Error('The certificate container exceeds the 10 MB limit.');
    let p12;
    try { p12 = f.pkcs12.pkcs12FromAsn1(f.asn1.fromDer(binary(data)), false, password == null ? '' : String(password)); }
    catch (e) { throw new Error('Unable to unlock this PKCS#12 file. Check the password and use a supported RSA P12/PFX container.'); }
    const bags = p12.safeContents.flatMap(contents => contents.safeBags);
    const keys = bags.map(b => b.key).filter(k => k && k.n && k.d);
    const chain = bags.map(b => b.cert).filter(Boolean);
    let key, certificate;
    for (const k of keys) {
      const c = chain.find(cert => cert.publicKey.n && cert.publicKey.n.equals(k.n) && cert.publicKey.e.equals(k.e));
      if (c) { key = k; certificate = c; break; }
    }
    if (!key || !certificate) throw new Error('No matching RSA private key and certificate were found. EC certificates are not supported.');
    if (key.n.bitLength() < 2048) throw new Error('Signing requires an RSA key of at least 2048 bits.');
    const usage = certificate.getExtension('keyUsage');
    if (usage && !usage.digitalSignature && !usage.nonRepudiation) throw new Error('This certificate does not permit digital signatures.');
    return { key, certificate, chain, summary: certificateInfo(certificate), trustNotice: TRUST_NOTICE };
  }
  function pdfDate(date) {
    return 'D:' + date.toISOString().replace(/[-:TZ.]/g, '').slice(0, 14) + 'Z';
  }
  function escapePdfString(s) {
    // Hex UTF-16BE is unambiguous even for names containing PDF delimiters.
    const value = String(s == null ? '' : s).slice(0, 2000);
    let hex = 'FEFF';
    for (let i = 0; i < value.length; i++) hex += value.charCodeAt(i).toString(16).padStart(4, '0');
    return '<' + hex + '>';
  }
  function lastXref(s) {
    const match = /startxref\s+(\d+)\s+%%EOF\s*$/.exec(s);
    if (!match) throw new Error('This PDF has no valid final cross-reference pointer. Repair or export it before signing.');
    const offset = Number(match[1]);
    if (!Number.isSafeInteger(offset) || offset < 0 || offset >= s.length) throw new Error('The PDF cross-reference pointer is invalid.');
    return offset;
  }
  async function loadPdf(input) {
    const { P } = deps();
    const data = bytes(input);
    if (data.length > MAX_PDF_BYTES) throw new Error('Certificate signing currently supports PDFs up to 150 MB.');
    const doc = await P.PDFDocument.load(data, { updateMetadata: false, throwOnInvalidObject: true });
    if (doc.isEncrypted || doc.context.trailerInfo.Encrypt) throw new Error('Decrypt the PDF before certificate signing or signature inspection.');
    return doc;
  }
  async function signPdf(input, credential, options) {
    const { P, f } = deps();
    options = options || {};
    if (!credential || !credential.key || !credential.certificate) throw new Error('Import an RSA P12/PFX certificate first.');
    const date = options.signingDate ? new Date(options.signingDate) : new Date();
    if (!Number.isFinite(date.getTime())) throw new Error('The signing date is invalid.');
    const cert = credential.certificate;
    if (date < cert.validity.notBefore || date > cert.validity.notAfter) throw new Error('The certificate is outside its validity dates.');
    const original = binary(input), previousXref = lastXref(original);
    const doc = await loadPdf(input), context = doc.context;
    const name = s => P.PDFName.of(s);
    if (doc.catalog.get(name('Perms'))) throw new Error('This document has certification or permission signatures. Additional signing is unavailable because its policy cannot be safely evaluated offline.');
    const rootRef = context.trailerInfo.Root;
    if (!(rootRef instanceof P.PDFRef)) throw new Error('The PDF catalog is not an indirect object. Export a repaired copy before signing.');
    const page = doc.getPages()[0];
    if (!page) throw new Error('A PDF must contain a page before it can be signed.');
    const currentForm = doc.catalog.lookupMaybe(name('AcroForm'), P.PDFDict);
    if (currentForm && currentForm.has(name('XFA'))) throw new Error('Dynamic XFA forms cannot be certificate signed by PDFCreator.');
    // Refuse explicit signature transforms; silently breaking a document lock is unsafe.
    for (const pair of context.enumerateIndirectObjects()) {
      const object = pair[1];
      if (object instanceof P.PDFDict && object.has(name('TransformMethod'))) throw new Error('This PDF contains a signature transformation policy that PDFCreator cannot evaluate.');
    }
    // pdf-lib omits some original ObjStm/XRef stream objects from its context.
    // Allocating from largestObjectNumber alone can overwrite a live object stream.
    // Conservative scanning may overestimate, but never reuses those object numbers.
    let largest = context.largestObjectNumber;
    for (const match of original.matchAll(/\/Size\s+(\d+)/g)) largest = Math.max(largest, Number(match[1]) - 1);
    for (const match of original.matchAll(/(?:^|[\r\n])\s*(\d+)\s+\d+\s+obj\b/g)) largest = Math.max(largest, Number(match[1]));
    if (!Number.isSafeInteger(largest) || largest > 10000000) throw new Error('The PDF object-number range exceeds the supported signing limit. Export a repaired copy first.');
    let next = largest + 1;
    const sigRef = P.PDFRef.of(next++), widgetRef = P.PDFRef.of(next++), formRef = P.PDFRef.of(next++);
    const form = currentForm ? currentForm.clone(context) : context.obj({});
    const oldFields = currentForm && currentForm.lookupMaybe(name('Fields'), P.PDFArray);
    const fields = oldFields ? oldFields.clone(context) : context.obj([]);
    fields.push(widgetRef);
    form.set(name('Fields'), fields);
    form.set(name('SigFlags'), P.PDFNumber.of(3));
    const catalog = doc.catalog.clone(context);
    catalog.set(name('AcroForm'), formRef);
    const pageNode = page.node.clone(context);
    const oldAnnots = page.node.lookupMaybe(name('Annots'), P.PDFArray);
    const annots = oldAnnots ? oldAnnots.clone(context) : context.obj([]);
    annots.push(widgetRef);
    pageNode.set(name('Annots'), annots);
    const suffix = f.util.bytesToHex(f.random.getBytesSync(6));
    const widget = context.obj({ Type: 'Annot', Subtype: 'Widget', FT: 'Sig', Rect: [0, 0, 0, 0],
      T: P.PDFString.of('pdfcreator-signature-' + suffix), V: sigRef, P: page.ref, F: 132 });
    // Reserved contents includes the certificate chain; no external resources or requests.
    const reservedBytes = Math.max(32768, Math.min(262144, Number(options.reserveBytes) || 65536));
    const rangeToken = '[0 000000000000 000000000000 000000000000]';
    const contents = '0'.repeat(reservedBytes * 2);
    const signatureDictionary = '<<\n/Type /Sig\n/Filter /Adobe.PPKLite\n/SubFilter /adbe.pkcs7.detached\n/ByteRange ' + rangeToken +
      '\n/Contents <' + contents + '>\n/M (' + pdfDate(date) + ')\n/Name ' + escapePdfString(options.name || fieldName(cert.subject)) +
      (options.reason ? '\n/Reason ' + escapePdfString(options.reason) : '') +
      (options.location ? '\n/Location ' + escapePdfString(options.location) : '') + '\n>>';
    const changes = [
      [rootRef, catalog.toString()], [page.ref, pageNode.toString()], [sigRef, signatureDictionary],
      [widgetRef, widget.toString()], [formRef, form.toString()],
    ].sort((a, b) => a[0].objectNumber - b[0].objectNumber);
    let output = original + '\n';
    const entries = [];
    let signatureOffset;
    for (const [ref, body] of changes) {
      const offset = output.length;
      if (ref === sigRef) signatureOffset = offset;
      entries.push({ number: ref.objectNumber, generation: ref.generationNumber, offset });
      output += ref.objectNumber + ' ' + ref.generationNumber + ' obj\n' + body + '\nendobj\n';
    }
    const xrefOffset = output.length;
    output += 'xref\n';
    for (let i = 0; i < entries.length;) {
      let j = i + 1;
      while (j < entries.length && entries[j].number === entries[j - 1].number + 1) j++;
      output += entries[i].number + ' ' + (j - i) + '\n';
      for (; i < j; i++) output += String(entries[i].offset).padStart(10, '0') + ' ' + String(entries[i].generation).padStart(5, '0') + ' n \n';
    }
    output += 'trailer\n<< /Size ' + next + ' /Root ' + rootRef.toString() + ' /Prev ' + previousXref;
    for (const key of ['Info', 'ID']) if (context.trailerInfo[key]) output += ' /' + key + ' ' + context.trailerInfo[key].toString();
    output += ' >>\nstartxref\n' + xrefOffset + '\n%%EOF\n';
    const contentStart = output.indexOf('/Contents <', signatureOffset) + '/Contents '.length;
    const contentEnd = contentStart + contents.length + 2;
    const range = [0, contentStart, contentEnd, output.length - contentEnd];
    const replacement = '[0 ' + range.slice(1).map(n => String(n).padStart(12, '0')).join(' ') + ']';
    const rangeStart = output.indexOf(rangeToken, signatureOffset);
    output = output.slice(0, rangeStart) + replacement + output.slice(rangeStart + rangeToken.length);
    const p7 = f.pkcs7.createSignedData();
    p7.content = f.util.createBuffer(output.slice(0, contentStart) + output.slice(contentEnd), 'raw');
    for (const c of credential.chain || [cert]) p7.addCertificate(c);
    p7.addSigner({ key: credential.key, certificate: cert, digestAlgorithm: f.pki.oids.sha256,
      authenticatedAttributes: [
        { type: f.pki.oids.contentType, value: f.pki.oids.data },
        { type: f.pki.oids.messageDigest },
        { type: f.pki.oids.signingTime, value: date },
      ] });
    p7.sign({ detached: true });
    const cmsHex = f.util.bytesToHex(f.asn1.toDer(p7.toAsn1()).getBytes());
    if (cmsHex.length > contents.length) throw new Error('The certificate chain exceeds the reserved signature space. Try a larger reserveBytes value.');
    output = output.slice(0, contentStart + 1) + cmsHex.padEnd(contents.length, '0') + output.slice(contentEnd - 1);
    const result = fromBinary(output);
    const verification = await verifyPdf(result);
    const last = verification.signatures[verification.signatures.length - 1];
    if (!last || last.integrity !== 'valid' || !last.coversCurrentFile) throw new Error('The newly created signature failed its integrity check. No output was saved.');
    return result;
  }
  function decodePdfString(value) {
    if (!value) return '';
    try { return value.decodeText(); } catch (e) { return value.toString(); }
  }
  async function signatureRecords(input) {
    const { P } = deps();
    const doc = await loadPdf(input), context = doc.context;
    const name = s => P.PDFName.of(s), result = [];
    const form = doc.catalog.lookupMaybe(name('AcroForm'), P.PDFDict);
    const fields = form && form.lookupMaybe(name('Fields'), P.PDFArray);
    const seen = new Set();
    const visit = (item, inheritedType, path, depth) => {
      if (depth > 40) throw new Error('The form field tree exceeds the supported depth.');
      const field = context.lookup(item);
      if (!(field instanceof P.PDFDict) || seen.has(field)) return;
      seen.add(field);
      const type = field.get(name('FT')) || inheritedType;
      const fieldLabel = decodePdfString(field.get(name('T')));
      const fieldPath = path.concat(fieldLabel || []).join('.');
      const value = type && type.toString() === '/Sig' ? field.lookupMaybe(name('V'), P.PDFDict) : null;
      if (type && type.toString() === '/Sig' && value) {
        const rangeArray = value.lookupMaybe(name('ByteRange'), P.PDFArray);
        const contents = value.lookupMaybe(name('Contents'), P.PDFHexString, P.PDFString);
        const subfilter = value.get(name('SubFilter'));
        result.push({ field: fieldPath || 'Signature ' + (result.length + 1),
          name: decodePdfString(value.get(name('Name'))), reason: decodePdfString(value.get(name('Reason'))),
          location: decodePdfString(value.get(name('Location'))), pdfDate: decodePdfString(value.get(name('M'))),
          byteRange: rangeArray ? rangeArray.asArray().map(n => n.asNumber ? n.asNumber() : NaN) : [],
          contents: contents && binary(contents.asBytes()),
          subfilter: subfilter ? subfilter.toString().slice(1) : '',
        });
      }
      const kids = field.lookupMaybe(name('Kids'), P.PDFArray);
      if (kids) for (const kid of kids.asArray()) visit(kid, type, fieldPath ? [fieldPath] : [], depth + 1);
    };
    if (fields) for (const field of fields.asArray()) visit(field, null, [], 0);
    return result;
  }
  async function inspectSignatures(input) {
    const records = await signatureRecords(input);
    return records.map(({ contents, ...record }) => ({ ...record, signedRevisionLength: record.byteRange.length === 4 ? record.byteRange[2] + record.byteRange[3] : null }));
  }
  function oid(node, f) { return f.asn1.derToOid(node.value); }
  function assert(condition, message) { if (!condition) throw new Error(message); }
  function parseCms(contents, f) {
    assert(contents && contents.length >= 2, 'The signature has no CMS contents.');
    const asn1 = f.asn1.fromDer(f.util.createBuffer(contents), { strict: true, parseAllBytes: false });
    assert(oid(asn1.value[0], f) === f.pki.oids.signedData, 'The signature is not CMS SignedData.');
    const signed = asn1.value[1].value[0];
    const encapsulated = signed.value[2];
    assert(oid(encapsulated.value[0], f) === f.pki.oids.data, 'The CMS content type is unsupported.');
    assert(encapsulated.value.length === 1, 'The CMS signature is not detached.');
    let certContainer, signerContainer;
    for (let i = 3; i < signed.value.length; i++) {
      const n = signed.value[i];
      if (n.tagClass === f.asn1.Class.CONTEXT_SPECIFIC && n.type === 0) certContainer = n;
      if (n.tagClass === f.asn1.Class.UNIVERSAL && n.type === f.asn1.Type.SET) signerContainer = n;
    }
    assert(certContainer && signerContainer && signerContainer.value.length, 'The CMS signature has no embedded certificates or signer.');
    const certificates = certContainer.value.map(n => {
      try { return { node: n, cert: f.pki.certificateFromAsn1(n) }; } catch (e) { return null; }
    }).filter(Boolean);
    return { certificates, signers: signerContainer.value };
  }
  function hashFactory(digestOid, f) {
    const mapping = { '1.3.14.3.2.26': 'sha1', '2.16.840.1.101.3.4.2.1': 'sha256',
      '2.16.840.1.101.3.4.2.2': 'sha384', '2.16.840.1.101.3.4.2.3': 'sha512' };
    const algorithm = mapping[digestOid];
    assert(algorithm && f.md[algorithm], 'This signature digest algorithm is unsupported.');
    return { algorithm, create: () => f.md[algorithm].create() };
  }
  function verifyCms(contents, signedBytes, f) {
    const parsed = parseCms(contents, f), signers = [];
    for (const node of parsed.signers) {
      const values = node.value;
      const sid = values[1];
      assert(sid.tagClass === f.asn1.Class.UNIVERSAL && sid.type === f.asn1.Type.SEQUENCE, 'Subject-key-identifier signers are unsupported.');
      const serial = f.util.bytesToHex(sid.value[1].value).replace(/^00/, '').toLowerCase();
      const issuer = f.asn1.toDer(sid.value[0]).getBytes();
      const match = parsed.certificates.find(({ cert, node: certificateNode }) => {
        const tbs = certificateNode.value[0].value;
        const hasVersion = tbs[0].tagClass === f.asn1.Class.CONTEXT_SPECIFIC;
        const issuerNode = tbs[hasVersion ? 3 : 2];
        return cert.serialNumber.replace(/^00/, '').toLowerCase() === serial && f.asn1.toDer(issuerNode).getBytes() === issuer;
      });
      assert(match, 'The CMS signer certificate was not found.');
      const cert = match.cert;
      assert(cert.publicKey && cert.publicKey.n, 'Only RSA certificate signatures can be verified.');
      const digestOid = oid(values[2].value[0], f), hash = hashFactory(digestOid, f);
      let i = 3, attrs;
      if (values[i].tagClass === f.asn1.Class.CONTEXT_SPECIFIC && values[i].type === 0) attrs = values[i++];
      const signatureAlgorithm = oid(values[i++].value[0], f), signature = values[i].value;
      const allowedRsa = { '1.2.840.113549.1.1.1': null, '1.2.840.113549.1.1.5': '1.3.14.3.2.26',
        '1.2.840.113549.1.1.11': '2.16.840.1.101.3.4.2.1', '1.2.840.113549.1.1.12': '2.16.840.1.101.3.4.2.2',
        '1.2.840.113549.1.1.13': '2.16.840.1.101.3.4.2.3' };
      assert(Object.prototype.hasOwnProperty.call(allowedRsa, signatureAlgorithm), 'Only RSA PKCS#1 v1.5 signatures are supported; RSA-PSS and EC signatures are unavailable.');
      assert(!allowedRsa[signatureAlgorithm] || allowedRsa[signatureAlgorithm] === digestOid, 'The CMS signature and digest algorithms disagree.');
      let signatureInput = signedBytes, claimedSigningTime = null;
      const documentDigest = hash.create().update(signedBytes).digest().getBytes();
      if (attrs) {
        let expectedDigest, contentType, digestCount = 0, typeCount = 0;
        for (const attribute of attrs.value) {
          const type = oid(attribute.value[0], f), set = attribute.value[1];
          if (type === f.pki.oids.messageDigest) { expectedDigest = set.value[0].value; digestCount++; }
          if (type === f.pki.oids.contentType) { contentType = oid(set.value[0], f); typeCount++; }
          if (type === f.pki.oids.signingTime) {
            try { claimedSigningTime = (set.value[0].type === f.asn1.Type.UTCTIME ? f.asn1.utcTimeToDate(set.value[0].value) : f.asn1.generalizedTimeToDate(set.value[0].value)).toISOString(); } catch (e) { /* Report absent. */ }
          }
        }
        assert(digestCount === 1 && typeCount === 1 && contentType === f.pki.oids.data, 'Required CMS signed attributes are missing or ambiguous.');
        assert(sameBytes(expectedDigest || '', documentDigest), 'Signed document bytes have changed: the CMS message digest does not match.');
        signatureInput = f.asn1.toDer(f.asn1.create(f.asn1.Class.UNIVERSAL, f.asn1.Type.SET, true, attrs.value)).getBytes();
      }
      const signatureDigest = hash.create().update(signatureInput).digest().getBytes();
      assert(cert.publicKey.verify(signatureDigest, signature), 'The RSA signature does not match the signed bytes.');
      signers.push({ certificate: certificateInfo(cert), digestAlgorithm: hash.algorithm, signatureAlgorithm: 'RSA PKCS#1 v1.5',
        weakDigest: hash.algorithm === 'sha1', claimedSigningTime, signingTimeTrusted: false });
    }
    return signers;
  }
  async function verifyPdf(input) {
    const { f } = deps(), data = bytes(input), raw = binary(data);
    const records = await signatureRecords(input), reports = [];
    for (const record of records) {
      const { contents, ...metadata } = record;
      const report = { ...metadata, integrity: 'unverified', coversCurrentFile: false, laterBytes: null,
        trust: 'not-established', trustNotice: TRUST_NOTICE, signers: [] };
      try {
        assert(SUPPORTED_SUBFILTERS.includes(record.subfilter), 'This PDF signature format is unsupported.');
        const r = record.byteRange;
        assert(r.length === 4 && r.every(Number.isSafeInteger), 'The signature ByteRange must contain exactly four integers.');
        assert(r[0] === 0 && r[1] > 0 && r[2] > r[1] && r[3] >= 0 && r[2] + r[3] <= data.length, 'The signature ByteRange is invalid.');
        const gap = raw.slice(r[1], r[2]);
        assert(/^<[0-9a-fA-F\s]+>$/.test(gap), 'The ByteRange excludes more than one hexadecimal signature container.');
        let gapHex = gap.slice(1, -1).replace(/\s/g, '');
        if (gapHex.length % 2) gapHex += '0';
        assert(sameBytes(f.util.hexToBytes(gapHex), contents), 'The ByteRange contents do not match the PDF signature field.');
        const signedBytes = raw.slice(0, r[1]) + raw.slice(r[2], r[2] + r[3]);
        report.signers = verifyCms(contents, signedBytes, f);
        report.integrity = 'valid';
        report.signedRevisionLength = r[2] + r[3];
        report.laterBytes = data.length - report.signedRevisionLength;
        report.coversCurrentFile = report.laterBytes === 0;
        report.message = report.coversCurrentFile ? 'Cryptographic signature valid; signed bytes cover this file. Identity and certificate trust are unverified.' :
          'Cryptographic signature valid for an earlier revision. This file contains later bytes that this signature does not cover.';
      } catch (error) {
        report.integrity = /unsupported|unavailable|Only RSA|Subject-key/.test(error.message) ? 'unsupported' : 'invalid';
        report.message = error.message;
      }
      reports.push(report);
    }
    return { signatures: reports, signatureCount: reports.length,
      allCryptographicallyValid: reports.length > 0 && reports.every(r => r.integrity === 'valid'),
      currentFileCovered: reports.some(r => r.integrity === 'valid' && r.coversCurrentFile), trustNotice: TRUST_NOTICE };
  }
  root.PdfProSigning = Object.freeze({ importP12, signPdf, inspectSignatures, verifyPdf, certificateInfo, TRUST_NOTICE,
    capabilities: Object.freeze({ signing: 'RSA PKCS#1 v1.5 / SHA-256 / PKCS#12', incremental: true,
      verification: 'Detached CMS RSA PKCS#1 v1.5 with SHA-1, SHA-256, SHA-384, SHA-512',
      certificateTrust: false, revocation: false, trustedTimestamp: false, encryptedPDFs: false, certificationPolicies: false }) });
  root.PDFCreatorSigning=root.PdfProSigning;
})(typeof window !== 'undefined' ? window : globalThis);
