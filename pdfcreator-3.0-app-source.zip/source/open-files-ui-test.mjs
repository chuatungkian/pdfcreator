/* Exercise the actual file-picker button with synthetic PDFs and native edits. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import {boot} from './experience-test-env.mjs';
let options={};
if(process.argv.includes('--compiled')){
 const html=fs.readFileSync(path.join(process.env.PDFCREATOR_RELEASE_DIR||'../../outputs','index.html'),'utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64'))),file=path.resolve('../../tmp/open-files-compiled.mjs');
 fs.writeFileSync(file,assets.app);options={moduleURL:pathToFileURL(file).href,assets};
}
let context,n=0;
const check=(v,l)=>{n++;assert.ok(v,l)},equal=(a,b,l)=>{n++;assert.deepEqual(a,b,l)},until=async(test,label)=>{const end=Date.now()+10000;while(!test()){if(Date.now()>end)throw Error('Timed out: '+label);await new Promise(r=>setTimeout(r,10))}};
try{
 context=await boot(options);const {app,$,window,fileSelections}=context;
 const imports=[],onchange=$('fileinput').onchange;$('fileinput').onchange=event=>{const task=onchange(event);imports.push(task);return task};
 async function fixture(name,pages=2){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<pages;i++)doc.addPage([300,400]).drawText(name+' '+(i+1),{x:25,y:350});const bytes=new Uint8Array(await doc.save({useObjectStreams:false}));return{name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer}}
 const first=await fixture('First.pdf'),second=await fixture('Second.pdf'),third=await fixture('Third.pdf',1);
 fileSelections.push([first]);await $('homeOpenFiles').onclick();await imports.at(-1);
 check(fileSelections.length===0,'Home Open files launches the actual file picker');
 await until(()=>app.tabs.length===1&&app.state.name==='First.pdf'&&$('busy').classList.contains('hidden'),'first file opens');await app.local.flush();
 const firstId=app.activeTabId;
 await app.editPDF('First edit',doc=>doc.getPage(0).drawText('Retained edit',{x:25,y:310}));
 app.state.page=1;app.state.fit=false;app.state.zoom=.8;app.state.marks=[{page:1,rect:[10,10,30,30]}];
 await app.activate('ink');const edited=app.state.bytes,undo=app.state.undo.length;
 await $('homeBtn').onclick();fileSelections.push([second,third]);await $('homeOpenFiles').onclick();await imports.at(-1);
 check(fileSelections.length===0,'Open files works with an edited PDF and a selected tool: '+$('toast').textContent);
 await until(()=>app.tabs.length===3&&app.state.name==='Third.pdf','additional files open in tabs');await app.local.flush();
 equal(app.tabs.length,3,'new files each receive a separate tab');
 const retained=app.tabs.find(t=>t.id===firstId).snapshot;
 equal(retained.bytes,edited,'previous PDF retains its edited bytes');equal(retained.undo.length,undo,'previous PDF retains Undo history');check(retained.dirty,'previous PDF retains PDF download-needed state');equal(retained.marks,[{page:1,rect:[10,10,30,30]}],'previous PDF retains pending redactions');equal(retained.page,1,'previous PDF retains its page');equal(retained.tool,'ink','previous PDF retains its selected tool');
 const thirdId=app.activeTabId;await app.editPDF('Third edit',doc=>doc.getPage(0).drawText('Third only',{x:25,y:280}));const thirdEdited=app.state.bytes;
 await app.switchTab(firstId);equal(app.state.bytes,edited,'switching back restores the first PDF exactly');equal(app.state.page,1,'switching back restores the first page position');await app.switchTab(thirdId);equal(app.state.bytes,thirdEdited,'new PDF is independently editable');
 // A genuinely running write still owns the active native document.
 let release;const working=app.editPDF('Deferred edit',async doc=>{await new Promise(resolve=>release=resolve);doc.getPage(0).drawText('Completed',{x:25,y:250})});await until(()=>!!release,'write starts');
 let chooserCalls=0;const originalClick=$('fileinput').click;$('fileinput').click=()=>chooserCalls++;
 await $('homeOpenFiles').onclick();equal(chooserCalls,0,'real in-flight write cannot be interrupted by document replacement');release();await working;$('fileinput').click=originalClick;
 // Cancellation leaves the current tab untouched and permits another attempt.
 const before=app.state.bytes,count=app.tabs.length;fileSelections.push([]);await $('homeOpenFiles').onclick();await imports.at(-1);await new Promise(r=>setTimeout(r,20));equal(app.tabs.length,count,'cancelled picker adds no tab');equal(app.state.bytes,before,'cancelled picker preserves current work');
 fileSelections.push([await fixture('Fourth.pdf',1)]);await $('homeOpenFiles').onclick();await imports.at(-1);await until(()=>app.tabs.length===4,'opening after cancellation');check(app.state.name==='Fourth.pdf','subsequent opening succeeds');
 const beforeCreate=app.tabs.length;fileSelections.push([await fixture('From Create.pdf',1)]);await app.activate('createPDF');equal(app.tabs.length,beforeCreate+1,'Create → Open PDF also adds an independent tab');equal(app.state.name,'From Create.pdf','Create selects its newly opened PDF');
 console.log('Open files UI: '+n+' assertions passed for real picker entry, edited-tab preservation, independent editing, multiple files, cancellation, Create and in-flight write protection.');
}finally{if(context)await context.close()}
