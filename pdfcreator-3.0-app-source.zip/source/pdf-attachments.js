/* Local embedded files and native PDF FileAttachment annotations. All coordinates use MuPDF page space. */
const hidden=1|2|32;
const filename=value=>String(value||'attachment').split(/[\\/]/).at(-1).replace(/[\x00-\x1f\x7f]/g,'_')||'attachment';
function details(doc,ref,fallback){const info=doc.getFilespecParams(ref);return {name:filename(info.filename||fallback),mime:info.mimetype||'application/octet-stream'}}
export function pageAttachments(doc,index){
 const page=doc.loadPage(index);let annotations=[];
 try{annotations=page.getAnnotations();return annotations.flatMap((annotation,i)=>{if(annotation.getType()!=='FileAttachment'||annotation.getFlags()&hidden)return [];let ref,object;try{ref=annotation.getFileSpec();if(!doc.isEmbeddedFile(ref))return [];object=annotation.getObject();return [{...details(doc,ref,'attachment'),page:index,index:i,flags:annotation.getFlags(),id:object.isIndirect()?object.asIndirect():null,rect:[...annotation.getBounds()]}]}finally{ref?.destroy();object?.destroy()}})}finally{annotations.forEach(a=>a.destroy());page.destroy()}
}
export function documentAttachments(doc){
 const files=doc.getEmbeddedFiles(),result=[];try{for(const [key,ref]of Object.entries(files)){if(doc.isEmbeddedFile(ref))result.push({...details(doc,ref,key),key,locations:[]})}for(let p=0;p<doc.countPages();p++)for(const icon of pageAttachments(doc,p)){const data=readSpec(doc,icon,ref=>({id:ref.isIndirect()?ref.asIndirect():null}));const matching=Object.entries(files).find(([,ref])=>data.id!==null&&ref.isIndirect()&&ref.asIndirect()===data.id);const entry=matching?result.find(f=>f.key===matching[0]):null;if(entry)entry.locations.push(icon);else result.push({...icon,locations:[icon]})}return result}finally{Object.values(files).forEach(f=>f.destroy())}
}
function readSpec(doc,target,fn){
 if(target.key!==undefined){const files=doc.getEmbeddedFiles();try{const ref=files[target.key];if(!ref||!doc.isEmbeddedFile(ref))throw Error('This attachment is no longer in the PDF.');return fn(ref)}finally{Object.values(files).forEach(f=>f.destroy())}}
 const page=doc.loadPage(target.page);let annotations=[],ref,object;
 try{annotations=page.getAnnotations();const a=annotations[target.index];if(!a||a.getType()!=='FileAttachment')throw Error('The attachment changed. Select its icon again.');object=a.getObject();if(target.id!==null&&(!object.isIndirect()||object.asIndirect()!==target.id))throw Error('The attachment changed. Select its icon again.');ref=a.getFileSpec();if(!doc.isEmbeddedFile(ref))throw Error('The attachment has no embedded file.');return fn(ref)}finally{ref?.destroy();object?.destroy();annotations.forEach(a=>a.destroy());page.destroy()}
}
export function attachmentData(doc,target){return readSpec(doc,target,ref=>{const buffer=doc.getEmbeddedFileContents(ref);if(!buffer)throw Error('This attachment could not be read.');try{return {...details(doc,ref,target.name),bytes:buffer.asUint8Array().slice()}}finally{buffer.destroy()}})}
export function attachmentMoveRect(rect,bounds,dx,dy){
 if(![...rect,...bounds,dx,dy].every(Number.isFinite)||rect.length!==4||bounds.length!==4)throw Error('Choose a valid attachment location.');
 const x=Math.max(bounds[0],Math.min(bounds[2]-(rect[2]-rect[0]),rect[0]+dx)),y=Math.max(bounds[1],Math.min(bounds[3]-(rect[3]-rect[1]),rect[1]+dy));return rect.map((v,i)=>v+(i%2?y-rect[1]:x-rect[0]));
}
export function moveAttachment(doc,target,rect){
 const page=doc.loadPage(target.page);let annotations=[],object;
 try{annotations=page.getAnnotations();const annotation=annotations[target.index];if(!annotation||annotation.getType()!=='FileAttachment')throw Error('The attachment changed. Select its icon again.');object=annotation.getObject();if(target.id!==null&&(!object.isIndirect()||object.asIndirect()!==target.id))throw Error('The attachment changed. Select its icon again.');if(annotation.getFlags()&(64|128))throw Error('Unlock this attachment before moving it.');const old=annotation.getBounds();if(old.some((v,i)=>Math.abs(v-target.rect[i])>.1))throw Error('The attachment moved. Select its icon again.');if(!Array.isArray(rect)||rect.length!==4||!rect.every(Number.isFinite)||Math.abs(rect[2]-rect[0]-(old[2]-old[0]))>.1||Math.abs(rect[3]-rect[1]-(old[3]-old[1]))>.1)throw Error('Moving an attachment must preserve its icon size.');const next=attachmentMoveRect(old,page.getBounds(),rect[0]-old[0],rect[1]-old[1]),source=annotation.getRect(),dx=next[0]-old[0],dy=next[1]-old[1];annotation.setRect(source.map((v,i)=>v+(i%2?dy:dx)));annotation.update();return [...annotation.getBounds()];
 }finally{object?.destroy();annotations.forEach(a=>a.destroy());page.destroy()}
}
export function placeAttachment(doc,index,point,payload){
 if(!Number.isInteger(index)||index<0||index>=doc.countPages()||!Array.isArray(point)||point.length!==2||!point.every(Number.isFinite))throw Error('Choose a location on a PDF page.');
 const page=doc.loadPage(index);let ref,annotation;try{
 const b=page.getBounds(),size=Math.min(24,b[2]-b[0],b[3]-b[1]);if(size<=0)throw Error('This page has no space for an attachment icon.');
 const x=Math.max(b[0],Math.min(b[2]-size,point[0])),y=Math.max(b[1],Math.min(b[3]-size,point[1]));let name;
 if(payload.existing){ref=readSpec(doc,payload.existing,value=>value.isIndirect()?doc.newIndirect(value.asIndirect()):value.resolve());name=details(doc,ref,payload.existing.name).name}
 else{if(!(payload.bytes instanceof Uint8Array))throw Error('Choose a file to attach.');const files=doc.getEmbeddedFiles();try{const used=new Set(Object.keys(files));for(const f of Object.values(files))used.add(details(doc,f,'').name);const base=filename(payload.name),dot=base.lastIndexOf('.'),stem=dot>0?base.slice(0,dot):base,ext=dot>0?base.slice(dot):'';name=base;for(let n=2;used.has(name);n++)name=stem+' ('+n+')'+ext;const now=new Date();ref=doc.addEmbeddedFile(name,payload.mime||'application/octet-stream',payload.bytes,now,now,true);doc.insertEmbeddedFile(name,ref)}finally{Object.values(files).forEach(f=>f.destroy())}}
 annotation=page.createAnnotation('FileAttachment');annotation.setFileSpec(ref);annotation.setIcon('Paperclip');annotation.setColor([.5,0,.125]);annotation.setAuthor('PDFCreator');annotation.setContents(name);annotation.setRect([x,y,x+size,y+size]);annotation.setFlags(4);annotation.update();return {name,page:index,rect:[...annotation.getBounds()]};
 }finally{annotation?.destroy();ref?.destroy();page.destroy()}
}
export function attachmentImageMime(bytes){
 if(!bytes)return null;const header=String.fromCharCode(...bytes.slice(0,12));
 if(bytes.length>=8&&[137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n))return 'image/png';
 if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
 if(header.startsWith('GIF87a')||header.startsWith('GIF89a'))return 'image/gif';
 if(header.startsWith('RIFF')&&header.slice(8)==='WEBP')return 'image/webp';
 if(header.startsWith('BM'))return 'image/bmp';return null;
}
export function attachmentPreviewKind({name,mime,bytes}){
 const lower=name.toLowerCase();if(bytes?.length>=5&&String.fromCharCode(...bytes.slice(0,5))==='%PDF-')return 'pdf';
 // Never execute HTML, SVG, scripts or attachment-supplied PDF actions.
 if(attachmentImageMime(bytes))return 'image';
 if(/^text\//i.test(mime)||/\.(txt|csv|tsv|json|xml|html?|svg|js|css|md|log)$/i.test(lower))return 'text';return 'download';
}
