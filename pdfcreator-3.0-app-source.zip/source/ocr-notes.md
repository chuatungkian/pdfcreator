# Offline OCR integration

`ocr.js` is an ES module. Configure it once before exposing the OCR action:

```js
configureOCR({
  workerSource,          // tesseract.js/dist/worker.min.js
  coreSource,            // tesseract.js-core/tesseract-core-lstm.js
  coreWasmBase64,        // matching tesseract-core-lstm.wasm as base64
  languageDataBase64,    // eng.traineddata or eng.traineddata.gz as base64
  language: 'eng',
});

const result = await recognizeImage(canvas, {
  onProgress: ({ status, progress }) => updateProgress(status, progress),
  signal: controller.signal,
  dpi: 200,
});
```

Use the portable non-SIMD core to support the broadest browser set. The `.wasm.js`
variant already contains wasm bytes and can instead be used alone as `coreSource`.
Do not embed its matching wasm again in that case.

The module creates a classic worker from a Blob. It supplies wasm bytes to the
Emscripten factory and direct language bytes to Tesseract's worker protocol.
Language cache storage is disabled. Worker `fetch`, `importScripts`, and XHR are
blocked, so an accidentally missing embedded dependency fails visibly instead
of falling back to a CDN.

Recognition accepts a canvas, ImageData, Blob, Uint8Array, or ArrayBuffer of a
supported encoded image. PDF pages must first be rendered; approximately 200–300
DPI is suitable for document OCR. Page-segmentation mode defaults to automatic
layout. Cancellation terminates the worker and a subsequent request starts a
fresh one. Concurrent recognition calls receive a busy error.

Results include text, mean confidence, word and line bounds, and uncertain words
below the selected threshold. Bounds use image pixel coordinates measured from
the top-left. Each bound also has a normalized representation. Map these to PDF
page points for a hidden searchable text layer. OCR can be wrong; provide a way
to inspect low-confidence words and export extracted text.

`compareCanvases` compares page images at the same rendering scale, aligned at
the top-left. It returns a canvas heatmap, changed percentage, changed bounding
rectangle, and a dimension-match flag. This is visual comparison, not proof that
the documents are semantically identical. `compareText` provides a bounded line
diff and signals `truncated` when its matrix limit is exceeded.

Validated with Tesseract.js 7.0.0, core 6.1.2, embedded English traineddata, and a
synthetic PDF rendered at 144 DPI: `PDFPRO OFFLINE TEST 123` was recognized exactly
with mean confidence 95. The test used the actual browser worker bundle in a VM
worker shim with network functions blocked. Final browser QA must also confirm
Blob worker startup from the delivered `file://` HTML and hosted HTTPS page.

Dependencies are Apache-2.0; include their notices and English model provenance
in the distributable license inventory.
